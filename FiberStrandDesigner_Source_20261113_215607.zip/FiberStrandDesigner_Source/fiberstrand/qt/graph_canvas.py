"""Typed interactive Construction Graph canvas; source graph remains authoritative."""
from copy import deepcopy
import math
from PySide6 import QtCore,QtGui,QtWidgets
from ..construction.core import OPS,normalize_graph

class Pin(QtWidgets.QGraphicsEllipseItem):
    def __init__(self,canvas,nid,port,kind,x,y,parent):
        super().__init__(-7,-7,14,14,parent);self.canvas=canvas;self.nid=nid;self.port=port;self.kind=kind;self.setPos(x,y);self.setBrush(QtGui.QColor('#15B7D0'));self.setToolTip(port+' · '+kind);self.setZValue(2)

class GraphNode(QtWidgets.QGraphicsRectItem):
    def __init__(self,canvas,record,position):
        ports=OPS[record['op']].ports;super().__init__(0,0,190,58+max(1,len(ports))*23)
        self.canvas=canvas;self.nid=record['id'];self.setPos(QtCore.QPointF(*position));self.setBrush(QtGui.QColor('#182938'));self.setPen(QtGui.QPen(QtGui.QColor('#2A4050')))
        self.setFlags(self.GraphicsItemFlag.ItemIsMovable|self.GraphicsItemFlag.ItemIsSelectable|self.GraphicsItemFlag.ItemSendsGeometryChanges)
        title=QtWidgets.QGraphicsSimpleTextItem(record['id']+'\n'+record['op'],self);title.setBrush(QtGui.QColor('#E4EDF3'));title.setPos(10,8)
        self.pins={};out=Pin(canvas,self.nid,'out',OPS[record['op']].output,190,43,self);self.pins['out']=out
        for i,(port,kind) in enumerate(ports.items()):
            self.pins[port]=Pin(canvas,self.nid,port,kind,0,62+i*23,self)
            text=QtWidgets.QGraphicsSimpleTextItem(port,self);text.setBrush(QtGui.QColor('#91A6B5'));text.setPos(10,53+i*23)
    def itemChange(self,change,value):
        if change==self.GraphicsItemChange.ItemPositionHasChanged and hasattr(self,'canvas'):self.canvas.update_edges()
        return super().itemChange(change,value)
    def mouseReleaseEvent(self,event):
        super().mouseReleaseEvent(event);self.canvas.save_positions()

class GraphEdge(QtWidgets.QGraphicsPathItem):
    """Selectable connection with a generous hit area for click/marquee picking."""
    def __init__(self,path,source,target,port):
        super().__init__(path);self.key=(source,target,port)
        self.setFlag(self.GraphicsItemFlag.ItemIsSelectable,True);self.setZValue(-1)
        pen=QtGui.QPen(QtGui.QColor('#147DAD'),2);pen.setCosmetic(True);self.setPen(pen)
        self.setToolTip(source+' → '+target+'.'+port+' · Delete to disconnect')
    def shape(self):
        stroke=QtGui.QPainterPathStroker();stroke.setWidth(12);return stroke.createStroke(self.path())
    def boundingRect(self):return self.path().controlPointRect().adjusted(-6,-6,6,6)
    def paint(self,painter,option,widget=None):
        painter.setPen(QtGui.QPen(QtGui.QColor('#C39A45') if self.isSelected() else QtGui.QColor('#147DAD'),3 if self.isSelected() else 2))
        painter.setBrush(QtCore.Qt.BrushStyle.NoBrush);painter.drawPath(self.path())

class NodePicker(QtWidgets.QFrame):
    def __init__(self,canvas,position,source=None):
        super().__init__(canvas,QtCore.Qt.WindowType.Popup);self.canvas=canvas;self.position=position;self.source=source
        self.project=canvas.editor.controller.project;self.tile=canvas.editor.current_tile
        self.setWindowTitle('Add Graph Node');self.setProperty('fsdPopup',True);self.resize(390,430)
        layout=QtWidgets.QVBoxLayout(self);self.search=QtWidgets.QLineEdit();self.search.setPlaceholderText('Search node name…');layout.addWidget(self.search)
        self.results=QtWidgets.QListWidget();layout.addWidget(self.results);self.search.textChanged.connect(self.filter);self.results.itemClicked.connect(self.choose)
        self.search.installEventFilter(self);self.results.installEventFilter(self);self.filter('')
    def filter(self,text):
        self.results.clear();query=text.casefold()
        for op,spec in OPS.items():
            ports=[port for port,kind in spec.ports.items() if kind==self.source[2]] if self.source else [None]
            for port in ports:
                label=spec.label+' ['+op+']'+(' → '+port if port else '')
                if query not in label.casefold():continue
                item=QtWidgets.QListWidgetItem(label);item.setData(QtCore.Qt.ItemDataRole.UserRole,(op,port));self.results.addItem(item)
        if self.results.count():self.results.setCurrentRow(0)
    def choose(self,item):
        if item is None:return
        op,port=item.data(QtCore.Qt.ItemDataRole.UserRole)
        if self.project is not self.canvas.editor.controller.project or self.tile is not self.canvas.editor.current_tile:self.close();return
        self.close();self.canvas._safe(lambda:self.canvas.add_node(op,self.position,self.source,port));self.canvas.setFocus()
    def eventFilter(self,receiver,event):
        if event.type()==QtCore.QEvent.Type.KeyPress:
            key=event.key()
            if key in (QtCore.Qt.Key.Key_Return,QtCore.Qt.Key.Key_Enter):self.choose(self.results.currentItem());return True
            if key==QtCore.Qt.Key.Key_Escape:self.close();self.canvas.setFocus();return True
            if receiver is self.search and key in (QtCore.Qt.Key.Key_Down,QtCore.Qt.Key.Key_Up):
                step=1 if key==QtCore.Qt.Key.Key_Down else -1;self.results.setCurrentRow(max(0,min(self.results.count()-1,self.results.currentRow()+step)));return True
        return super().eventFilter(receiver,event)
    def showEvent(self,event):super().showEvent(event);self.search.setFocus()

class GraphCanvas(QtWidgets.QGraphicsView):
    tileDropped=QtCore.Signal(str)
    def __init__(self,editor,parent=None):
        super().__init__(parent);self.editor=editor;self.setAcceptDrops(True);self.viewport().setAcceptDrops(True);self.nodes={};self.edges=[];self.pending=None;self.drag_point=None;self.last=None;self.picker=None
        self.setScene(QtWidgets.QGraphicsScene(self));self.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing);self.setBackgroundBrush(QtGui.QColor('#0A111B'));self.setDragMode(self.DragMode.RubberBandDrag);self.setRubberBandSelectionMode(QtCore.Qt.ItemSelectionMode.IntersectsItemShape)
        self.scene().selectionChanged.connect(self._selection);self.setMinimumSize(220,180);self.sync()
    def _tile_drop_id(self,event):
        from .tile_library import TILE_MIME
        if not event.mimeData().hasFormat(TILE_MIME):return None
        try:tile_id=bytes(event.mimeData().data(TILE_MIME)).decode('utf-8')
        except UnicodeError:return None
        return tile_id if self.editor.controller.project.find(tile_id) is not None else None
    def dragEnterEvent(self,event):
        if self._tile_drop_id(event) is not None:
            event.setDropAction(QtCore.Qt.DropAction.CopyAction);event.accept();return
        super().dragEnterEvent(event)
    def dragMoveEvent(self,event):
        if self._tile_drop_id(event) is not None:
            event.setDropAction(QtCore.Qt.DropAction.CopyAction);event.accept();return
        super().dragMoveEvent(event)
    def dropEvent(self,event):
        tile_id=self._tile_drop_id(event)
        if tile_id is not None:
            self.cancel_connection();event.setDropAction(QtCore.Qt.DropAction.CopyAction);event.accept();self.tileDropped.emit(tile_id);return
        super().dropEvent(event)

    def sync(self):
        selected_nodes={item.nid for item in self.scene().selectedItems() if isinstance(item,GraphNode)}
        selected_edges={item.key for item in self.scene().selectedItems() if isinstance(item,GraphEdge)}
        context=(id(self.editor.controller.project),self.editor.current_tile.id if self.editor.current_tile else None)
        if not getattr(self,'_synced',False) or getattr(self,'_tile_context',None)!=context:
            selected_nodes={self.editor.selected_node_id};selected_edges=set();self.cancel_connection()
        self._tile_context=context
        self.scene().blockSignals(True);self.scene().clear();self.nodes={};self.edges=[]
        positions=self.editor.controller.project.metadata.get('graph_layouts',{}).get(self.editor.current_tile.id if self.editor.current_tile else '',self.editor.graph.get('ui',{}).get('positions',{}))
        for i,record in enumerate(self.editor.graph.get('nodes',[])):
            item=GraphNode(self,record,positions.get(record['id'],[40+(i%4)*260,40+(i//4)*190]));self.scene().addItem(item);self.nodes[item.nid]=item
            item.setSelected(item.nid in selected_nodes)
        self.update_edges();self.scene().setSceneRect(self.scene().itemsBoundingRect().adjusted(-200,-200,200,200));self.scene().blockSignals(False);self._synced=True
        for edge in self.edges:edge.setSelected(edge.key in selected_edges)
    def update_edges(self):
        selected={edge.key for edge in self.edges if edge.isSelected()};blocker=QtCore.QSignalBlocker(self.scene())
        for edge in self.edges:self.scene().removeItem(edge)
        self.edges=[]
        for record in self.editor.graph.get('nodes',[]):
            dst=self.nodes.get(record['id'])
            if dst is None:continue
            for port,source in record.get('inputs',{}).items():
                src=self.nodes.get(source)
                if src is None or port not in dst.pins:continue
                a=src.pins['out'].scenePos();b=dst.pins[port].scenePos();path=QtGui.QPainterPath(a);path.cubicTo(a+QtCore.QPointF(100,0),b-QtCore.QPointF(100,0),b)
                edge=GraphEdge(path,source,record['id'],port);self.scene().addItem(edge);edge.setSelected(edge.key in selected);self.edges.append(edge)
    def delete_selection(self):
        nodes={item.nid for item in self.scene().selectedItems() if isinstance(item,GraphNode)}
        wires={item.key for item in self.scene().selectedItems() if isinstance(item,GraphEdge)}
        if not nodes and not wires:return
        trial=deepcopy(self.editor.graph);trial['nodes']=[record for record in trial.get('nodes',[]) if record['id'] not in nodes]
        for record in trial['nodes']:
            record['inputs']={port:source for port,source in record.get('inputs',{}).items() if source not in nodes and (source,record['id'],port) not in wires}
        if trial.get('output') in nodes:
            trial['output']=next((record['id'] for record in reversed(trial['nodes']) if OPS[record['op']].output=='curves'),None)
        self.editor._checkpoint_graph();self.editor.graph=trial;self.scene().clearSelection()
        self.editor.selected_node_id=next((record['id'] for record in trial['nodes']),None)
        self.editor._refresh_nodes_list();self.editor._request_preview();self.sync()
        if not trial['nodes']:self.editor._on_node_selected(-1)

    def _safe(self,callback):
        try:return callback()
        except (ValueError,KeyError) as error:self.editor.controller.jobFailed.emit('Graph',str(error))
    def show_picker(self,position=None,source=None,global_position=None):
        if self.picker is not None:self.picker.close();self.picker.deleteLater()
        if position is None:position=self.mapToScene(self.viewport().rect().center())
        self.picker=NodePicker(self,QtCore.QPointF(position),source)
        point=global_position if global_position is not None else self.viewport().mapToGlobal(self.mapFromScene(position))
        from .popups import point_popup_geometry
        point_popup_geometry(self.picker,point,QtCore.QSize(390,430))
        self.picker.show()
    def add_node(self,op,position,source=None,port=None):
        if len(self.editor.graph.get('nodes',[]))>=160:raise ValueError('Graph supports at most 160 nodes')
        spec=OPS[op];trial=deepcopy(self.editor.graph);ids={record['id'] for record in trial.get('nodes',[])};index=1
        while op+'_'+str(index) in ids:index+=1
        nid=op+'_'+str(index);record={'id':nid,'op':op,'params':deepcopy(spec.defaults),'inputs':{}}
        if op=='fiber_source' and self.editor.current_tile:
            tile=deepcopy(self.editor.current_tile);tile.construction_graph=None;record['params']['tile']=tile.to_dict()
        if source:
            upstream=next((r for r in trial['nodes'] if r['id']==source[0]),None)
            if upstream is None or port not in spec.ports or spec.ports[port]!=OPS[upstream['op']].output:raise ValueError('Source/port no longer compatible')
            record['inputs'][port]=source[0]
        trial.setdefault('nodes',[]).append(record)
        if spec.output=='curves' and (not trial.get('output') or source and trial.get('output')==source[0]):trial['output']=nid
        self.editor._checkpoint_graph();self.editor.graph=trial;self.editor.selected_node_id=nid
        tile=self.editor.current_tile
        if tile is not None:
            project=self.editor.controller.project;layouts=deepcopy(project.metadata.get('graph_layouts',{}));layouts.setdefault(tile.id,{})[nid]=[position.x(),position.y()];project.metadata={**project.metadata,'graph_layouts':layouts};self.editor.controller.mark_dirty(True)
        self.editor._refresh_nodes_list();self.editor._request_preview();self.sync();self.scene().clearSelection();self.nodes[nid].setSelected(True)
        return nid
    def _pin_at(self,position):
        # Screen-space tolerance works at all canvas zoom levels and above labels.
        closest=None;distance=13.
        for node in self.nodes.values():
            for pin in node.pins.values():
                point=self.mapFromScene(pin.scenePos());delta=QtCore.QPointF(point)-position;size=math.hypot(delta.x(),delta.y())
                if size<distance:closest=pin;distance=size
        return closest
    def _node_at(self,position):
        item=self.itemAt(position.toPoint())
        while item is not None and not isinstance(item,GraphNode):item=item.parentItem()
        return item
    def cancel_connection(self):self.pending=None;self.drag_point=None;self.viewport().update()
    def drawForeground(self,painter,rect):
        super().drawForeground(painter,rect)
        if self.pending and self.drag_point is not None and self.pending[0] in self.nodes:
            a=self.nodes[self.pending[0]].pins['out'].scenePos();path=QtGui.QPainterPath(a);path.cubicTo(a+QtCore.QPointF(100,0),self.drag_point-QtCore.QPointF(100,0),self.drag_point)
            pen=QtGui.QPen(QtGui.QColor('#15B7D0'),2,QtCore.Qt.PenStyle.DashLine);pen.setCosmetic(True);painter.setPen(pen);painter.drawPath(path)

    def save_positions(self):
        tile=self.editor.current_tile
        if tile is None:return
        project=self.editor.controller.project;layouts={**project.metadata.get('graph_layouts',{}),tile.id:{nid:[item.pos().x(),item.pos().y()] for nid,item in self.nodes.items()}}
        project.metadata={**project.metadata,'graph_layouts':layouts};self.editor.controller.mark_dirty(True)
    def _selection(self):
        item=next((n for n in self.scene().selectedItems() if isinstance(n,GraphNode)),None)
        if item is not None:
            for i,node in enumerate(self.editor.graph['nodes']):
                if node['id']==item.nid:self.editor.node_list.setCurrentRow(i);break
    def connect_nodes(self,source,target,port):
        lookup={n['id']:n for n in self.editor.graph['nodes']}
        if source==target:raise ValueError('A node cannot connect to itself')
        if OPS[lookup[source]['op']].output!=OPS[lookup[target]['op']].ports[port]:raise ValueError('Port data types do not match')
        trial=deepcopy(self.editor.graph);next(n for n in trial['nodes'] if n['id']==target).setdefault('inputs',{})[port]=source
        nodes={n['id']:n for n in trial['nodes']};active=set();done=set()
        def visit(nid):
            if nid in active:raise ValueError('Connection would create a cycle')
            if nid in done:return
            active.add(nid)
            for dependency in nodes[nid].get('inputs',{}).values():visit(dependency)
            active.remove(nid);done.add(nid)
        for nid in nodes:visit(nid)
        self.editor._checkpoint_graph();self.editor.graph=trial;self.editor._refresh_nodes_list();self.editor._request_preview();self.sync()
    def mousePressEvent(self,event):
        if event.modifiers() & QtCore.Qt.KeyboardModifier.AltModifier:self.last=event.position();self.nav_button=event.button();event.accept();return
        item=self._pin_at(event.position())
        if event.button()==QtCore.Qt.MouseButton.LeftButton and item is not None and item.port=='out':
            self.setFocus();self.pending=(item.nid,item.port,item.kind);self.drag_point=self.mapToScene(event.position().toPoint());self.viewport().update();event.accept();return
        super().mousePressEvent(event)
    def mouseMoveEvent(self,event):
        if self.pending:
            self.drag_point=self.mapToScene(event.position().toPoint());self.viewport().update();event.accept();return
        if self.last is not None:
            dx=event.position().x()-self.last.x();dy=event.position().y()-self.last.y();self.last=event.position()
            if self.nav_button==QtCore.Qt.MouseButton.MiddleButton:self.horizontalScrollBar().setValue(self.horizontalScrollBar().value()-int(dx));self.verticalScrollBar().setValue(self.verticalScrollBar().value()-int(dy))
            elif self.nav_button==QtCore.Qt.MouseButton.RightButton:self.scale(math.exp(dx*.01),math.exp(dx*.01))
            elif self.nav_button==QtCore.Qt.MouseButton.LeftButton:self.rotate(-dx*.4)
            event.accept();return
        super().mouseMoveEvent(event)
    def mouseReleaseEvent(self,event):
        if self.last is not None:self.last=None;event.accept();return
        if self.pending:
            source=self.pending;end=self._pin_at(event.position());target=self._node_at(event.position());position=self.mapToScene(event.position().toPoint());self.cancel_connection()
            if end is not None:
                if end.port!='out':self._safe(lambda:self.connect_nodes(source[0],end.nid,end.port))
            elif target is not None:
                ports=[port for port,kind in OPS[next(r['op'] for r in self.editor.graph['nodes'] if r['id']==target.nid)].ports.items() if kind==source[2]]
                if len(ports)==1:self._safe(lambda:self.connect_nodes(source[0],target.nid,ports[0]))
                elif ports:
                    self._port_menu=QtWidgets.QMenu(self)
                    for port in ports:self._port_menu.addAction(port,lambda p=port,t=target.nid:self._safe(lambda:self.connect_nodes(source[0],t,p)))
                    self._port_menu.popup(event.globalPosition().toPoint())
                else:self.editor.controller.jobFailed.emit('Graph','Node has no compatible input')
            else:self.show_picker(position,source,event.globalPosition().toPoint())
            event.accept();return
        super().mouseReleaseEvent(event)
    def contextMenuEvent(self,event):
        if event.modifiers() & QtCore.Qt.KeyboardModifier.AltModifier:return
        item=self.itemAt(event.pos())
        if item is None:
            position=self.mapToScene(event.pos())
            self.show_picker(position,None,event.globalPos())
            event.accept()
            return
        super().contextMenuEvent(event)
    def wheelEvent(self,event):self.scale(1.2 if event.angleDelta().y()>0 else 1/1.2,1.2 if event.angleDelta().y()>0 else 1/1.2);event.accept()
    def event(self,event):
        if event.type()==QtCore.QEvent.Type.KeyPress and event.key()==QtCore.Qt.Key.Key_Tab:
            source=self.pending;position=self.drag_point;self.cancel_connection();self.show_picker(position,source);event.accept();return True
        if event.type()==QtCore.QEvent.Type.ShortcutOverride:
            if event.key() in (QtCore.Qt.Key.Key_Tab,QtCore.Qt.Key.Key_Delete,QtCore.Qt.Key.Key_Backspace) or (event.modifiers() & QtCore.Qt.KeyboardModifier.ControlModifier and event.key() in (QtCore.Qt.Key.Key_Z,QtCore.Qt.Key.Key_Y)):
                event.accept();return True
        return super().event(event)
    def keyPressEvent(self,event):
        if event.key()==QtCore.Qt.Key.Key_Escape:self.cancel_connection();event.accept();return
        if event.key()==QtCore.Qt.Key.Key_Tab:
            source=self.pending;position=self.drag_point;self.cancel_connection();self.show_picker(position,source);event.accept();return
        if event.key()==QtCore.Qt.Key.Key_F:self.fitInView(self.scene().itemsBoundingRect(),QtCore.Qt.AspectRatioMode.KeepAspectRatio);return
        if event.key() in (QtCore.Qt.Key.Key_Delete,QtCore.Qt.Key.Key_Backspace):self.delete_selection();event.accept();return
        if event.modifiers() & QtCore.Qt.KeyboardModifier.ControlModifier and event.key()==QtCore.Qt.Key.Key_Z:
            (self.editor._redo_graph if event.modifiers() & QtCore.Qt.KeyboardModifier.ShiftModifier else self.editor._undo_graph)();self.sync();return
        if event.modifiers() & QtCore.Qt.KeyboardModifier.ControlModifier and event.key()==QtCore.Qt.Key.Key_Y:self.editor._redo_graph();self.sync();return
        super().keyPressEvent(event)
