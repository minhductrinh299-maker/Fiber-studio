r"""Opt-in benchmark; never invoked automatically by application/startup.

Run from the project root: .venv\Scripts\python.exe tools\benchmark_fiber_v2.py
Outputs measurements from this machine only; no pre-filled performance claims.
Legacy and V2 are timed separately, not treated as visually identical algorithms.
"""
from pathlib import Path
import argparse
import csv
import json
import platform
import sys
import time
from copy import deepcopy

ROOT = Path(__file__).resolve().parents[1]/'source'
sys.path.insert(0, str(ROOT))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--counts', default='1000,10000')
    ap.add_argument('--size', type=int, default=512)
    ap.add_argument('--repeat', type=int, default=3)
    ap.add_argument('--legacy', action='store_true', help='Also time preserved V1 full bake')
    ap.add_argument('--out', default='benchmark_fiber_v2')
    ns = ap.parse_args()
    from fiberstrand.model import Tile, VERSION, MAP_NAMES, EXTRA_MAP_NAMES
    from fiberstrand.engine_v2.engine import FiberEngine
    from fiberstrand.raster import render_tile_legacy
    rows = []
    for count in map(int, ns.counts.split(',')):
        for repeat in range(ns.repeat):
            engine = FiberEngine()
            tile = Tile.create('V2 benchmark')
            tile.id = 'benchmark-fixed-tile'
            tile.seed = 42
            tile.width = tile.height = ns.size
            tile.settings.count = count
            for operation in ('cold', 'warm', 'color', 'roughness', 'specular', 'single_strand', 'width'):
                if operation == 'color':tile.settings.color_mid = '#cc6633'
                elif operation == 'roughness':tile.settings.roughness = .33
                elif operation == 'specular':tile.settings.specular = .72
                elif operation == 'single_strand':tile.overrides['0'] = {'offset_x': .02}
                elif operation == 'width':tile.settings.root_width += .3
                tile.revision += 1
                start = time.perf_counter()
                result = engine.render(deepcopy(tile), channels=MAP_NAMES+EXTRA_MAP_NAMES)
                wall_ms = (time.perf_counter()-start)*1000
                row = dict(backend='v2_cpu_reference', count=count, size=ns.size,
                    repeat=repeat, operation=operation, wall_ms=wall_ms,
                    stages=result.metadata['timings_ms'],
                    baked_channels=result.metadata['baked_channels'],
                    dirty_blocks={c:len(r) for c,r in result.metadata['dirty_regions'].items()},
                    caches=result.metadata['caches'])
                rows.append(row)
                print(f'V2 {count} {operation}: {wall_ms:.2f} ms', flush=True)
            if ns.legacy:
                start = time.perf_counter()
                render_tile_legacy(deepcopy(tile))
                rows.append(dict(backend='legacy_numpy',count=count,size=ns.size,repeat=repeat,
                                 operation='full_after_edits',wall_ms=(time.perf_counter()-start)*1000))
    dest = Path(ns.out)
    dest.mkdir(parents=True, exist_ok=True)
    payload = dict(app_version=VERSION, platform=platform.platform(), python=sys.version,
                   gpu='not measured by CPU harness', measurements=rows,
                   notes='Wall time includes snapshot. Legacy and V2 pigments/AO differ; not an image-equivalence test.')
    (dest/'measurements.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
    with (dest/'measurements.csv').open('w',newline='',encoding='utf-8') as handle:
        writer=csv.DictWriter(handle,fieldnames=['backend','count','size','repeat','operation','wall_ms'])
        writer.writeheader()
        for row in rows:writer.writerow({key:row[key] for key in writer.fieldnames})


if __name__ == '__main__':
    main()
