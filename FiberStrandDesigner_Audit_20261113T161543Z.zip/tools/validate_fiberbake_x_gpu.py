"""CPU/GPU differential tests. Requires actual GL4.3, no mocked GPU results."""
import sys,os,json,time
from pathlib import Path
from copy import deepcopy
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
os.environ['FSD_FIBERBAKE_BACKEND']='gpu'
import numpy as np
from fiberstrand.model import Tile
from fiberstrand.engine_v2.engine import FiberEngine
from fiberstrand.engine_v2.dependencies import ALL_CHANNELS
from fiberstrand.engine_v2.samples import build_bins
from fiberstrand.fiberbake_x.service import render_resident,device
import fiberstrand.engine_v2.bake as bake
bake.try_gpu_bake=lambda *args:None
channels=ALL_CHANNELS;rows=[];e=FiberEngine();reference=FiberEngine()
t=Tile.create('FiberBake X parity');t.width=t.height=128;t.settings.count=24;t.settings.pattern='speckle';t.settings.root_width=.7

def run(operation):
 t.revision+=1;truth,keys=e.truth(t);bins=build_bins(truth,(t.width,t.height),lambda:False)
 d,result=render_resident(t,truth,keys,bins,(t.width,t.height),channels)
 raw=d.call(lambda gpu:gpu.readback(result)).result();os.environ['FSD_FIBERBAKE_BACKEND']='cpu'
 cpu=reference.render(deepcopy(t),channels=channels)
 os.environ['FSD_FIBERBAKE_BACKEND']='gpu'
 maxima={}
 for c in channels:
  actual=raw[c] if c=='color' else raw[c][:,:,:3] if c in ('normal','flow','id','cluster_id','material_id','material_mask','rgb_mask') else raw[c][:,:,0]
  error=np.abs(actual.astype(int)-np.array(cpu.maps[c]).astype(int));maxima[c]=int(error.max())
  # CPU AO caches finite-radius proximity as float16; allow 2/255 quantization.
  assert maxima[c]<=2,(operation,c,maxima[c],float(error.mean()))
 row=dict(operation=operation,max_error=maxima,metrics=result.metrics);rows.append(row);print(operation,result.metrics['total_ms'],maxima,flush=True)
 return result
run('cold');warm=run('warm');assert warm.metrics['uploaded_bytes']==0 and warm.metrics['passes']==0
old_truth,old_keys=e.truth(t);t.settings.color_mid='#ff2211';color=run('color');assert color.metrics['dirty_channels']==['color']
new_truth,_=e.truth(t);assert np.array_equal(old_truth[0].points,new_truth[0].points)
t.settings.roughness=.17;rough=run('roughness');assert rough.metrics['dirty_channels']==['roughness']
t.settings.specular=.73;spec=run('specular');assert spec.metrics['dirty_channels']==['specular']
t.overrides['0']={'offset_x':.25};run('move_strand')
t.overrides['0']['attributes']={'roughness':[.05,.95],'opacity':[.2,.9],'specular':[.9,.1]};run('source_profiles')
# Quantitative partial-vs-full and repeatability, with independent GPU cache identity.
partial=run('repeat');full=deepcopy(t);full.id+='fresh'
# SIDs change with tile ID: compare the SAME truth under a different resource cache key.
truth,keys=e.truth(t);bins=build_bins(truth,(128,128),lambda:False)
d,r=render_resident(full,truth,keys,bins,(128,128),channels)
a=d.call(lambda gpu:gpu.readback(r)).result();d,b=render_resident(t,truth,keys,bins,(128,128),channels);b=d.call(lambda gpu:gpu.readback(b)).result()
assert all(np.array_equal(a[c],b[c]) for c in channels),'partial/full mismatch'
Path('work/fiberbake_x').mkdir(exist_ok=True)
Path('work/fiberbake_x/parity.json').write_text(json.dumps(dict(pass_=True,threshold_lsb=2,rows=rows,partial_full_exact=True),indent=2))
# CPU-bin / GPU-bin paths must consume the same canonical truth and resolve identically.
bin_fixture=deepcopy(t);bin_fixture.id+='-gpu-bin-fixture'
d,gpu_bins=render_resident(bin_fixture,truth,keys,None,(128,128),channels)
actual=d.call(lambda gpu:gpu.readback(gpu_bins)).result()
assert all(np.array_equal(actual[c],b[c]) for c in channels),'GPU bin builder diverged'
# This is a source-only extension after the user's stop-testing request.
print('PASS: parity, deterministic repeat, material isolation, partial/full, CPU/GPU bins.')
