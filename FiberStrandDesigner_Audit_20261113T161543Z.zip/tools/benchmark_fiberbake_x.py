"""Measured FiberBake X matrix; reports actual GL renderer, never DXGI assumptions."""
import os,sys,time,json,argparse
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from fiberstrand.model import Tile
from fiberstrand.engine_v2.engine import FiberEngine
from fiberstrand.engine_v2.samples import build_bins
from fiberstrand.fiberbake_x.service import render_resident
parser=argparse.ArgumentParser();parser.add_argument('--out',default='work/fiberbake_x/benchmark_gpu.json');parser.add_argument('--counts',nargs='*',type=int);args=parser.parse_args()
rows=[]
truth_worker=ThreadPoolExecutor(max_workers=1,thread_name_prefix='fiberbake-benchmark-source')
for count,size in [(100,512),(500,512),(1000,1024),(3000,1024),(6000,2048),(20000,2048),(20000,4096)]:
 if args.counts and count not in args.counts:continue
 tile=Tile.create(f'Bench {count} {size}');tile.width=tile.height=size;tile.settings.count=count;engine=FiberEngine()
 for edit in ('cold','warm','color','roughness','specular','single_strand'):
  if edit=='color':tile.settings.color_mid='#cc6633'
  if edit=='roughness':tile.settings.roughness=.17
  if edit=='specular':tile.settings.specular=.73
  if edit=='single_strand':tile.overrides['0']={'offset_x':.005}
  tile.revision+=1;start=time.perf_counter();truth,keys=truth_worker.submit(engine.truth,tile).result();truth_end=time.perf_counter();bins=None
  bins_end=time.perf_counter()
  service,result=render_resident(tile,truth,keys,bins,(size,size),('color','alpha','roughness','specular'))
  row=dict(count=count,size=size,edit=edit,wall_ms=(time.perf_counter()-start)*1000,truth_ms=(truth_end-start)*1000,bins_ms=(bins_end-truth_end)*1000,**result.metrics)
  rows.append(row);Path(args.out).parent.mkdir(parents=True,exist_ok=True);Path(args.out).write_text(json.dumps(dict(rows=rows,scope='GPU source evaluation via worker/canonical bridge, GPU bins and resident raster. Wall includes preparation; GPU timestamps require FSD_FIBERBAKE_PROFILE=1'),indent=2))
  print(f'{count} {size} {edit}: wall={row["wall_ms"]:.1f}ms gpu-stage={row["total_ms"]:.1f}ms upload={row["uploaded_bytes"]}B VRAM={row["gpu_bytes"]/1024**2:.1f}MiB',flush=True)

truth_worker.shutdown(wait=True)
