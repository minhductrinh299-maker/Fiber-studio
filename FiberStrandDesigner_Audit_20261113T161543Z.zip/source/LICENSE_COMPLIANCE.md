# LGPLv3 Compliance Statement & Relinking Instructions
# Fiber Strand Designer (FSD)

## 1. Compliance Statement

Fiber Strand Designer utilizes **PySide6** and **Qt 6** libraries licensed under the **GNU Lesser General Public License version 3 (LGPLv3)**.

In accordance with Section 4 of the LGPLv3:
1. **Notice**: The software conveys prominent notices acknowledging that Qt 6 and PySide6 are used, and that these libraries are protected by the LGPLv3.
2. **License Texts**: A complete copy of the GNU General Public License v3 (GPLv3) and the GNU Lesser General Public License v3 (LGPLv3) is included with the software distribution.
3. **Dynamic Linking & User Modification**: The Qt and PySide6 components are interfaced via dynamically linked shared libraries (`.dll` files on Windows). End users have the full legal right and technical capability to replace, re-link, or update the Qt and PySide6 libraries with modified or newer compatible versions.
4. **No Restrictions on Debugging**: FSD does not restrict reverse engineering or debugging of modifications made by the user to the LGPLv3-covered libraries for the sole purpose of debugging such modifications.

---

## 2. Instructions for Modifying or Upgrading Qt/PySide6

Users wishing to replace or update the Qt 6 / PySide6 shared libraries used by FSD may do so following these steps:

1. Locate the application's Python runtime directory (e.g. `.gpu_runtime/Lib/site-packages/PySide6` or the bundled application folder).
2. Obtain or compile a binary-compatible build of Qt 6 (ABI compatible with the target PySide6 release).
3. Replace the corresponding `.dll` files (such as `Qt6Core.dll`, `Qt6Gui.dll`, `Qt6Widgets.dll`, etc.) within the PySide6 package directory.
4. Launch the application normally via `run_windows.bat` or the private application executable.

Source code for the official PySide6 / Qt 6 release utilized can be obtained directly from the official Qt Git repositories at:
- https://code.qt.io/cgit/pyside/pyside-setup.git
- https://code.qt.io/cgit/qt/qtbase.git
