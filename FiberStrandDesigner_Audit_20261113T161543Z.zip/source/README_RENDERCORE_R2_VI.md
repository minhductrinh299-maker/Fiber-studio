# Fiber Strand Designer v1.5 — FiberLight R2 & Shift + Right Drag

**Mục đích:** nâng cấp lõi shader lông thực thi trên GPU trong bản v1.4 và đơn giản hóa thao tác xoay ánh sáng trong Render Studio. Bản này kế thừa Construction Graph V4, Fiber Studio, Card Editor và Hybrid OIT v1.4; không phải D3D12 renderer sản xuất.

## 1. Thao tác mới trong GPU Render Studio

| Thao tác | Kết quả |
|---|---|
| **Shift + giữ chuột phải, kéo ngang** | Xoay ánh sáng theo phương ngang (**Azimuth**) |
| **Shift + giữ chuột phải, kéo dọc** | Xoay ánh sáng theo chiều dọc (**Elevation**); kéo lên thì nguồn sáng cao hơn |
| Chuột trái kéo | Orbit camera, **không** xoay ánh sáng |
| Lăn chuột | Phóng to/thu nhỏ camera |
| `F` | Frame All camera |
| **Reset Light** | Trả nguồn sáng về Azimuth 40°, Elevation 54° |
| **Light Sweep** | Tự động xoay nguồn sáng; bắt đầu kéo tay sẽ dừng Sweep |
| `Esc` | Hủy kéo đèn hoặc Light Sweep đang hoạt động |

- Độ nhạy mặc định: **0,42° / pixel** cho cả hai trục.
- Azimuth quay vòng trong [-180°, 180°); Elevation giới hạn **[-85°, +85°]**.
- Dải hiển thị phía dưới viewport chỉ báo **góc hiện tại**; hai thanh trượt góc chiếu sáng đã được bỏ.
- Giữ Shift khi *bắt đầu* RMB drag để kích hoạt. Một lần kéo đã được nhận sẽ tiếp tục cho tới khi thả chuột phải.
- Các thao tác này chỉ cập nhật hướng đèn và render frame mới, **không sinh lại sợi/texture/mesh**.
- Thanh Lighting còn Key Intensity, Fill Intensity, Ambient Light, Softbox Size và Exposure — các thuộc tính vật liệu/chiếu sáng cần độc lập.

## 2. Nâng cấp RenderCore thật

### FiberLight R2 (GPU GLSL)

- Tái tạo hướng sợi từ Flow + normal sau khi chiếu tangent lên mặt phẳng của card (an toàn hơn với card biến dạng).
- Hai vệt phản xạ dọc sợi (**primary và secondary longitudinal lobes**) có roughness/độ lệch độc lập, thay cho hai hàm lũy thừa đơn giản v1.4.
- Phản xạ phụ thuộc hướng nhìn, Fresnel xấp xỉ và khả năng điều khiển Anisotropy.
- **Key/Fill/Ambient studio light rig**: key đổi góc bằng thao tác Shift+RMB, fill mềm tự bám rig từ phía đối diện; ambient bán cầu để giữ chi tiết vùng tối.
- `Softbox Size` điều chỉnh độ rộng các vệt phản xạ, không cần đổi texture.
- Backlight và Sheen dùng biểu thức chiếu sáng riêng; tránh nhân đôi Light Intensity như công thức shader thử nghiệm cũ.
- Artistic Iridescence được cộng trong thành phần phản xạ, thay vì làm đổi màu toàn bộ nền vật liệu. **Chưa phải mô phỏng quang phổ/thin-film vật lý**.
- Vẫn giữ scene-linear sRGB decode cho BaseColor, premultiplied linear compositing và debug views.

### Hybrid OIT tiết kiệm bộ nhớ hơn

- Nếu chọn Hybrid 2 Layers, renderer chỉ cấp phát **2 texture RGBA16F front-layer**, không cấp phát thừa 4 texture như v1.4.
- Nếu chọn Hybrid 4 Layers, cấp phát đúng 4 front-layer texture. Giữ 2 depth textures ping-pong.
- Đổi số lớp hoặc chuyển về Weighted Fast giải phóng tài nguyên front-layer cũ.
- Thêm chỉ số **peel memory MiB (ước tính)** ở HUD dưới viewport. Chỉ số chưa gồm padding/driver overhead/weighted targets.
- Vẫn dùng **multi-pass depth peeling + Weighted OIT tail**. Đây **không phải** Adaptive K-Buffer một lượt rasterize và không được gọi là giải pháp tối ưu cuối cùng.

Ví dụ ở viewport 1920×1080, giảm từ K=4 xuống K=2 tiết kiệm khoảng **31,6 MiB** chỉ tính hai texture RGBA16F không còn cần. Chi phí depth và các render target khác giữ nguyên.

## 3. Chạy bản Windows

1. Giải nén toàn bộ bản ZIP.
2. Chạy `run_windows.bat` (cần Python 3.11+, NumPy, Pillow; lần đầu cài thư viện cần Internet).
3. Mở **GPU Render Studio** từ cửa sổ chính.
4. Trong viewport giữ **Shift + RMB** kéo trái/phải/lên/xuống.
5. Thử đổi Key/Fill/Ambient/Softbox và quan sát Hair BRDF không cần rebuild atlas.
6. Thử `Weighted · Fast`, `Hybrid · 2 Layers` và `Hybrid · 4 Layers` để so sánh alpha nhiều lớp.
7. Chọn `Capture PNG` để lưu hình render.

`build_exe_windows.bat` là script đóng gói PyInstaller để chạy trên máy Windows; **chưa có EXE Windows đã biên dịch và được kiểm chứng** trong bản ZIP này.

## 4. Các tệp mới/đã sửa

- `fiberstrand/rendercore/lighting.py` — tính toán light drag và xử lý vòng/clamp góc độc lập khỏi UI.
- `fiberstrand/rendercore/studio.py` — bindings Shift+RMB, Reset Light, báo góc và thanh điều khiển gọn hơn.
- `fiberstrand/rendercore/renderer.py` — thông số key/fill/ambient/softbox; cập nhật uniform; cấp phát đúng K layers.
- `fiberstrand/rendercore/shaders/hair.frag` — FiberLight R2 shader GLSL.
- `tests/test_rendercore_r2_light.py` — kiểm thử thao tác, shader thật, không rebake atlas và GPU layer lifetime.
- `examples/render_studio_r2_light_drag.png` — ảnh UI kiểm thử trong Xvfb.
- `examples/r2_default_studio_light.png`, `r2_rotated_studio_light.png`, `r2_optical_light.png` — ảnh GPU mẫu thực thi EGL/Mesa.

## 5. Kiểm thử và giới hạn

- Linux/EGL/Mesa: `python -m pytest -q tests` → **52 passed, 4 subtests passed**.
- Mở Render Studio thực tế bằng Tk/Xvfb, thực hiện LightDrag trên một cửa sổ thật, lưu screenshot.
- Đã xác minh trên renderer OpenGL thực thi qua Mesa `llvmpipe`. **Đây là GPU API test, không phải hiệu năng GPU chuyên dụng**.
- **Chưa kiểm thử trên Windows + GTX 1650/RTX 3050 Ti**; cần thử chuột và Wacom WGL thực tế.
- D3D12 C++ HLSL trong `native_d3d12/` vẫn chỉ là probe nền tảng của v1.4, không phải viewport native.
- Không có shadow/self-shadow vật lý, môi trường HDRI/IBL thực, OCIO, Adaptive K-buffer, GPU memory residency 4 GB hay Render Match với Arnold/Unreal/Unity.
- Cập nhật tile vùng nhỏ vẫn tái tạo mipmap toàn atlas trong đường OpenGL prototype; cần tile-local mip baking ở bản sản xuất.

**Hướng tiếp theo:** Native RenderCore + Adaptive K-buffer, optical material, hair shadow, HDRI, GPU profiling & benchmark trên GPU rời 4 GB.
