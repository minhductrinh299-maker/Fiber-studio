# Fiber Strand Designer v1.6 — RenderCore R3: integrated experimental release

**Mục tiêu bản này:** Một lượt nâng cấp nhiều hạng mục trên mã nguồn v1.5, **không phải** bản renderer thương mại hoàn chỉnh. Giao diện hiện vẫn chạy OpenGL 3.3 trên Windows/Linux; D3D12 mới có hai compute probes.

## Những phần đã chạy được

1. **FiberShadow R3**: thêm shadow-density pass (GPU) từ góc nhìn đèn, lưu tổng extinction trong 4 khoảng depth ở render target RGBA16F. Shader hair lấy mẫu và suy ra transmittance để tạo bóng tự che khuất giữa các card. Đây là **4-bin light-space approximation**, không phải deep-opacity map chính xác. Có `Self Shadow` slider.
2. **Fiber Scattering**: thành phần tán xạ xấp xỉ biến thiên theo hướng sáng/camera và transmittance; `Fiber Scattering` slider. Không bake lại texture khi đổi.
3. **Tile-Local Coverage Mip**: tạo mip theo từng logical tile với padding, filter màu theo premultiplied alpha, hiệu chỉnh alpha-test coverage và normalize dữ liệu normal/flow. Do các tile vẫn chia sẻ atlas 2D, LOD bị giới hạn khi padding không còn đủ. Đây chưa phải hệ texture-array/virtual atlas hoàn chỉnh.
4. **Partial Tile Update**: cập nhật vùng mip liên quan của tile theo revision qua glTexSubImage2D; giữ các tile độc lập khác. Bản alpha/color có thể cần cùng cập nhật trong một lần sửa sợi.
5. **GPU Device Diagnostics trên Windows**: đọc danh sách DXGI adapters bằng ctypes, cảnh báo nếu OpenGL chạy GPU tích hợp trong khi có GPU rời 4GB+. Nút **GPU Settings** mở Windows Graphics Settings. Cảnh báo ≠ ép chuyển thiết bị WGL; việc chọn GPU chủ động thực sự nằm ở backend D3D12 sắp tới.
6. **GPU Timer Queries**: đo GPU duration theo frame (không còn chỉ dựa trên CPU wall time); bỏ mẫu đo không hợp lệ trên driver.
7. **Auto GPU Budget**: chọn Weighted Fast hoặc Hybrid 1/2/4 front layers theo GPU-time EMA, giữ quality profile thủ công để đối chiếu. Đây là **frame-level adaptive policy**, không phải per-pixel Adaptive K-buffer.
8. **D3D12 Compute Probes**: hai chương trình C++20/HLSL dùng DXGI chọn adapter high-performance, đọc ngân sách VRAM, thực thi sorted alpha và K=4/weighted tail resolve trên GPU Windows khi build; **chưa kiểm thử Windows trong lượt bàn giao**.

## Hướng dẫn chạy

1. Giải nén ZIP toàn bộ.
2. Chạy `run_windows.bat`, Python 3.11+; lần đầu cần Internet để cài NumPy và Pillow.
3. Trong Fiber Studio mở **GPU Render Studio**.
4. Trên toolbar chọn `Auto · GPU Budget` (mặc định), hoặc Hybrid 2/4 Layers để so sánh.
5. Chỉnh các slider `Self Shadow`, `Fiber Scattering`, `Iridescence`, `Roughness` để xem shader GPU phản ứng tức thì.
6. **Shift + RMB kéo ngang/dọc** để xoay đèn (giữ hành vi của v1.5); LMB orbit camera, con lăn zoom.
7. `GPU Settings` chỉ hiện trên Windows; khi có RTX nhưng OpenGL dùng Intel, ứng dụng hiển thị cảnh báo.
8. Thử D3D12 native probes qua `native_d3d12/build_and_test_windows.bat` trên Windows có MSVC/Windows SDK/CMake.

## Giới hạn kỹ thuật cần ghi nhận

- Shader mới được kiểm thử bằng API OpenGL với EGL/Mesa llvmpipe trên Linux, **không phải benchmark GPU NVIDIA**.
- Chưa có D3D12 viewport, Adaptive per-pixel K-buffer gather/resolve, deep opacity shadow hoàn chỉnh, HDRI/IBL/OCIO production, LOD ổn định cho toàn bộ hệ card, renderer match với Arnold/Unreal/Unity hay đóng gói EXE đã thử trên Windows.
- D3D12 source chưa được biên dịch/kiểm chứng bởi môi trường Linux; build bằng Windows SDK mới có kết quả hợp lệ.
- 4 GB là mức GPU dự kiến hỗ trợ, chưa phải cấu hình tối thiểu đã chứng minh qua benchmark.
- `gpu_ms` là GPU timer khi driver hỗ trợ; với llvmpipe là thông số Mesa software GPU API, không tương đương tốc độ RTX.

## Nghiệm thu tiếp theo trên máy thực

- Xác minh đúng OpenGL adapter sau khi chọn Windows High Performance.
- Chạy D3D12 probes trên RTX 3050 Ti và xác nhận PASS.
- Benchmark 1080p, 4K atlas, 6.000 card: FPS trung bình, P95/P99 frame time và VRAM.
- So sánh bật/tắt Shadow/Scattering, đo sai lệch ảnh vs Arnold và lỗi transparency khi card chồng sâu.
- Chỉ chốt D3D12 RenderCore production sau khi đã thực thi viewport, shadow, atlas upload và alpha nhiều lớp trên GPU đích.
