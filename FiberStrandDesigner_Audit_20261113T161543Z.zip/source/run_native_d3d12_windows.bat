@echo off
setlocal
cd /d "%~dp0"
set "VIEWPORT=native_d3d12\bin\fsd_d3d12_viewport.exe"
if not exist "%VIEWPORT%" set "VIEWPORT=native_d3d12\build\Release\fsd_d3d12_viewport.exe"
if not exist "%VIEWPORT%" (
  echo Build native_d3d12 with CMake first. See README_RENDERCORE_R4_VI.md.
  pause
  exit /b 1
)
"%VIEWPORT%" --scene native_d3d12\demo_scene\scene.fsdn %*
if errorlevel 1 pause
endlocal
