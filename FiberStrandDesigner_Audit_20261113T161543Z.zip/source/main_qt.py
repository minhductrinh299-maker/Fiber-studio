"""Fiber Strand Designer - Qt 6 / PySide6 Main Application Entry Point."""

from __future__ import annotations

import sys
import os
from pathlib import Path

# Ensure workspace root is in sys.path
WORKSPACE_ROOT = Path(__file__).resolve().parent
if str(WORKSPACE_ROOT) not in sys.path:
    sys.path.insert(0, str(WORKSPACE_ROOT))

# Optional GPU bootstrap launcher for high-performance discrete GPU binding
from fiberstrand.gpu_bootstrap import maybe_launch_private_host
gpu_exit = maybe_launch_private_host(WORKSPACE_ROOT)
if gpu_exit is not None:
    raise SystemExit(gpu_exit)

from PySide6 import QtWidgets, QtCore, QtGui
from fiberstrand.qt.theme import setup_qt_application
from fiberstrand.qt.main_window import FSDMainWindow


def run_qt() -> int:
    """Initialize and run the Qt 6 / PySide6 application."""
    if sys.platform=='win32':
        plugins=Path(QtCore.QLibraryInfo.path(QtCore.QLibraryInfo.LibraryPath.PluginsPath))
        platform=plugins/'platforms'
        if not (platform/'qwindows.dll').is_file():
            raise RuntimeError('Qt Windows platform plugin missing: '+str(platform)+'. Reinstall requirements.txt into .venv.')
        os.environ['QT_QPA_PLATFORM_PLUGIN_PATH']=str(platform)
        QtCore.QCoreApplication.addLibraryPath(str(plugins))
    # High-DPI attributes for Qt 6 are enabled by default, but we ensure smooth rendering
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.ApplicationAttribute.AA_UseHighDpiPixmaps, True)
    
    app = setup_qt_application(sys.argv)
    window = FSDMainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(run_qt())
