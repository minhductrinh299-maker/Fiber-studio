# Auto GPU + màu đèn Render Studio

Mở app bằng `run_windows.bat` như trước. **Source mới chưa được chạy/test**;
không có số đo hay xác nhận chuyển GPU trong lần bàn giao này.

## Tự ưu tiên card rời

Startup đọc DXGI để nhận diện các GPU, rồi tự đặt yêu cầu Windows High Performance
cho một Python host riêng của app **trước** khi khởi chạy process tạo Tk/WGL.
Đại ca không phải tự vào Windows Graphics Settings để thêm app.

Lần đầu app tự tạo `.gpu_runtime/`: sao chép Python executable/DLL đã cài trên máy,
dùng lại NumPy/Pillow của môi trường launcher. Đây không phải build/đóng gói app
thành EXE; runtime này vẫn phụ thuộc bản Python và thư viện đang cài trên máy.
Không mang `.gpu_runtime` sang máy khác; source ZIP không chứa thư mục này.

Lý do dùng host riêng: Python venv Windows thường là redirector sang interpreter
chung. Đổi tên redirector hoặc đặt preference cho file venv có thể không nhắm đúng
process render. App dùng executable image thực, đồng thời không đổi preference
của python.exe chung và các phần mềm Python khác.

Khi chạy app, cơ chế này ghi đúng một giá trị cho đường dẫn host riêng dưới:

`HKCU\Software\Microsoft\DirectX\UserGpuPreferences`

Đặt `GpuPreference=2;`, giữ các tùy chọn khác, không sửa global GPU preference,
không tắt iGPU, không cần quyền admin. Giá trị trước được lưu tại
`.gpu_runtime/gpu_preference_backup.json`. Có fallback khởi động thông thường nếu
chuẩn bị runtime/ghi policy/khởi động host thất bại; không tạo vòng restart vô hạn.

Windows/driver có quyền quyết định cuối cùng với WGL: đây là yêu cầu chọn GPU,
không phải API ép tạo OpenGL device theo DXGI LUID. **GPU Info** hiển thị tên lấy
từ GL_RENDERER và inventory DXGI riêng biệt. Nếu policy bị từ chối nhưng iGPU vẫn
render, app báo đúng trạng thái đó, không giả là đã chạy RTX. Không bắt người dùng
đi cài đặt thủ công trong luồng mặc định. Nút GPU Settings cũ được thay bằng GPU Info.

Nếu cần hoàn tác riêng preference do app tạo, từ thư mục project chạy:

```bat
.venv\Scripts\python.exe -m fiberstrand.gpu_bootstrap --restore
```

Lệnh chỉ khôi phục khi giá trị hiện tại vẫn là giá trị app đã ghi, tránh ghi đè
một thay đổi mới khác. Lần mở app sau sẽ tự yêu cầu High Performance lại.

Giới hạn chưa xác minh: CPython private-host startup, các bản Python Store/
embedded/free-threaded khác nhau, Windows/driver thực sự chọn card nào, nhiều
GPU rời, quyền policy doanh nghiệp và các máy chỉ có iGPU. Adapter 4GB+ theo
tiêu chí inventory hiện tại vẫn là cấu hình mục tiêu. D3D12 native cũ không thay đổi.

## Chọn màu đèn

Trong **Render Studio → Studio Lighting** có ba ô màu nhỏ nằm **bên phải slider
cường độ tương ứng**, không chiếm hàng riêng:

- **Key Color** — đèn chính.
- **Fill Color** — đèn bù.
- **Ambient Color** — ánh sáng môi trường của rig, chưa phải HDRI.

Bấm ô để mở color picker. Màu chọn là sRGB, được chuyển thành scene-linear trước
khi đưa vào shader. Cường độ vẫn chỉnh bằng Key/Fill/Ambient Intensity riêng.
Defaults giữ màu tuyến tính của rig cũ để không đổi hình ảnh chỉ vì thêm UI.

Mọi slider trong Render Studio có ô số có thể nhập trực tiếp ở bên phải tên
thông số. **Enter/Tab hoặc rời ô** áp dụng giá trị; **Escape** phục hồi giá trị
đang dùng. Kéo slider cập nhật ô số và ngược lại. Nhập được dấu chấm/dấu phẩy
thập phân; số vượt phạm vi được giới hạn theo min/max của slider. Chuỗi không
hợp lệ, NaN/Infinity không đổi material và được đánh dấu màu lỗi trong ô nhập.

Key/Fill color áp dụng cho diffuse, specular, sheen, scattering và các thành phần
quang học đang dùng đèn tương ứng. Đổi màu chỉ thay uniform và hủy temporal
history/reference không còn khớp; không tạo lại geometry, fiber hoặc atlas.
Capture PNG có metadata màu đèn và trạng thái startup GPU. Màu là trạng thái
Render Studio của phiên hiện tại, chưa bổ sung schema lưu rig vào project .fsd.

Giữ nguyên Alt+LMB orbit, Alt+MMB pan, Alt+RMB dolly, Shift+RMB xoay hướng đèn.
Reset Light vẫn reset hướng sáng, không xóa màu đã chọn.

Các test mới nằm trong `tests/test_gpu_bootstrap_lights.py` nhưng **chưa chạy**.
Không có thao tác registry, tạo private runtime, khởi chạy app hay compiler nào
được thực hiện trong quá trình viết source lần này.

Tài liệu nền: [Python venv](https://docs.python.org/3.14/library/venv.html),
[CPython path initialization source](https://github.com/python/cpython/blob/3.14/Modules/getpath.py),
[NVIDIA Optimus policies](https://developer.download.nvidia.com/devzone/devcenter/gamegraphics/files/OptimusRenderingPolicies.pdf).
