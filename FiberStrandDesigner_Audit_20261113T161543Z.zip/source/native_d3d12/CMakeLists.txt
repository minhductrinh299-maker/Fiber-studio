cmake_minimum_required(VERSION 3.20)
project(FSDNativeD3D12 LANGUAGES CXX)
if(NOT WIN32)
  message(FATAL_ERROR "Windows SDK required: native D3D12 test must build on Windows")
endif()
add_executable(fsd_d3d12_viewport viewport.cpp)
target_compile_features(fsd_d3d12_viewport PRIVATE cxx_std_20)
target_compile_definitions(fsd_d3d12_viewport PRIVATE UNICODE _UNICODE WIN32_LEAN_AND_MEAN NOMINMAX)
target_link_libraries(fsd_d3d12_viewport PRIVATE d3d12 dxgi d3dcompiler windowscodecs ole32 user32)
add_custom_command(TARGET fsd_d3d12_viewport POST_BUILD
  COMMAND "${CMAKE_COMMAND}" -E make_directory "$<TARGET_FILE_DIR:fsd_d3d12_viewport>/shaders"
  COMMAND "${CMAKE_COMMAND}" -E copy_if_different "${CMAKE_CURRENT_SOURCE_DIR}/shaders/viewport.hlsl" "$<TARGET_FILE_DIR:fsd_d3d12_viewport>/shaders/viewport.hlsl")
add_executable(fsd_d3d12_probe main.cpp)
target_compile_features(fsd_d3d12_probe PRIVATE cxx_std_20)
target_compile_definitions(fsd_d3d12_probe PRIVATE UNICODE _UNICODE WIN32_LEAN_AND_MEAN NOMINMAX)
target_link_libraries(fsd_d3d12_probe PRIVATE d3d12 dxgi d3dcompiler)
add_custom_command(TARGET fsd_d3d12_probe POST_BUILD
  COMMAND "${CMAKE_COMMAND}" -E make_directory "$<TARGET_FILE_DIR:fsd_d3d12_probe>/shaders"
  COMMAND "${CMAKE_COMMAND}" -E copy_if_different "${CMAKE_CURRENT_SOURCE_DIR}/shaders/layered_composite.hlsl" "$<TARGET_FILE_DIR:fsd_d3d12_probe>/shaders/layered_composite.hlsl")
enable_testing()
add_test(NAME fsd_native_d3d12_viewport_smoke COMMAND $<TARGET_FILE:fsd_d3d12_viewport>
  --scene "${CMAKE_CURRENT_SOURCE_DIR}/demo_scene/scene.fsdn" --frames 3 --hidden)
add_test(NAME fsd_native_d3d12_compositing COMMAND $<TARGET_FILE:fsd_d3d12_probe>)
set_tests_properties(fsd_native_d3d12_compositing PROPERTIES WORKING_DIRECTORY $<TARGET_FILE_DIR:fsd_d3d12_probe>)

# Experimental bounded K + weighted overflow tail compute probe.
add_executable(fsd_d3d12_adaptive_probe main_adaptive.cpp)
target_compile_features(fsd_d3d12_adaptive_probe PRIVATE cxx_std_20)
target_compile_definitions(fsd_d3d12_adaptive_probe PRIVATE UNICODE _UNICODE WIN32_LEAN_AND_MEAN NOMINMAX)
target_link_libraries(fsd_d3d12_adaptive_probe PRIVATE d3d12 dxgi d3dcompiler)
add_custom_command(TARGET fsd_d3d12_adaptive_probe POST_BUILD
  COMMAND "${CMAKE_COMMAND}" -E make_directory "$<TARGET_FILE_DIR:fsd_d3d12_adaptive_probe>/shaders"
  COMMAND "${CMAKE_COMMAND}" -E copy_if_different "${CMAKE_CURRENT_SOURCE_DIR}/shaders/adaptive_oit.hlsl" "$<TARGET_FILE_DIR:fsd_d3d12_adaptive_probe>/shaders/adaptive_oit.hlsl")
add_test(NAME fsd_native_d3d12_adaptive_oit COMMAND $<TARGET_FILE:fsd_d3d12_adaptive_probe>)
set_tests_properties(fsd_native_d3d12_adaptive_oit PROPERTIES WORKING_DIRECTORY $<TARGET_FILE_DIR:fsd_d3d12_adaptive_probe>)
