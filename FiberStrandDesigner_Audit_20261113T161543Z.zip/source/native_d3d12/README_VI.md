# FSD Native D3D12 — R3 compute reference (Windows only)

## Trạng thái thực tế

**CHƯA có renderer viewport D3D12 native.** Thư mục này chứa hai chương trình compute nhỏ thật sự gọi D3D12 và chạy trên GPU Windows sau khi biên dịch:

1. `fsd_d3d12_probe.exe`: phép ghép alpha sorted front-to-back (3 lớp trong suốt + nền).
2. `fsd_d3d12_adaptive_probe.exe`: tham chiếu GPU K=4 nearest fragment + weighted overflow tail, kiểm tra 32 fragments sai thứ tự; đối chiếu với hàm CPU và báo PASS/FAIL.

Phần K-buffer mới chỉ mô phỏng giai đoạn **resolve** từ danh sách fragment đã thu thập; **chưa có pixel-shader fragment gathering, bộ nhớ per-pixel, synchronization và render graph** nên không phải Adaptive OIT hoàn chỉnh.

## Build/Run

Trên Windows 10/11 với MSVC, Windows 10/11 SDK và CMake:

```bat
build_and_test_windows.bat
```

Liệt kê card D3D12 theo hiệu năng ưu tiên:

```bat
build\Release\fsd_d3d12_probe.exe --list-adapters
```

Thử trên GPU chỉ định (0 là GPU hiệu năng cao ưu tiên theo DXGI):

```bat
build\Release\fsd_d3d12_adaptive_probe.exe --adapter 0
```

Fallback WARP chỉ để kiểm tra chức năng (không dùng làm benchmark):

```bat
build\Release\fsd_d3d12_probe.exe --warp
```

D3D12 adapter được tạo **chủ động** từ danh sách DXGI; có log VRAM budget khi adapter/driver hỗ trợ. Điều này không tự chuyển OpenGL/Tk Render Studio đang chạy sang NVIDIA.

## Các giới hạn cần công khai

- Chưa biên dịch và chạy các file này trên Windows trong môi trường build Linux của phiên bản bàn giao.
- Compute probe không phải phần giao diện Tk/OpenGL đang chạy.
- D3D12 chưa thực hiện render card geometry, FiberLight/HairShadow, texture atlas hay swapchain.
- Hiệu năng NVIDIA GTX 1650/RTX 3050 Ti cần thử trên máy Windows thật.
- HLSL dùng shader model 5.0 làm phép kiểm thử nhỏ, không phải shader production DXC/SM6.
