// Fiber Strand Designer - Windows D3D12 compute RHI technology probe.
// No third-party libraries; requires the Windows 10+ SDK and an available D3D12 adapter.
// This does NOT yet provide the full viewport, hair BRDF, or K-buffer pipeline.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <d3d12.h>
#include <dxgi1_6.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#include <array>
#include <cmath>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

using Microsoft::WRL::ComPtr;

static void check(HRESULT hr, const char* what) {
    if (FAILED(hr)) throw std::runtime_error(std::string(what) + " HRESULT=" + std::to_string(static_cast<unsigned>(hr)));
}

struct Pixel { float r, g, b, a; };

static D3D12_RESOURCE_DESC buffer_desc(UINT64 size, D3D12_RESOURCE_FLAGS flags = D3D12_RESOURCE_FLAG_NONE) {
    D3D12_RESOURCE_DESC d{};
    d.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER;
    d.Alignment = 0;
    d.Width = size;
    d.Height = 1;
    d.DepthOrArraySize = 1;
    d.MipLevels = 1;
    d.Format = DXGI_FORMAT_UNKNOWN;
    d.SampleDesc.Count = 1;
    d.SampleDesc.Quality = 0;
    d.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
    d.Flags = flags;
    return d;
}
static D3D12_HEAP_PROPERTIES heap_props(D3D12_HEAP_TYPE type) {
    D3D12_HEAP_PROPERTIES p{};
    p.Type = type;
    p.CPUPageProperty = D3D12_CPU_PAGE_PROPERTY_UNKNOWN;
    p.MemoryPoolPreference = D3D12_MEMORY_POOL_UNKNOWN;
    p.CreationNodeMask = 1;
    p.VisibleNodeMask = 1;
    return p;
}
static ComPtr<ID3D12Resource> make_buffer(ID3D12Device* device, UINT64 bytes,
                                         D3D12_HEAP_TYPE type, D3D12_RESOURCE_STATES initial,
                                         D3D12_RESOURCE_FLAGS flags = D3D12_RESOURCE_FLAG_NONE) {
    ComPtr<ID3D12Resource> out;
    const auto heap = heap_props(type);
    const auto desc = buffer_desc(bytes, flags);
    check(device->CreateCommittedResource(&heap, D3D12_HEAP_FLAG_NONE, &desc,
          initial, nullptr, IID_PPV_ARGS(&out)), "CreateCommittedResource");
    return out;
}
static ComPtr<ID3DBlob> compile_compute(const wchar_t* shader) {
    ComPtr<ID3DBlob> bytecode, error;
    HRESULT hr = D3DCompileFromFile(shader, nullptr, D3D_COMPILE_STANDARD_FILE_INCLUDE,
                                    "CSMain", "cs_5_0", D3DCOMPILE_ENABLE_STRICTNESS, 0,
                                    &bytecode, &error);
    if (FAILED(hr) && error) std::cerr << (const char*)error->GetBufferPointer() << '\n';
    check(hr, "D3DCompileFromFile");
    return bytecode;
}
static Pixel reference(const std::array<Pixel, 4>& p) {
    Pixel answer{0, 0, 0, 1};
    float transmit = 1.f;
    for (int i=0; i<3; ++i) {
        const float alpha = std::fmax(0.f, std::fmin(1.f, p[i].a));
        answer.r += transmit * alpha * p[i].r;
        answer.g += transmit * alpha * p[i].g;
        answer.b += transmit * alpha * p[i].b;
        transmit *= 1-alpha;
    }
    answer.r += transmit * p[3].r;
    answer.g += transmit * p[3].g;
    answer.b += transmit * p[3].b;
    return answer;
}
int main(int argc, char** argv) {
    try {
        const bool allowWarp = argc>1 && std::string(argv[1])=="--warp";
        ComPtr<IDXGIFactory6> factory;
        check(CreateDXGIFactory2(0, IID_PPV_ARGS(&factory)), "CreateDXGIFactory2");
        ComPtr<IDXGIAdapter1> adapter;
        int requested = -1;
        bool listOnly = false;
        for (int i=1;i<argc;i++) {
            if (std::string(argv[i])=="--adapter" && i+1<argc) requested=std::stoi(argv[++i]);
            if (std::string(argv[i])=="--list-adapters") listOnly=true;
        }
        std::vector<ComPtr<IDXGIAdapter1>> choices;
        for (UINT i=0;;++i) {
            ComPtr<IDXGIAdapter1> candidate;
            // Enumerate in OS-defined GPU-performance order instead of
            // unintentionally selecting the integrated adapter first.
            HRESULT hr=factory->EnumAdapterByGpuPreference(i,DXGI_GPU_PREFERENCE_HIGH_PERFORMANCE,
                                                           IID_PPV_ARGS(&candidate));
            if (hr==DXGI_ERROR_NOT_FOUND)break;
            check(hr,"EnumAdapterByGpuPreference");
            DXGI_ADAPTER_DESC1 desc{};candidate->GetDesc1(&desc);
            if (desc.Flags & DXGI_ADAPTER_FLAG_SOFTWARE)continue;
            if (SUCCEEDED(D3D12CreateDevice(candidate.Get(),D3D_FEATURE_LEVEL_11_0,
                                            __uuidof(ID3D12Device),nullptr))) choices.push_back(candidate);
        }
        for(size_t i=0;i<choices.size();i++) {
            DXGI_ADAPTER_DESC1 d{};choices[i]->GetDesc1(&d);
            std::wcout << L"Adapter " << i << L": " << d.Description
                       << L" (VRAM " << (d.DedicatedVideoMemory/(1024*1024)) << L" MiB)\n";
        }
        if(listOnly)return 0;
        if(allowWarp)check(factory->EnumWarpAdapter(IID_PPV_ARGS(&adapter)),"EnumWarpAdapter");
        else if(requested>=0 && requested<(int)choices.size())adapter=choices[requested];
        else if(requested>=0)throw std::runtime_error("Adapter index out of range");
        else if(!choices.empty())adapter=choices.front();
        if (!adapter) throw std::runtime_error("No D3D12 hardware adapter found (try --warp for a CPU reference probe)");
        ComPtr<ID3D12Device> device;
        check(D3D12CreateDevice(adapter.Get(), D3D_FEATURE_LEVEL_11_0, IID_PPV_ARGS(&device)), "D3D12CreateDevice");
        DXGI_ADAPTER_DESC1 adapterDesc{};adapter->GetDesc1(&adapterDesc);
        std::wcout << L"D3D12 adapter: " << adapterDesc.Description << L"\n";
        ComPtr<IDXGIAdapter3> budgetAdapter;
        if(SUCCEEDED(adapter.As(&budgetAdapter))) {
            DXGI_QUERY_VIDEO_MEMORY_INFO budget{};
            if(SUCCEEDED(budgetAdapter->QueryVideoMemoryInfo(0,DXGI_MEMORY_SEGMENT_GROUP_LOCAL,&budget)))
                std::wcout << L"DXGI local memory budget: " << budget.Budget/(1024*1024)
                           << L" MiB, usage " << budget.CurrentUsage/(1024*1024) << L" MiB\n";
        }

        D3D12_COMMAND_QUEUE_DESC queueDesc{};
        queueDesc.Type = D3D12_COMMAND_LIST_TYPE_DIRECT;
        ComPtr<ID3D12CommandQueue> queue;
        check(device->CreateCommandQueue(&queueDesc,IID_PPV_ARGS(&queue)), "CreateCommandQueue");
        ComPtr<ID3D12CommandAllocator> allocator;
        check(device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT,IID_PPV_ARGS(&allocator)), "CreateCommandAllocator");
        ComPtr<ID3D12GraphicsCommandList> list;
        check(device->CreateCommandList(0,D3D12_COMMAND_LIST_TYPE_DIRECT,allocator.Get(),nullptr,
                                        IID_PPV_ARGS(&list)), "CreateCommandList");

        D3D12_ROOT_PARAMETER params[3]{};
        params[0].ParameterType=D3D12_ROOT_PARAMETER_TYPE_SRV;
        params[0].Descriptor.ShaderRegister=0;
        params[0].ShaderVisibility=D3D12_SHADER_VISIBILITY_ALL;
        params[1].ParameterType=D3D12_ROOT_PARAMETER_TYPE_UAV;
        params[1].Descriptor.ShaderRegister=0;
        params[1].ShaderVisibility=D3D12_SHADER_VISIBILITY_ALL;
        params[2].ParameterType=D3D12_ROOT_PARAMETER_TYPE_32BIT_CONSTANTS;
        params[2].Constants.ShaderRegister=0;
        params[2].Constants.Num32BitValues=1;
        params[2].ShaderVisibility=D3D12_SHADER_VISIBILITY_ALL;
        D3D12_ROOT_SIGNATURE_DESC signature{};
        signature.NumParameters=3;signature.pParameters=params;
        signature.Flags=D3D12_ROOT_SIGNATURE_FLAG_NONE;
        ComPtr<ID3DBlob> signatureBytes,signatureError;
        HRESULT hr = D3D12SerializeRootSignature(&signature,D3D_ROOT_SIGNATURE_VERSION_1,
                                                 &signatureBytes,&signatureError);
        if (FAILED(hr) && signatureError) std::cerr << (const char*)signatureError->GetBufferPointer() << '\n';
        check(hr,"D3D12SerializeRootSignature");
        ComPtr<ID3D12RootSignature> root;
        check(device->CreateRootSignature(0,signatureBytes->GetBufferPointer(),signatureBytes->GetBufferSize(),
                                          IID_PPV_ARGS(&root)),"CreateRootSignature");

        auto shader=compile_compute(L"shaders/layered_composite.hlsl");
        D3D12_COMPUTE_PIPELINE_STATE_DESC psoDesc{};
        psoDesc.pRootSignature=root.Get();
        psoDesc.CS={shader->GetBufferPointer(),shader->GetBufferSize()};
        ComPtr<ID3D12PipelineState> pipeline;
        check(device->CreateComputePipelineState(&psoDesc,IID_PPV_ARGS(&pipeline)),"CreateComputePipelineState");

        // Three separate translucent layers + opaque background, sorted nearest first.
        const std::array<Pixel,4> layers{{{1.f,0.f,0.f,.5f},{0.f,1.f,0.f,.25f},
                                           {0.f,0.f,1.f,.5f},{.1f,.1f,.1f,1.f}}};
        auto input=make_buffer(device.Get(),sizeof(layers),D3D12_HEAP_TYPE_UPLOAD,D3D12_RESOURCE_STATE_GENERIC_READ);
        auto result=make_buffer(device.Get(),sizeof(Pixel),D3D12_HEAP_TYPE_DEFAULT,
                                D3D12_RESOURCE_STATE_UNORDERED_ACCESS,D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS);
        auto readback=make_buffer(device.Get(),sizeof(Pixel),D3D12_HEAP_TYPE_READBACK,D3D12_RESOURCE_STATE_COPY_DEST);
        void* inputMapped=nullptr;
        D3D12_RANGE emptyRange{0,0};
        check(input->Map(0,&emptyRange,&inputMapped),"Map(input)");
        std::memcpy(inputMapped,layers.data(),sizeof(layers));
        input->Unmap(0,nullptr);

        list->SetPipelineState(pipeline.Get());
        list->SetComputeRootSignature(root.Get());
        list->SetComputeRootShaderResourceView(0,input->GetGPUVirtualAddress());
        list->SetComputeRootUnorderedAccessView(1,result->GetGPUVirtualAddress());
        list->SetComputeRoot32BitConstant(2,3,0);
        list->Dispatch(1,1,1);
        D3D12_RESOURCE_BARRIER barrier{};
        barrier.Type=D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
        barrier.Transition.pResource=result.Get();
        barrier.Transition.Subresource=D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        barrier.Transition.StateBefore=D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
        barrier.Transition.StateAfter=D3D12_RESOURCE_STATE_COPY_SOURCE;
        list->ResourceBarrier(1,&barrier);
        list->CopyResource(readback.Get(),result.Get());
        check(list->Close(),"Close command list");
        ID3D12CommandList* batches[]={list.Get()};
        queue->ExecuteCommandLists(1,batches);
        ComPtr<ID3D12Fence> fence;
        check(device->CreateFence(0,D3D12_FENCE_FLAG_NONE,IID_PPV_ARGS(&fence)),"CreateFence");
        check(queue->Signal(fence.Get(),1),"Queue Signal");
        if (fence->GetCompletedValue()<1) {
            HANDLE evt=CreateEventW(nullptr,FALSE,FALSE,nullptr);
            if (!evt) throw std::runtime_error("CreateEventW failed");
            check(fence->SetEventOnCompletion(1,evt),"SetEventOnCompletion");
            const DWORD waiting=WaitForSingleObject(evt,10000);
            CloseHandle(evt);
            if (waiting!=WAIT_OBJECT_0) throw std::runtime_error("GPU timeout during D3D12 probe");
        }
        D3D12_RANGE readRange{0,sizeof(Pixel)};
        void* mapped=nullptr;
        check(readback->Map(0,&readRange,&mapped),"Map(readback)");
        Pixel actual{};std::memcpy(&actual,mapped,sizeof(Pixel));
        readback->Unmap(0,&emptyRange);
        Pixel expected=reference(layers);
        std::cout << "GPU composite RGB: " << actual.r << ", " << actual.g << ", " << actual.b << '\n'
                  << "CPU reference RGB: " << expected.r << ", " << expected.g << ", " << expected.b << '\n';
        const bool ok=std::fabs(actual.r-expected.r)<0.0001f &&
                      std::fabs(actual.g-expected.g)<0.0001f &&
                      std::fabs(actual.b-expected.b)<0.0001f &&
                      std::fabs(actual.a-1.f)<0.0001f;
        std::cout << (ok?"PASS":"FAIL") << ": GPU front-to-back layered composite" << std::endl;
        return ok?0:2;
    } catch (const std::exception& error) {
        std::cerr << "D3D12 probe error: " << error.what() << '\n';
        return 1;
    }
}
