// FSD Native RHI probe: exact reference front-to-back alpha compositor.
// Input RGBA colors are straight scene-linear; layer 0 is closest to camera.
StructuredBuffer<float4> gLayers : register(t0);
RWStructuredBuffer<float4> gOutput : register(u0);
cbuffer Params : register(b0) { uint gLayerCount; };

[numthreads(1,1,1)]
void CSMain(uint3 index : SV_DispatchThreadID)
{
    float3 color = 0;
    float transmittance = 1.0;
    [loop]
    for (uint i = 0; i < gLayerCount; ++i)
    {
        float4 layer = gLayers[i];
        float a = saturate(layer.a);
        color += transmittance * a * layer.rgb;
        transmittance *= (1.0-a);
    }
    float4 background = gLayers[gLayerCount];
    color += transmittance * background.rgb;
    gOutput[0] = float4(color, 1.0);
}
