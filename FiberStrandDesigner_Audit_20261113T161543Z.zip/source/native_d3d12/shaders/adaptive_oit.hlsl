// Bounded K-buffer + weighted overflow tail compute reference for Direct3D 12.
// This is an experimental compute pass, not yet a full hair raster/gather pass.
// For pixel production, fragments must be gathered using bounded on-GPU storage.
#define MAX_LAYERS 64
#define FRONT_K 4
struct Fragment {float4 rgba; float depth; float3 reserved;};
StructuredBuffer<Fragment> gFragments:register(t0);
RWStructuredBuffer<float4> gOutput:register(u0);
cbuffer Settings:register(b0) {uint gFragmentCount;};
[numthreads(1,1,1)]
void CSMain(uint3 tid:SV_DispatchThreadID) {
    float4 nearest[FRONT_K];
    float depths[FRONT_K];
    uint count=0;
    float3 tailAcc=float3(0,0,0);
    float tailWeight=0.0;
    float tailReveal=1.0;
    [loop]
    for(uint i=0;i<min(gFragmentCount,MAX_LAYERS);i++) {
        Fragment f=gFragments[i];
        float4 cur=f.rgba;
        float d=f.depth;
        uint pos=count;
        [unroll]
        for(uint j=0;j<FRONT_K;j++) {
            if(j<count && d<depths[j]) {pos=min(pos,j);}
        }
        bool enters=(count<FRONT_K || pos<FRONT_K);
        if(enters) {
            float4 overflow=float4(0,0,0,0);
            float overflowDepth=1.0;
            bool evict=count==FRONT_K;
            if(evict) {overflow=nearest[FRONT_K-1];overflowDepth=depths[FRONT_K-1];}
            [unroll]
            for(int j=FRONT_K-1;j>=1;j--) {
                if(j>int(pos) && j<=int(count)) {nearest[j]=nearest[j-1];depths[j]=depths[j-1];}
            }
            if(pos<FRONT_K) {nearest[pos]=cur;depths[pos]=d;}
            count=min(FRONT_K,count+1);
            if(evict) {cur=overflow;d=overflowDepth;}
            else continue;
        }
        float a=saturate(cur.a);
        float w=clamp(3.0/(.2+pow(max(d,0.0),3.0)),.05,12.0);
        tailAcc+=cur.rgb*a*w;
        tailWeight+=a*w;
        tailReveal*=(1.0-a);
    }
    float3 background=float3(.05,.05,.05);
    float3 avg=tailAcc/max(tailWeight,1e-8);
    float3 rgb=avg*(1.0-tailReveal)+background*tailReveal;
    for(int j=int(count)-1;j>=0;j--) {
        float a=saturate(nearest[j].a);
        rgb=nearest[j].rgb*a+rgb*(1.0-a);
    }
    gOutput[0]=float4(rgb,1.0);
}
