cbuffer Frame : register(b0) {
    row_major float4x4 viewProjection;
    float4 eye;
    float4 light;
};
Texture2D colorMap : register(t0);
Texture2D alphaMap : register(t1);
Texture2D normalMap : register(t2);
Texture2D flowMap : register(t3);
Texture2D roughnessMap : register(t4);
SamplerState atlasSampler : register(s0);
struct Vertex {
    float3 position : POSITION;
    float3 normal : NORMAL;
    float3 tangent : TANGENT;
    float2 uv : TEXCOORD;
};
struct Fragment {
    float4 position : SV_Position;
    float3 world : POSITION;
    float3 normal : NORMAL;
    float3 tangent : TANGENT;
    float2 uv : TEXCOORD;
};
Fragment VSMain(Vertex v) {
    Fragment o;
    o.position = mul(float4(v.position, 1), viewProjection);
    o.world = v.position; o.normal = v.normal; o.tangent = v.tangent; o.uv = v.uv;
    return o;
}
float4 PSMain(Fragment f, bool front : SV_IsFrontFace) : SV_Target {
    float a = alphaMap.Sample(atlasSampler, f.uv).r;
    clip(a - 0.001);
    // Color SRV decodes sRGB; all other maps are linear data.
    float3 base = colorMap.Sample(atlasSampler, f.uv).rgb;
    float3 t = normalize(f.tangent);
    float3 n = normalize(f.normal) * (front ? 1 : -1);
    float3 b = normalize(cross(t, n));
    float3 mapN = normalMap.Sample(atlasSampler, f.uv).xyz * 2 - 1;
    n = normalize(b * mapN.x + t * mapN.y + n * max(.05, mapN.z));
    float2 flow = flowMap.Sample(atlasSampler, f.uv).rg * 2 - 1;
    if (dot(flow, flow) > .01) t = normalize(b * flow.x + t * flow.y);
    float roughness = clamp(roughnessMap.Sample(atlasSampler, f.uv).r, .08, 1);
    float3 l = normalize(light.xyz);
    float3 v = normalize(eye.xyz - f.world);
    float3 h = normalize(l + v);
    float strand = sqrt(saturate(1 - pow(dot(t, h), 2)));
    float specular = pow(strand, lerp(160, 8, roughness)) * .45;
    float3 linearColor = base * (.25 + .75 * abs(dot(n, l))) + specular;
    // Render target is UNORM; encode output once, after linear blending below.
    return float4(linearColor, a);
}
struct Quad { float4 position : SV_Position; float2 uv : TEXCOORD; };
Quad FullscreenVS(uint id : SV_VertexID) {
    Quad o;
    o.uv = float2((id << 1) & 2, id & 2);
    o.position = float4(o.uv * float2(2, -2) + float2(-1, 1), 0, 1);
    return o;
}
Texture2D linearFrame : register(t0);
float4 DisplayPS(Quad f) : SV_Target {
    float3 c = max(0, linearFrame.Sample(atlasSampler, f.uv).rgb);
    c = min(c, 1);
    c = lerp(c * 12.92, 1.055 * pow(c, 1 / 2.4) - .055, step(.0031308, c));
    return float4(c, 1);
}
