// Experimental standalone D3D12 viewport. No external C++ dependencies.
// Sorted triangle alpha is a foundation only, NOT adaptive per-pixel OIT.
#include <windows.h>
#include <windowsx.h>
#include <d3d12.h>
#include <dxgi1_6.h>
#include <d3dcompiler.h>
#include <wincodec.h>
#include <wrl/client.h>
#include <DirectXMath.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <numeric>
#include <stdexcept>
#include <vector>

using Microsoft::WRL::ComPtr;
using namespace DirectX;
namespace fs = std::filesystem;
static void check(HRESULT hr, const char* what) {
    if (FAILED(hr)) throw std::runtime_error(std::string(what) + " HRESULT=" + std::to_string(unsigned(hr)));
}
static D3D12_HEAP_PROPERTIES heap(D3D12_HEAP_TYPE type) {
    D3D12_HEAP_PROPERTIES h{}; h.Type=type; h.CreationNodeMask=h.VisibleNodeMask=1; return h;
}
static D3D12_RESOURCE_DESC buffer(UINT64 bytes) {
    D3D12_RESOURCE_DESC d{}; d.Dimension=D3D12_RESOURCE_DIMENSION_BUFFER; d.Width=bytes;
    d.Height=1; d.DepthOrArraySize=1; d.MipLevels=1; d.SampleDesc.Count=1;
    d.Layout=D3D12_TEXTURE_LAYOUT_ROW_MAJOR; return d;
}
static D3D12_RESOURCE_DESC texture(UINT w, UINT h, DXGI_FORMAT format, D3D12_RESOURCE_FLAGS flags={}) {
    auto d=buffer(w); d.Dimension=D3D12_RESOURCE_DIMENSION_TEXTURE2D; d.Height=h;
    d.Format=format; d.Layout=D3D12_TEXTURE_LAYOUT_UNKNOWN; d.Flags=flags; return d;
}
struct Vertex { XMFLOAT3 p,n,t; XMFLOAT2 uv; };
static_assert(sizeof(Vertex)==44);
struct Frame { XMFLOAT4X4 vp; XMFLOAT4 eye,light; };

class Viewport {
public:
    HWND window{}; UINT width=960,height=640;
    float yaw=0,pitch=.08f,distance=4,azimuth=40,elevation=54;
    XMFLOAT3 target{0,.7f,0};
    bool minimized=false,dragCamera=false,dragLight=false,sweep=false;
    int navigation=0; // 1 orbit, 2 camera-plane pan, 3 horizontal dolly
    POINT last{};
    ComPtr<ID3D12Device> device;
    ComPtr<IDXGIAdapter1> adapter;
    ComPtr<ID3D12CommandQueue> queue;
    ComPtr<IDXGISwapChain3> swap;
    ComPtr<ID3D12CommandAllocator> allocator;
    ComPtr<ID3D12GraphicsCommandList> list;
    ComPtr<ID3D12Fence> fence;
    HANDLE eventHandle{}; UINT64 fenceValue=0;
    ComPtr<ID3D12DescriptorHeap> rtv,srv;
    UINT rtvStep=0,srvStep=0;
    std::array<ComPtr<ID3D12Resource>,2> back;
    ComPtr<ID3D12Resource> linear,vb,cb;
    std::array<ComPtr<ID3D12Resource>,5> maps;
    ComPtr<ID3D12RootSignature> root;
    ComPtr<ID3D12PipelineState> hairPSO,displayPSO;
    ComPtr<IWICImagingFactory> wic;
    ComPtr<ID3D12QueryHeap> timestamps;
    ComPtr<ID3D12Resource> timingReadback;
    UINT64 frequency=0;
    std::vector<Vertex> vertices,sorted;
    std::vector<double> gpuTimes;
    UINT atlasSize=0;
    bool debug=false;

    ~Viewport() {
        if(queue && fence && eventHandle) { try { wait(); } catch (...) {} }
        if(eventHandle) CloseHandle(eventHandle);
        if(window) DestroyWindow(window);
    }
    D3D12_CPU_DESCRIPTOR_HANDLE cpu(ID3D12DescriptorHeap* h,UINT i,UINT step) {
        auto p=h->GetCPUDescriptorHandleForHeapStart(); p.ptr+=SIZE_T(i)*step; return p;
    }
    D3D12_GPU_DESCRIPTOR_HANDLE gpu(UINT i) {
        auto p=srv->GetGPUDescriptorHandleForHeapStart(); p.ptr+=UINT64(i)*srvStep; return p;
    }
    ComPtr<ID3D12Resource> resource(const D3D12_RESOURCE_DESC& d,D3D12_HEAP_TYPE type,
                                  D3D12_RESOURCE_STATES state,const D3D12_CLEAR_VALUE* clear=nullptr) {
        ComPtr<ID3D12Resource> r; auto h=heap(type);
        check(device->CreateCommittedResource(&h,D3D12_HEAP_FLAG_NONE,&d,state,clear,IID_PPV_ARGS(&r)),"Create resource");
        return r;
    }
    void wait() {
        check(queue->Signal(fence.Get(),++fenceValue),"Signal");
        if(fence->GetCompletedValue()<fenceValue) {
            check(fence->SetEventOnCompletion(fenceValue,eventHandle),"Fence event");
            if(WaitForSingleObject(eventHandle,30000)!=WAIT_OBJECT_0)
                throw std::runtime_error("GPU fence timeout/device removed");
        }
    }
    void begin() {
        check(allocator->Reset(),"Reset allocator"); check(list->Reset(allocator.Get(),nullptr),"Reset list");
    }
    void submit() {
        check(list->Close(),"Close list"); ID3D12CommandList* lists[]={list.Get()};
        queue->ExecuteCommandLists(1,lists); wait();
    }
    void barrier(ID3D12Resource* r,D3D12_RESOURCE_STATES a,D3D12_RESOURCE_STATES b) {
        D3D12_RESOURCE_BARRIER x{}; x.Type=D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
        x.Transition={r,D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES,a,b}; list->ResourceBarrier(1,&x);
    }
    void loadScene(const fs::path& path) {
        std::ifstream in(path,std::ios::binary); char magic[8]{}; UINT count=0;
        in.read(magic,8); in.read(reinterpret_cast<char*>(&count),4); in.read(reinterpret_cast<char*>(&atlasSize),4);
        if(!in || std::string(magic,8)!="FSDNAT01" || !count || count%3 || count>6000000 || !atlasSize || atlasSize>16384)
            throw std::runtime_error("Invalid native snapshot header");
        if(fs::file_size(path)!=16+UINT64(count)*sizeof(Vertex)) throw std::runtime_error("Invalid snapshot size");
        vertices.resize(count); in.read(reinterpret_cast<char*>(vertices.data()),count*sizeof(Vertex));
        XMFLOAT3 lo=vertices[0].p,hi=lo;
        for(const auto& v:vertices) {
            const float* f=reinterpret_cast<const float*>(&v);
            for(int j=0;j<11;++j) if(!std::isfinite(f[j])) throw std::runtime_error("Non-finite vertex");
            lo.x=std::min(lo.x,v.p.x);lo.y=std::min(lo.y,v.p.y);lo.z=std::min(lo.z,v.p.z);
            hi.x=std::max(hi.x,v.p.x);hi.y=std::max(hi.y,v.p.y);hi.z=std::max(hi.z,v.p.z);
        }
        target={(lo.x+hi.x)*.5f,(lo.y+hi.y)*.5f,(lo.z+hi.z)*.5f};
        distance=std::max({hi.x-lo.x,hi.y-lo.y,hi.z-lo.z,.1f})*1.8f;
        sorted.resize(count);
        std::cout<<"Snapshot vertices="<<count<<" triangles="<<count/3<<" atlas="<<atlasSize<<"\n";
    }
    void init(int requested,bool warp,bool listOnly,const fs::path& executable) {
        if(debug) {
            ComPtr<ID3D12Debug> d; check(D3D12GetDebugInterface(IID_PPV_ARGS(&d)),"Debug layer unavailable");
            d->EnableDebugLayer();
        }
        ComPtr<IDXGIFactory6> factory; check(CreateDXGIFactory2(0,IID_PPV_ARGS(&factory)),"DXGI factory");
        std::vector<ComPtr<IDXGIAdapter1>> choices;
        for(UINT i=0;;++i) {
            ComPtr<IDXGIAdapter1> a;
            HRESULT hr=factory->EnumAdapterByGpuPreference(i,DXGI_GPU_PREFERENCE_HIGH_PERFORMANCE,IID_PPV_ARGS(&a));
            if(hr==DXGI_ERROR_NOT_FOUND) break; check(hr,"Enumerate adapters");
            DXGI_ADAPTER_DESC1 d{}; check(a->GetDesc1(&d),"Adapter description");
            if(d.Flags&DXGI_ADAPTER_FLAG_SOFTWARE) continue;
            if(FAILED(D3D12CreateDevice(a.Get(),D3D_FEATURE_LEVEL_11_0,__uuidof(ID3D12Device),nullptr))) continue;
            std::wcout<<L"Adapter "<<choices.size()<<L": "<<d.Description<<L" VRAM MiB="<<d.DedicatedVideoMemory/1048576<<L"\n";
            choices.push_back(a);
        }
        if(listOnly) return;
        if(warp) check(factory->EnumWarpAdapter(IID_PPV_ARGS(&adapter)),"WARP");
        else {
            if(requested<0 || requested>=int(choices.size())) throw std::runtime_error("Invalid/no hardware adapter");
            adapter=choices[requested];
        }
        check(D3D12CreateDevice(adapter.Get(),D3D_FEATURE_LEVEL_11_0,IID_PPV_ARGS(&device)),"D3D12 device");
        DXGI_ADAPTER_DESC1 selected{};check(adapter->GetDesc1(&selected),"Selected adapter");
        std::wcout<<L"Selected: "<<selected.Description<<(warp?L" (SOFTWARE)":L" (HARDWARE)")<<L"\n";
        WNDCLASSW wc{};wc.lpfnWndProc=wndproc;wc.hInstance=GetModuleHandleW(nullptr);wc.lpszClassName=L"FSDNativeViewport";
        wc.hCursor=LoadCursor(nullptr,IDC_ARROW); RegisterClassW(&wc);
        RECT rect{0,0,LONG(width),LONG(height)};AdjustWindowRect(&rect,WS_OVERLAPPEDWINDOW,FALSE);
        window=CreateWindowW(wc.lpszClassName,L"FSD Native D3D12 - experimental",WS_OVERLAPPEDWINDOW,
            CW_USEDEFAULT,CW_USEDEFAULT,rect.right-rect.left,rect.bottom-rect.top,nullptr,nullptr,wc.hInstance,this);
        if(!window) throw std::runtime_error("Create viewport window failed");
        D3D12_COMMAND_QUEUE_DESC q{};q.Type=D3D12_COMMAND_LIST_TYPE_DIRECT;
        check(device->CreateCommandQueue(&q,IID_PPV_ARGS(&queue)),"Command queue");
        DXGI_SWAP_CHAIN_DESC1 sc{};sc.Width=width;sc.Height=height;sc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;
        sc.SampleDesc.Count=1;sc.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;sc.BufferCount=2;sc.SwapEffect=DXGI_SWAP_EFFECT_FLIP_DISCARD;
        ComPtr<IDXGISwapChain1> s;
        check(factory->CreateSwapChainForHwnd(queue.Get(),window,&sc,nullptr,nullptr,&s),"Swapchain");
        check(s.As(&swap),"Swapchain3");check(factory->MakeWindowAssociation(window,DXGI_MWA_NO_ALT_ENTER),"Window association");
        check(device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT,IID_PPV_ARGS(&allocator)),"Allocator");
        check(device->CreateCommandList(0,D3D12_COMMAND_LIST_TYPE_DIRECT,allocator.Get(),nullptr,IID_PPV_ARGS(&list)),"Command list");
        check(list->Close(),"Initial close");
        check(device->CreateFence(0,D3D12_FENCE_FLAG_NONE,IID_PPV_ARGS(&fence)),"Fence");
        eventHandle=CreateEventW(nullptr,FALSE,FALSE,nullptr);if(!eventHandle) throw std::runtime_error("Create event");
        D3D12_DESCRIPTOR_HEAP_DESC hd{};hd.Type=D3D12_DESCRIPTOR_HEAP_TYPE_RTV;hd.NumDescriptors=3;
        check(device->CreateDescriptorHeap(&hd,IID_PPV_ARGS(&rtv)),"RTV heap");
        hd.Type=D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV;hd.NumDescriptors=10;hd.Flags=D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
        check(device->CreateDescriptorHeap(&hd,IID_PPV_ARGS(&srv)),"SRV heap");
        rtvStep=device->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV);
        srvStep=device->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);
        // Display reuses the five-SRV table at slot 5. Unused slots must still
        // be valid null descriptors, with the entire range inside the heap.
        D3D12_SHADER_RESOURCE_VIEW_DESC nullView{};
        nullView.Format=DXGI_FORMAT_R8G8B8A8_UNORM;
        nullView.ViewDimension=D3D12_SRV_DIMENSION_TEXTURE2D;
        nullView.Shader4ComponentMapping=D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
        nullView.Texture2D.MipLevels=1;
        for(UINT i=6;i<10;++i)device->CreateShaderResourceView(nullptr,&nullView,cpu(srv.Get(),i,srvStep));
        targets();
        check(CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&wic)),"WIC factory");
        pipelines(executable.parent_path()/L"shaders"/L"viewport.hlsl");
        vb=resource(buffer(vertices.size()*sizeof(Vertex)),D3D12_HEAP_TYPE_UPLOAD,D3D12_RESOURCE_STATE_GENERIC_READ);
        cb=resource(buffer(256),D3D12_HEAP_TYPE_UPLOAD,D3D12_RESOURCE_STATE_GENERIC_READ);
        D3D12_QUERY_HEAP_DESC th{};th.Type=D3D12_QUERY_HEAP_TYPE_TIMESTAMP;th.Count=2;
        check(device->CreateQueryHeap(&th,IID_PPV_ARGS(&timestamps)),"Timestamp queries");
        timingReadback=resource(buffer(16),D3D12_HEAP_TYPE_READBACK,D3D12_RESOURCE_STATE_COPY_DEST);
        check(queue->GetTimestampFrequency(&frequency),"Timestamp frequency");
    }
    void targets() {
        for(UINT i=0;i<2;++i) {
            check(swap->GetBuffer(i,IID_PPV_ARGS(&back[i])),"Back buffer");
            device->CreateRenderTargetView(back[i].Get(),nullptr,cpu(rtv.Get(),i,rtvStep));
        }
        D3D12_CLEAR_VALUE clear{};clear.Format=DXGI_FORMAT_R16G16B16A16_FLOAT;
        clear.Color[0]=.018f;clear.Color[1]=.023f;clear.Color[2]=.03f;clear.Color[3]=1;
        linear=resource(texture(width,height,clear.Format,D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET),
            D3D12_HEAP_TYPE_DEFAULT,D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE,&clear);
        device->CreateRenderTargetView(linear.Get(),nullptr,cpu(rtv.Get(),2,rtvStep));
        D3D12_SHADER_RESOURCE_VIEW_DESC sd{};sd.Format=clear.Format;sd.ViewDimension=D3D12_SRV_DIMENSION_TEXTURE2D;
        sd.Shader4ComponentMapping=D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;sd.Texture2D.MipLevels=1;
        device->CreateShaderResourceView(linear.Get(),&sd,cpu(srv.Get(),5,srvStep));
    }
    void resize(UINT w,UINT h) {
        if(!swap || !w || !h || (w==width && h==height)) return;
        wait();for(auto& b:back)b.Reset();linear.Reset();
        check(swap->ResizeBuffers(2,w,h,DXGI_FORMAT_R8G8B8A8_UNORM,0),"ResizeBuffers");
        width=w;height=h;targets();
    }
    void pipelines(const fs::path& shader) {
        D3D12_DESCRIPTOR_RANGE range{};range.RangeType=D3D12_DESCRIPTOR_RANGE_TYPE_SRV;range.NumDescriptors=5;
        D3D12_ROOT_PARAMETER params[2]{};
        params[0].ParameterType=D3D12_ROOT_PARAMETER_TYPE_CBV;params[0].Descriptor.ShaderRegister=0;
        params[1].ParameterType=D3D12_ROOT_PARAMETER_TYPE_DESCRIPTOR_TABLE;
        params[1].DescriptorTable={1,&range};params[1].ShaderVisibility=D3D12_SHADER_VISIBILITY_PIXEL;
        D3D12_STATIC_SAMPLER_DESC sampler{};sampler.Filter=D3D12_FILTER_MIN_MAG_MIP_LINEAR;
        sampler.AddressU=sampler.AddressV=sampler.AddressW=D3D12_TEXTURE_ADDRESS_MODE_CLAMP;
        sampler.MaxLOD=0;sampler.ComparisonFunc=D3D12_COMPARISON_FUNC_ALWAYS;sampler.ShaderVisibility=D3D12_SHADER_VISIBILITY_PIXEL;
        D3D12_ROOT_SIGNATURE_DESC rd{2,params,1,&sampler,D3D12_ROOT_SIGNATURE_FLAG_ALLOW_INPUT_ASSEMBLER_INPUT_LAYOUT};
        ComPtr<ID3DBlob> blob,error;
        check(D3D12SerializeRootSignature(&rd,D3D_ROOT_SIGNATURE_VERSION_1,&blob,&error),"Serialize root signature");
        check(device->CreateRootSignature(0,blob->GetBufferPointer(),blob->GetBufferSize(),IID_PPV_ARGS(&root)),"Root signature");
        auto compile=[&](const char* entry,const char* profile) {
            ComPtr<ID3DBlob> code,err;
            HRESULT hr=D3DCompileFromFile(shader.c_str(),nullptr,D3D_COMPILE_STANDARD_FILE_INCLUDE,entry,profile,
                D3DCOMPILE_ENABLE_STRICTNESS,0,&code,&err);
            if(FAILED(hr) && err) std::cerr<<static_cast<const char*>(err->GetBufferPointer());
            check(hr,"Compile viewport HLSL");return code;
        };
        auto vs=compile("VSMain","vs_5_0"),ps=compile("PSMain","ps_5_0");
        D3D12_INPUT_ELEMENT_DESC input[]={
            {"POSITION",0,DXGI_FORMAT_R32G32B32_FLOAT,0,0,D3D12_INPUT_CLASSIFICATION_PER_VERTEX_DATA,0},
            {"NORMAL",0,DXGI_FORMAT_R32G32B32_FLOAT,0,12,D3D12_INPUT_CLASSIFICATION_PER_VERTEX_DATA,0},
            {"TANGENT",0,DXGI_FORMAT_R32G32B32_FLOAT,0,24,D3D12_INPUT_CLASSIFICATION_PER_VERTEX_DATA,0},
            {"TEXCOORD",0,DXGI_FORMAT_R32G32_FLOAT,0,36,D3D12_INPUT_CLASSIFICATION_PER_VERTEX_DATA,0}};
        D3D12_GRAPHICS_PIPELINE_STATE_DESC p{};p.pRootSignature=root.Get();
        p.VS={vs->GetBufferPointer(),vs->GetBufferSize()};p.PS={ps->GetBufferPointer(),ps->GetBufferSize()};
        p.InputLayout={input,4};p.SampleMask=UINT_MAX;p.PrimitiveTopologyType=D3D12_PRIMITIVE_TOPOLOGY_TYPE_TRIANGLE;
        p.RasterizerState.FillMode=D3D12_FILL_MODE_SOLID;p.RasterizerState.CullMode=D3D12_CULL_MODE_NONE;p.RasterizerState.DepthClipEnable=TRUE;
        p.DepthStencilState.DepthEnable=FALSE;p.DepthStencilState.StencilEnable=FALSE;
        auto& blend=p.BlendState.RenderTarget[0];blend.BlendEnable=TRUE;
        blend.SrcBlend=D3D12_BLEND_SRC_ALPHA;blend.DestBlend=D3D12_BLEND_INV_SRC_ALPHA;blend.BlendOp=D3D12_BLEND_OP_ADD;
        blend.SrcBlendAlpha=D3D12_BLEND_ONE;blend.DestBlendAlpha=D3D12_BLEND_INV_SRC_ALPHA;blend.BlendOpAlpha=D3D12_BLEND_OP_ADD;
        blend.RenderTargetWriteMask=D3D12_COLOR_WRITE_ENABLE_ALL;
        p.NumRenderTargets=1;p.RTVFormats[0]=DXGI_FORMAT_R16G16B16A16_FLOAT;p.SampleDesc.Count=1;
        check(device->CreateGraphicsPipelineState(&p,IID_PPV_ARGS(&hairPSO)),"Hair PSO");
        vs=compile("FullscreenVS","vs_5_0");ps=compile("DisplayPS","ps_5_0");
        p.VS={vs->GetBufferPointer(),vs->GetBufferSize()};p.PS={ps->GetBufferPointer(),ps->GetBufferSize()};
        p.InputLayout={nullptr,0};blend.BlendEnable=FALSE;p.RTVFormats[0]=DXGI_FORMAT_R8G8B8A8_UNORM;
        check(device->CreateGraphicsPipelineState(&p,IID_PPV_ARGS(&displayPSO)),"Display PSO");
    }
    void loadMap(const fs::path& path,UINT slot) {
        ComPtr<IWICBitmapDecoder> decoder;ComPtr<IWICBitmapFrameDecode> frame;ComPtr<IWICFormatConverter> converter;
        check(wic->CreateDecoderFromFilename(path.c_str(),nullptr,GENERIC_READ,WICDecodeMetadataCacheOnLoad,&decoder),"Decode atlas PNG");
        check(decoder->GetFrame(0,&frame),"PNG frame");check(wic->CreateFormatConverter(&converter),"PNG converter");
        check(converter->Initialize(frame.Get(),GUID_WICPixelFormat32bppRGBA,WICBitmapDitherTypeNone,nullptr,0,WICBitmapPaletteTypeCustom),"Convert RGBA");
        UINT w,h;check(converter->GetSize(&w,&h),"PNG dimensions");
        if(w!=atlasSize || h!=atlasSize) throw std::runtime_error("Atlas dimensions differ from snapshot");
        std::vector<BYTE> pixels(size_t(w)*h*4);check(converter->CopyPixels(nullptr,w*4,UINT(pixels.size()),pixels.data()),"PNG pixels");
        auto td=texture(w,h,DXGI_FORMAT_R8G8B8A8_UNORM);
        maps[slot]=resource(td,D3D12_HEAP_TYPE_DEFAULT,D3D12_RESOURCE_STATE_COPY_DEST);
        D3D12_PLACED_SUBRESOURCE_FOOTPRINT foot{};UINT64 size;
        device->GetCopyableFootprints(&td,0,1,0,&foot,nullptr,nullptr,&size);
        auto upload=resource(buffer(size),D3D12_HEAP_TYPE_UPLOAD,D3D12_RESOURCE_STATE_GENERIC_READ);
        BYTE* ptr;D3D12_RANGE empty{0,0};check(upload->Map(0,&empty,reinterpret_cast<void**>(&ptr)),"Map texture upload");
        for(UINT y=0;y<h;++y) memcpy(ptr+foot.Offset+size_t(y)*foot.Footprint.RowPitch,pixels.data()+size_t(y)*w*4,w*4);
        upload->Unmap(0,nullptr);begin();
        D3D12_TEXTURE_COPY_LOCATION dst{};dst.pResource=maps[slot].Get();dst.Type=D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
        D3D12_TEXTURE_COPY_LOCATION src{};src.pResource=upload.Get();src.Type=D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;src.PlacedFootprint=foot;
        list->CopyTextureRegion(&dst,0,0,0,&src,nullptr);
        barrier(maps[slot].Get(),D3D12_RESOURCE_STATE_COPY_DEST,D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE);submit();
        D3D12_SHADER_RESOURCE_VIEW_DESC sd{};sd.Format=slot==0?DXGI_FORMAT_R8G8B8A8_UNORM_SRGB:DXGI_FORMAT_R8G8B8A8_UNORM;
        sd.ViewDimension=D3D12_SRV_DIMENSION_TEXTURE2D;sd.Shader4ComponentMapping=D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;sd.Texture2D.MipLevels=1;
        device->CreateShaderResourceView(maps[slot].Get(),&sd,cpu(srv.Get(),slot,srvStep));
    }
    void render(const fs::path& capture={}) {
        if(sweep) azimuth=std::remainder(azimuth+.3f,360.f);
        const float cp=cosf(pitch),sp=sinf(pitch),cy=cosf(yaw),sy=sinf(yaw);
        XMFLOAT3 eye{target.x+distance*sy*cp,target.y+distance*sp,target.z+distance*cy*cp};
        auto view=XMMatrixLookAtRH(XMLoadFloat3(&eye),XMLoadFloat3(&target),XMVectorSet(0,1,0,0));
        auto projection=XMMatrixPerspectiveFovRH(XM_PIDIV4,float(width)/height,.01f,1000.f);
        Frame f{};XMStoreFloat4x4(&f.vp,view*projection);f.eye={eye.x,eye.y,eye.z,1};
        float a=XMConvertToRadians(azimuth),e=XMConvertToRadians(elevation);
        f.light={sinf(a)*cosf(e),sinf(e),cosf(a)*cosf(e),0};
        // Back-to-front triangle centroid sort: known intersections/order limits.
        std::vector<size_t> order(vertices.size()/3);std::iota(order.begin(),order.end(),0);
        XMFLOAT3 forward{target.x-eye.x,target.y-eye.y,target.z-eye.z};
        auto depth=[&](size_t i) { float d=0;for(int j=0;j<3;++j) {
            auto p=vertices[3*i+j].p;d+=(p.x-eye.x)*forward.x+(p.y-eye.y)*forward.y+(p.z-eye.z)*forward.z;
        }return d;};
        std::stable_sort(order.begin(),order.end(),[&](size_t a,size_t b){return depth(a)>depth(b);});
        for(size_t i=0;i<order.size();++i) for(int j=0;j<3;++j) sorted[i*3+j]=vertices[order[i]*3+j];
        void* ptr;D3D12_RANGE empty{0,0};check(vb->Map(0,&empty,&ptr),"Map vertex buffer");
        memcpy(ptr,sorted.data(),sorted.size()*sizeof(Vertex));vb->Unmap(0,nullptr);
        check(cb->Map(0,&empty,&ptr),"Map constants");memcpy(ptr,&f,sizeof(f));cb->Unmap(0,nullptr);
        begin();list->EndQuery(timestamps.Get(),D3D12_QUERY_TYPE_TIMESTAMP,0);
        barrier(linear.Get(),D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE,D3D12_RESOURCE_STATE_RENDER_TARGET);
        auto lr=cpu(rtv.Get(),2,rtvStep);float bg[]={.018f,.023f,.03f,1};list->ClearRenderTargetView(lr,bg,0,nullptr);
        list->OMSetRenderTargets(1,&lr,FALSE,nullptr);
        D3D12_VIEWPORT vp{0,0,float(width),float(height),0,1};D3D12_RECT rect{0,0,LONG(width),LONG(height)};
        list->RSSetViewports(1,&vp);list->RSSetScissorRects(1,&rect);
        list->SetGraphicsRootSignature(root.Get());ID3D12DescriptorHeap* heaps[]={srv.Get()};list->SetDescriptorHeaps(1,heaps);
        list->SetGraphicsRootConstantBufferView(0,cb->GetGPUVirtualAddress());list->SetGraphicsRootDescriptorTable(1,gpu(0));
        list->SetPipelineState(hairPSO.Get());list->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
        D3D12_VERTEX_BUFFER_VIEW bv{vb->GetGPUVirtualAddress(),UINT(vertices.size()*sizeof(Vertex)),sizeof(Vertex)};
        list->IASetVertexBuffers(0,1,&bv);list->DrawInstanced(UINT(vertices.size()),1,0,0);
        barrier(linear.Get(),D3D12_RESOURCE_STATE_RENDER_TARGET,D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE);
        UINT index=swap->GetCurrentBackBufferIndex();
        barrier(back[index].Get(),D3D12_RESOURCE_STATE_PRESENT,D3D12_RESOURCE_STATE_RENDER_TARGET);
        auto br=cpu(rtv.Get(),index,rtvStep);list->OMSetRenderTargets(1,&br,FALSE,nullptr);
        list->SetPipelineState(displayPSO.Get());list->SetGraphicsRootDescriptorTable(1,gpu(5));list->DrawInstanced(3,1,0,0);
        list->EndQuery(timestamps.Get(),D3D12_QUERY_TYPE_TIMESTAMP,1);
        list->ResolveQueryData(timestamps.Get(),D3D12_QUERY_TYPE_TIMESTAMP,0,2,timingReadback.Get(),0);
        ComPtr<ID3D12Resource> readback;D3D12_PLACED_SUBRESOURCE_FOOTPRINT foot{};
        if(!capture.empty()) {
            auto desc=back[index]->GetDesc();UINT64 bytes;
            device->GetCopyableFootprints(&desc,0,1,0,&foot,nullptr,nullptr,&bytes);
            readback=resource(buffer(bytes),D3D12_HEAP_TYPE_READBACK,D3D12_RESOURCE_STATE_COPY_DEST);
            barrier(back[index].Get(),D3D12_RESOURCE_STATE_RENDER_TARGET,D3D12_RESOURCE_STATE_COPY_SOURCE);
            D3D12_TEXTURE_COPY_LOCATION src{};src.pResource=back[index].Get();src.Type=D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
            D3D12_TEXTURE_COPY_LOCATION dst{};dst.pResource=readback.Get();dst.Type=D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;dst.PlacedFootprint=foot;
            list->CopyTextureRegion(&dst,0,0,0,&src,nullptr);
            barrier(back[index].Get(),D3D12_RESOURCE_STATE_COPY_SOURCE,D3D12_RESOURCE_STATE_PRESENT);
        } else barrier(back[index].Get(),D3D12_RESOURCE_STATE_RENDER_TARGET,D3D12_RESOURCE_STATE_PRESENT);
        submit();check(swap->Present(1,0),"Present");
        UINT64* ticks;D3D12_RANGE read{0,16};check(timingReadback->Map(0,&read,reinterpret_cast<void**>(&ticks)),"Map timestamps");
        gpuTimes.push_back(double(ticks[1]-ticks[0])*1000/double(frequency));timingReadback->Unmap(0,&empty);
        if(readback) {
            BYTE* pixels;D3D12_RANGE r{0,SIZE_T(foot.Footprint.RowPitch)*height};
            check(readback->Map(0,&r,reinterpret_cast<void**>(&pixels)),"Map capture");
            std::ofstream out(capture,std::ios::binary);out<<"P6\n"<<width<<" "<<height<<"\n255\n";
            for(UINT y=0;y<height;++y)for(UINT x=0;x<width;++x)
                out.write(reinterpret_cast<char*>(pixels+foot.Offset+size_t(y)*foot.Footprint.RowPitch+x*4),3);
            readback->Unmap(0,&empty);if(!out) throw std::runtime_error("Capture write failed");
        }
        wchar_t title[256];swprintf_s(title,L"FSD D3D12 | GPU %.2f ms | Light %.0f / %.0f | Alt+LMB orbit; Alt+MMB pan; Alt+RMB zoom; Shift+RMB light",
            gpuTimes.back(),azimuth,elevation);SetWindowTextW(window,title);
    }
    void report() {
        if(gpuTimes.empty()) return;
        auto samples=gpuTimes;if(samples.size()>10)samples.erase(samples.begin(),samples.begin()+10);
        std::sort(samples.begin(),samples.end());
        auto p=[&](double q){return samples[size_t(std::ceil(q*samples.size()))-1];};
        std::cout<<"GPU timestamps ms (hair + display only, excludes Present, CPU sort, uploads): mean="
            <<std::accumulate(samples.begin(),samples.end(),0.)/samples.size()<<" P95="<<p(.95)<<" P99="<<p(.99)<<" samples="<<samples.size()<<"\n";
        ComPtr<IDXGIAdapter3> a;if(SUCCEEDED(adapter.As(&a))) {
            DXGI_QUERY_VIDEO_MEMORY_INFO m{};
            if(SUCCEEDED(a->QueryVideoMemoryInfo(0,DXGI_MEMORY_SEGMENT_GROUP_LOCAL,&m)))
                std::cout<<"DXGI process local usage MiB="<<m.CurrentUsage/1048576<<" budget MiB="<<m.Budget/1048576<<"\n";
        }
    }
    static LRESULT CALLBACK wndproc(HWND hwnd,UINT msg,WPARAM w,LPARAM l) {
        auto self=reinterpret_cast<Viewport*>(GetWindowLongPtrW(hwnd,GWLP_USERDATA));
        if(msg==WM_NCCREATE) {self=static_cast<Viewport*>(reinterpret_cast<CREATESTRUCTW*>(l)->lpCreateParams);SetWindowLongPtrW(hwnd,GWLP_USERDATA,reinterpret_cast<LONG_PTR>(self));}
        if(!self) return DefWindowProcW(hwnd,msg,w,l);
        switch(msg) {
        case WM_CLOSE:ShowWindow(hwnd,SW_HIDE);PostQuitMessage(0);return 0;
        case WM_SIZE:self->minimized=w==SIZE_MINIMIZED;return 0; // Resize safely in main loop.
        case WM_LBUTTONDOWN:case WM_MBUTTONDOWN:case WM_RBUTTONDOWN:
            if(self->navigation || self->dragLight)return 0;
            if(GetKeyState(VK_MENU)&0x8000) {
                self->navigation=msg==WM_LBUTTONDOWN?1:msg==WM_MBUTTONDOWN?2:3;
                self->last={GET_X_LPARAM(l),GET_Y_LPARAM(l)};SetCapture(hwnd);
            } else if(msg==WM_RBUTTONDOWN && (w&MK_SHIFT)) {
                self->dragLight=true;self->sweep=false;
                self->last={GET_X_LPARAM(l),GET_Y_LPARAM(l)};SetCapture(hwnd);
            }
            return 0;
        case WM_MOUSEMOVE: {
            POINT p{GET_X_LPARAM(l),GET_Y_LPARAM(l)};float dx=float(p.x-self->last.x),dy=float(p.y-self->last.y);
            if(self->dragLight) {self->azimuth=std::remainder(self->azimuth+dx*.42f,360.f);self->elevation=std::clamp(self->elevation-dy*.42f,-85.f,85.f);}
            else if(self->navigation==1) {self->yaw-=dx*.007f;self->pitch=std::clamp(self->pitch+dy*.007f,-1.4f,1.4f);}
            else if(self->navigation==2) {
                float scale=2*self->distance*tanf(XM_PI/8)/std::max(1u,self->height);
                float sy=sinf(self->yaw),cy=cosf(self->yaw),sp=sinf(self->pitch),cp=cosf(self->pitch);
                self->target.x+=(-dx*cy-dy*sy*sp)*scale;
                self->target.y+=dy*cp*scale;
                self->target.z+=(dx*sy-dy*cy*sp)*scale;
            } else if(self->navigation==3)self->distance=std::clamp(self->distance*expf(std::clamp(-dx*.01f,-20.f,20.f)),.05f,500.f);
            self->last=p;return 0;
        }
        case WM_LBUTTONUP:case WM_MBUTTONUP:case WM_RBUTTONUP:ReleaseCapture();self->navigation=0;self->dragLight=false;return 0;
        case WM_CAPTURECHANGED:case WM_KILLFOCUS:self->navigation=0;self->dragLight=false;return 0;
        case WM_MOUSEWHEEL:self->distance=std::clamp(self->distance*std::pow(.9f,GET_WHEEL_DELTA_WPARAM(w)/120.f),.05f,500.f);return 0;
        case WM_KEYDOWN:
            if(w=='S')self->sweep=!self->sweep;
            if(w=='R'){self->azimuth=40;self->elevation=54;self->sweep=false;}
            if(w==VK_ESCAPE)PostQuitMessage(0);return 0;
        }
        return DefWindowProcW(hwnd,msg,w,l);
    }
};

int wmain(int argc,wchar_t** argv) {
    HRESULT co=CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);
    if(FAILED(co)) {std::cerr<<"COM initialization failed\n";return 1;}
    int result=0;
    try {
        Viewport app;fs::path scene,capture;int adapter=0,frames=0;bool warp=false,list=false,hidden=false;
        for(int i=1;i<argc;++i) {
            std::wstring arg=argv[i];
            if(arg==L"--scene" && i+1<argc)scene=argv[++i];
            else if(arg==L"--capture" && i+1<argc)capture=argv[++i];
            else if(arg==L"--frames" && i+1<argc){frames=std::stoi(argv[++i]);if(frames<1)throw std::runtime_error("frames must be positive");}
            else if(arg==L"--adapter" && i+1<argc)adapter=std::stoi(argv[++i]);
            else if(arg==L"--light-azimuth" && i+1<argc)app.azimuth=std::stof(argv[++i]);
            else if(arg==L"--light-elevation" && i+1<argc)app.elevation=std::stof(argv[++i]);
            else if(arg==L"--yaw" && i+1<argc)app.yaw=std::stof(argv[++i]);
            else if(arg==L"--width" && i+1<argc)app.width=std::stoul(argv[++i]);
            else if(arg==L"--height" && i+1<argc)app.height=std::stoul(argv[++i]);
            else if(arg==L"--warp")warp=true;
            else if(arg==L"--list-adapters")list=true;
            else if(arg==L"--hidden")hidden=true;
            else if(arg==L"--debug")app.debug=true;
            else throw std::runtime_error("Unknown/missing argument; use --scene snapshot/scene.fsdn [--frames N --capture output.ppm --hidden --adapter N --debug]");
        }
        if(hidden && !frames && !list)throw std::runtime_error("Hidden mode requires bounded --frames");
        if(app.width<32 || app.width>8192 || app.height<32 || app.height>8192 ||
           !std::isfinite(app.azimuth) || !std::isfinite(app.elevation) || !std::isfinite(app.yaw))
            throw std::runtime_error("Invalid dimensions or non-finite camera/light");
        if(!list) {if(scene.empty())throw std::runtime_error("--scene required");app.loadScene(scene);}
        wchar_t exe[32768];DWORD n=GetModuleFileNameW(nullptr,exe,32768);if(!n || n>=32768)throw std::runtime_error("Executable path");
        app.init(adapter,warp,list,exe);
        if(!list) {
            const wchar_t* names[]={L"color.png",L"alpha.png",L"normal.png",L"flow.png",L"roughness.png"};
            for(UINT i=0;i<5;++i)app.loadMap(scene.parent_path()/names[i],i);
            if(!hidden)ShowWindow(app.window,SW_SHOW);
            MSG msg{};int rendered=0;
            while(msg.message!=WM_QUIT && (!frames || rendered<frames)) {
                while(PeekMessageW(&msg,nullptr,0,0,PM_REMOVE)){if(msg.message==WM_QUIT)break;TranslateMessage(&msg);DispatchMessageW(&msg);}
                if(msg.message==WM_QUIT)break;
                if(app.minimized){MsgWaitForMultipleObjects(0,nullptr,FALSE,100,QS_ALLINPUT);continue;}
                RECT rect;GetClientRect(app.window,&rect);app.resize(rect.right,rect.bottom);
                app.render(frames && rendered==frames-1?capture:fs::path{});++rendered;
            }
            app.report();std::cout<<"Rendered frames="<<rendered<<"\n";
        }
    } catch(const std::exception& e) {std::cerr<<"FSD viewport: "<<e.what()<<"\n";result=1;}
    CoUninitialize();return result;
}
