@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul
if errorlevel 1 (
  echo CMake 3.20+ required with MSVC C++ workload and Windows SDK.
  exit /b 1
)
cmake -S . -B build -A x64 || exit /b 1
cmake --build build --config Release || exit /b 1
build\Release\fsd_d3d12_viewport.exe --list-adapters || exit /b 1
ctest --test-dir build -C Release --output-on-failure || exit /b 1
echo FSD Native D3D12 viewport smoke and compute probes PASSED.
endlocal
