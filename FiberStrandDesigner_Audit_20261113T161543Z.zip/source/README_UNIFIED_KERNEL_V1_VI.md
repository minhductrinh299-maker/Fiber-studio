# Fiber Unified Kernel V1 — bản tích hợp

Mở `run_windows.bat`; không cần build EXE. Thư viện FBX Windows x64 đã nằm trong
`fiberstrand/native/fsd_fbx.dll`; khách hàng không cần Blender hay MSVC.

Trong **Card Editor 3D → Unified Fiber Tools…**:

- **Guides**: vẽ bằng cách click điểm trong viewport, Enter để nhận, Escape để hủy;
  sửa control points; dùng chung guide; Make Unique; parent theo u; nội suy;
  tạo guide từ chuỗi cạnh mesh nhập vào. Groom và Clump có tham số nguồn.
- **Surface**: profile trái/phải, twist, camber, cupping, offset và edge. Có thể
  nhập mảng giá trị hoặc `{ "knots": [0, 0.35, 1], "values": [1, 2, 0.2] }`.
  Đổi cả Segments và Width Segments trong Card Properties. Nét sculpt được giữ
  bằng lớp biến dạng liên tục, không gắn cứng với chỉ số vertex hiện tại.
- **Modifiers**: thêm Transform/Deform/Twist/Profile; bật/tắt, sửa, đổi thứ tự,
  Freeze và Restore source. Mỗi lần Apply có thể Undo/Redo bằng lịch sử project.
- **Assemblies**: Hair / Fur / Free Fiber / Feather cùng dùng guide và strand
  structure. Feather có rachis, barb và barbule phân cấp. Tạo assembly, sinh
  card, phân bố lên mesh hoặc gửi sang tile / Construction Graph / atlas / baker.
  Có thể nhận ngược dữ liệu từ Graph/Fiber Studio và chuyển guide của card sang
  strand assembly. Tác vụ tạo nhiều nguồn chạy nền; kết quả cũ bị loại nếu scene
  đã đổi trước khi công bố. Đợi dòng trạng thái hoàn tất rồi dùng bước kế tiếp.
- **Attachments**: chọn target object, Free/Object/Surface/Skinned/Joint. Bind giữ
  placement hiện tại; Remap thay anchor khi đổi topology; Detach giữ bề mặt ở pose
  đang thấy. ID target và tên model hiện bên cạnh bộ chọn.

Để dùng animation: **Outliner → chọn các part của FBX → Enable Selected FBX
Sources → Play / timeline**. Skinned attachment bám vào tam giác đã biến dạng,
không chỉ transform object. Joint: nhập tên/path, Fetch joint pose rồi Bind.
Bật nguồn animation trước khi lấy pose. Khi save `.fsd`, FBX animation và texture
được đóng gói kèm checksum; không phụ thuộc đường dẫn cũ sau khi mở lại.

Chuyển assembly sang tile là phép chiếu 3D → XY được khai báo rõ; nguồn 3D giữ
nguyên trong registry. Depth thay đổi dọc sợi đi vào truth/bake. Profile quang học
đi theo nguồn strand; không lấy normal/depth/AO bằng cách suy ngược từ ảnh màu.

Giới hạn và số đo thực thi nằm trong `docs/UNIFIED_KERNEL_V1_STATUS.md` và
`docs/KERNEL_GPU_MEASUREMENT.json`. Đây là bản phát triển tích hợp, không phải
chứng nhận hiệu năng trên mọi GPU hay mọi biến thể FBX.
