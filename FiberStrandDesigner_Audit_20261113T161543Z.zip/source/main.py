"""Windows GUI entry point for Fiber Strand Designer.
Supports dual-mode startup:
- Default / --qt: Launches modern Qt 6 / PySide6 UI.
- --legacy / --tk: Launches original Tkinter UI for regression verification.
"""
import sys
from pathlib import Path

WORKSPACE_ROOT = Path(__file__).resolve().parent
if str(WORKSPACE_ROOT) not in sys.path:
    sys.path.insert(0, str(WORKSPACE_ROOT))

if __name__ == '__main__':
    from fiberstrand.gpu_bootstrap import maybe_launch_private_host
    gpu_exit = maybe_launch_private_host(WORKSPACE_ROOT)
    if gpu_exit is not None:
        raise SystemExit(gpu_exit)

def run():
    # Detect launcher flags
    args = [a.lower() for a in sys.argv[1:]]
    use_legacy = '--legacy' in args or '--tk' in args or '--tkinter' in args
    
    if use_legacy:
        from fiberstrand.dpi import enable_high_dpi
        enable_high_dpi()  # before importing/creating any Tk HWND
        from fiberstrand.ui import run as run_tk
        run_tk()
    else:
        from main_qt import run_qt
        sys.exit(run_qt())

if __name__ == "__main__":
    run()

