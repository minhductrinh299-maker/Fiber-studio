Lucide Icons — https://github.com/lucide-icons/lucide
Retrieved 2026-11-13. SVG sources from main and tag 0.468.0 (for renamed aliases).
Original source files, full ISC/MIT notices in LICENSE.
Bundled locally; no network or added Python dependency at app startup.
