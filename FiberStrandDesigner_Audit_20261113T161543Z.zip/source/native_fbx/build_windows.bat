@echo off
setlocal
cd /d "%~dp0"
if /I not "%VSCMD_ARG_TGT_ARCH%"=="x64" (
  if exist "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" (
    call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
  ) else if exist "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" (
    call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
  )
)
where cl >nul 2>nul
if errorlevel 1 (echo MSVC x64 C/C++ compiler required to rebuild DLL. & exit /b 1)
if /I not "%VSCMD_ARG_TGT_ARCH%"=="x64" (echo Use an x64 MSVC developer environment. & exit /b 1)
if not exist build mkdir build
if not exist ..\fiberstrand\native mkdir ..\fiberstrand\native
cl /nologo /O2 /MT /TC /c ..\vendor\ufbx\ufbx.c /Fobuild\ufbx.obj || exit /b 1
cl /nologo /O2 /MT /EHsc /std:c++17 /LD /I..\vendor\ufbx fsd_fbx.cpp build\ufbx.obj /Fobuild\fsd_fbx.obj /link /OUT:..\fiberstrand\native\fsd_fbx.dll /IMPLIB:build\fsd_fbx.lib || exit /b 1
echo FBX reader DLL compiled. No application or importer tests executed.
endlocal
