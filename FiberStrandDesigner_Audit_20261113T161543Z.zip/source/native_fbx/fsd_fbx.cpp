// Narrow, versioned C ABI: no Python SDK, Blender, Autodesk SDK or JSON library.
#include "ufbx.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <map>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#define API extern "C" __declspec(dllexport)
struct Texture { std::string path; const void *bytes=nullptr; uint64_t size=0; };
struct Mesh {
    std::string name; std::vector<float> data;
    float color[3]={.48f,.50f,.54f}, roughness=.55f;
    Texture textures[8]; uint32_t flags=0;
};
struct Scene {
    ufbx_scene *source=nullptr; std::vector<Mesh> meshes;
    ~Scene(){ if(source) ufbx_free_scene(source); }
};
struct View {
    const char *name; const float *data; uint64_t corners;
    float color[3]; float roughness;
    const char *paths[8]; const void *content[8]; uint64_t sizes[8];
    uint32_t flags;
};
static std::string str(ufbx_string s){ return std::string(s.data?s.data:"",s.length); }
static void fail(char *dst,uint64_t size,const char *message){
    if(dst && size) std::snprintf(dst,(size_t)size,"%s",message);
}
static const ufbx_material_map *choose(const ufbx_material_map &a,const ufbx_material_map &b){
    return a.texture && a.texture_enabled ? &a : &b;
}
static void texture(Texture &dst,const ufbx_material_map *map,uint32_t &flags){
    if(!map || !map->texture || !map->texture_enabled) return;
    ufbx_texture *tex=map->texture;
    if(tex->file_textures.count>1) flags|=1; // Unbaked layered graph: report simplification.
    if(tex->type!=UFBX_TEXTURE_FILE){
        if(!tex->file_textures.count){ flags|=1;return; }
        tex=tex->file_textures.data[0];
    }
    if(tex->has_uv_transform || tex->uv_set.length) flags|=2;
    dst.path=str(tex->relative_filename.length?tex->relative_filename:tex->filename);
    if(dst.path.empty()) dst.path=str(tex->absolute_filename);
    if(tex->content.size>128ull*1024*1024) throw std::runtime_error("Embedded FBX texture exceeds 128 MiB");
    dst.bytes=tex->content.data;dst.size=(uint64_t)tex->content.size;
}
static void material(Mesh &out,ufbx_material *m){
    if(!m) return;
    auto &p=m->pbr; auto &f=m->fbx;
    const ufbx_material_map &base=p.base_color.has_value?p.base_color:f.diffuse_color;
    if(base.has_value){
        out.color[0]=(float)base.value_vec3.x;out.color[1]=(float)base.value_vec3.y;out.color[2]=(float)base.value_vec3.z;
    }
    if(p.roughness.has_value) out.roughness=(float)std::clamp((double)p.roughness.value_real,.03,1.);
    else if(f.specular_exponent.has_value) out.roughness=(float)std::sqrt(2./(std::max(0.,(double)f.specular_exponent.value_real)+2.));
    const ufbx_material_map *maps[8]={choose(p.base_color,f.diffuse_color),choose(p.normal_map,f.normal_map),
        &p.roughness,&p.opacity,choose(p.specular_color,f.specular_color),&p.metalness,&p.ambient_occlusion,choose(p.emission_color,f.emission_color)};
    for(int i=0;i<8;i++) texture(out.textures[i],maps[i],out.flags);
    // Shader nodes, UV transforms and animation are not silently reconstructed.
    if(p.opacity.has_value && p.opacity.value_real<.999) out.flags|=4;
}
static std::string node_path(const ufbx_node *node){
    std::string path=str(node->name);
    for(auto parent=node->parent;parent && parent->parent;parent=parent->parent)
        path=str(parent->name)+"/"+path;
    return path;
}
static void flatten(Scene &result,uint64_t max_triangles,bool posed,const ufbx_scene *rest=nullptr){
        uint64_t total=0;
        for(size_t ni=0;ni<result.source->nodes.count;ni++){
            ufbx_node *node=result.source->nodes.data[ni];ufbx_mesh *mesh=node->mesh;
            if(!mesh || !mesh->num_triangles)continue;
            if(mesh->num_triangles>max_triangles-total)throw std::runtime_error("FBX exceeds import triangle budget");
            total+=mesh->num_triangles;
            if(mesh->max_face_triangles>max_triangles)throw std::runtime_error("FBX polygon exceeds triangulation budget");
            std::vector<uint32_t> indices(mesh->max_face_triangles*3);
            ufbx_matrix transform=node->geometry_to_world;
            ufbx_matrix normals=ufbx_matrix_for_normals(&transform);
            const ufbx_matrix &winding=(rest && ni<rest->nodes.count)?rest->nodes.data[ni]->geometry_to_world:transform;
            bool mirrored=ufbx_matrix_determinant(&winding)<0.;
            std::map<uint32_t,size_t> parts;
            for(size_t fi=0;fi<mesh->faces.count;fi++){
                ufbx_face face=mesh->faces.data[fi];if(face.num_indices<3)continue;
                uint32_t slot=fi<mesh->face_material.count?mesh->face_material.data[fi]:0;
                if(!parts.count(slot)){
                    if(result.meshes.size()>=4096)throw std::runtime_error("FBX exceeds 4096 mesh/material parts");
                    size_t index=result.meshes.size();parts[slot]=index;result.meshes.emplace_back();
                    Mesh &out=result.meshes.back();out.name=node_path(node);
                    ufbx_material *mat=slot<node->materials.count?node->materials.data[slot]:nullptr;
                    if(mat && mat->name.length)out.name+=" / "+str(mat->name);
                    material(out,mat);
                    if(mesh->skin_deformers.count || mesh->blend_deformers.count)out.flags|=8;
                }
                Mesh &out=result.meshes[parts[slot]];
                ufbx_mesh *rest_mesh=(rest && ni<rest->nodes.count)?rest->nodes.data[ni]->mesh:mesh;
                uint32_t triangles=ufbx_triangulate_face(indices.data(),indices.size(),rest_mesh,face);
                if(triangles!=face.num_indices-2)throw std::runtime_error("FBX polygon could not be triangulated completely");
                for(uint32_t t=0;t<triangles;t++){
                    for(int v=0;v<3;v++){
                        uint32_t corner=indices[t*3+(mirrored && v>0?3-v:v)];
                        bool skin=posed && mesh->skinned_position.exists;
                        ufbx_vec3 pos=ufbx_get_vertex_vec3(skin?&mesh->skinned_position:&mesh->vertex_position,corner);
                        ufbx_vec3 normal=ufbx_get_vertex_vec3(skin && mesh->skinned_normal.exists?&mesh->skinned_normal:&mesh->vertex_normal,corner);
                        ufbx_vec2 uv={};if(mesh->vertex_uv.exists)uv=ufbx_get_vertex_vec2(&mesh->vertex_uv,corner);
                        if(!skin || mesh->skinned_is_local){pos=ufbx_transform_position(&transform,pos);normal=ufbx_transform_direction(&normals,normal);}
                        double length=std::sqrt(normal.x*normal.x+normal.y*normal.y+normal.z*normal.z);
                        if(length>1e-12){normal.x/=length;normal.y/=length;normal.z/=length;}
                        const float values[8]={(float)pos.x,(float)pos.y,(float)pos.z,(float)normal.x,(float)normal.y,(float)normal.z,(float)uv.x,(float)uv.y};
                        for(float value:values){if(!std::isfinite(value))throw std::runtime_error("FBX contains nonfinite vertex attributes");out.data.push_back(value);}
                    }
                }
            }
        }
        if(!total)throw std::runtime_error("No polygon meshes in FBX");
}
API uint32_t fsd_fbx_abi(){return 1;}
API uint32_t fsd_fbx_library_version(){return UFBX_HEADER_VERSION;}
API void *fsd_fbx_load(const char *path,uint64_t max_triangles,char *error,uint64_t error_size){
    try {
        auto result=std::make_unique<Scene>();
        ufbx_load_opts opts={};
        opts.target_axes=ufbx_axes_right_handed_y_up;opts.target_unit_meters=1.;
        opts.generate_missing_normals=true;opts.ignore_animation=false;
        opts.load_external_files=false;opts.ignore_missing_external_files=true;
        opts.use_blender_pbr_material=true;opts.node_depth_limit=128;
        opts.temp_allocator.memory_limit=512ull*1024*1024;
        opts.result_allocator.memory_limit=512ull*1024*1024;
        ufbx_error load_error={};result->source=ufbx_load_file(path,&opts,&load_error);
        if(!result->source){ufbx_format_error(error,(size_t)error_size,&load_error);return nullptr;}
        flatten(*result,max_triangles,false);
        return result.release();
    }catch(const std::exception &ex){fail(error,error_size,ex.what());return nullptr;}
     catch(...){fail(error,error_size,"Native FBX reader error");return nullptr;}
}
API uint64_t fsd_fbx_mesh_count(void *handle){return handle?((Scene*)handle)->meshes.size():0;}
API int fsd_fbx_mesh(void *handle,uint64_t index,View *view){
    if(!handle || !view || index>=((Scene*)handle)->meshes.size())return 0;
    Mesh &mesh=((Scene*)handle)->meshes[(size_t)index];std::memset(view,0,sizeof(*view));
    view->name=mesh.name.c_str();view->data=mesh.data.data();view->corners=mesh.data.size()/8;
    std::copy(mesh.color,mesh.color+3,view->color);view->roughness=mesh.roughness;view->flags=mesh.flags;
    for(int i=0;i<8;i++){view->paths[i]=mesh.textures[i].path.c_str();view->content[i]=mesh.textures[i].bytes;view->sizes[i]=mesh.textures[i].size;}
    return 1;
}
API void fsd_fbx_free(void *handle){delete (Scene*)handle;}

API void *fsd_fbx_evaluate(void *handle,double seconds,uint64_t max_triangles,char *error,uint64_t error_size){
    try {
        if(!handle || !std::isfinite(seconds))throw std::runtime_error("Invalid animation request");
        Scene *base=(Scene*)handle;auto result=std::make_unique<Scene>();
        ufbx_evaluate_opts opts={};opts.evaluate_skinning=true;
        opts.temp_allocator.memory_limit=512ull*1024*1024;opts.result_allocator.memory_limit=512ull*1024*1024;
        ufbx_error detail={};result->source=ufbx_evaluate_scene(base->source,base->source->anim,seconds,&opts,&detail);
        if(!result->source){ufbx_format_error(error,(size_t)error_size,&detail);return nullptr;}
        flatten(*result,max_triangles,true,base->source);return result.release();
    }catch(const std::exception &ex){fail(error,error_size,ex.what());return nullptr;}
     catch(...){fail(error,error_size,"Native FBX pose evaluation failed");return nullptr;}
}
API int fsd_fbx_time_range(void *handle,double *begin,double *end){
    if(!handle || !begin || !end)return 0;
    auto scene=((Scene*)handle)->source;*begin=scene->anim->time_begin;*end=scene->anim->time_end;return 1;
}
API int fsd_fbx_node_matrix(void *handle,const char *path,double *matrix){
    if(!handle || !path || !matrix)return 0;
    auto scene=((Scene*)handle)->source;
    for(size_t i=0;i<scene->nodes.count;i++){
        auto node=scene->nodes.data[i];
        if(node_path(node)!=path && str(node->name)!=path)continue;
        auto m=node->node_to_world;
        for(int r=0;r<4;r++)for(int c=0;c<4;c++)matrix[r*4+c]=r==3?(c==3?1.:0.):m.v[c*3+r];
        return 1;
    }
    return 0;
}
