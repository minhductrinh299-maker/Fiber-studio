@echo off
setlocal
set "FSD_RENDER_LEGACY=0"
call "%~dp0run_windows.bat"
endlocal
