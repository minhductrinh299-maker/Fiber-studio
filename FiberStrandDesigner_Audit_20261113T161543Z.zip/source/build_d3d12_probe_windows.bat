@echo off
setlocal
cd /d "%~dp0native_d3d12"
call build_and_test_windows.bat
exit /b %errorlevel%
