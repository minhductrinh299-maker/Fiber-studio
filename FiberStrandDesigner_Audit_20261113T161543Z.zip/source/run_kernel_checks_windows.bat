@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (echo Start run_windows.bat first to create the runtime. & exit /b 1)
.venv\Scripts\python.exe -m pip show pytest >nul 2>nul
if errorlevel 1 (echo Install pytest in the venv before running developer checks. & exit /b 1)
.venv\Scripts\python.exe tests\validate_kernel_windows.py
exit /b %errorlevel%
