# Third-Party Licenses and Open Source Software Manifest
# Fiber Strand Designer (FSD) Commercial Distribution

This document details all third-party software, libraries, and frameworks integrated into or bundled with Fiber Strand Designer, including their licensing terms, official sources, and commercial compliance requirements.

---

## 1. GUI Framework: Qt 6 & PySide6

- **Package**: PySide6 (Official Python Bindings for Qt 6)
- **Version**: 6.12.0
- **Upstream Project**: The Qt Company / Qt Project (https://www.qt.io, https://wiki.qt.io/PySide6)
- **License**: **GNU Lesser General Public License version 3 (LGPLv3)** with Qt Company GPL/LGPL exceptions where applicable; parts under BSD-3-Clause.
- **Allowed Usage in Commercial Closed-Source Software**: **YES** (strictly following LGPLv3 obligations).

### LGPLv3 Compliance Architecture in FSD:
1. **Dynamic Linking**: FSD interacts with PySide6 and Qt 6 exclusively through standard Python dynamic imports / C ABI DLL loading. No proprietary FSD C++ or Python source is statically linked into Qt binaries.
2. **User Relink / Replacement Right**: End users and licensees are permitted to inspect, upgrade, or swap any shared Qt/PySide DLLs located within the distribution or Python environment without invalidating the application's license.
3. **No Qt Commercial / GPL-only Modules**: FSD strictly utilizes modules licensed under LGPLv3 (`QtCore`, `QtGui`, `QtWidgets`, `QtSvg`, `QtOpenGL`, `QtOpenGLWidgets`). Proprietary/Commercial-only or GPL-only Qt components (such as Qt Quick 3D Commercial or Qt Charts GPL-only) are excluded.
4. **License Distribution**: Full texts of the LGPLv3 and GPLv3 are provided in `LICENSE_COMPLIANCE.md`.

---

## 2. Core Python Dependencies

| Package | Version | License | Upstream Source | Commercial Closed-Source Use |
| :--- | :--- | :--- | :--- | :--- |
| **Python (CPython)** | 3.14.6 | Python Software Foundation License (PSFL) | https://www.python.org | Allowed (BSD-compatible) |
| **NumPy** | 2.x | BSD-3-Clause | https://numpy.org | Allowed without restriction |
| **Pillow (PIL)** | 12.3.0 | Historical Permission Notice and Disclaimer (HPND) | https://python-pillow.org | Allowed (MIT/BSD-compatible) |
| **shiboken6** | 6.12.0 | LGPLv3 / BSD-3-Clause | https://wiki.qt.io/PySide6 | Allowed (dynamic link) |

---

## 3. Native Graphics & 3D Import Libraries

| Library | Version | License | Upstream Source | Commercial Closed-Source Use |
| :--- | :--- | :--- | :--- | :--- |
| **ufbx** | 0.23.1 | MIT License | https://github.com/bqqbarbhg/ufbx | Allowed without restriction |
| **Direct3D 12 / DXGI** | Windows 10/11 SDK | Microsoft Windows SDK License | https://developer.microsoft.com | Native Windows OS Runtime |
| **OpenGL / WGL** | Khronos Group | Permissive / Native Driver ABI | https://www.khronos.org | Native GPU Driver ABI |

---

## 4. Proprietary FSD Components

All proprietary algorithms, neural/procedural hair solvers, Marschner hair shading shaders, ribbon generators, and application shell code authored for Fiber Strand Designer remain the exclusive intellectual property of the author/company and are closed-source.


## Qt migration dependency scope (2026-11-13)
Qt frontend imports QtCore, QtGui and QtWidgets from PySide6. requirements.txt uses
PySide6-Essentials; no QtCharts / QtDataVisualization / QtVirtualKeyboard or other
GPL-only addon API is intentionally introduced by this stabilization work.
PySide6 community distribution has LGPLv3/GPL options; proprietary application
shipping under LGPL requires complying with those terms. Do not statically bundle
Qt or omit required Qt/PySide notices/source-access/replacement rights. Existing
EXE build script edits have NOT been executed or certified for distribution.
Sources: https://doc.qt.io/qt-6/licensing.html and
https://www.qt.io/development/open-source-lgpl-obligations


## Lucide UI icons (Quiet Graphite redesign)

Local SVG subset in `assets/icons/lucide`. Source: https://github.com/lucide-icons/lucide .
ISC / MIT notices are reproduced in `assets/icons/lucide/LICENSE`; retain this file when redistributing.
No runtime download or icon service is used.
