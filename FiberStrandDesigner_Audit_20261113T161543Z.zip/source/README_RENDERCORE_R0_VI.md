# Fiber Strand Designer v1.3 — GPU RenderCore R0/R1 Preview

## Trạng thái và mục tiêu

Đây là bản **GPU renderer thử nghiệm có thể chạy**, tích hợp vào mã nguồn Fiber Strand Designer v1.2 (Construction Graph V4). Chức năng lõi dùng OpenGL 3.3, shader GLSL và bộ nạp OpenGL qua `ctypes` của Python, **không phải** bộ dựng Direct3D 12/C++ thương mại đã thiết kế. Kiến trúc context/GPU/resource được tách thành module `fiberstrand/rendercore` để có thể thay thế sau.

Tính năng đã chạy/kiểm thử trong môi trường Linux Mesa (EGL):

- Tạo context GPU OpenGL, biên dịch shader thật và raster hóa card mesh 3D.
- Đọc các map Color+Alpha, Normal, Flow, Roughness từ atlas V4 có sẵn.
- Hair shading xấp xỉ với specular chính/phụ có hướng theo Flow, Roughness, Anisotropy, Sheen và Backlight.
- **Iridescence nghệ thuật** biến đổi theo hướng nhìn và nguồn sáng (chưa phải mô hình giao thoa vật lý).
- **Weighted Blended OIT**: tổng hợp nhiều lớp card alpha bằng hai render target floating-point.
- Hỗ trợ một-pass MRT có blending độc lập nếu driver cung cấp; fallback hai-pass cho GL 3.3.
- Cập nhật texture GPU bằng `glTexSubImage2D` theo hình chữ nhật của tile; không nạp lại atlas khi chỉ đổi geometry/material.
- Shader debug: Rendered, Alpha Coverage, Normal, Fiber Direction, Roughness, Specular, Iridescence.
- Cửa sổ Render Studio: orbit/zoom, light sweep, các tham số material, atlas demo, sync atlas dự án, capture PNG.
- Trên Windows: tạo WGL context trực tiếp trên cửa sổ Tk để hiển thị GPU mà không phải đọc frame từ GPU về CPU mỗi lần.
- Trên Linux: dùng EGL offscreen, đọc ảnh để kiểm thử và hiển thị tham khảo trong Tk (không phải đường render hiệu năng cao).

## Khởi động trên Windows

1. Giải nén toàn bộ ZIP.
2. Chạy `run_windows.bat` (cài Python 3.11+ và các thư viện trong `requirements.txt` nếu chưa có).
3. Mở ứng dụng; nhấn **GPU Render Studio** trên thanh trên cùng.
4. Cửa sổ tự mở Sample Atlas, với hair cards V4 trong viewport.
5. Kéo chuột trái để Orbit; cuộn để Zoom; nhấn `F` hoặc **Frame All** để reset camera.
6. Chỉnh Roughness, Specular, Anisotropy, Sheen, Backlight, Iridescence hoặc nguồn sáng và quan sát hình ảnh.
7. Dùng dropdown **Rendered** để xem các kênh debug. Nhấn **Light Sweep** để xoay nguồn sáng.
8. Bấm **Sync Project** để lấy card/atlas hiện tại; bấm **Load Atlas Folder** để xem atlas đã export (có file `FSD_Atlas_manifest.json`).

### Phần cứng

Đường WGL yêu cầu driver đồ họa có OpenGL 3.3+ và hỗ trợ FBO floating point. Khuyến nghị GPU rời 4GB VRAM hoặc tốt hơn; các mốc FPS chưa được kiểm chứng trên GTX 1650/RTX 3050 Ti. Không có cơ chế tự động chọn card LOD, VRAM residency hay full production GPU frame graph trong bản này.

### Tệp quan trọng

- `fiberstrand/rendercore/context.py`: EGL/WGL context, quản lý vòng đời.
- `fiberstrand/rendercore/glapi.py`: OpenGL function loader, shader compiler, bindings.
- `fiberstrand/rendercore/renderer.py`: atlas upload, mesh buffer, Weighted OIT và shading.
- `fiberstrand/rendercore/studio.py`: giao diện Render Studio trong ứng dụng Tk.
- `fiberstrand/rendercore/shaders/`: GLSL source có thể chỉnh sửa.
- `samples/rendercore/`: atlas V4 thử nghiệm (5 map + manifest).
- `tests/test_rendercore_gpu.py`: bài test GPU thực thi trên EGL; không phải benchmark driver Windows.
- `examples/render_studio_ui_actual.png`: ảnh giao diện chạy thử trên Linux/Xvfb.
- `examples/render_peacock_material_base.png` và `examples/render_peacock_iridescence.png`: ảnh output GPU.

## Kiến trúc cập nhật dữ liệu

| Khi thay đổi | Tác vụ |
|---|---|
| Material slider | Shader uniform; không bake Fiber/Atlas |
| Card shape | VBO mới cho geometry; không bake Fiber/Atlas |
| Tile Color/Alpha/Normal/Flow/Roughness | Upload GPU subrectangle; hiện còn generate mip cho cả texture |
| Camera/Light | Render frame mới; không reupload mesh/texture |
| Atlas repack hoặc thay kích cỡ | Phải sync lại atlas/UV |

### Giới hạn kỹ thuật đã biết

1. **Chưa phải C++/D3D12 RenderCore V2**. Đây là giai đoạn đầu kiểm tra shader GPU và hợp đồng dữ liệu, với backend Python/OpenGL. Windows WGL path được viết nhưng chưa thể kiểm thử trên phần cứng Windows trong môi trường build Linux này.
2. **Transparency hiện là Weighted Blended OIT**, chưa có Adaptive K-buffer, per-pixel sorting, overflow tail hay kiểm chuẩn full alpha nhiều lớp với Arnold. Weighted OIT có sai số với các lớp màu/độ sâu phức tạp.
3. **Không có hair self-shadow/deep opacity maps và HDRI/IBL thật**. Hiện chiếu sáng bằng directional light + ambient đơn giản và backlight xấp xỉ. Đèn vật lý và nhiều nguồn sáng sẽ phát triển trong Native RenderCore.
4. **Iridescence là mô hình nghệ thuật**, không mô phỏng microstructure hoặc thin-film giao thoa nhiều bước sóng.
5. **Không có full OCIO/color-managed render**. Composite sử dụng tone map và display sRGB xấp xỉ, không bảo đảm khớp Arnold/Unreal/Unity.
6. GPU tile update đúng subregion ở mức mip 0 nhưng hiện **tái tạo mipmap toàn trang**; phải thay bằng tile-local mip update để giữ hiệu năng khi atlas lớn.
7. Renderer chưa quản lý VRAM 4GB theo ngân sách driver, chưa có progressive quality, precise GPU timer query hay cơ chế khôi phục device loss.
8. GUI Fiber Studio và Card Editor cũ vẫn dùng Tk/Pillow; GPU Render Studio hiện là cửa sổ xem vật liệu riêng, chưa thay toàn bộ UI 3D cũ.
9. Không có FBX skeleton/animation playback trong Render Studio.
10. Preview atlas mẫu chỉ minh họa cấu trúc renderer; chất lượng tạo hình lông công của lõi Fiber V4 vẫn là bản thử nghiệm.

## Lộ trình kế tiếp để đạt sản phẩm thương mại

- **R0 Native D3D12:** C++20 RHI, render graph, DirectX Shader Compiler, native UI viewport, memory residency & GPU timing; kiểm thử trên Windows thật.
- **R1 Hair BRDF:** mô hình phản xạ có hướng được hiệu chỉnh với vật liệu hair card chuẩn; lighting/HDRI, tone mapping và OCIO.
- **R2 FiberTrans:** adaptive layered OIT, bounded overflow, CPU/reference sorted compare, metrics theo độ phủ và overdraw.
- **R3 FiberShadow:** alpha-aware self-shadow, deep-opacity approximation, light/transmittance tests.
- **R4 FiberOptics:** iridescence LUT và vật liệu lông vũ, ánh nhũ theo vật liệu vi mô.
- **R5 Performance:** tile-local mipmaps, adaptive quality, renderer calibration, GPU budget 4GB, driver matrix NVIDIA/AMD.

## Kiểm thử đã thực hiện

Chạy `python -m pytest -q tests/test_cards.py tests/test_construction_v4.py tests/test_engine.py tests/test_rendercore_gpu.py` trong thư mục ứng dụng. Tại môi trường build hiện tại: **39 tests + 4 subtests passed**. GPU rendering trên EGL dùng phần mềm Mesa llvmpipe; **không dùng kết quả đó để công bố FPS trên VGA thật**.

## Quyền sử dụng

Mã nguồn mới thuộc bản phát triển thử nghiệm của người dùng. Trước khi phát hành thương mại phải kiểm kê giấy phép mọi thư viện được đóng gói (Python, Pillow, NumPy, Tcl/Tk, OpenGL driver/OS distribution), bản quyền tài sản ảnh/texture và chạy test trên Windows thật. `samples/rendercore` được sao chép từ atlas thử nghiệm do FSD tạo ở các bước trước.
