@echo off
setlocal
set "FSD_FIBERBAKE_BACKEND=cpu"
call "%~dp0run_windows.bat" %*
endlocal
