# Fiber Realtime Engine V2 — source handoff, 2026-11-12

Trạng thái: **đã tích hợp một đợt refactor lõi; chưa hoàn thành toàn bộ đặc tả**.
Không chạy ứng dụng, test, shader compiler, benchmark, native compiler hoặc build
EXE trong đợt này, theo yêu cầu source-only trước đó. Không có số đo realtime,
PASS hay xác nhận chạy trên RTX/GTX cho source mới. Các báo cáo cũ không xác
nhận bản này. Card Editor GPU vẫn PAUSED; checkpoint trước đó được giữ nguyên.

## Mở ứng dụng

Chạy `run_windows.bat`. Trong Fiber Studio hoặc Construction Studio, bấm
**Live Fiber GPU** để mở viewport WGL trực tiếp từ strand truth. Kéo slider ở
Fiber Studio cập nhật liên tục; thả chuột yêu cầu bake đủ kích thước tile.
Viewport GPU độc lập với quá trình bake, không chờ AO hoặc export maps.
Không tự mở thêm cửa sổ khi khởi động. GPU không khởi tạo được thì thông báo
trong cửa sổ, CPU bake vẫn còn. GPU thực tế hiện bằng GL_RENDERER.

Alt+LMB xoay mặt ảnh theo chiều đã yêu cầu, Alt+MMB pan, Alt+RMB kéo ngang zoom.
Đây là viewport sợi 2D/2.5D, không phải tiếp tục Card Editor 3D.

## Audit trực tiếp mã nguồn trước sửa

| Khu vực | Phát hiện trong source cũ | Thay đổi lần này |
|---|---|---|
| `raster.render_tile` | Generate toàn bộ rồi bake cả 9 map | Entry point chuyển sang `engine_v2.engine`; giữ `render_tile_legacy` cho đối chiếu |
| `_grid_for_strand` | `np.mgrid` nằm trong vòng lặp từng segment | Bins theo segment; một grid cho mỗi block 32×32; mẫu hình học cache độc lập vật liệu |
| Vật liệu | Roughness/màu và hình học chung luồng sinh | Random stream vật liệu riêng; cache geometry không chứa màu/roughness/optics |
| AO | Dùng `prealpha` từ output accumulation | Proximity đến centerline + radius + depth của các sợi trong vùng; 8 depth bins, không đọc output alpha |
| Main sliders | Chỉ commit khi release; debounce 180ms | Throttle tối đa 33ms, numeric finite/clamp, một undo mỗi drag |
| Main workers | ThreadPool queue không giới hạn; token không bỏ queued work | Scheduler keyed, tối đa 64 pending; ưu tiên tile active; hủy token, chặn publish cũ |
| Atlas | Paste/resize toàn tile từ `_poll_workers` trên UI | Worker sở hữu atlas staging; công bố cả bộ channel/page nhất quán |
| Graph V4 | Cache giới hạn theo node count; preview debounce | Byte LRU, cache dùng lại qua engine, cancel giữa node, scheduler latest-wins |
| Save/load | JSON v1 settings whitelist | Thêm giá trị material với default cho file cũ; không lưu buffer/cache/GL handle |
| Render Studio | Đã có tile-local float mips/subimage; có nhánh CPU mip đồng bộ | Giữ nguyên renderer chung để không đụng phần Card Editor đang pause; chưa thay hoàn toàn nhánh legacy |

Audit trên là đọc source, **không phải benchmark**. Công cụ đo đã viết trong
`tools/benchmark_fiber_v2.py`, chưa thực thi. Không chọn một native/GPU compute
backend theo hiệu năng khi chưa có kết quả đo thực tế.

## Data flow và dependency

`Tile/Graph snapshot → geometry cache → immutable StrandTruth → material fields`
chia thành hai nhánh: `instanced GPU ribbons` và `bins → shared samples → channels
→ atlas staging → publication`.

StrandTruth chứa stable SID, numeric export ID không trùng trong snapshot,
cluster/region, curve/radii, root, tham số theo chiều dài, tangent/frame,
depth và pigment; opacity, roughness, specular, anisotropy, transmission,
scatter, iridescence là source riêng. Có per-length source knots qua
`tile.overrides[id]['attributes'][name]`, clamp [0,1]. Không suy kênh specular
từ roughness, normal từ alpha hay AO từ output texture.

Graph ID dựa trên Curve.key thay vì vị trí trong danh sách; `.fsd` giữ graph
gốc. Numeric ID 24 bit có bảng ánh xạ trong tile manifest. Model hiện vẫn là
curve phẳng + depth từng sợi; chưa phải spline/transport-frame 3D có twist và
cross-section tùy ý. Generator feather không còn âm thầm giới hạn 3000 barbs;
số được yêu cầu và barbules được giữ trong bake.

`dependencies.py` khai báo nguồn của từng kênh. Baked-channel cache khóa theo
source version + resolution/filter. Block cache khóa theo toàn bộ contributors
trong block, kể cả sợi lân cận AO. Vì vậy thay đổi cục bộ xét hợp footprint cũ
và mới; vùng trống cũ cũng bị xóa. Material override cục bộ chỉ đổi signature
của sợi liên quan. Dependency chưa tách riêng từng material operator trong
Graph: thay graph phải đánh giá output và chuyển lại truth, nhưng node upstream
có thể dùng cache. Camera/light không đi qua fiber bake.

Các output continuous dùng painter-order visible coverage weighting; normal/
flow normalize sau accumulation; ID lấy sợi đóng góp cuối coverage > .26.
RGB mask là root/mid/tip field; scalar optics là thuộc tính nghệ thuật, không
phải kết quả transport vật lý. Color giữ quy ước pigment sRGB/artistic của
generator cũ. Map 2D chỉ biểu diễn lớp tổng hợp, mất thông tin multilayer.
GPU preview dùng cùng curve/pigment/opacity, nội suy màu theo các control point;
biên ribbon, giao nhau và pattern tần số cao có thể khác analytic bake.

## Caches, atlas và consistency

Engine có 384 MiB ngân sách cache tổng cộng: geometry 72, material 72, bins 24,
samples 108, block channels 36, complete channels 36, graph 24, history 12 MiB.
LRU có hit/miss/evictions, bỏ entry vượt budget. Chi phí là ước lượng bảo thủ
theo ndarray/PIL/Python records, không phải giới hạn RSS của cả process.
Working arrays, in-flight results, atlas pages và GPU storage nằm ngoài budget
này. GPU preview giới hạn instance data 256 MiB, báo lỗi nếu vượt, không âm
thầm giảm strand count. Không có GPU resource LRU toàn ứng dụng mới trong đợt này.

Atlas bỏ các kênh có signature không đổi. Nếu base channel version khớp và
dirty area <60%, không chạm border thì paste subregions; các trường hợp khác
copy đầy đủ changed tile/gutter. Không sử dụng dirty rect từ một base khác.
Map/page set mới được đổi atomically sau khi worker hoàn thành; UI không nhận
một nửa kênh của revision mới. Copy-on-write hiện vẫn copy nguyên changed atlas
channel page trên worker; đây chưa phải sparse atlas GPU/staging-buffer hoàn chỉnh.
Dirty mip rectangles được tính và báo trong metadata; chưa nối toàn bộ chúng
vào mọi nhánh upload/mipmap hiện có của Render Studio.

## Export và instrumentation

9 map mặc định giữ nguyên tên/file. GUI export hỏi có thêm các kênh V2 không;
CLI hỗ trợ `--all-channels`. Thêm: specular, anisotropy, transmission, scatter,
iridescence, cluster_id. Những kênh mới xuất độc lập nhưng Render Studio cũ
chưa tiêu thụ toàn bộ scalar optics dưới dạng texture.

Ví dụ tự chạy trong project:

```bat
run_windows.bat
.venv\Scripts\python.exe -m fiberstrand.cli --project scene.fsd --export exported --all-channels
.venv\Scripts\python.exe tools\benchmark_fiber_v2.py --counts 1000,10000 --size 512 --repeat 3 --legacy
```

Benchmark ghi JSON/CSV wall time, truth/bins/bake stages, baked channels,
dirty-block counts và cache stats. Đây là CPU harness; không đo GPU frame,
P95 input-to-present, VRAM hay chất lượng hình ảnh. Legacy khác pigment random
stream/AO nên số đo là workload comparison, không phải pixel equivalence.
Tests invariants mới ở `tests/test_fiber_engine_v2.py` chỉ được viết source.

## Chưa hoàn thành trong đặc tả

- Native SIMD/GPU compute bake backend và lựa chọn backend bằng benchmark.
- True 3D strand frames/twist/cross-section và transport/AO vật lý.
- GPU atlas staging ring/fences, dirty mip subregions cho toàn pipeline,
  GPU cache budget/LRU thống nhất; thay nhánh mip legacy đồng bộ còn tồn tại.
- Realtime P95/P99, VRAM/RSS trên RTX 3050 Ti / GTX 1650, kiểm chứng ảnh preview
  so với final, regression của Graph/UI/project/save/export.
- Không có cam kết 10k/50k sợi realtime ở source chưa được chạy này.

Các mục trên là việc còn lại thật sự, không được xem là đã hoàn thành chỉ vì
đã có CPU reference hoặc viewport GPU. Lịch sử Card Editor vẫn ở
`docs/CARD_EDITOR_GPU_PAUSED.md`.
