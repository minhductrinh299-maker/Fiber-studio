@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (set "PY=py -3") else (set "PY=python")
if not exist .venv\Scripts\python.exe (
  echo Creating Fiber Strand Designer runtime...
  %PY% -m venv .venv || goto :error
)
.venv\Scripts\python.exe -c "import numpy; import PIL; import tkinter; import PySide6.QtWidgets" >nul 2>nul
if errorlevel 1 (
  .venv\Scripts\python.exe -m pip install -r requirements.txt || goto :error
)
.venv\Scripts\python.exe main.py %*
if errorlevel 1 goto :app_error
goto :end
:error
echo.
echo Setup failed. Install Python 3.11+ from https://www.python.org/downloads/ then retry.
pause
exit /b 1
:app_error
echo.
echo Fiber Strand Designer stopped with an error. Read the traceback above.
pause
exit /b 1
:end
endlocal
