@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Run run_windows.bat once to install Python dependencies.
  pause
  exit /b 1
)
.venv\Scripts\python.exe -m fiberstrand.cli %*
endlocal
