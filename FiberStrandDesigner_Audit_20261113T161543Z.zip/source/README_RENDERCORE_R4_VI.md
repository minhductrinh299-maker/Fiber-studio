# Fiber Strand Designer v1.7-dev — Native D3D12 foundation

Đã có cửa sổ Win32/D3D12 thật, swapchain hai buffer và draw pipeline raster.
Đây là mốc nền native độc lập. GUI Fiber Studio, Construction Graph, Card Editor
và OpenGL Render Studio hiện có được giữ nguyên.

## Chạy bản đã build

Mở `run_native_d3d12_windows.bat`. Binary đã biên dịch nằm trong
`native_d3d12/bin/`, kèm shader. Không cần Python để chạy cảnh demo này.

- LMB kéo: orbit camera; cuộn chuột: zoom.
- Shift + RMB kéo: xoay riêng đèn, ngang azimuth, dọc elevation.
- S: bật/tắt Light Sweep; R: Reset Light; Esc: đóng.
- Thanh tiêu đề hiện GPU duration và góc đèn.
- `run_native_d3d12_windows.bat --adapter 1` chọn adapter theo danh sách DXGI.
- `native_d3d12\bin\fsd_d3d12_viewport.exe --list-adapters` liệt kê GPU.

Mặc định chọn adapter D3D12 đầu tiên theo thứ tự high-performance của Windows.
Không tự chuyển sang WARP khi GPU lỗi. `--warp` chỉ dùng khi chủ động yêu cầu
software rendering; kết quả đó không phải benchmark phần cứng.

## Build từ source

Yêu cầu CMake 3.20+, Visual Studio C++ Build Tools và Windows SDK.

```powershell
cmake -S native_d3d12 -B native_d3d12/build -A x64
cmake --build native_d3d12/build --config Release
ctest --test-dir native_d3d12/build -C Release --output-on-failure
```

Launcher ưu tiên binary đóng gói `bin`. Khi sửa source, chạy binary vừa build
trong `native_d3d12/build/Release` để tránh dùng lại bản đóng gói cũ.

## Xuất snapshot từ dữ liệu FSD

```powershell
python -m fiberstrand.rendercore.native_scene --atlas samples/rendercore --output native_d3d12/demo_scene
native_d3d12\build\Release\fsd_d3d12_viewport.exe --scene native_d3d12/demo_scene/scene.fsdn
```

CLI mặc định tạo bốn card minh họa. Thêm `--project duong_dan.fsd` để dùng các
card đã lưu; atlas phải được xuất từ chính project đó và chứa cùng tile IDs.
API `export_cache(cards, cache, folder)` xuất trực tiếp mesh hiện tại và các map
đã cache, không gọi fiber rasterizer. Snapshot là bản sao tại thời điểm xuất,
chưa tự đồng bộ khi chỉnh trong GUI. Cache phải được render đầy đủ trước khi xuất.

Format `FSDNAT01`: magic 8 byte, uint32 số vertex, uint32 atlas size, rồi vertex
little-endian float32 gồm position(3), normal(3), tangent(3), UV(2).
Các PNG color/alpha/normal/flow/roughness nằm cạnh `scene.fsdn`. UV gốc trên-trái,
root ở đáy tile; không dùng phép đảo V của OBJ/OpenGL. Chỉ hỗ trợ atlas page 0;
project dùng nhiều trang sẽ báo lỗi rõ ràng thay vì bỏ card âm thầm.

## Capture và kiểm thử

```powershell
native_d3d12\bin\fsd_d3d12_viewport.exe --scene native_d3d12/demo_scene/scene.fsdn --frames 90 --hidden --capture sample.ppm
python -m pytest -q tests
```

Shader được tìm theo vị trí EXE, không phụ thuộc working directory. Capture là
PPM RGB đọc từ swapchain GPU sau display transform. `--width`, `--height`,
`--light-azimuth`, `--light-elevation`, `--yaw` cho phép tái lập cảnh thử.
`--debug` yêu cầu Windows Graphics Tools debug layer; máy hiện tại chưa cài
thành phần này nên debug-layer validation chưa thực hiện được.

## Trạng thái chính xác

- Đã build MSVC, chạy D3D12 hardware trên RTX 3050 Ti Laptop 3962 MiB.
- Đã render atlas mẫu, kiểm tra GPU readback và đổi ánh sáng thay đổi pixel.
- Color SRV giải mã sRGB; data maps tuyến tính; blend FP16 tuyến tính rồi encode
  sRGB ở display pass. BRDF sợi vẫn là approximation, chưa được calibration.
- Alpha đang sort theo centroid tam giác. Card giao nhau/chồng sâu vẫn có thể
  sai thứ tự; chưa có Weighted OIT/native Adaptive K-buffer raster.
- Atlas chỉ có base mip, chưa có coverage mip/tile revision upload native.
- Mỗi frame chờ fence: đúng vòng đời tài nguyên nhưng chưa tối ưu throughput.
- GPU timestamps đo hair + display pass, không gồm CPU sort/upload/Present.
  Cảnh demo bốn card không phải benchmark 6.000 card/4K/1080p.
- Chưa có native shadow/scattering/iridescence parity, live material UI,
  Qt/render-thread integration, device-loss recovery hoặc renderer match.

Ưu tiên tiếp: scene revisions và upload atlas từng vùng, Weighted OIT làm
fallback, sau đó K-buffer có overflow tail cùng cảnh kiểm chuẩn 4–32 lớp.
