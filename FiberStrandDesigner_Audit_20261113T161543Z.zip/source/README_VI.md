> **FBX độc lập:** xem `docs/INDEPENDENT_FBX_READER.md`. Windows x64 đi kèm DLL ufbx, không cần Blender/Autodesk SDK. DLL đã biên dịch; chưa chạy app, importer hoặc kiểm thử.

> **Mới: Fiber Engine V2 — source đang triển khai, chưa kiểm thử.** Đọc `README_FIBER_ENGINE_V2_VI.md`. Đã tích hợp strand truth/cache/dependency, block bake, scheduler, live GPU strand preview và async CPU atlas; chưa hoàn tất GPU compute bake/GPU atlas mới. Card Editor 3D vẫn tạm dừng. Mở bằng `run_windows.bat`, dùng nút **Live Fiber GPU**.

> **Mới: Auto GPU + màu đèn (source chưa kiểm thử).** Startup tự chuẩn bị Python host riêng và đặt ưu tiên High Performance trước WGL; GPU Info vẫn xác nhận GPU thực tế. Render Studio có Key/Fill/Ambient Color. Đọc `README_AUTO_GPU_LIGHTS_VI.md`. Không chạy app/test hay build EXE trong lần cập nhật này.

> **Mới: FiberCoverage + High-DPI (source chưa kiểm thử).** Đọc `README_FIBERCOVERAGE_HIDPI_VI.md`. Đã viết tile-local float mips, AA/quality controls, comparison và DPI-aware UI/framebuffer. Theo yêu cầu người dùng: không chạy test/app/benchmark hoặc build EXE. Các báo cáo PASS và ảnh trước đây không áp dụng cho source mới này. Chạy `run_windows.bat` để tự test.

> **Điều hướng Maya:** chạy `run_windows.bat`. Mọi viewport dùng **Alt + LMB: xoay**, **Alt + MMB: pan**, **Alt + RMB kéo ngang: zoom**. Preview 2D xoay mặt ảnh; viewport 3D orbit camera. Shift + RMB vẫn xoay riêng đèn trong Render Studio. Bản cập nhật này chạy từ Python, không build thêm EXE. Các native EXE đã đóng gói trước đây chưa có thay đổi điều hướng này.

> **v1.7-dev RenderCore R4:** Xem `README_RENDERCORE_R4_VI.md`. Đã có viewport D3D12 độc lập chạy trên RTX 3050 Ti Windows. Chạy `run_native_d3d12_windows.bat` để mở bản thử; GUI chính vẫn dùng OpenGL.

> **NEW v1.6 RenderCore R3:** Open `README_RENDERCORE_R3_VI.md` for GPU selection diagnostics, shadow/scattering, tile-specific coverage mip, adaptive render quality, D3D12 compute probes and verified limitations.

**GPU Render Studio v1.4:** Xem [`README_RENDERCORE_R1_VI.md`](README_RENDERCORE_R1_VI.md) để chạy Hybrid Transparency 1/2/4 layers, D3D12 Compute Probe và đọc rõ giới hạn kiểm thử.

**GPU Render Studio v1.3:** Xem [`README_RENDERCORE_R0_VI.md`](README_RENDERCORE_R0_VI.md) để biết cách chạy, giới hạn và trạng thái triển khai renderer.

# Fiber Strand Designer — Fiber Studio + Card Editor v1.1.0

Ứng dụng độc lập, tạo từ đầu cho Windows, tập trung **Fiber Studio, tile texture atlas và Card Editor 3D độc lập**. Không phải bản sửa/đổi tên CatCard Studio.

## Khởi chạy trên Windows

1. Cài Python 3.11 trở lên, chọn **Add Python to PATH** (nếu chưa có).
2. Giải nén ZIP và mở `run_windows.bat` (lần đầu cần internet để tải NumPy và Pillow).
3. Giao diện mở với dự án mẫu gồm 3 tile lông mèo. Chỉnh tham số ở bên phải, mỗi lần thả thanh trượt sẽ cập nhật tile đang chọn.
4. Mở chế độ **Atlas** để xem bố cục các tile. Chọn từng map trong danh sách Map.
5. Nhấp vào sợi trong chế độ **Tile** để chỉnh riêng ở tab **Single Strand**.
6. Nhấn **Save** để lưu file `.fsd`; **Export Atlas** để xuất đầy đủ các map PNG và file JSON UV.
7. Muốn đóng gói `.exe`: chạy `build_exe_windows.bat`. File build ở `dist\FiberStrandDesigner\FiberStrandDesigner.exe`.

## Chức năng đã có

- Mô hình nguồn theo tile, seed ổn định, ID từng sợi ổn định khi tăng số lượng sợi.
- Các solver: fur/undercoat/guard/flyaway, tóc thẳng/xoăn/gợn, fur fuzz, stylized, feather rachis/barbs/barbules.
- Hình dạng: taper, bulge, width, length, frizz đa tần, curl, bend, twist, sag, guide, macro/micro clumping.
- Màu 3 điểm từ gốc đến ngọn, nhiễu màu theo từng sợi, vằn banded/agouti, speckle, ombre.
- Override từng sợi: chiều dài, độ dày, offset, uốn, màu, opacity, ẩn, reset.
- Một lõi raster tạo 9 map: Color RGBA, Alpha, Normal, Flow, Depth, AO, ID, Roughness, RGB Mask.
- Mỗi tile được render riêng; Atlas Manager chỉ thay vùng tile thay đổi, giữ các vùng khác.
- Atlas nhiều trang theo dung lượng, gutter cho vùng tile; xuất JSON vị trí atlas + UV scale/offset.
- UI phản hồi không bị khóa bởi công việc render (worker thread), hỗ trợ hủy render cũ, undo/redo, mở/lưu.
- Export chất lượng đầy đủ có thể chạy ở chế độ CLI không cần GUI.

## Giới hạn kỹ thuật cần hiểu

- **Đây là bản v1.1 chạy được, chưa phải bộ grooming production hoàn chỉnh.** Card Editor đã có viewport phối cảnh 3D bằng Pillow/Tk và các lệnh chỉnh mesh. FBX/skinning/timeline và viewport GPU sẽ triển khai ở các giai đoạn sau.
- AO là ước lượng che phủ 2.5D, không phải ray-traced AO. Normal là mặt cắt trụ giả lập; cần hiệu chỉnh hướng tangent space trong shader 3D sau này.
- Texture được tính bằng CPU + NumPy để thuận lợi kiểm thử; GPU compute là hướng tối ưu hóa tiếp theo, chưa được triển khai.
- Atlas đang dùng fixed-size shelf packing, mỗi tile thay đổi nội dung không pack lại. Thêm/xóa/đổi kích thước tile sẽ tạo lại layout.
- Color gradient dùng nội suy sRGB mang tính tạo hình; không phải mô hình hấp thụ/phản xạ ánh sáng của sợi vật lý.
- Tên `color` có alpha tích hợp; `alpha` được xuất riêng dưới dạng grayscale. Cần kết nối và kiểm tra shader Arnold/Unreal ở giai đoạn tích hợp.
- Lưu `.fsd` chứa dữ liệu nguồn sợi và card (không chứa PNG cache) để dễ đồng bộ và tái tạo. Khi mở dự án sẽ cần render lại preview.
- Windows EXE chưa được đóng gói trong môi trường Linux; bộ script build trên Windows được cung cấp, có yêu cầu kết nối mạng ban đầu.

## Lệnh CLI

```powershell
python -m fiberstrand.cli --new --project demo.fsd
python -m fiberstrand.cli --project demo.fsd --export exports
python -m fiberstrand.cli --preset "Bird Feather" --preview feather.png
python -m fiberstrand.cli --project demo.fsd --benchmark
```

## Quy ước dữ liệu atlas

- Mỗi tile có ID độc lập, không phụ thuộc tên, seed bất biến trừ khi sửa thủ công trong dữ liệu.
- Atlas gồm `FSD_Atlas_00_color.png` và các map cùng tên theo nhóm; tile chia sẻ hình học/UV gốc giữa tất cả các map.
- `FSD_Atlas_manifest.json` chứa `rect_px`, `uv_scale`, `uv_offset` và trang atlas. Tọa độ UV mô tả gốc trên-trái của file PNG. OpenGL cần đổi hướng V khi áp dụng theo UV convention.
- Khi Export, renderer tạo map theo full tile resolution, không dùng ảnh thumbnail của preview.

## Cấu trúc module

`model.py` dữ liệu và preset; `geometry.py` sinh hình dạng; `raster.py` tạo map; `atlas.py` cache / packing / UV; `projectio.py` lưu mở; `ui.py` giao diện; `cli.py` chế độ batch.

## Kiểm thử

```powershell
python -m unittest discover -s tests -v
```

## Chỉnh hình dạng từng sợi trong giao diện

1. Chọn chế độ `Tile`, chọn map `color`, nhấp vào một sợi trong vùng preview.
2. Mở tab `Strand` và bật `Sculpt curve: drag the 5 nodes`.
3. Kéo trực tiếp các nút vàng dọc sợi để thay đổi đường cong, thả chuột để render lại tile.
4. Dùng các thanh `Width multiplier`, `Length multiplier`, `Add bend`, `Offset`, `Opacity` hoặc nút `Dye selected strand` để thay đổi độc lập một sợi.
5. Vào tab `Extra`, dùng `PROFILE ROOT → TIP` để chỉnh độ dày sợi theo 5 điểm; các thông số feather cũng ở tab này.
6. Trong workspace, cuộn chuột để zoom, giữ chuột giữa để pan, nhấn `Fit` để về kích thước vừa màn hình.

## Cơ chế lưu từng tile

Khi xuất, thư mục `Tiles/` chứa ảnh map PNG và `tile_manifest.json` cho từng tile. Các file atlas cùng tên vẫn được xuất ở thư mục gốc. `AtlasCache.update_tile` chỉ thay đổi hình chữ nhật của tile có dữ liệu mới; preview UI dùng lại atlas cache nhưng có thể dựng lại hình hiển thị trên Canvas (chưa phải GPU texture sub-image của viewport 3D).

---

# Card Editor v1.1 — Bản tích hợp mới (11/11/2026)

Từ giao diện Fiber Studio, nhấn **Card Editor 3D** để mở cửa sổ thao tác card. Dự án mẫu mới có 7 card liên kết với các tile có sẵn. Những dự án `.fsd` v1 cũ mở bình thường, danh sách card ban đầu có thể trống; dùng **+ Add** để tạo card.

## Thành phần đã có

- **Card Geometry Core**: ribbon 3D, Length, Width, Bend, Twist, Lift, Yaw, Tilt, Taper, Width Profile 5 nút, số hàng dọc 1–64, vertex offsets tách khỏi hình học tham số.
- **3D Card Editor**: xem card 3D có phối cảnh và camera orbit/zoom. Khi tile đã được raster, viewport đọc pixel từ **AtlasCache**, cắt đúng vùng tile rồi texture-map lên card; card thay đổi hình học mà không gọi Fiber Generator hoặc bake tile.
- **Direct Editing**: Select, Move, Rotate, Scale, Bend, Length, Width, Twist, Lift, Root, Comb, Relax, Smooth, Spread, Noise; chỉnh nhiều card, brush falloff, kéo trực tiếp vertex/hàng, Insert/Remove Row, bảo toàn vertex overrides khi đổi subdivision.
- **UI tối giản**: bốn tab Select/Groom/Shape/Mesh, công cụ thường dùng nằm dưới viewport, thanh thông số bên phải, menu chuột phải, **Space Pie Menu** 6 hướng thay đổi theo chế độ, chế độ chọn Card/Root/Row/Vertex.
- **Hỗ trợ workflow**: Duplicate, Delete, Select All, Edit Width Profile, Make Tile Unique, Undo/Redo chung với Fiber Studio, lưu card trong `.fsd`, xuất OBJ/MTL và atlas cache preview.
- **Hai cấp hiển thị**: khi kéo dùng polygon viewport nhẹ, thả chuột sẽ cập nhật texture đã lưu. Không có bước tự động raster lại sợi khi chỉnh card.

## Các thao tác nhanh

| Thao tác | Chức năng |
|---|---|
| `Q / W / E / R` | Select / Move / Rotate / Scale |
| `Space` giữ + rê hướng + thả | Pie Menu theo chế độ |
| `1 / 2 / 3 / 4` | Chọn Card / Root / Row / Vertex |
| `B` | Bật/tắt Groom Brush |
| `S` + kéo ngang | Kích thước Brush |
| `Shift` + kéo | Chỉnh tinh |
| `Alt + LMB` / `MMB` | Orbit camera |
| Lăn chuột | Zoom |
| `F` | Frame Selection (ước lượng khoảng cách) |
| `Shift + D` / `Delete` | Duplicate / Delete |
| `G` | Lặp thao tác kéo gần nhất (không áp dụng Vertex) |
| `Ctrl + Z` / `Ctrl + Shift + Z` | Undo / Redo |
| `Tab` | Ẩn/hiện Inspector |
| `Esc` | Hủy thao tác đang kéo |

**Shape Pie:** Bend, Width, Length, Twist, Root, Lift. **Groom Pie:** Comb, Relax, Spread, Smooth, Lift, Noise. **Mesh Pie:** Vertex, Insert Row, Remove Row, Relax, Root, Width. **Select Pie:** Move, Rotate, Scale, Duplicate, Delete, Make Unique.

## Xuất OBJ và ánh xạ texture

Trong Card Editor chọn **Export OBJ**. Kết quả chứa `FiberCards.obj`, `FiberCards.mtl`, `FiberCards_manifest.json` và các PNG atlas preview đã có trong cache. UV dùng gốc dưới-trái đúng OBJ, tự chuyển từ tọa độ atlas nguồn (PNG gốc trên-trái). Dự án lưu bằng File → Save tại Fiber Studio.

**Lưu ý**: OBJ export từ Card Editor dùng **texture preview đang có**. Muốn chất lượng texture cuối cùng, sử dụng **Export Atlas** của Fiber Studio để bake ở full resolution rồi gán các atlas đó khi đưa vào Maya/Arnold/Unreal. OBJ không chứa hệ xương và animation.

## Giới hạn hiện tại, không nên nhầm với chức năng đã hoàn thiện

- Viewport hiện dùng **Tk Canvas + Pillow software perspective rasterization**, không phải GPU OpenGL/DirectX. Khi kéo dùng preview hình học nhẹ để đảm bảo tương tác; chưa có benchmark với hàng nghìn card và chưa bảo đảm 60 FPS trên mọi máy.
- Chưa có nhập mesh FBX, surface snapping thực, skin binding, playback skeletal animation, collision tránh xuyên mesh, mirror/symmetry hoặc hệ thống LOD.
- Groom Brush hiện thay đổi thuộc tính của card trong phạm vi brush (không phải comb theo toàn bộ surface tangent vector field).
- Chọn Root/Row/Vertex là chọn hình học card trong viewport độc lập, không phải lựa chọn vertex trên mesh động vật.
- Texture preview xuất OBJ không thay thế bản Atlas Full Quality; các tile chưa raster trong cache hiển thị dưới dạng card đơn sắc.
- Mọi card dùng cùng tile sẽ cùng ảnh texture; dùng **Make Tile Unique** để tách tile khi cần chỉnh sợi riêng. Lệnh này có thể phải repack atlas khi bổ sung tile.

## Kiểm thử Card Editor

Chạy `python -m unittest tests.test_cards -v`. Các kiểm thử bao gồm tạo mesh và UV, thay đổi shape độc lập với fiber, override vertex khi đổi subdivision, lưu/mở `.fsd`, xuất OBJ/MTL, và bảo toàn cache atlas khi chỉ chỉnh card.
