# FiberCoverage + High-DPI — source handoff v1.7-dev

Đã sửa source trực tiếp trong bản làm việc này. **Theo yêu cầu của người dùng,
không chạy test, không mở app, không compile shader/C++, không benchmark và
không build/đóng gói EXE trong lượt nâng cấp này.** Tất cả tính năng mới bên dưới
đang ở trạng thái **đã viết code, chưa xác minh hoạt động**. Các báo cáo PASS,
ảnh và binary R3/R4/navigation cũ không chứng minh chất lượng của source mới.

## Mở để tự test

Chạy `run_windows.bat`, sau đó mở **GPU Render Studio**. Launcher dùng Python,
tự cài NumPy/Pillow vào `.venv` ở lần đầu; không cần EXE. Đóng app cũ trước khi
mở lại để startup áp dụng DPI awareness trước HWND đầu tiên.

- **Quality:** Interactive / Live / Inspect.
- **Scale:** Auto / 1x / 1.5x / 2x. Live Auto = 1x, Inspect Auto = 1.5x.
- **AA:** Off / Spatial / Temporal / MSAA4.
- **Transparency:** Weighted / Hybrid 2 / Hybrid 4 / Auto như trước.
- **Alt + LMB:** xoay; **Alt + MMB:** pan; **Alt + RMB kéo ngang:** zoom.
- **Shift + RMB:** xoay riêng đèn. Light Sweep và Reset Light vẫn được giữ.

Temporal dùng tối đa 1/4/8 mẫu theo Interactive/Live/Inspect. Khi kéo, history
bị hủy và chỉ dùng một mẫu; không cấp phát lại cả bộ render target mỗi lần
nhấn/thả chuột. Sau khi đứng yên, viewport tự render các mẫu còn lại.

Để so sánh sampling: chọn AA Off và Scale 1x, **Pin Before**, rồi đổi AA/Scale/
Quality. Bên trái giữ ảnh đã pin, bên phải là ảnh hiện tại. Camera, ánh sáng,
material, geometry, tile hoặc viewport thay đổi sẽ vô hiệu hóa ảnh pin. Đây là
so sánh sampling trong source mới, không phải ảnh so với binary R3 cũ. **Capture
PNG** ghi thêm JSON metadata cùng tên gồm GPU thật, material, sampling và DPI.

## Nguyên nhân đọc được từ source cũ

1. Mip Color được lọc trong sRGB và lượng tử hóa trước khi chia alpha. Khi đưa
   straight-alpha RGB vào linear texture filtering, RGB đen ở texel trong suốt
   còn có thể đi vào mép sợi. Chỉ premultiply khi tạo mip chưa đủ sửa base-level
   bilinear/trilinear sampling.
2. Alpha mip bị scale theo occupancy ở ngưỡng alpha-test 0.5, trong khi beauty
   dùng blended OIT. Hai đại lượng này khác nhau; bảo toàn threshold coverage
   không đồng nghĩa bảo toàn lượng alpha/area coverage.
3. Shader chặn alpha riêng bằng Color.a và loại fragment alpha thấp. Alpha R8
   làm mất coverage dưới một mức lượng tử khi thu nhỏ. Ngoài ra revealage R16F
   nhân gần 1 có thể làm tròn các lớp alpha rất nhỏ về 1.
4. Shared-atlas mip chỉ đi được vài cấp an toàn theo padding. Thu xa hơn dễ
   alias; tạo mip cả trang sâu hơn sẽ làm tile lẫn nhau.
5. App chưa yêu cầu PMv2 trước khi tạo Tk windows. CardPreview còn dựng tối đa
   1100×740 rồi phóng bitmap lên kích thước widget lớn hơn.
6. OpenGL/CPU card preview dùng một phép đảo V khác native snapshot. Quy ước
   ribbon thực tế là root v=1 tại đáy ảnh PNG; mapping đã được thống nhất.

Đây là kết luận từ đọc code, chưa phải kết luận từ ảnh hoặc đo trên GPU.

## Thay đổi kiến trúc đã viết

### Coverage, color và mip

- `rendercore/sampling.py`: tile-local full mip chain đến 1×1. Alpha là mean
  coverage float; không dùng threshold gain hay thay đổi độ dày/hình học sợi.
- Color được decode sRGB, premultiply với Alpha Map, lưu RGBA16F tuyến tính.
  Filter diễn ra trên premultiplied RGB/alpha; shader unpremultiply sau sampling.
  Nếu không có Alpha Map riêng, RGBA Color.a được dùng làm fallback duy nhất.
- Alpha dùng R16F. Normal/Flow lọc vector có trọng số alpha rồi normalize;
  Roughness lọc theo bình phương roughness với trọng số alpha.
- Mỗi tile có texture riêng, clamp-to-edge và full mips, nên không phụ thuộc
  gutter của shared atlas khi thu xa. Anisotropic filtering đến 8× nếu có extension.
- Atlas trang vẫn giữ để debug/readback và cập nhật vùng cũ. Đổi một tile chỉ
  xếp lịch mip/upload cho tile đó. Color/Normal/Flow/Roughness phụ thuộc Alpha
  được cập nhật cùng snapshot; không bake lại fiber.
- Render Studio tạo mip trên worker, GL upload trên thread sở hữu context;
  job cũ bị bỏ khi có revision mới. API/headless mặc định vẫn có chế độ đồng bộ.
- Khi sync project, thay atlas cache/layout mới nạp lại atlas; commit từ Card
  Editor chỉ upload geometry. Tile revision vẫn theo dirty regions riêng.
- Weighted OIT tích lũy optical depth `tau=-log(1-alpha)` thay revealage nhân
  R16F. Nhánh xấp xỉ ổn định giữ alpha nhỏ; resolve lấy `exp(-sum(tau))`.

### AA và transparency

- Weighted và Hybrid composite thành RGB premultiplied tuyến tính + alpha trước.
  Temporal/spatial resolve xong mới ghép nền, exposure, tone roll-off và sRGB.
- SSAA 1.5×/2× dùng cùng camera, mesh, atlas và BRDF; tích hợp các mẫu bằng cùng
  kernel cho RGB premultiplied và coverage, không thêm blur toàn cảnh/FXAA.
- MSAA4: texture multisample cho Weighted OIT; composite từng sample rồi mới
  average. Không average accum/reveal riêng rồi mới thực hiện compositing.
- Nếu chọn MSAA4 với Hybrid/Auto, không đổi transparency âm thầm: yêu cầu SSAA2
  làm fallback và báo trên HUD. Thiếu sample support/FBO phù hợp cũng fallback.
- **Alpha-to-Coverage chưa có render path riêng.** Không bật vào OIT hiện tại
  vì coverage đã tham gia blend; cắt sample mask thêm sẽ sai coverage. MSAA này
  chủ yếu xử lý cạnh hình học, chưa có per-sample texture shading.
- Temporal hiện là **tích lũy jitter khi đứng yên**, reject toàn bộ history khi
  camera/geometry/tile/material/transparency/DPI framebuffer thay đổi. Motion
  vectors có camera và previous vertex positions ở nearest-card pass để debug.
  **Chưa có motion-reprojected multilayer TAA khi camera chuyển động.** Không
  dùng nearest-surface motion để kéo history của các lớp trong suốt phía sau.

### DPI, viewport và input

- `dpi.py`: yêu cầu Windows Per-Monitor V2 trước Tk; host đã đặt process policy
  thì thử PMv2 trên GUI thread. Windows cũ có fallback được ghi rõ, không giả là V2.
- Từng top-level có font pixel/style riêng theo DPI, padding, row height và
  một số theme metrics được scale từ giá trị gốc. Theo dõi DPI/child widgets
  mới, giữ tỷ lệ sash; không đổi global font scaling theo cửa sổ đang focus.
- `viewport_metrics()` tách logical size, DPR và client pixel size. WGL dùng
  GetClientRect; **không nhân DPR lần nữa** vào tọa độ Tk/native pixels.
- Framebuffer vật lý và internal render resolution tách riêng. Resize/DPI
  thay đổi sẽ tạo target mới và hủy history, không phóng framebuffer cũ.
- CPU CardPreview bỏ giới hạn bitmap 1100×740; handles/picking/brush/pie menu
  dùng DPI phù hợp. Camera rotation/dolly tính theo delta logic, pan/picking
  giữ cùng không gian client pixels.
- Chưa thêm Wintab/Windows Ink hay xác minh Wacom/multi-monitor thực tế. Tk 8.6
  và native theme metrics vẫn cần đại ca kiểm tra trên display matrix yêu cầu.

## Diagnostics và giới hạn hiệu năng

Debug: Original Alpha (LOD0 chiếu trên card), Effective Coverage, Mipmap Level
(ước lượng từ derivatives, không phải LOD anisotropic chính xác của driver),
Alpha Cutoff (chỉ diagnostic), Normal, Flow, Overdraw, Silhouette, Motion Vectors,
Temporal History. Ngưỡng Alpha Cutoff không được dùng để cắt beauty.

HUD/metadata có CPU call time, GPU timer, P95/P99 trên cửa sổ 240 mẫu gần nhất,
GPU shadow/OIT/AA+display pass, render scale, physical/internal dimensions,
history count, thời gian queue/upload CPU, số lần tạo lại bộ target. GPU timestamp
không gồm Present; AA pass time có composite/motion/temporal/present shader.
Đây là telemetry phiên làm việc, **không phải benchmark đã thực hiện**.

Target allocator dự toán tối đa 1 GiB offscreen targets, tile sampling residency
giới hạn 768 MiB; scale vượt dự toán được giảm và hiện trên HUD. Atlas debug
pages, geometry, driver allocations/alignment nằm ngoài các ước lượng này.
Không có tổng VRAM usage/peak hoặc upload GPU latency đã được đo. Có tăng draw
batch theo tile và có bản sao atlas trang; cần profile trước khi tối ưu tiếp.
Chưa chứng minh 60 FPS hoặc performance trên bất kỳ GPU/display nào của lượt này.

GPU đang render lấy từ GL_RENDERER; DXGI chỉ là inventory. Cập nhật tiếp theo
đã thêm startup tự đặt ưu tiên GPU qua Python host riêng và GPU Info: xem
`README_AUTO_GPU_LIGHTS_VI.md`. OpenGL không được coi là đã chuyển RTX chỉ vì tìm
thấy adapter. D3D12 adapter selection và native viewport cũ không được thay
backend/compile lại trong task này.

## Phần còn lại để nghiệm thu

- Chạy shader/UI/regressions và display matrix FHD/QHD/4K, 100–200%, khác DPI.
- Đánh giá hair quality matrix, ảnh trước/sau và benchmark 4GB thực tế.
- Kiểm tra Hybrid depth ties/coplanar cards, ordering và sai số vs sorted reference.
- Hoàn thiện động học temporal nhiều lớp, A2C path riêng nếu cần, VRAM residency
  và tối ưu upload/draw batching dựa trên số đo.
- Chưa chuyển Qt 6, chưa port quality pipeline mới sang native D3D12, chưa có
  commercial acceptance hoặc renderer calibration.

Đã thêm test source `tests/test_sampling_quality.py` cho lần chạy sau; **chưa chạy**.
Schema `.fsd`, Construction Graph, engine sinh sợi và source PNG không đổi.
UV mapping preview/OBJ đã sửa theo root-bottom; các workflow từng dựa vào phép
đảo V cũ cần được người dùng đối chiếu lại.

Tham khảo API: [Microsoft PMv2](https://learn.microsoft.com/en-us/windows/win32/hidpi/dpi-awareness-context),
[GetDpiForWindow](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-getdpiforwindow),
[Khronos multisampling](https://wikis.khronos.org/opengl/Multisample).
