@echo off
setlocal
set "FSD_RENDER_LEGACY=1"
call "%~dp0run_windows.bat"
endlocal
