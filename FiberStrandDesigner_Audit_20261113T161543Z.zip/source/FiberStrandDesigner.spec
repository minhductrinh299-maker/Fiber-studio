# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=[('fiberstrand/native/fsd_fbx.dll', 'fiberstrand/native')],
    datas=[('assets', 'assets'), ('fiberstrand/rendercore/shaders', 'fiberstrand/rendercore/shaders'), ('samples/rendercore', 'samples/rendercore'), ('vendor', 'vendor'), ('THIRD_PARTY_LICENSES.md', '.')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='FiberStrandDesigner',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['assets/branding/FSD_Peacock_Logo_Branding_Kit_for_Codex/FSD_Peacock_Brand_Kit/04_windows/FiberStrandDesigner.ico'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='FiberStrandDesigner',
)
