# Fiber Strand Designer v1.4 — Hybrid Transparency R1 + Native D3D12 Probe

**Bản thử nghiệm nâng cấp renderer thật trên GPU.** Kế thừa hoàn toàn lõi tạo lông Construction Graph V4, Fiber Studio, Card Editor và OpenGL Render Studio v1.3. Không phải bản D3D12 sản xuất hoàn chỉnh.

## 1. Có gì mới?

- **Hybrid GPU Transparency**: peel chính xác 1/2/4 lớp hair card gần camera (front-to-back), những lớp sâu hơn được tổng hợp bằng Weighted Blended OIT (*weighted tail*). Đây là cơ chế nhiều pass giới hạn chất lượng, **không** phải Adaptive K-Buffer tối ưu.
- **Chuyển chế độ ngay trong Render Studio** ở dropdown phía trên viewport: `Weighted · Fast`, `Hybrid · 2 Layers`, `Hybrid · 4 Layers`.
- Dùng **chung shader Hair BRDF**, Flow/Normal/Roughness/Color/Alpha và ánh nhũ cho tất cả các chế độ.
- Mỗi pass peel dùng depth texture, depth test và ngưỡng loại bỏ fragment đã xuất hiện ở lớp gần hơn. Các lớp trước được composite chính xác theo thứ tự depth; phần đuôi vẫn xấp xỉ.
- Hiệu chỉnh phép đọc **Color Map sRGB → scene-linear** bằng đường truyền sRGB chuẩn thay cho gamma 2.2 xấp xỉ.
- Bộ nhớ peel (4 ảnh RGBA16F + 2 depth textures) chỉ cấp phát khi bật Hybrid và được giải phóng khi về Weighted; resize tái tạo tài nguyên đúng kích thước.
- Shader/geometry/light/atlas upload vẫn là các đường cập nhật độc lập. Đổi chế độ transparency **không** bake lại texture sợi.
- Có thêm **D3D12 C++/HLSL Compute Probe** trong `native_d3d12`: tạo GPU device/command queue, biên dịch compute shader, composite các layer bằng D3D12 rồi so sánh với CPU reference. **Chưa được build/kiểm thử trên Windows trong môi trường hiện tại.**

## 2. Cách chạy thử trên Windows

1. Giải nén ZIP.
2. Chạy `run_windows.bat` bằng Python 3.11+ và các thư viện trong `requirements.txt`.
3. Mở `GPU Render Studio`.
4. Ở thanh trên viewport chọn `Weighted · Fast` để thao tác nhanh, `Hybrid · 2 Layers` hoặc `Hybrid · 4 Layers` để kiểm tra thứ tự lớp gần camera.
5. Dùng camera orbit/zoom và các slider roughness, specular, anisotropy, iridescence, đèn để so sánh.
6. Bấm `Capture PNG` để chụp, hoặc `Sync Project` để dùng atlas từ Fiber Studio.

**Chú ý:** trên Windows, WGL renderer cần driver OpenGL desktop 3.3+. Backend EGL/Linux chỉ để kiểm tra tính đúng đắn bằng Mesa; không đại diện FPS GTX 1650/RTX 3050 Ti.

## 3. Kiểm thử

- `python -m pytest -q tests`
- Kết quả trên Linux Mesa/EGL: **46 tests và 4 subtests đạt** (12/11/2026).
- 7 bài mới kiểm tra chất lượng Hybrid, thay đổi mức peel, không phụ thuộc thứ tự vẽ, chuyển path GL 3.3, thay đổi material không upload atlas, vòng đời GPU resources và cảnh 32 card chồng lớp.
- Các bài RenderCore R0 và tất cả bài Construction Graph V4/Card Editor/Fiber Engine cũ tiếp tục đạt.
- Bài test trên Linux xác minh shader chạy trên OpenGL thật (Mesa có thể dùng software rasterizer), **không phải benchmark GPU Windows**.

### D3D12 native technology probe (Windows)

Chạy `build_d3d12_probe_windows.bat` trên Windows có Visual Studio 2022 C++ Desktop, Windows SDK, CMake 3.20+ và GPU hỗ trợ D3D12. Chương trình trong `native_d3d12` sử dụng GPU compute và in PASS khi kết quả alpha composite khớp CPU reference.

Chưa có dữ liệu xác nhận dự án C++ đã compile trên Windows thật; build này kèm nguồn và kịch bản build để đại ca kiểm thử. Đây **không phải** viewport D3D12 tích hợp vào Fiber Studio.

## 4. Kiến trúc Hybrid OIT

```text
Card Mesh + Tile Atlas + FSD Hair BRDF
           |                      |
           +---- Front Depth Peeling (K=1/2/4)
           |        | RGBA16F front layers
           |        | depth ping-pong
           +---- Weighted OIT tail (fragments deeper than K)
                    | accum + revealage
                    v
               Hybrid Composite
                    v
              Tonemap + sRGB Display
```

**Bộ nhớ:** Ở 1920×1080, riêng 4 ảnh RGBA16F và 2 depth 24-bit (không tính alignment) khoảng 80 MiB; các render targets weighted và scene texture cần ngân sách riêng. Render nhiều pass có thể chậm hơn đáng kể trên GPU phổ thông. Đây là chế độ inspect/correctness chứ chưa phải mục tiêu 60 FPS.

### Giới hạn quan trọng

1. Depth peeling xấp xỉ vị trí fragment có depth rất gần nhau qua ngưỡng loại trừ; fragment cùng độ sâu có thể không tách thành hai lớp độc lập.
2. Weighted tail xấp xỉ thứ tự các lớp phía sau, nên không tương đương sorted transparency hoàn toàn.
3. Mỗi lớp peel cần một lượt rasterize geometry; đây không phải K-buffer 1-pass hay memory-adaptive tiles.
4. Đang render phần lớn theo OpenGL 3.3; D3D12 chỉ là compute technology probe nguồn chưa kiểm chứng Windows.
5. Chưa có deep-opacity shadows, HDRI/IBL, GPU timing queries, resource residency budget 4GB, OCIO và Render Match với Arnold/Unreal.
6. Lệnh `glGenerateMipmap` vẫn tạo lại mipmap toàn trang khi update một tile; chưa có per-tile mip cache.
7. Chưa kiểm thử WGL thực tế trên Windows; cần QA trên NVIDIA và AMD trước khi có thể gọi đây là bản release.
8. Cửa sổ GPU Render Studio vẫn tách biệt với Card Editor cũ. Chưa chuyển toàn bộ UI sang Qt/native.

## 5. Tiếp theo để đạt sản phẩm thương mại

- D3D12/Qt native viewport thật, tối ưu GPU frame graph, phân bổ bộ nhớ và timestamp queries.
- GPU *adaptive bounded K-buffer* hoặc tương đương, có so sánh chất lượng/tốc độ với bản hybrid multipass này.
- FiberShadow/Deep Opacity, HDRI và material calibration với Arnold/Unreal trên card thật.
- Texture upload/mipmap per-tile và GPU caching tối ưu.
- Benchmark GTX 1650 4GB và GPU AMD 4GB: p95/p99 frame time, VRAM peak và chất lượng ảnh.
