# Fiber Strand Designer v1.2 — Construction Graph V4 (bản thử nghiệm)

**Bản build này dùng để kiểm thử lõi tạo hình thủ tục dạng graph**, không phải bản commercial production. Tính năng Fiber Studio cũ, atlas và Card Editor v1.1 vẫn được giữ lại. V4 hiện là lõi CPU tham chiếu cho kiến trúc tổng quát, chưa phải renderer GPU D3D12 mà dự án sẽ phát triển riêng.

## Chạy trên Windows

1. Giải nén file ZIP, cài **Python 3.11+** (đánh dấu *Add Python to PATH*).
2. Nhấn đúp `run_windows.bat`. Lần đầu cần Internet để cài NumPy và Pillow.
3. Chọn một tile trong danh sách bên trái.
4. Nhấn **Construction Graph V4** trên thanh trên cùng.
5. Chọn một mẫu trong dropdown, nhấn **Load preset** (mặc định khởi tạo từ tile đang chọn).
6. Chọn từng operator ở panel trái để chỉnh tham số hoặc nối đầu vào trong **Node Inspector**.
7. Nhấn Enter/Commit để cập nhật preview; nhấn **Apply to tile** để sử dụng graph làm nguồn tạo sợi cho tile hiện tại.
8. Quay về Fiber Studio để xem Color/Alpha/Normal/Flow và các map còn lại, xem Atlas, lưu `.fsd` hoặc xuất texture.

> Khi tile chạy bằng Construction Graph, nhóm slider **Fiber Studio cũ** không điều khiển graph. Vui lòng chỉnh trong Construction Graph. Muốn trở về engine cũ, dùng `Apply preset` trên Fiber Studio và xác nhận thay thế graph.

### Lệnh CLI không cần GUI

```powershell
python -m fiberstrand.construction.cli --preset "Feather / Peacock Branches" --out exports/Peacock --size 512
python -m fiberstrand.construction.cli --graph samples/v4/Graph_Peacock.json --out exports/Peacock --size 512
python -m unittest discover -s tests -v
```

### Tạo EXE Windows

Chạy `build_exe_windows.bat`. Script sử dụng PyInstaller chạy trên **máy Windows của đại ca** để đóng gói. Gói này cung cấp mã nguồn và script, **không có EXE Windows build sẵn**.

## Những phần lõi V4 đã có thật

- **Typed Graph DAG:** `points`, `curves`, `scalar_field`, `color_field`; kiểm tra kiểu dữ liệu, kết nối thiếu và chu trình graph.
- **12 operator thực thi:** Path, Scatter, Along, Grow, Deform, Taper, Join, Instance, Color Field, Scalar Field, Paint, Filter.
- **Tạo cấu trúc nhiều cấp:** một `Curve` có thể là trục, barb, sợi thường hoặc guide. Có thể phân bố nhánh con tiếp từ bất kỳ CurveSet nào.
- **Field tùy biến:** eye nhiều vòng, stripes, gradient, noise; scalar constant/gradient/radial phục vụ điều khiển cấu trúc như độ dài, taper và filter.
- **Pattern theo hình học:** color field được lấy mẫu dọc từng sợi, không chỉ tô gradient 3 màu từ gốc tới ngọn.
- **Node cache có fingerprint:** nút không phụ thuộc vào thay đổi được tái sử dụng trong preview của Construction Studio.
- **Ổn định seed:** các điểm scatter hiện có giữ vị trí khi tăng số lượng, miễn là không thay đổi quy tắc ảnh hưởng tới chúng.
- **Graph editor:** chọn node, chỉnh giá trị và đầu vào đúng kiểu, thêm/xóa operator, chọn output, Undo/Redo, import/export graph JSON.
- **Tích hợp `.fsd`:** graph được lưu cùng tile. Các dự án v1.0/v1.1 vẫn mở được.
- **Unified maps:** giữ 9 kênh Color, Alpha, Normal, Flow, Depth, AO, ID, Roughness và RGB Mask.
- **Atlas theo tile:** chỉnh một tile không thay đổi vùng atlas của những tile độc lập khác.
- **Tài nguyên có giới hạn:** cỡ graph, số điểm, curve và sample được chặn nhằm tránh bùng nổ phân nhánh do người dùng cấu hình.

## Bốn graph mẫu

| Mẫu | Cấu trúc |
|---|---|
| Fur / Soft Undercoat | Scatter → Grow → Taper → Color Gradient |
| Hair / Curly Locks | Scatter → Grow → Deform → Taper → Stripe Color |
| Feather / Peacock Branches | Rachis → Along → Grow Barbs → Along → Grow Barbules → Join → Eye Pattern |
| Experimental / Instances | Path → Scatter → Instance → Color Noise |

File JSON riêng và ảnh preview có trong `samples/v4` và `examples/v4`.

## Cách thử sức mạnh mở rộng

- Mở Peacock, chọn `barbule_roots` rồi đổi `count` từ 24 lên 32: tăng số nhánh nhỏ của mỗi barb.
- Chọn `barbules`, đổi `angle`, `length`, `bend`: nhánh nhỏ đổi hình dạng nhưng vẫn phát sinh từ barb.
- Chọn `eye`, đổi `radius_x`, `radius_y`, `center_y`, `palette` (JSON) để thay đổi hoa văn mắt công trên toàn bộ cấu trúc.
- Chọn `merge_b` làm output tạm để kiểm tra hình học trước khi tô màu; chọn lại `colorize` để có pattern.
- Chọn operator `scalar_field`, tạo node, gắn vào cổng `length_field` của một `grow`; chọn mode `radial` để thay đổi chiều dài theo vị trí.
- Thêm `deform` sau một kết quả `curves` để tạo biến dạng chung; chọn node kết quả làm output.

## Giới hạn bản kiểm thử

- Hệ hình học hiện **2D trong không gian tile**, chưa có node editor nối dây trực quan, chưa hỗ trợ full 3D structural primitives/ribbons/surfaces.
- **12 operator**, chưa có toàn bộ Operator SDK, full Compound System, Curve Paint Brush, ảnh tham chiếu hoặc Node Graph Compiler native.
- Feather/Vane là **mô phỏng cấu trúc thủ tục 2.5D**, không phải mô phỏng vi cấu trúc sinh học/quang học chính xác; ảnh lông công mẫu mang tính thử thuật toán và pattern.
- Node cache giảm phần tạo cấu trúc, nhưng **raster CPU vẫn bake lại toàn bộ tile** khi người dùng sửa; chưa có dirty-map raster hoặc GPU compute.
- Color field được lấy mẫu trên các điểm hình học; muốn ranh giới màu cực sắc có thể cần tăng `points_per_curve`/resample.
- Nghiệm thu hiện qua các test chức năng, chưa benchmark VRAM 4 GB, viewport GPU, Arnold/Unreal matching hoặc FPS của D3D12 RenderCore.
- Save project không lưu cache PNG. Muốn xuất file atlas sản xuất thì dùng **Export Atlas** của Fiber Studio.

## Kiểm thử và changelog

```powershell
python -m unittest discover -s tests -v
```

Bộ kiểm thử gồm graph typing/cycle, deterministic geometry, caching, stability khi tăng mật độ, rendering 9 map, alpha/color consistency, project save/load, atlas independence và các bài tương thích từ phiên bản trước.
