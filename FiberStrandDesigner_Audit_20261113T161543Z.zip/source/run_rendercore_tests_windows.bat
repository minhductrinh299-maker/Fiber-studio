@echo off
setlocal
cd /d "%~dp0"
if exist .venv\Scripts\python.exe (
  set PY=.venv\Scripts\python.exe
) else (
  set PY=python
)
%PY% -m pip install pytest
if errorlevel 1 exit /b 1
%PY% -m pytest -q tests
if errorlevel 1 exit /b 1
echo Test suite finished. EGL-only GPU tests are skipped on Windows; manually verify WGL Studio.
echo For native D3D12 compute probe, run build_d3d12_probe_windows.bat
pause
endlocal
