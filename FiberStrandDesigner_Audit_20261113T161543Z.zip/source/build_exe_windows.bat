@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (set "PY=py -3") else (set "PY=python")
if not exist .venv\Scripts\python.exe (
  echo Creating build environment ...
  %PY% -m venv .venv || goto :error
)
.venv\Scripts\python.exe -m pip install -r requirements.txt || goto :error
.venv\Scripts\python.exe -m pip install --upgrade "pyinstaller>=6.0" || goto :error
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onedir --windowed --name "FiberStrandDesigner" --icon "assets\branding\FSD_Peacock_Logo_Branding_Kit_for_Codex\FSD_Peacock_Brand_Kit\04_windows\FiberStrandDesigner.ico" --add-data "assets;assets" --add-data "fiberstrand\rendercore\shaders;fiberstrand\rendercore\shaders" --add-data "samples\rendercore;samples\rendercore" --add-data "vendor;vendor" --add-data "THIRD_PARTY_LICENSES.md;." --add-binary "fiberstrand\native\fsd_fbx.dll;fiberstrand\native" main.py || goto :error
echo.
echo Build ready: dist\FiberStrandDesigner\FiberStrandDesigner.exe
pause
goto :end
:error
echo Windows EXE build failed. Check Python installation and network connection.
pause
:end
endlocal
