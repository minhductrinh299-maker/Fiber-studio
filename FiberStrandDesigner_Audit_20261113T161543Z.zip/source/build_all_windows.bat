@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo  FSD v1.6 : GUI + tests + D3D12 experimental probes
 echo ============================================================
where py >nul 2>nul
if not errorlevel 1 (set "PY=py -3") else (set "PY=python")
if not exist .venv\Scripts\python.exe (
  %PY% -m venv .venv || goto :error
)
.venv\Scripts\python.exe -m pip install -r requirements.txt "pytest>=8" "pyinstaller>=6" || goto :error
.venv\Scripts\python.exe -m pytest -q tests || goto :error
where cmake >nul 2>nul
if errorlevel 1 (
  echo WARNING: CMake not found; native D3D12 probes not built.
) else (
  cmake -S native_d3d12 -B native_d3d12\build -A x64 || goto :error
  cmake --build native_d3d12\build --config Release || goto :error
  ctest --test-dir native_d3d12\build -C Release --output-on-failure || goto :error
)
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onedir --windowed --name "FiberStrandDesigner" --add-data "fiberstrand\rendercore\shaders;fiberstrand\rendercore\shaders" --add-data "samples\rendercore;samples\rendercore" main.py || goto :error
echo.
echo GUI BUILD: dist\FiberStrandDesigner\FiberStrandDesigner.exe
echo IMPORTANT: inspect actual GPU and validate WGL/OIT on Windows 4 GB.
goto :end
:error
echo Build/test failed: read error above and README_RENDERCORE_R3_VI.md.
exit /b 1
:end
endlocal
