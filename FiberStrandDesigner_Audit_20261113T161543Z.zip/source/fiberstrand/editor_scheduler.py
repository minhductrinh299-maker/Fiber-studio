"""One pending frame, newest state wins; no mouse-event debounce cancellation."""
import math
import time


class LatestFrameScheduler:
    def __init__(self,widget,draw,interval_ms=16):
        self.widget=widget;self.draw=draw;self.interval=interval_ms/1000
        self.pending=None;self.dirty=False;self.interacting=False;self.closed=False
        self.last_frame=0.;self.input_time=None;self.in_frame=False

    def request(self,input_event=False):
        if self.closed:return
        self.dirty=True
        if input_event:self.input_time=time.perf_counter()
        if self.pending is None and not self.in_frame:
            delay=max(0,math.ceil((self.last_frame+self.interval-time.perf_counter())*1000))
            self.pending=self.widget.after(delay,self._frame)

    def active(self,value):
        self.interacting=bool(value);self.request()

    def _frame(self):
        self.pending=None
        if self.closed:return
        if not self.dirty and not self.interacting:return
        self.in_frame=True;self.dirty=False
        received=self.input_time;self.input_time=None
        try:more=bool(self.draw(received))
        finally:self.in_frame=False;self.last_frame=time.perf_counter()
        if more or self.interacting or self.dirty:self.request()

    def close(self):
        self.closed=True
        if self.pending is not None:
            self.widget.after_cancel(self.pending);self.pending=None
