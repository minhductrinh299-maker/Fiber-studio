"""Static OBJ/MTL and independent native FBX import. Parsing/texture decode run on workers."""
from pathlib import Path
import shlex
import uuid
import numpy as np
from PIL import Image

MAX_TRIANGLES=1000000


def material_default():
    return dict(color=[.48,.50,.54],roughness=.55,maps={})


def read_mtl(path):
    result={};current=None
    if not path.is_file():return result
    for line in path.read_text(encoding='utf-8-sig',errors='replace').splitlines():
        parts=line.strip().split(maxsplit=1)
        if len(parts)<2:continue
        key,value=parts
        if key=='newmtl':current=result.setdefault(value,material_default())
        elif current is not None:
            if key=='Kd':current['color']=list(map(float,value.split()[:3]))
            elif key=='Ns':current['roughness']=float(np.clip(np.sqrt(2/(float(value)+2)),.03,1))
            elif key in ('map_Kd','map_Bump','bump','norm','map_Pr','map_Ks','map_d','map_Pm','map_Ke','map_AO'):
                channel={'map_Kd':'color','map_Bump':'bump','bump':'bump','norm':'normal',
                         'map_Pr':'roughness','map_Ks':'specular','map_d':'alpha',
                         'map_Pm':'metallic','map_Ke':'emission','map_AO':'ao'}[key]
                # MTL options precede the filename. Quoted paths are supported.
                words=shlex.split(value,posix=False)
                filename=' '.join(words).strip('"') if not value.startswith('-') else words[-1].strip('"')
                current['maps'][channel]=str((path.parent/filename.replace('\\','/')).resolve())
    return result


def triangulate(points):
    """Ear clipping on the dominant projection, including concave OBJ polygons."""
    points=np.asarray(points,float)
    normal=np.sum(np.cross(points,np.roll(points,-1,axis=0)),axis=0)
    p=np.delete(points,int(np.argmax(abs(normal))),axis=1)
    signed=np.sum(p[:,0]*np.roll(p[:,1],-1)-np.roll(p[:,0],-1)*p[:,1])
    orientation=1 if signed>=0 else -1
    indices=list(range(len(p)));triangles=[]
    def cross(a,b):return a[0]*b[1]-a[1]*b[0]
    while len(indices)>3:
        clipped=False
        for k,b in enumerate(indices):
            a,c=indices[k-1],indices[(k+1)%len(indices)]
            if cross(p[b]-p[a],p[c]-p[b])*orientation<=1e-12:continue
            contains=False
            for j in indices:
                if j in (a,b,c):continue
                edges=[cross(p[v]-p[u],p[j]-p[u])*orientation for u,v in ((a,b),(b,c),(c,a))]
                if min(edges)>=-1e-12:contains=True;break
            if contains:continue
            triangles.append((a,b,c));indices.pop(k);clipped=True;break
        if not clipped:raise ValueError('Non-simple or degenerate polygon; triangulate this face in the source DCC')
    if len(indices)==3:triangles.append(tuple(indices))
    return triangles


def validate(record):
    vertices=np.asarray(record['vertices'],np.float32).reshape(-1,3)
    faces=np.asarray(record['triangles'],np.int64).reshape(-1,3)
    if not len(vertices) or not len(faces):raise ValueError('Empty mesh')
    if len(faces)>MAX_TRIANGLES:raise ValueError(f'Mesh exceeds {MAX_TRIANGLES:,} triangles')
    if not np.isfinite(vertices).all() or faces.min()<0 or faces.max()>=len(vertices):raise ValueError('Invalid mesh data')
    uv=np.asarray(record.get('uv',np.zeros((len(vertices),2))),np.float32).reshape(-1,2)
    if len(uv)!=len(vertices) or not np.isfinite(uv).all():raise ValueError('Invalid UV data')
    normals=np.asarray(record.get('normals',np.zeros_like(vertices)),np.float32).reshape(-1,3)
    if len(normals)!=len(vertices) or not np.isfinite(normals).all():raise ValueError('Invalid normals')
    missing=np.linalg.norm(normals,axis=1)<1e-8
    if np.any(missing):
        derived=np.zeros_like(vertices)
        tri=vertices[faces];n=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0])
        for i in range(3):np.add.at(derived,faces[:,i],n)
        normals[missing]=derived[missing]
    normals/=np.maximum(np.linalg.norm(normals,axis=1,keepdims=True),1e-8)
    record.update(id=record.get('id',uuid.uuid4().hex),visible=True,locked=False,
                  position=[0.,0.,0.],scale=1.,vertices=vertices.tolist(),triangles=faces.tolist(),
                  normals=normals.tolist(),uv=uv.tolist())
    record.setdefault('material',material_default())
    return record


def read_obj(path):
    path=Path(path);positions=[];normals=[];uv=[];groups={};materials={}
    name=path.stem;material='';count=0
    def index(value,size):
        n=int(value);i=n-1 if n>0 else size+n
        if n==0 or not 0<=i<size:raise ValueError('OBJ index out of bounds')
        return i
    with path.open(encoding='utf-8-sig',errors='replace') as handle:
        for number,line in enumerate(handle,1):
            fields=line.partition('#')[0].strip().split()
            if not fields:continue
            op,args=fields[0],fields[1:]
            try:
                if op=='v':positions.append(list(map(float,args[:3])))
                elif op=='vn':normals.append(list(map(float,args[:3])))
                elif op=='vt':uv.append(list(map(float,args[:2])))
                elif op in ('o','g'):name=' '.join(args) or path.stem
                elif op=='usemtl':material=' '.join(args)
                elif op=='mtllib':
                    joined=path.parent/' '.join(args).strip('"')
                    for lib in ([joined] if joined.exists() else [path.parent/x.strip('"') for x in args]):materials.update(read_mtl(lib))
                elif op=='f':
                    if len(args)>4096:raise ValueError('Polygon exceeds 4096 corners; triangulate in the source DCC')
                    corners=[]
                    for token in args:
                        values=token.split('/')
                        corners.append((index(values[0],len(positions)),
                            index(values[1],len(uv)) if len(values)>1 and values[1] else None,
                            index(values[2],len(normals)) if len(values)>2 and values[2] else None))
                    if len(corners)<3:continue
                    bucket=groups.setdefault((name,material),dict(vertices=[],uv=[],normals=[],triangles=[],lookup={}))
                    for face in triangulate([positions[c[0]] for c in corners]):
                        indices=[]
                        for j in face:
                            key=corners[j]
                            if key not in bucket['lookup']:
                                bucket['lookup'][key]=len(bucket['vertices'])
                                bucket['vertices'].append(positions[key[0]])
                                bucket['uv'].append(uv[key[1]] if key[1] is not None else [0.,0.])
                                bucket['normals'].append(normals[key[2]] if key[2] is not None else [0.,0.,0.])
                            indices.append(bucket['lookup'][key])
                        bucket['triangles'].append(indices);count+=1
                        if count>MAX_TRIANGLES:raise ValueError('Import triangle budget exceeded')
                if len(positions)>2000000:raise ValueError('OBJ exceeds 2 million source positions')
            except (ValueError,IndexError) as error:raise ValueError(f'OBJ line {number}: {error}') from error
    output=[]
    for (name,mat),record in groups.items():
        record.pop('lookup')
        record.update(name=name+(f' / {mat}' if mat else ''),source=str(path.resolve()),
                      material=materials.get(mat,material_default()))
        output.append(validate(record))
    if not output:raise ValueError('No polygon meshes in OBJ')
    return output


def import_scene(path):
    path=Path(path).resolve()
    if path.stat().st_size>512*1024**2:raise ValueError('Input exceeds 512 MiB budget')
    if path.suffix.lower()=='.obj':return read_obj(path)
    if path.suffix.lower()!='.fbx':raise ValueError('Choose OBJ or FBX')
    from .fbx_reader import read_fbx
    return [validate(record) for record in read_fbx(path,MAX_TRIANGLES)]


def decode_texture(path,max_edge=2048):
    with Image.open(path) as image:
        image.load();image=image.convert('RGBA')
        image.thumbnail((max_edge,max_edge),Image.Resampling.LANCZOS)
        return image
