"""Bounded-memory closest point queries on a median-split triangle BVH."""
import heapq
import numpy as np


def closest(points,triangles):
    p=np.asarray(points,float)
    a,b,c=triangles[:,0],triangles[:,1],triangles[:,2]
    ab,ac=b-a,c-a
    n=np.cross(ab,ac);n2=np.sum(n*n,axis=1)
    projection=p-n*(np.sum((p-a)*n,axis=1)/np.maximum(n2,1e-20))[:,None]
    d00=np.sum(ab*ab,1);d01=np.sum(ab*ac,1);d11=np.sum(ac*ac,1)
    ap=projection-a;d20=np.sum(ap*ab,1);d21=np.sum(ap*ac,1)
    denominator=d00*d11-d01*d01
    u=(d11*d20-d01*d21)/np.maximum(denominator,1e-20)
    v=(d00*d21-d01*d20)/np.maximum(denominator,1e-20)
    inside=(n2>1e-20)&(u>=0)&(v>=0)&(u+v<=1)
    candidates=[np.where(inside[:,None],projection,np.inf)]
    for start,end in ((a,b),(b,c),(c,a)):
        delta=end-start
        t=np.clip(np.sum((p-start)*delta,1)/np.maximum(np.sum(delta*delta,1),1e-20),0,1)
        candidates.append(start+t[:,None]*delta)
    candidates=np.stack(candidates)
    distances=np.sum((candidates-p)**2,axis=2)
    i,j=np.unravel_index(int(np.argmin(distances)),distances.shape)
    normal=n[j]/max(np.sqrt(n2[j]),1e-10)
    return candidates[i,j],normal,float(distances[i,j])


class SurfaceBVH:
    def __init__(self,record):
        vertices=np.asarray(record['vertices'],np.float32)*np.float32(record.get('scale',1))+np.asarray(record.get('position',[0,0,0]),np.float32)
        self.triangles=vertices[np.asarray(record['triangles'],np.int32)]
        self.lo=self.triangles.min(axis=1);self.hi=self.triangles.max(axis=1)
        self.centers=(self.lo+self.hi)*.5
        self.nodes=[]
        def build(ids):
            lo=self.lo[ids].min(axis=0);hi=self.hi[ids].max(axis=0)
            index=len(self.nodes);self.nodes.append(None)
            if len(ids)<=24:self.nodes[index]=(lo,hi,None,None,ids)
            else:
                axis=int(np.argmax(hi-lo));order=ids[np.argsort(self.centers[ids,axis],kind='stable')];mid=len(ids)//2
                left,right=build(order[:mid]),build(order[mid:])
                self.nodes[index]=(lo,hi,left,right,None)
            return index
        build(np.arange(len(self.triangles)))

    def nearest(self,point,max_distance=float('inf')):
        point=np.asarray(point,float);best=max_distance*max_distance;answer=None
        queue=[(0.,0)]
        while queue:
            distance,index=heapq.heappop(queue)
            if distance>best:continue
            lo,hi,left,right,ids=self.nodes[index]
            if ids is not None:
                hit,normal,d2=closest(point,self.triangles[ids])
                if d2<=best:best=d2;answer=(hit,normal)
            else:
                for child in (left,right):
                    lo,hi,*_=self.nodes[child]
                    delta=np.maximum(np.maximum(lo-point,point-hi),0)
                    d2=float(delta@delta)
                    if d2<=best:heapq.heappush(queue,(d2,child))
        return answer
