"""Explicit workspace handoff using project IDs, never screenshots/demo data."""
import tkinter as tk
from tkinter import ttk

DESTINATIONS=(('Fiber Studio','fiber'),('Construction Graph','graph'),
              ('Atlas','atlas'),('Card Editor 3D','cards'),('Render Studio','render'))


def continuation_menu(parent, app, context, before=None):
    button=ttk.Menubutton(parent,text='Continue In…')
    menu=tk.Menu(button,tearoff=False);button.configure(menu=menu)
    def handoff(destination):
        if before is not None and before() is False:return
        tile_id,card_ids=context()
        app._continue_workflow(destination,tile_id,card_ids)
    for label,destination in DESTINATIONS:
        menu.add_command(label=label,command=lambda d=destination:handoff(d))
    return button


def graph_from_tile(tile):
    from copy import deepcopy
    if tile.construction_graph:return deepcopy(tile.construction_graph)
    # Parametric source, not a baked bitmap; retains seed/settings/overrides.
    source=tile.to_dict();source['construction_graph']=None
    return dict(format='fsd-construction-graph',version=1,output='fiber_source',nodes=[dict(id='fiber_source',
        op='fiber_source',inputs={},params={'tile':source})])
