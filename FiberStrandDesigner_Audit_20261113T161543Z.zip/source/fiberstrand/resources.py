"""Package-relative resource lookup, independent of process working directory."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent.parent

def resource_path(relative):
    path=(ROOT/relative).resolve()
    if not path.is_relative_to(ROOT):raise ValueError('Resource path escapes application root')
    return path

def branding_asset(name):
    folder=resource_path('assets/branding')
    theme=json.loads((folder/'ui_theme.json').read_text(encoding='utf-8'))
    path=(folder/theme['assets'][name]).resolve()
    if not path.is_relative_to(folder):raise ValueError('Invalid branding resource path')
    return path
