"""Base frame for embedded workspace views with Toplevel-compatible interface."""
import tkinter as tk

class WorkspaceFrame(tk.Frame):
    """Container frame providing Toplevel-compatible API for embedded workspaces."""
    def __init__(self, parent, bg=None):
        if bg is not None:
            super().__init__(parent, bg=bg)
        else:
            super().__init__(parent)
        self._wm_protocol_handlers = {}
        self._geom = "1200x800+0+0"

    def title(self, *args): return "Fiber Strand Designer"

    def geometry(self, newGeometry=None):
        if newGeometry is not None:
            self._geom = str(newGeometry)
            return
        w = self.winfo_width()
        h = self.winfo_height()
        if w > 1 and h > 1:
            return f"{w}x{h}+0+0"
        return self._geom

    def minsize(self, *args): return (100, 100)
    def maxsize(self, *args): return (4000, 4000)
    def resizable(self, *args): return (True, True)
    def iconbitmap(self, *args): pass

    def attributes(self, *args, **kwargs):
        if args and args[0] == '-topmost' and len(args) == 1:
            return False
        return None

    def protocol(self, name=None, func=None):
        if name and func:
            self._wm_protocol_handlers[name] = func

    def lift(self, *args):
        super().lift(*args)

    def lower(self, *args):
        super().lower(*args)

    def withdraw(self): pass
    def deiconify(self): pass
    def state(self, *args): return "normal"
