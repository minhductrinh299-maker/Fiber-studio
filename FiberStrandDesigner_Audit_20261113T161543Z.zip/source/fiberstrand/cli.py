"""Headless render pipeline, intended for automation and regression tests."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import time
from .model import Project,Tile,PRESETS,MAP_NAMES,EXTRA_MAP_NAMES
from .projectio import save_project,load_project
from .atlas import AtlasCache,write_tile_maps
from .raster import render_tile


def export_project(project:Project,folder:str|Path,verbose=True,channels=None):
    atlas=AtlasCache(project)
    start=time.perf_counter()
    tile_files=[]
    for i,tile in enumerate(project.tiles):
        ts=time.perf_counter()
        result=render_tile(tile,channels=channels)
        atlas.update_tile(result)
        tile_files.extend(write_tile_maps(folder,tile,result))
        if verbose: print(f"[{i+1}/{len(project.tiles)}] {tile.name}: {len(result.strands)} fibers, {time.perf_counter()-ts:.2f}s")
    paths=atlas.write(folder,project,names=channels or MAP_NAMES)+tile_files
    if verbose: print(f"Exported {len(paths)} files / {atlas.layout.pages} page(s) in {time.perf_counter()-start:.2f}s")
    return paths


def main(args=None):
    ap=argparse.ArgumentParser(description="Fiber Strand Designer renderer / atlas exporter")
    ap.add_argument("--project",help="Input .fsd project")
    ap.add_argument("--new",action="store_true",help="Create starter project at --project")
    ap.add_argument("--export",help="Write full-quality atlas to this directory")
    ap.add_argument("--preview",help="Render a single tile to an RGBA PNG")
    ap.add_argument("--tile",type=int,default=0,help="0-based tile index for --preview")
    ap.add_argument("--preset",choices=list(PRESETS),help="Preview a preset without a project")
    ap.add_argument("--benchmark",action="store_true")
    ap.add_argument('--all-channels',action='store_true',help='Include V2 specular/anisotropy/transmission/scatter/iridescence/cluster IDs')
    ns=ap.parse_args(args)
    if ns.project and ns.new:
        project=Project.sample();save_project(project,ns.project)
        print(f"Created {ns.project}")
    elif ns.project:
        project=load_project(ns.project)
    elif ns.preset:
        project=Project(name=ns.preset,tiles=[Tile.create(ns.preset,ns.preset)])
    else:
        project=Project.sample()
    if ns.export: export_project(project,ns.export,channels=MAP_NAMES+EXTRA_MAP_NAMES if ns.all_channels else None)
    if ns.preview or ns.benchmark:
        index=max(0,min(len(project.tiles)-1,ns.tile))
        t0=time.perf_counter()
        result=render_tile(project.tiles[index])
        print(f"Tile preview: {len(result.strands)} strands, {time.perf_counter()-t0:.2f} seconds")
        if ns.preview:
            result.maps["color"].save(ns.preview)
            print(f"Saved {ns.preview}")
    if not (ns.project or ns.export or ns.preview or ns.preset or ns.benchmark):
        ap.print_help()

if __name__=="__main__": main()
