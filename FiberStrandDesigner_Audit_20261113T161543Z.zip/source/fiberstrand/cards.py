"""Parametric 3D hair-card geometry and interchange, independent of fiber rasterization.

All lengths are editor units, +Y is up. Root->tip maps bottom->top of tile.
No tile rasterization occurs in this module.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
import json, math, uuid
from copy import deepcopy
from pathlib import Path
import numpy as np
from PIL import Image


def _limited(value, lo, hi):
    v=float(value)
    if not math.isfinite(v): raise ValueError('non-finite card parameter')
    return max(lo,min(hi,v))


@dataclass
class HairCard:
    id: str
    name: str
    tile_id: str
    root: list[float]=field(default_factory=lambda:[0.,0.,0.])
    yaw: float=0.
    tilt: float=0.
    length: float=1.
    width: float=.22
    bend: float=.06
    lift: float=.0
    twist: float=0.
    taper: float=.35
    segments: int=5
    width_profile: list[float]=field(default_factory=lambda:[1.]*5)
    offsets: list[list[float]]=field(default_factory=lambda:[[0.,0.,0.] for _ in range(5)])
    vertex_offsets: dict[str,list[float]]=field(default_factory=dict)
    locked_root: bool=True
    visible: bool=True
    locked: bool=False
    deformation_layers: list[dict]=field(default_factory=list)
    guide_id: str|None=None
    guide_points: list[list[float]]=field(default_factory=list)
    width_segments:int=1
    surface:dict=field(default_factory=dict)
    modifiers:list[dict]=field(default_factory=list)
    frozen_sources:list[dict]=field(default_factory=list)
    attachment:dict|None=None

    @classmethod
    def create(cls,tile_id,name='Card',root=None):
        return cls(uuid.uuid4().hex[:12],name,tile_id,list(root if root is not None else [0,0,0]))

    def duplicate(self,dx=.28):
        c=HairCard.from_dict(self.to_dict())
        c.id=uuid.uuid4().hex[:12];c.name=self.name+' Copy';c.root[0]+=dx
        for m in c.modifiers:m['id']=uuid.uuid4().hex
        return c

    def fast_copy(self):
        return HairCard(
            id=self.id,
            name=self.name,
            tile_id=self.tile_id,
            root=list(self.root),
            yaw=self.yaw,
            tilt=self.tilt,
            length=self.length,
            width=self.width,
            bend=self.bend,
            lift=self.lift,
            twist=self.twist,
            taper=self.taper,
            segments=self.segments,
            width_profile=list(self.width_profile),
            offsets=[list(r) for r in self.offsets],
            vertex_offsets={k:list(v) for k,v in self.vertex_offsets.items()},
            locked_root=self.locked_root,
            visible=self.visible,
            locked=self.locked,
            deformation_layers=deepcopy(self.deformation_layers),
            guide_id=self.guide_id,guide_points=deepcopy(self.guide_points),
            width_segments=self.width_segments,surface=deepcopy(self.surface),
            frozen_sources=deepcopy(self.frozen_sources),modifiers=deepcopy(self.modifiers),attachment=deepcopy(self.attachment),
        )

    def to_dict(self):
        data=asdict(self)
        if data.get('attachment'):
            data['attachment'].pop('_evaluated_matrix',None);data['attachment'].pop('_invalid_reason',None)
        return data

    @classmethod
    def from_dict(cls,d):
        keys=cls.__dataclass_fields__
        data={k:deepcopy(v) for k,v in d.items() if k in keys}
        c=cls(**data)
        c.sanitize()
        return c

    def sanitize(self):
        self.root=[_limited(i,-10000,10000) for i in self.root[:3]]
        if len(self.root)!=3: raise ValueError('Card root must have 3 coordinates')
        for name,lo,hi in [('yaw',-10000,10000),('tilt',-2.8,2.8),('length',.015,100),
                           ('width',.002,100),('bend',-5,5),('lift',-5,5),
                           ('twist',-30,30),('taper',0,1)]:
            setattr(self,name,_limited(getattr(self,name),lo,hi))
        self.segments=int(np.clip(int(self.segments),1,64))
        self.width_segments=int(np.clip(int(self.width_segments),1,16))
        if len(self.width_profile)!=5 or len(self.offsets)!=5: raise ValueError('expected 5 profile knots')
        self.width_profile=[_limited(v,.01,4) for v in self.width_profile]
        self.offsets=[[_limited(v,-20,20) for v in row] for row in self.offsets]
        if any(len(x)!=3 for x in self.offsets):raise ValueError('each offset must be xyz')
        self.vertex_offsets={str(k):[_limited(v,-20,20) for v in vals] for k,vals in self.vertex_offsets.items() if len(vals)==3}
        return self


_RIBBON_TOPOLOGY_CACHE: dict[int, tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]] = {}
_KNOT_T = np.linspace(0, 1, 5, dtype=np.float64)


def _ribbon_topology(n: int):
    cached = _RIBBON_TOPOLOGY_CACHE.get(n)
    if cached is not None:
        return cached
    t = np.linspace(0, 1, n + 1, dtype=np.float64)
    v_coords = (1.0 - t).astype(np.float32)
    uv = np.empty((2 * (n + 1), 2), dtype=np.float32)
    uv[0::2, 0] = 0.0
    uv[1::2, 0] = 1.0
    uv[0::2, 1] = v_coords
    uv[1::2, 1] = v_coords
    j = np.arange(0, 2 * n, 2, dtype=np.int32)
    faces = np.empty((2 * n, 3), dtype=np.int32)
    faces[0::2, 0] = j
    faces[0::2, 1] = j + 1
    faces[0::2, 2] = j + 2
    faces[1::2, 0] = j + 1
    faces[1::2, 1] = j + 3
    faces[1::2, 2] = j + 2
    uv.setflags(write=False)
    faces.setflags(write=False)
    cached = (t, t * t, uv, faces)
    _RIBBON_TOPOLOGY_CACHE[n] = cached
    return cached


def ribbon_mesh(card:HairCard):
    from .kernel.operations import evaluate_card_modifiers
    evaluated=evaluate_card_modifiers(card)
    if evaluated.surface or evaluated.width_segments!=1:
        from .kernel.card_surface import evaluate
        mesh=evaluate(evaluated)
    else:mesh=_legacy_ribbon_mesh(evaluated)
    if evaluated.attachment and '_evaluated_matrix' in evaluated.attachment:
        vertices,uv,faces,rows=mesh;matrix=np.asarray(evaluated.attachment['_evaluated_matrix'],float)
        vertices=(np.column_stack((vertices,np.ones(len(vertices))))@matrix.T)[:,:3].astype(np.float32)
        rows=(np.column_stack((rows,np.ones(len(rows))))@matrix.T)[:,:3].astype(np.float32)
        mesh=vertices,uv,faces,rows
    return mesh


def _legacy_ribbon_mesh(card:HairCard):
    """Return (N,3) vertices, (N,2) UVs, indexed triangles, row centers.

    Surface is a true 3D twisted ribbon, centerline offsets are interpolated.
    Editing a single card never changes any atlas texture data.
    """
    c=card
    if c.guide_points:
        from .kernel.surface import evaluate_surface,smooth_samples
        u=np.linspace(0,1,len(c.width_profile))
        width=np.asarray(c.width_profile)*c.width*np.maximum(.03,1-c.taper*u*u)
        raw=np.asarray(c.guide_points,float)
        if raw.ndim!=2 or raw.shape[1]!=3 or len(raw)<2 or not np.isfinite(raw).all():raise ValueError('Invalid guide controls')
        lengths=np.r_[0,np.cumsum(np.linalg.norm(np.diff(raw,axis=0),axis=1))]
        if lengths[-1]<1e-9:raise ValueError('Zero-length guide')
        t=np.linspace(0,1,max(9,c.segments+1))
        source_root=raw[0].copy()
        points=smooth_samples(lengths/lengths[-1],raw-source_root,t)*c.length
        x,y=points[:,0].copy(),points[:,1].copy()
        points[:,0]=x*math.cos(c.tilt)+y*math.sin(c.tilt)
        points[:,1]=-x*math.sin(c.tilt)+y*math.cos(c.tilt)
        points+=source_root
        lateral=np.array([math.cos(c.yaw),0.,-math.sin(c.yaw)])
        front=np.cross(lateral,[math.sin(c.tilt),math.cos(c.tilt),0.]);front/=max(np.linalg.norm(front),1e-8)
        points+=(4*t*(1-t)*c.bend*c.length)[:,None]*lateral+(t*t*c.lift*c.length)[:,None]*front
        points+=smooth_samples(np.linspace(0,1,5),np.asarray(c.offsets),t)
        vertices,uv,faces,center=evaluate_surface(
            points+np.asarray(c.root),c.segments,1,
            width=width,twist=[c.yaw,c.yaw-c.twist],layers=c.deformation_layers)
        for key,delta in c.vertex_offsets.items():
            row,side=map(int,key.split(':'))
            if 0<=row<=c.segments and side in (0,1):vertices[row*2+side]+=delta
        return vertices,uv,faces,center.astype(np.float32)
    n=c.segments
    t, t2, uv, faces = _ribbon_topology(n)
    yaw=float(c.yaw)
    tilt=float(c.tilt)
    # The tangent points up and may tilt left/right; width rotates in the X/Z plane.
    direction=np.array([math.sin(tilt),math.cos(tilt),0.],dtype=np.float64)
    lateral=np.array([math.cos(yaw),0.,-math.sin(yaw)],dtype=np.float64)
    front=np.cross(lateral,direction)
    front/=max(1e-9,np.linalg.norm(front))
    root=np.asarray(c.root,dtype=np.float64)
    center=(root[None,:] + t[:,None]*c.length*direction[None,:]
            + (4*t*(1-t)*c.bend*c.length)[:,None]*lateral[None,:]
            + (t2*c.lift*c.length)[:,None]*front[None,:])
    if any(x != 0.0 for row in c.offsets for x in row):
        offs=np.asarray(c.offsets,dtype=np.float64)
        from .kernel.surface import smooth_samples
        center+=smooth_samples(_KNOT_T,offs,t)
    if all(v == 1.0 for v in c.width_profile):
        widths=c.width*np.maximum(.03,1-c.taper*t2)
    else:
        prof=np.interp(t,_KNOT_T,c.width_profile)
        widths=c.width*prof*np.maximum(.03,1-c.taper*t2)
    angles=c.twist*t
    from .kernel.surface import transport
    _,normal,binormal=transport(center,initial_normal=lateral)
    wings=np.cos(angles)[:,None]*normal-np.sin(angles)[:,None]*binormal
    half_wings=wings*(widths*0.5)[:,None]
    verts=np.empty((2*(n+1),3),dtype=np.float64)
    verts[0::2]=center-half_wings
    verts[1::2]=center+half_wings
    if c.deformation_layers:
        from .kernel.surface import deformation
        verts+=deformation(c.deformation_layers,np.repeat(t,2),np.tile([0.,1.],len(t)))
    if c.vertex_offsets:
        for k,val in c.vertex_offsets.items():
            try:
                rs,ss=k.split(':',1)
                idx=int(rs)*2+int(ss)
                if 0<=idx<len(verts):verts[idx]+=val
            except (ValueError,TypeError):pass
    return verts.astype(np.float32),uv.copy(),faces.copy(),center.astype(np.float32)


def atlas_uvs(local_uv:np.ndarray, placement, atlas_size:int):
    """Map local (u,v) to OBJ/OpenGL UV with lower-left origin.

    placement uses top-left PNG pixels; ribbon local v=1 at the root/bottom.
    """
    lu=local_uv[:,0]
    lv=local_uv[:,1]
    rot=float(getattr(placement,'rotation',0.0))%360.0
    if abs(rot)>=1e-4:
        rad=math.radians(rot)
        c,s=math.cos(rad),math.sin(rad)
        dx,dy=lu-0.5,lv-0.5
        lu=0.5+dx*c+dy*s
        lv=0.5-dx*s+dy*c
    u=(placement.x+lu*placement.width)/atlas_size
    v=1-(placement.y+lv*placement.height)/atlas_size
    return np.column_stack([u,v]).astype(np.float32)


def udim_uvs(local_uv: np.ndarray, placement, atlas_size: int) -> np.ndarray:
    """Map local ribbon (u,v) to continuous UDIM UV space [u_col, u_col+1] x [v_row, v_row+1].

    UDIM 1001 maps to [0, 1] x [0, 1].
    UDIM 1002 maps to [1, 2] x [0, 1].
    UDIM 1011 maps to [0, 1] x [1, 2].
    """
    local_mapped = atlas_uvs(local_uv, placement, atlas_size)
    udim = getattr(placement, "udim", 1001 + getattr(placement, "page", 0))
    offset = max(0, int(udim) - 1001)
    u_col = offset % 10
    v_row = offset // 10
    return np.column_stack([local_mapped[:, 0] + u_col, local_mapped[:, 1] + v_row]).astype(np.float32)


def export_obj(cards, project, cache, folder, mode: str = "udim", channels: tuple[str, ...] = ('color', 'alpha', 'normal')):
    """Export cards with baked maps, supporting UDIM format, separate Texture Sets, and legacy pages.

    - mode="udim": exports single OBJ with continuous UDIM UVs [0..N, 0..M], textures named
      FSD_Cards_Atlas_<channel>.<UDIM>.png, and standard UDIM MTL references.
    - mode="texture_set": exports separate texture sets per UDIM into TextureSet_<UDIM>/ directories,
      with [0..1] UVs and per-UDIM materials (Fiber_TextureSet_<UDIM>).
    - mode="legacy": exports separate material per page (Fiber_Atlas_00) with [0..1] UVs.
    """
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    udims = getattr(cache.layout, "udims", None) or [1001 + p for p in range(cache.layout.pages)]
    if not udims:
        udims = [1001]

    mtl = ['# Fiber Strand Designer - Universal Hair Card Exporter']

    if mode == "texture_set":
        # Separate Texture Sets per UDIM
        for udim in udims:
            page = cache.layout.udim_to_page(udim) if hasattr(cache.layout, "udim_to_page") else (udim - 1001)
            ts_dir = folder / f"TextureSet_{udim}"
            ts_dir.mkdir(parents=True, exist_ok=True)
            for channel in channels:
                im = cache.get_page(channel, page)
                im.save(ts_dir / f"{channel}.png")
                im.save(folder / f"FSD_Cards_TextureSet_{udim}_{channel}.png")

            mtl.extend([
                f'newmtl Fiber_TextureSet_{udim}',
                'Kd 1 1 1',
                'd 1',
                f'map_Kd TextureSet_{udim}/color.png',
                f'map_d TextureSet_{udim}/alpha.png',
                f'# normal TextureSet_{udim}/normal.png',
                ''
            ])
    else:
        # UDIM or Legacy mode
        for udim in udims:
            page = cache.layout.udim_to_page(udim) if hasattr(cache.layout, "udim_to_page") else (udim - 1001)
            for channel in channels:
                im = cache.get_page(channel, page)
                # Standard UDIM filename
                im.save(folder / f'FSD_Cards_Atlas_{channel}.{udim}.png')
                # Legacy page filename
                im.save(folder / f'FSD_Cards_Atlas_{page:02d}_{channel}.png')

        # Generic UDIM material entry
        mtl.extend([
            'newmtl Fiber_Atlas_UDIM',
            'Kd 1 1 1',
            'd 1',
            'map_Kd FSD_Cards_Atlas_color.<UDIM>.png',
            'map_d FSD_Cards_Atlas_alpha.<UDIM>.png',
            '# normal FSD_Cards_Atlas_normal.<UDIM>.png',
            ''
        ])

        # Per-UDIM material entries for DCC tools that bind per-tile materials
        for udim in udims:
            page = cache.layout.udim_to_page(udim) if hasattr(cache.layout, "udim_to_page") else (udim - 1001)
            mtl.extend([
                f'newmtl Fiber_Atlas_{udim}',
                'Kd 1 1 1',
                'd 1',
                f'map_Kd FSD_Cards_Atlas_color.{udim}.png',
                f'map_d FSD_Cards_Atlas_alpha.{udim}.png',
                f'# normal FSD_Cards_Atlas_normal.{udim}.png',
                ''
            ])
            if f'Fiber_Atlas_{page:02d}' != f'Fiber_Atlas_{udim}':
                mtl.extend([
                    f'newmtl Fiber_Atlas_{page:02d}',
                    'Kd 1 1 1',
                    'd 1',
                    f'map_Kd FSD_Cards_Atlas_{page:02d}_color.png',
                    f'map_d FSD_Cards_Atlas_{page:02d}_alpha.png',
                    f'# normal FSD_Cards_Atlas_{page:02d}_normal.png',
                    ''
                ])

    (folder / 'FiberCards.mtl').write_text('\n'.join(mtl), encoding='utf-8')
    out = ['# +Y up; triangles with correct tile atlas UVs', 'mtllib FiberCards.mtl']
    iv = 1
    it = 1
    manifest = []

    for card in cards:
        if not card.visible:
            continue
        if card.attachment:
            from .kernel.binding import resolved_card
            owner = getattr(project, '_object_workspace', None)
            card = resolved_card(card, owner.evaluated_objects() if owner else project.objects,
                                 owner.joint_poses if owner else None, strict=True)
        from .kernel.operations import effective_tile_id
        tile_id = effective_tile_id(card)
        p = cache.layout.placements.get(tile_id)
        if p is None:
            continue
        vertices, uv, tri, _ = ribbon_mesh(card)

        if mode == "texture_set":
            auv = atlas_uvs(uv, p, cache.layout.size)
            mat_name = f'Fiber_TextureSet_{p.udim}'
        elif mode == "legacy":
            auv = atlas_uvs(uv, p, cache.layout.size)
            mat_name = f'Fiber_Atlas_{p.page:02d}'
        else: # "udim"
            auv = udim_uvs(uv, p, cache.layout.size)
            mat_name = f'Fiber_Atlas_{p.udim}'

        out.extend([f'o Card_{card.id}', f'usemtl {mat_name}'])
        out.extend(f'v {x:.7f} {y:.7f} {z:.7f}' for x,y,z in vertices)
        out.extend(f'vt {u:.8f} {v:.8f}' for u,v in auv)
        for a,b,c in tri:
            out.append(f'f {iv+a}/{it+a} {iv+b}/{it+b} {iv+c}/{it+c}')
        iv += len(vertices)
        it += len(auv)
        manifest.append({
            'card_id': card.id,
            'tile_id': card.tile_id,
            'udim': getattr(p, "udim", 1001 + p.page),
            'atlas_page': p.page,
            'segments': card.segments,
            'material': mat_name,
        })

    (folder / 'FiberCards.obj').write_text('\n'.join(out) + '\n', encoding='utf-8')
    manifest_meta = {
        'generator': 'Fiber Strand Designer',
        'format': mode,
        'cards': manifest,
        'up': 'Y',
        'uv_origin': 'bottom-left',
        'udims': udims,
        'note': 'Full UDIM texture coordinates supported. Multi-UDIM or TextureSet maps written.',
    }
    (folder / 'FiberCards_manifest.json').write_text(json.dumps(manifest_meta, indent=2), encoding='utf-8')
    return folder / 'FiberCards.obj'


def change_segments(card:HairCard,segments:int):
    """Change tessellation without repeatedly resampling the sculpt source."""
    new=int(np.clip(segments,1,64))
    if new==card.segments:return
    from .kernel.surface import capture_vertices
    capture_vertices(card)
    card.segments=new


def change_width_segments(card:HairCard,segments:int):
    new=int(np.clip(segments,1,16))
    if new==card.width_segments:return
    from .kernel.surface import capture_vertices
    capture_vertices(card);card.width_segments=new
