"""CPU textured card viewport (stdlib Tk + Pillow) with perspective projection.

Texture sampling uses the cached atlas page and its placement, not the fiber
procedural generator. Canvas overlays remain immediately responsive on drag.
This portable preview intentionally doesn't pretend to be a GPU viewport.
"""
from __future__ import annotations
import math
import numpy as np
from PIL import Image,ImageDraw,ImageTk
from .cards import ribbon_mesh
from .dpi import pixels


def camera_project(points,width,height,yaw=-.25,pitch=.08,distance=4.9,target=(0,.7,0)):
    pts=np.asarray(points,dtype=float).reshape(-1,3)
    # Orbit camera basis, +Y world up.
    cp=math.cos(pitch);sp=math.sin(pitch);cy=math.cos(yaw);sy=math.sin(yaw)
    cam=np.asarray(target,dtype=float)+distance*np.array([sy*cp,sp,cy*cp])
    forward=np.asarray(target,dtype=float)-cam;forward/=np.linalg.norm(forward)
    right=np.cross(forward,np.array([0.,1.,0.]));right/=max(1e-8,np.linalg.norm(right))
    up=np.cross(right,forward)
    rel=pts-cam
    z=rel@forward
    f=max(100,min(width,height)*1.45)
    xy=np.column_stack([width*.5+f*(rel@right)/np.maximum(z,.04),
                        height*.53-f*(rel@up)/np.maximum(z,.04)])
    return xy,z


def _perspective_coeffs(dst,src):
    # dst pixel coordinates to source coordinates (Pillow PERSPECTIVE inverse map)
    a=[];b=[]
    for (x,y),(u,v) in zip(dst,src):
        a.extend([[x,y,1,0,0,0,-u*x,-u*y],
                  [0,0,0,x,y,1,-v*x,-v*y]])
        b.extend([u,v])
    try: return tuple(np.linalg.solve(np.asarray(a,dtype=float),np.asarray(b,dtype=float)))
    except np.linalg.LinAlgError:return None


def texture_quad(canvas, tile_img:Image.Image, corners, uv, max_dimension=1024):
    """Warp one polygon cell with alpha, returns small patch and top-left position."""
    p=np.asarray(corners,dtype=float)
    x0=max(0,int(math.floor(np.min(p[:,0]))));x1=min(canvas.width,int(math.ceil(np.max(p[:,0]))))
    y0=max(0,int(math.floor(np.min(p[:,1]))));y1=min(canvas.height,int(math.ceil(np.max(p[:,1]))))
    if x1<=x0 or y1<=y0 or x1-x0>max_dimension or y1-y0>max_dimension:return None
    dst=p-np.array([x0,y0]);scale=np.array([tile_img.width-1,tile_img.height-1])
    src=np.asarray(uv)*scale
    coeff=_perspective_coeffs(dst,src)
    if coeff is None:return None
    patch=tile_img.transform((x1-x0,y1-y0),Image.Transform.PERSPECTIVE,coeff,
                              resample=Image.Resampling.BILINEAR,fillcolor=(0,0,0,0))
    mask=Image.new('L',patch.size,0)
    d=ImageDraw.Draw(mask)
    # Quad vertex order: a=root left, b=root right, c=tip right, d=tip left.
    d.polygon([tuple(map(float,q)) for q in dst],fill=255)
    a=np.asarray(patch.getchannel('A'),dtype=np.uint8)
    m=np.asarray(mask,dtype=np.uint8)
    patch.putalpha(Image.fromarray(np.minimum(a,m)))
    return patch,(x0,y0)


def make_background(w,h):
    bg=Image.new('RGBA',(w,h),(23,26,31,255))
    d=ImageDraw.Draw(bg)
    # Subtle gradient and a grounded reference grid (not part of scene geometry).
    for y in range(h):
        x=y/max(h,1)
        d.line((0,y,w,y),fill=(int(28-8*x),int(31-8*x),int(37-8*x),255))
    return bg


class CardPreview:
    def __init__(self,canvas):
        self.canvas=canvas
        self.cache={}
        self.image=None
        self.photo=None
        self.hit=[]
        self.handles={}

    def render(self,cards,selected,tile_image,yaw,pitch,distance,show_wire=False,quality='textured',target=(0,.7,0)):
        w=max(100,self.canvas.winfo_width());h=max(100,self.canvas.winfo_height())
        # Render CPU fallback at the actual client-pixel size. Enlarging an
        # 1100x740 bitmap on QHD made both textures and overlays look soft.
        dw=w;dh=h
        self.canvas.delete('all')
        bg=make_background(dw,dh)
        d=ImageDraw.Draw(bg,'RGBA')
        # Ground/reference guides
        grid_lines=[]
        for a in np.arange(-2,2.01,.5):
            grid_lines.extend([np.array([[-2,0,a],[2,0,a]]),np.array([[a,0,-2],[a,0,2]])])
        for line in grid_lines:
            pp,zz=camera_project(line,dw,dh,yaw,pitch,distance,target)
            if np.all(zz>.05):d.line([tuple(p) for p in pp],fill=(85,91,103,58),width=1)
        # Build individually textured ribbon quads and sort for painter compositing.
        polys=[];self.hit=[];self.handles={}
        for card in cards:
            if not card.visible:continue
            verts,uv,faces,center=ribbon_mesh(card)
            projected,depth=camera_project(verts,dw,dh,yaw,pitch,distance,target)
            projected/=np.array([dw/max(1,w),dh/max(1,h)])
            if not np.all(np.isfinite(projected)):continue
            center2,_=camera_project(center,dw,dh,yaw,pitch,distance,target)
            center2/=np.array([dw/max(1,w),dh/max(1,h)])
            self.handles[card.id]={'verts':projected,'centers':center2,'uv':uv,'card':card}
            img=tile_image(card.tile_id)
            for j in range(card.segments):
                ix=[2*j,2*j+1,2*j+3,2*j+2]
                coords=projected[ix]
                if np.max(coords[:,0])<0 or np.min(coords[:,0])>w or np.max(coords[:,1])<0 or np.min(coords[:,1])>h:continue
                polys.append((float(np.mean(depth[ix])),card.id,coords,uv[ix],img))
            self.hit.append((card.id,projected))
        polys.sort(reverse=True,key=lambda x:x[0])
        # Work at preview render dimensions; scaled to widget on presentation.
        sw=dw/max(1,w);sh=dh/max(1,h)
        for depth,cid,coords,uv,img in polys:
            coords_small=coords*np.array([sw,sh])
            if img is not None and quality=='textured':
                tmp=texture_quad(bg,img,coords_small,uv,max_dimension=max(dw,dh))
                if tmp:
                    patch,pos=tmp
                    bg.alpha_composite(patch,pos)
            else:
                col=(190,151,104,240) if cid in selected else (134,121,100,210)
                ImageDraw.Draw(bg).polygon([tuple(q) for q in coords_small],fill=col)
        if dw!=w or dh!=h:bg=bg.resize((w,h),Image.Resampling.BILINEAR)
        self.image=bg
        self.photo=ImageTk.PhotoImage(bg)
        self.canvas.create_image(0,0,image=self.photo,anchor='nw')
        # Outline and handles: cheap Tk canvas overlay, redrawn at full pointer rate.
        self.draw_handles(selected,show_wire)

    def draw_handles(self,selected,show_wire=False,mode='Shape',selection_mode='Card'):
        self.canvas.delete('overlay')
        for cid,info in self.handles.items():
            if cid not in selected and not show_wire:continue
            c=info['card'];xy=info['verts']
            color='#eac188' if cid in selected else '#677483'
            for j in range(c.segments):
                for a,b in [(2*j,2*j+2),(2*j+1,2*j+3)]:
                    self.canvas.create_line(*xy[a],*xy[b],fill=color,width=max(1,pixels(self.canvas,1.6 if cid in selected else 1)),tags='overlay')
            if cid in selected:
                i0=xy[0];i1=xy[1];im=(i0+i1)/2
                tip=(xy[-1]+xy[-2])/2
                for name,p in [('Root',im),('Tip',tip)]:
                    r=pixels(self.canvas,5)
                    self.canvas.create_oval(p[0]-r,p[1]-r,p[0]+r,p[1]+r,
                                            fill='#f3c67c',outline='#32231a',tags=('overlay','handle_'+name.lower()))
                if mode=='Mesh':
                    for i in range(1,c.segments):
                        p=(xy[2*i]+xy[2*i+1])/2
                        r=pixels(self.canvas,3)
                        self.canvas.create_oval(p[0]-r,p[1]-r,p[0]+r,p[1]+r,fill='#f5ba73',outline='',tags='overlay')
                else:
                    mid=(xy[2*(c.segments//2)]+xy[2*(c.segments//2)+1])/2
                    r=pixels(self.canvas,4)
                    self.canvas.create_oval(mid[0]-r,mid[1]-r,mid[0]+r,mid[1]+r,fill='#85d7ce',outline='',tags='overlay')

    def pick(self,x,y,selection_mode='Card'):
        # Screen-space projected triangles, back-to-front depth not needed for this simple selection.
        for cid,verts in reversed(self.hit):
            card=self.handles[cid]['card']
            if selection_mode in ('Vertex','Row','Root'):
                pts=[]
                if selection_mode=='Root':pts=[(0,(verts[0]+verts[1])/2)]
                elif selection_mode=='Row':pts=[(i,(verts[2*i]+verts[2*i+1])/2) for i in range(card.segments+1)]
                else:pts=list(enumerate(verts))
                for ix,p in pts:
                    if np.linalg.norm(np.asarray([x,y])-p)<pixels(self.canvas,13):return cid,ix
            # point in triangles
            def tri_contains(a,b,c):
                p=np.array([x,y],dtype=float);v0=c-a;v1=b-a;v2=p-a
                det=v0[0]*v1[1]-v1[0]*v0[1]
                if abs(det)<1e-8:return False
                u=(v2[0]*v1[1]-v1[0]*v2[1])/det
                v=(v0[0]*v2[1]-v2[0]*v0[1])/det
                return u>=0 and v>=0 and u+v<=1
            for i in range(card.segments):
                j=2*i
                if tri_contains(verts[j],verts[j+1],verts[j+2]) or tri_contains(verts[j+1],verts[j+3],verts[j+2]):return cid,None
        return None,None

    def render_live(self,cards,selected,yaw,pitch,distance,mode='Shape',show_wire=False,target=(0,.7,0)):
        """Interactive mode: only Tk polygons, no texture regeneration or warp."""
        w=max(100,self.canvas.winfo_width());h=max(100,self.canvas.winfo_height())
        self.canvas.delete('all')
        self.canvas.configure(bg='#1b1e24')
        self.hit=[];self.handles={}
        drawlist=[]
        for card in cards:
            if not card.visible:continue
            verts,uv,tri,center=ribbon_mesh(card)
            xy,depth=camera_project(verts,w,h,yaw,pitch,distance,target)
            centers,_=camera_project(center,w,h,yaw,pitch,distance,target)
            self.handles[card.id]={'verts':xy,'centers':centers,'uv':uv,'card':card}
            self.hit.append((card.id,xy))
            for j in range(card.segments):
                idx=[2*j,2*j+1,2*j+3,2*j+2]
                drawlist.append((float(np.mean(depth[idx])),card.id,xy[idx]))
        drawlist.sort(reverse=True,key=lambda v:v[0])
        for _,cid,p in drawlist:
            self.canvas.create_polygon(*[float(k) for q in p for k in q],
                                       fill='#b99b74' if cid in selected else '#807a71',
                                       outline='#ad947a' if cid in selected else '#4c5662')
        self.draw_handles(selected,show_wire,mode)
