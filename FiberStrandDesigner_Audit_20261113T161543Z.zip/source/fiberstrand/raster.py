"""Single-source strand rasterizer.

One analytic geometry pass produces coverage and per-pixel strand attributes;
all output maps are composited from those same samples. Raster is tile-local.
This is a 2.5D artistic representation, not true multiple-scattering/AO.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable
import math
import numpy as np
from PIL import Image
from .model import Tile, MAP_NAMES, stable_int
from .geometry import Strand, generate_strands


@dataclass
class RenderResult:
    tile_id: str
    revision: int
    width: int
    height: int
    maps: dict[str, Image.Image]
    strands: list[Strand]
    metadata: dict


def _grid_for_strand(strand: Strand, width: int, height: int, anti: float):
    """Raster a strand once. Returns bounding rectangle and shared per-pixel geometry.

    By taking the MAX coverage of individual consecutive segments we avoid
    accidentally stacking a strand over itself at segment junctions.
    """
    px = np.empty_like(strand.points)
    px[:,0] = strand.points[:,0]*width
    px[:,1] = strand.points[:,1]*height
    radii = strand.radii*(width/512)
    reach = float(np.max(radii) + 1.6*anti)
    left = max(0, int(math.floor(float(np.min(px[:,0])-reach))))
    top = max(0, int(math.floor(float(np.min(px[:,1])-reach))))
    right = min(width, int(math.ceil(float(np.max(px[:,0])+reach))))
    bottom = min(height, int(math.ceil(float(np.max(px[:,1])+reach))))
    if right<=left or bottom<=top:
        return None
    w,h=right-left,bottom-top
    layer=np.zeros((h,w),dtype=np.float32)
    along=np.zeros((h,w),dtype=np.float32)
    across=np.zeros((h,w),dtype=np.float32)
    tangent_x=np.zeros((h,w),dtype=np.float32)
    tangent_y=np.zeros((h,w),dtype=np.float32)
    ts=np.linspace(0,1,len(px),dtype=np.float32)
    edge_width=max(.3,anti)
    for i in range(len(px)-1):
        (ax,ay),(bx,by)=px[i],px[i+1]
        dx,dy=float(bx-ax),float(by-ay)
        seg_len2=dx*dx+dy*dy
        if seg_len2<1e-9: continue
        pad=max(float(radii[i]),float(radii[i+1]))+edge_width+1.0
        x0=max(left,int(math.floor(min(ax,bx)-pad)))
        y0=max(top,int(math.floor(min(ay,by)-pad)))
        x1=min(right,int(math.ceil(max(ax,bx)+pad)))
        y1=min(bottom,int(math.ceil(max(ay,by)+pad)))
        if x1<=x0 or y1<=y0: continue
        yy,xx=np.mgrid[y0:y1,x0:x1]
        xx=xx.astype(np.float32)+.5
        yy=yy.astype(np.float32)+.5
        along_segment=np.clip(((xx-ax)*dx+(yy-ay)*dy)/seg_len2,0,1)
        nearest_x=ax+along_segment*dx
        nearest_y=ay+along_segment*dy
        rx=xx-nearest_x
        ry=yy-nearest_y
        dist=np.sqrt(rx*rx+ry*ry)
        radius=radii[i]+along_segment*(radii[i+1]-radii[i])
        # Smooth 1-pixel analytic edge coverage; no bitmap line drawing.
        cover=np.clip((radius-dist)/edge_width+.5,0,1)
        ly=slice(y0-top,y1-top)
        lx=slice(x0-left,x1-left)
        old=layer[ly,lx]
        better=cover>old
        if not np.any(better): continue
        np.maximum(old,cover,out=old)
        along_patch=along[ly,lx]
        across_patch=across[ly,lx]
        tx_patch=tangent_x[ly,lx]
        ty_patch=tangent_y[ly,lx]
        param=ts[i]+along_segment*(ts[i+1]-ts[i])
        d=math.sqrt(seg_len2)
        lateral=((-dy/d)*rx+(dx/d)*ry)/np.maximum(radius,.02)
        along_patch[better]=param[better]
        across_patch[better]=lateral[better]
        tx_patch[better]=dx/d
        ty_patch[better]=dy/d
    return (left,top,right,bottom,layer,along,across,tangent_x,tangent_y)


def _shade_strand(strand: Strand, along: np.ndarray, across: np.ndarray, s):
    """Color is sampled from a gradient on exactly the same coverage raster."""
    t=along
    # Root->mid->tip continuity. Artistic paint ramp uses display-space sRGB.
    t2=np.clip(t*2,0,1)
    t3=np.clip(t*2-1,0,1)
    root=strand.color_root.reshape(1,1,3)
    mid=strand.color_mid.reshape(1,1,3)
    tip=strand.color_tip.reshape(1,1,3)
    color=np.where((t[...,None]<=.5),
                   root*(1-t2[...,None])+mid*t2[...,None],
                   mid*(1-t3[...,None])+tip*t3[...,None])
    if s.pattern == "banded":
        wave=np.sin(t*math.tau*s.band_count+strand.pattern_phase*math.tau)
        band=(.5+.5*np.tanh(wave*4))
        color*= (1-s.band_strength*.68*(1-band))[...,None]
    elif s.pattern == "agouti":
        wave=np.sin(t*math.tau*s.band_count+strand.pattern_phase*math.tau)
        dark=np.clip(.5+.5*wave,0,1)
        color*= (1-s.band_strength*.8*dark)[...,None]
    elif s.pattern == "speckle":
        freckles=np.sin((t*101+strand.pattern_phase*19)*3.3)*np.sin((t*58+across*3.1)*5.1)
        marks=np.clip((freckles-.38)*2.9,0,1)
        color*= (1-s.speckle*.62*marks)[...,None]
    elif s.pattern == "ombre":
        color*= (.76+.24*t)[...,None]
    if strand.sampled_colors is not None:
        # Construction Graph samples the colour field along the actual curve,
        # not just at root / middle / tip. Same geometry parameterization as alpha.
        samples = np.asarray(strand.sampled_colors, np.float32)
        if samples.ndim == 2 and samples.shape[1] == 3 and len(samples) > 1:
            knots = getattr(strand,'t',np.linspace(0,1,len(samples),dtype=np.float32))
            if len(knots)!=len(samples):knots=np.linspace(0,1,len(samples),dtype=np.float32)
            color = np.stack([np.interp(t,knots,samples[:,i]) for i in range(3)],axis=-1).astype(np.float32)
    # Subtle pigment cross-sectional asymmetry under control of root->tip ramp.
    color*= (1-.055*np.clip(across, -1,1))[...,None]
    return np.clip(color,0,1).astype(np.float32)


def _rgb8(arr: np.ndarray) -> Image.Image:
    return Image.fromarray(np.rint(np.clip(arr,0,1)*255).astype(np.uint8),"RGB")


def _gray8(arr: np.ndarray) -> Image.Image:
    return Image.fromarray(np.rint(np.clip(arr,0,1)*255).astype(np.uint8),"L")


def render_tile(tile: Tile, size: tuple[int,int]|None=None, detail: int=20,
                progress: Callable[[float],None]|None=None,
                should_cancel: Callable[[], bool]|None=None,
                graph_evaluator=None, channels=None) -> RenderResult:
    """V2 entry point shared by GUI, graph, CLI and full-resolution export."""
    from .engine_v2.engine import ENGINE
    return ENGINE.render(tile,size,detail,channels,progress,should_cancel,graph_evaluator)


def render_tile_legacy(tile: Tile, size: tuple[int,int]|None=None, detail: int=20,
                progress: Callable[[float],None]|None=None,
                should_cancel: Callable[[], bool]|None=None,
                graph_evaluator=None) -> RenderResult:
    s=tile.settings.sanitize()
    width,height=size if size is not None else (tile.width,tile.height)
    width,height=int(width),int(height)
    if width<16 or height<16: raise ValueError("Render dimensions too small")
    if tile.construction_graph:
        from .construction.core import GraphEvaluator, to_strands
        # Cached per-node evaluation is provided in the Construction Studio;
        # batch renderer can rebuild deterministically with no global state.
        evaluator=graph_evaluator if graph_evaluator is not None else GraphEvaluator()
        strands=to_strands(evaluator.evaluate(tile.construction_graph,seed=tile.seed),tile.id,s.roughness)
    else:
        strands=generate_strands(tile,detail=detail)
    shape=(height,width)
    alpha=np.zeros(shape,np.float32)
    rgb=np.zeros((height,width,3),np.float32)  # premultiplied RGB
    normal=np.zeros((height,width,3),np.float32)
    flow=np.zeros((height,width,2),np.float32)
    depth=np.zeros(shape,np.float32)
    ao=np.zeros(shape,np.float32)
    roughness=np.zeros(shape,np.float32)
    rgb_mask=np.zeros((height,width,3),np.float32)
    ids=np.zeros(shape,np.uint32)
    n=len(strands)
    for k,strand in enumerate(strands):
        if should_cancel and k%20==0 and should_cancel():
            raise RuntimeError("Render cancelled")
        data=_grid_for_strand(strand,width,height,s.antialias)
        if data is None: continue
        l,t,r,b,cover,progress_at,across,tx,ty=data
        if not np.any(cover>0): continue
        cover=cover*strand.opacity
        sl=(slice(t,b),slice(l,r))
        prealpha=alpha[sl]
        over=1-cover
        pigment=_shade_strand(strand,progress_at,across,s)
        rgb_patch=rgb[sl]
        rgb_patch[:]=pigment*cover[...,None]+rgb_patch*over[...,None]
        # Normal: faux cylindrical strand. Works as a tangent-space normal
        # preview when cards lie on the image plane (normal map RGB).
        lateral=np.clip(across,-.94,.94)*s.fiber_roundness
        perp_x=-ty
        perp_y=tx
        nz=np.sqrt(np.maximum(.03,1-lateral**2))
        nvec=np.stack([perp_x*lateral,perp_y*lateral,nz],axis=-1)
        normal_patch=normal[sl]
        normal_patch[:]=nvec*cover[...,None]+normal_patch*over[...,None]
        tangent=np.stack([tx,ty],axis=-1)
        flow_patch=flow[sl]
        flow_patch[:]=tangent*cover[...,None]+flow_patch*over[...,None]
        dep=depth[sl]
        dep[:]=strand.depth*cover+dep*over
        # Occlusion approximation uses previous layer coverage, not true AO.
        occlusion_factor=np.clip(1-.38*prealpha-.13*(1-progress_at),0,1)
        ao_patch=ao[sl]
        ao_patch[:]=occlusion_factor*cover+ao_patch*over
        rough=roughness[sl]
        rough[:]=strand.roughness*cover+rough*over
        root_mask=1-progress_at
        mid_mask=4*progress_at*(1-progress_at)
        tip_mask=progress_at
        trio=np.stack([root_mask,mid_mask,tip_mask],axis=-1)
        mask_patch=rgb_mask[sl]
        mask_patch[:]=trio*cover[...,None]+mask_patch*over[...,None]
        prealpha[:]=cover+prealpha*over
        # ID is the visible-most strand whose coverage exceeds the threshold.
        number=int(strand.sid.split(":")[1]) + 1
        ids_patch=ids[sl]
        ids_patch[cover>.26]=number
        if progress and k%max(1,n//24)==0:
            progress((k+1)/max(1,n))
    has=alpha>1e-6
    inv=np.zeros_like(alpha)
    np.divide(1,alpha,out=inv,where=has)
    color=np.clip(rgb*inv[...,None],0,1)
    color_rgba=np.dstack([np.rint(color*255).astype(np.uint8),
                          np.rint(np.clip(alpha,0,1)*255).astype(np.uint8)])
    # Tangents and normals are normalized AFTER averaging by visible coverage.
    n3=normal*inv[...,None]
    nl=np.sqrt(np.sum(n3*n3,axis=-1))
    n3=np.divide(n3,np.maximum(1e-8,nl)[...,None])
    n3[~has]=[0,0,1]
    f2=flow*inv[...,None]
    fl=np.sqrt(np.sum(f2*f2,axis=-1))
    f2=np.divide(f2,np.maximum(1e-8,fl)[...,None])
    f2[~has]=[0,0]
    id_rgb=np.stack([(ids>>16)&255,(ids>>8)&255,ids&255],axis=-1).astype(np.uint8)
    outputs={
        "color": Image.fromarray(color_rgba,"RGBA"),
        "alpha":_gray8(alpha),
        "normal":_rgb8((n3+1)*.5),
        "flow":_rgb8(np.dstack([(f2+1)*.5,np.full(shape,.5,dtype=np.float32)])),
        "depth":_gray8(depth*inv),
        "ao":_gray8(np.where(has,ao*inv,1)),
        "id":Image.fromarray(id_rgb,"RGB"),
        "roughness":_gray8(np.where(has,roughness*inv,s.roughness)),
        "rgb_mask":_rgb8(rgb_mask*inv[...,None]),
    }
    if progress: progress(1.0)
    return RenderResult(tile.id,tile.revision,width,height,outputs,strands,
                        {"strand_count":len(strands),"resolution":[width,height],
                         "alpha_coverage_pixels":float(alpha.sum()),
                         "note":"AO and normal are artistic approximations, not a physical shading simulation"})
