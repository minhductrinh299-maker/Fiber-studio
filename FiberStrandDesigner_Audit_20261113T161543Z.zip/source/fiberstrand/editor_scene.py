"""CPU editing state and coalesced geometry jobs; no OpenGL on worker threads."""
from dataclasses import dataclass,field
from threading import Condition,Thread
import time
import json
from copy import deepcopy
import numpy as np
from .cards import HairCard,ribbon_mesh
from .kernel.operations import effective_tile_id


def card_signature(card):
    return (card.tile_id,tuple(card.root),card.yaw,card.tilt,card.length,card.width,
            card.bend,card.lift,card.twist,card.taper,card.segments,tuple(card.width_profile),
            tuple(tuple(x) for x in card.offsets),tuple(sorted((k,tuple(v)) for k,v in card.vertex_offsets.items())),
            json.dumps(card.deformation_layers,sort_keys=True,separators=(',',':')),
            card.guide_id,tuple(tuple(point) for point in card.guide_points),card.width_segments,
            json.dumps(card.surface,sort_keys=True),json.dumps(card.modifiers,sort_keys=True),json.dumps(card.attachment,sort_keys=True),card.visible)


def geometry_signature(card):
    signature=list(card_signature(card)[2:-1])
    signature[-2]=json.dumps([m for m in card.modifiers if m.get('op') not in ('material','attribute')],sort_keys=True)
    return tuple(signature)


@dataclass
class Mesh:
    vertices:np.ndarray
    indices:np.ndarray
    positions:np.ndarray
    rows:np.ndarray
    edges:np.ndarray
    center:np.ndarray
    radius:float
    origin:np.ndarray
    columns:int=2


_EDGES_CACHE: dict[int, np.ndarray] = {}


def _ribbon_edges(segments: int, tri: np.ndarray) -> np.ndarray:
    cached = _EDGES_CACHE.get(segments)
    if cached is not None:
        return cached
    edges = np.unique(np.sort(np.concatenate((tri[:, [0, 1]], tri[:, [1, 2]], tri[:, [2, 0]])), axis=1), axis=0)
    edges.setflags(write=False)
    _EDGES_CACHE[segments] = edges
    return edges


def build_mesh_card(card: HairCard, numeric_id: int) -> Mesh:
    p, uv, tri, rows = ribbon_mesh(card)
    tangent = np.gradient(rows.astype(np.float64), axis=0)
    tangent /= np.maximum(np.linalg.norm(tangent, axis=1, keepdims=True), 1e-9)
    tangent = np.repeat(tangent, card.width_segments+1, axis=0)
    face = np.cross(p[tri[:, 1]] - p[tri[:, 0]], p[tri[:, 2]] - p[tri[:, 0]])
    normal = np.zeros_like(p)
    for i in range(3):
        np.add.at(normal, tri[:, i], face)
    normal /= np.maximum(np.linalg.norm(normal, axis=1, keepdims=True), 1e-9)
    tex = np.column_stack((uv[:, 0], 1. - uv[:, 1]))
    origin = np.asarray(card.root, np.float32)
    local = p - origin
    data = np.column_stack((local, tex, tangent, normal, local, np.full(len(p), numeric_id, dtype=np.float32))).astype(np.float32)
    edges = _ribbon_edges((card.segments,card.width_segments), tri)
    center = (p.min(axis=0) + p.max(axis=0)) * .5
    radius = float(np.max(np.linalg.norm(p - center, axis=1)))
    return Mesh(
        np.ascontiguousarray(data),
        np.ascontiguousarray(tri.reshape(-1), dtype=np.uint32),
        p, rows, edges, center, radius, origin, card.width_segments+1,
    )


def build_mesh(snapshot,numeric_id):
    return build_mesh_card(HairCard.from_dict(snapshot), numeric_id)


class GeometryWorker:
    """Latest job per card; selected edits take priority over initial scene load."""
    def __init__(self):
        self.condition=Condition();self.pending={};self.results={};self.running=None
        self.closed=False;self.sequence=0
        self.thread=Thread(target=self._run,name='editor-geometry',daemon=True);self.thread.start()

    def submit(self,cid,version,snapshot,numeric_id,priority):
        with self.condition:
            self.sequence+=1
            self.pending[cid]=(priority,self.sequence,version,snapshot,numeric_id)
            self.results.pop(cid,None);self.condition.notify()

    def _run(self):
        while True:
            with self.condition:
                self.condition.wait_for(lambda:self.closed or self.pending)
                if self.closed:return
                cid=min(self.pending,key=lambda k:self.pending[k][:2])
                _,_,version,snapshot,numeric=self.pending.pop(cid);self.running=cid
            try:result=build_mesh(snapshot,numeric)
            except Exception as exc:result=exc
            with self.condition:
                if self.closed:return
                # A newer version stays queued; never publish an obsolete edit.
                if cid not in self.pending:self.results[cid]=(version,result)
                self.running=None

    def cancel(self,cid):
        with self.condition:
            self.pending.pop(cid,None)
            self.results.pop(cid,None)

    def take(self):
        with self.condition:
            values=self.results;self.results={};return values

    @property
    def busy(self):
        with self.condition:return bool(self.pending or self.results or self.running is not None)

    def close(self):
        with self.condition:
            self.closed=True;self.pending.clear();self.results.clear();self.condition.notify()


@dataclass
class Record:
    card:HairCard
    signature:tuple
    numeric_id:int
    version:int=1
    mesh:Mesh|None=None
    pending_mesh:Mesh|None=None
    gpu_version:int=0
    gpu_signature:tuple|None=None
    slot:object=None
    binding:tuple=()
    root:tuple=()
    gpu_root:tuple=(0.,0.,0.)


class EditorScene:
    def __init__(self):
        self.records={};self.numeric={};self.next_id=1;self.dirty=set();self.removed=set()
        self.selected=set();self.active=None;self.hover=None;self.hover_component=None;self.components={};self.selection_box=None
        self.revision=0;self.selection_revision=0;self.worker=GeometryWorker()
        self.root_dirty=set()

    def reconcile(self,cards):
        ids=set()
        for card in cards:
            ids.add(card.id);signature=geometry_signature(card);old=self.records.get(card.id)
            binding=(effective_tile_id(card),card.visible)
            if old is None:
                if self.next_id>=2**23:raise ValueError('Editor ID space exhausted')
                old=Record(card,signature,self.next_id,binding=binding,root=tuple(card.root));self.next_id+=1
                self.records[card.id]=old;self.numeric[old.numeric_id]=card.id
                self.root_dirty.add(card.id)
                self.dirty.add(card.id);self.revision+=1
            elif old.signature!=signature:
                old.card=card;old.signature=signature;old.version+=1
                if self.hover_component and self.hover_component[0]==card.id:self.hover_component=None
                old.pending_mesh=None
                if old.gpu_signature==signature:old.gpu_version=old.version;self.dirty.discard(card.id)
                else:self.dirty.add(card.id)
                self.revision+=1
            else:old.card=card
            if old.binding!=binding:
                old.binding=binding;self.revision+=1
            if old.root!=tuple(card.root):
                old.root=tuple(card.root);self.root_dirty.add(card.id);self.revision+=1
        for cid in set(self.records)-ids:
            record=self.records.pop(cid);self.numeric.pop(record.numeric_id,None)
            self.removed.add(cid);self.dirty.discard(cid);self.revision+=1
            self.root_dirty.discard(cid)

    def touch(self,cards):
        for card in cards:
            record=self.records.get(card.id)
            if record is None:continue
            record.card=card
            if record.root!=tuple(card.root):
                record.root=tuple(card.root);self.root_dirty.add(card.id);self.revision+=1
            signature=geometry_signature(card)
            binding=(effective_tile_id(card),card.visible)
            if record.binding!=binding:record.binding=binding;self.revision+=1
            if signature==record.signature:continue
            if self.hover_component and self.hover_component[0]==card.id:self.hover_component=None
            record.card=card;record.signature=signature;record.version+=1
            record.pending_mesh=None
            if record.gpu_signature==signature:record.gpu_version=record.version;self.dirty.discard(card.id)
            else:self.dirty.add(card.id)
            self.revision+=1

    def pump(self,budget=24,sync_selected=False,time_budget=0.004):
        # Selected cards during interactive transforms build synchronously up to time_budget
        # so Rotate/Scale/Shape reflect on the exact same frame without worker drop/lag.
        if sync_selected and self.dirty and self.selected:
            deadline=time.perf_counter()+time_budget
            for cid in list(self.selected):
                if cid not in self.dirty:continue
                record=self.records.get(cid)
                if record is None:
                    self.dirty.discard(cid)
                    continue
                self.worker.cancel(cid)
                record.pending_mesh=build_mesh_card(record.card,record.numeric_id)
                self.dirty.discard(cid)
                if time.perf_counter()>=deadline:
                    break
        # Bound snapshot creation on the UI thread. No full-scene deepcopy in a drag.
        priority=[cid for cid in self.selected if cid in self.dirty]
        remaining=budget-len(priority[:budget])
        ids=priority[:budget]+[cid for cid in self.dirty if cid not in self.selected][:max(0,remaining)]
        for cid in ids:
            record=self.records[cid]
            snapshot=record.card.to_dict()
            snapshot["attachment"]=deepcopy(record.card.attachment)
            self.worker.submit(cid,record.version,snapshot,record.numeric_id,0 if cid in self.selected else 10)
            self.dirty.discard(cid)
        for cid,(version,result) in self.worker.take().items():
            record=self.records.get(cid)
            if record is None or record.version!=version:continue
            if isinstance(result,Exception):raise result
            record.pending_mesh=result

    @property
    def busy(self):return bool(self.dirty or self.root_dirty or self.worker.busy or any(r.pending_mesh is not None for r in self.records.values()))

    def select(self,selected,components=None):
        value=set(selected)
        components=components or {}
        if value!=self.selected or components!=self.components:
            self.selected=value;self.components={k:set(v) for k,v in components.items()};self.selection_revision+=1

    def close(self):self.worker.close()
