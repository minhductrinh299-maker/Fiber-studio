"""Persistent indexed GPU chunks with three fenced upload banks per card."""
from dataclasses import dataclass,field
import ctypes as C
import numpy as np
from .rendercore.glapi import *

MAX_VERTICES=130
MAX_INDICES=384
STRIDE=60
CARDS_PER_CHUNK=256


class SubmissionFences:
    def __init__(self,gl):self.gl=gl;self.serial=0;self.completed=0;self.pending=[]
    def begin(self):self.serial+=1;return self.serial
    def end(self):
        fence=self.gl.glFenceSync(GL_SYNC_GPU_COMMANDS_COMPLETE,0)
        self.pending.append((self.serial,fence))
    def poll(self):
        while self.pending:
            serial,fence=self.pending[0]
            state=self.gl.glClientWaitSync(fence,GL_SYNC_FLUSH_COMMANDS_BIT,0)
            if state==GL_WAIT_FAILED:raise RuntimeError('Editor GPU submission fence failed')
            if state not in (GL_ALREADY_SIGNALED,GL_CONDITION_SATISFIED):break
            self.gl.glDeleteSync(fence);self.pending.pop(0);self.completed=serial
    def wait_oldest(self,timeout_ns=2_000_000):
        if not self.pending:return False
        serial,fence=self.pending[0]
        state=self.gl.glClientWaitSync(fence,GL_SYNC_FLUSH_COMMANDS_BIT,int(timeout_ns))
        if state==GL_WAIT_FAILED:raise RuntimeError('Editor GPU submission fence failed')
        if state in (GL_ALREADY_SIGNALED,GL_CONDITION_SATISFIED):
            self.gl.glDeleteSync(fence);self.pending.pop(0);self.completed=serial
            return True
        return False
    def close(self):
        for _,fence in self.pending:self.gl.glDeleteSync(fence)
        self.pending=[]


@dataclass
class Slot:
    chunk:object
    index:int
    bank:int=-1
    used:list=field(default_factory=lambda:[0,0,0])
    count:int=0
    vertices:int=0

    @property
    def first(self):return (self.index*3+self.bank)*self.chunk.max_vertices
    @property
    def offset(self):return (self.index*3+self.bank)*self.chunk.max_indices*4


class Chunk:
    def __init__(self,g,columns=2):
        self.columns=columns;self.max_vertices=65*columns;self.max_indices=64*(columns-1)*6
        self.capacity=min(CARDS_PER_CHUNK,max(8,8*1024**2//(3*(self.max_vertices*STRIDE+self.max_indices*4))))
        self.g=g;self.vao=g.name('VertexArrays');self.vbo=g.name('Buffers');self.ibo=g.name('Buffers')
        g.glBindVertexArray(self.vao);g.glBindBuffer(GL_ARRAY_BUFFER,self.vbo)
        g.glBufferData(GL_ARRAY_BUFFER,self.capacity*3*self.max_vertices*STRIDE,None,GL_DYNAMIC_DRAW)
        for location,count,offset in ((0,3,0),(1,2,12),(2,3,20),(3,3,32),(4,3,44),(5,1,56)):
            g.glEnableVertexAttribArray(location)
            g.glVertexAttribPointer(location,count,GL_FLOAT,GL_FALSE,STRIDE,V(offset))
        g.glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,self.ibo)
        g.glBufferData(GL_ELEMENT_ARRAY_BUFFER,self.capacity*3*self.max_indices*4,None,GL_DYNAMIC_DRAW)
        self.row_vao=g.name('VertexArrays');g.glBindVertexArray(self.row_vao);g.glBindBuffer(GL_ARRAY_BUFFER,self.vbo)
        for location,offset in ((0,0),(1,(columns-1)*STRIDE)):
            g.glEnableVertexAttribArray(location)
            g.glVertexAttribPointer(location,3,GL_FLOAT,GL_FALSE,STRIDE*columns,V(offset))
        g.glEnableVertexAttribArray(5)
        g.glVertexAttribPointer(5,1,GL_FLOAT,GL_FALSE,STRIDE*columns,V(56))
        self.free=[Slot(self,i) for i in reversed(range(self.capacity))]

    def close(self):
        for name in (self.vbo,self.ibo):
            value=U(name);self.g.glDeleteBuffers(1,C.byref(value))
        value=U(self.vao);self.g.glDeleteVertexArrays(1,C.byref(value))
        value=U(self.row_vao);self.g.glDeleteVertexArrays(1,C.byref(value))


class GeometryCache:
    def __init__(self,g,fences):self.g=g;self.fences=fences;self.chunks=[];self.slots={};self.upload_bytes=0

    def slot(self,cid,columns=2):
        if cid in self.slots and self.slots[cid].chunk.columns!=columns:self.remove(cid)
        if cid in self.slots:return self.slots[cid]
        chunk=next((c for c in self.chunks if c.free and c.columns==columns),None)
        if chunk is None:chunk=Chunk(self.g,columns);self.chunks.append(chunk)
        slot=chunk.free.pop();self.slots[cid]=slot;return slot

    def publish(self,cid,mesh):
        slot=self.slot(cid,getattr(mesh,"columns",2));g=self.g
        bank=next((b for b in ((slot.bank+1)%3,(slot.bank+2)%3,slot.bank)
                   if b>=0 and slot.used[b]<=self.fences.completed),None)
        if bank is None:return None
        if len(mesh.vertices)>slot.chunk.max_vertices or len(mesh.indices)>slot.chunk.max_indices:
            raise ValueError('Card mesh exceeds the 64-segment editor slot')
        first=(slot.index*3+bank)*slot.chunk.max_vertices
        offset=(slot.index*3+bank)*slot.chunk.max_indices*4
        g.glBindVertexArray(slot.chunk.vao);g.glBindBuffer(GL_ARRAY_BUFFER,slot.chunk.vbo)
        g.glBufferSubData(GL_ARRAY_BUFFER,first*STRIDE,mesh.vertices.nbytes,V(mesh.vertices.ctypes.data))
        g.glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,slot.chunk.ibo)
        g.glBufferSubData(GL_ELEMENT_ARRAY_BUFFER,offset,mesh.indices.nbytes,V(mesh.indices.ctypes.data))
        slot.bank=bank;slot.count=len(mesh.indices);slot.vertices=len(mesh.vertices)
        self.upload_bytes+=mesh.vertices.nbytes+mesh.indices.nbytes
        return slot

    def draw(self,records,serial,primitive=GL_TRIANGLES):
        groups={}
        for record in records:
            if record.slot is None:continue
            groups.setdefault(record.slot.chunk,[]).append(record.slot)
        calls=0
        for chunk,slots in groups.items():
            self.g.glBindVertexArray(chunk.vao)
            counts=(I*len(slots))(*(s.count for s in slots))
            offsets=(V*len(slots))(*(s.offset for s in slots))
            bases=(I*len(slots))(*(s.first for s in slots))
            self.g.glMultiDrawElementsBaseVertex(primitive,counts,GL_UNSIGNED_INT,offsets,len(slots),bases)
            for slot in slots:slot.used[slot.bank]=serial
            calls+=1
        return calls

    def remove(self,cid):
        slot=self.slots.pop(cid,None)
        if slot is not None:slot.chunk.free.append(slot)

    def draw_points(self,records,serial,mode):
        groups={}
        for r in records:
            if r.slot is not None:groups.setdefault(r.slot.chunk,[]).append(r.slot)
        for chunk,slots in groups.items():
            rows=mode!='Vertex'
            self.g.glBindVertexArray(chunk.row_vao if rows else chunk.vao)
            first=(I*len(slots))(*(s.first//chunk.columns if rows else s.first for s in slots))
            counts=(I*len(slots))(*(1 if mode=='Root' else s.vertices//chunk.columns if rows else s.vertices for s in slots))
            self.g.glMultiDrawArrays(GL_POINTS,first,counts,len(slots))
            for s in slots:s.used[s.bank]=serial
        return len(groups)

    @property
    def reserved_bytes(self):return sum(c.capacity*3*(c.max_vertices*STRIDE+c.max_indices*4) for c in self.chunks)

    def close(self):
        for chunk in self.chunks:chunk.close()
        self.chunks=[];self.slots={}


class RootTransforms:
    """Fenced texture-buffer transforms: moving a card uploads 16 bytes, not a mesh.

    Each bank tracks dirty numeric IDs since it was last used. No bank is
    overwritten while a prior GPU submission still references it.
    """
    def __init__(self,g,fences):
        self.g=g;self.fences=fences;self.capacity=0;self.data=np.zeros((0,4),np.float32)
        self.banks=[];self.active=-1;self.upload_bytes=0

    def _grow(self,size):
        capacity=max(256,1<<(size-1).bit_length());data=np.zeros((capacity,4),np.float32)
        data[:len(self.data)]=self.data;self.data=data
        self.close();self.capacity=capacity
        for _ in range(3):
            buffer=self.g.name('Buffers');texture=self.g.name('Textures')
            self.g.glBindBuffer(GL_TEXTURE_BUFFER,buffer)
            self.g.glBufferData(GL_TEXTURE_BUFFER,data.nbytes,None,GL_DYNAMIC_DRAW)
            self.g.glBindTexture(GL_TEXTURE_BUFFER,texture);self.g.glTexBuffer(GL_TEXTURE_BUFFER,GL_RGBA32F,buffer)
            self.banks.append({'buffer':buffer,'texture':texture,'used':0,'dirty':set(range(size))})

    def sync(self,scene):
        needed=scene.next_id
        grew=needed>self.capacity
        if grew:self._grow(needed)
        ids=set(scene.root_dirty)
        if grew:ids=set(scene.records)
        for cid in ids:
            r=scene.records.get(cid)
            if r:
                self.data[r.numeric_id,:3]=r.root
                for bank in self.banks:bank['dirty'].add(r.numeric_id)
        choices=[(self.active+i)%3 for i in (1,2,3)]
        choice=next((i for i in choices if self.banks[i]['used']<=self.fences.completed),None)
        if choice is None:return False
        # Only select a new bank when there is a transform change or growth.
        if not ids and self.active>=0:return True
        bank=self.banks[choice];self.g.glBindBuffer(GL_TEXTURE_BUFFER,bank['buffer'])
        numbers=sorted(bank['dirty']);start=None;previous=None
        ranges=[]
        for number in numbers:
            if start is None:start=previous=number
            elif number==previous+1:previous=number
            else:ranges.append((start,previous+1));start=previous=number
        if start is not None:ranges.append((start,previous+1))
        for lo,hi in ranges:
            payload=np.ascontiguousarray(self.data[lo:hi])
            self.g.glBufferSubData(GL_TEXTURE_BUFFER,lo*16,payload.nbytes,V(payload.ctypes.data))
            self.upload_bytes+=payload.nbytes
        bank['dirty'].clear();self.active=choice
        for cid in ids:
            r=scene.records.get(cid)
            if r:r.gpu_root=tuple(map(float,self.data[r.numeric_id,:3]))
        scene.root_dirty.difference_update(ids)
        return True

    def bind(self,program,serial):
        self.g.uniform(program,'uRoots',7)
        self.g.uniform(program,'uUseRoots',int(self.active>=0))
        if self.active>=0:
            bank=self.banks[self.active];self.g.glActiveTexture(GL_TEXTURE0+7)
            self.g.glBindTexture(GL_TEXTURE_BUFFER,bank['texture']);bank['used']=serial

    @property
    def reserved_bytes(self):return self.capacity*16*3

    def close(self):
        for bank in self.banks:
            value=U(bank['buffer']);self.g.glDeleteBuffers(1,C.byref(value))
            value=U(bank['texture']);self.g.glDeleteTextures(1,C.byref(value))
        self.banks=[];self.active=-1
