"""Compact Number Slider Widget for Fiber Strand Designer.

A modern Blender / Unreal style property widget:
- Shows the parameter value as a text box that can be clicked/double-clicked to type manually.
- Acts as a smooth slider: dragging horizontally adjusts the numeric value.
- Displays an accent-colored progress fill / handle bar to clearly indicate the current proportion.
- Supports integer or float precision, min/max clamps, arrow keys, and keyboard focus.
"""
from __future__ import annotations
from .ui_theme import color as ui_color
import math
import tkinter as tk
from tkinter import ttk


class NumberSlider(tk.Canvas):
    """Interactive numeric slider with integrated text field and colored progress handle."""

    def __init__(
        self,
        parent,
        variable=None,
        from_: float = 0.0,
        to: float = 1.0,
        step: float = 0.01,
        command=None,
        width: int = 150,
        height: int = 24,
        is_integer: bool = False,
        format_str: str | None = None,
        bg: str = ui_color('panel'),
        fg: str = ui_color('text'),
        fill_color: str = ui_color('control'),
        handle_color: str = ui_color('selection'),
        border_color: str = ui_color('border'),
        focus_border: str = ui_color('cyan'),
        **kwargs,
    ):
        super().__init__(
            parent,
            width=width,
            height=height,
            bg=bg,
            highlightthickness=0,
            borderwidth=0,
            takefocus=True,
            **kwargs,
        )
        self.var = variable if variable is not None else tk.DoubleVar(value=from_)
        self.from_ = float(from_)
        self.to = float(to)
        self.step = float(step)
        self.command = command
        self.is_integer = is_integer
        self.format_str = format_str

        self.bg_color = bg
        self.fg_color = fg
        self.fill_color = fill_color
        self.handle_color = handle_color
        self.border_color = border_color
        self.focus_border = focus_border

        self._dragging = False
        self._drag_start_x = 0
        self._drag_start_val = 0.0
        self._entry = None
        self._trace_id = None

        if hasattr(self.var, "trace_add"):
            self._trace_id = self.var.trace_add("write", self._on_var_write)

        self.bind("<Configure>", self._on_configure)
        self.bind("<Button-1>", self._on_button_1)
        self.bind("<B1-Motion>", self._on_b1_motion)
        self.bind("<ButtonRelease-1>", self._on_button_release_1)
        self.bind("<Double-Button-1>", self._on_double_click)
        self.bind("<Key-Left>", lambda e: self._step_value(-1))
        self.bind("<Key-Right>", lambda e: self._step_value(1))
        self.bind("<Key-Up>", lambda e: self._step_value(1))
        self.bind("<Key-Down>", lambda e: self._step_value(-1))
        self.bind("<Key-Return>", lambda e: self._start_inline_edit())
        self.bind("<Destroy>", self._on_destroy)

        self._draw_slider()

    def _on_destroy(self, event=None):
        if self._trace_id and hasattr(self.var, "trace_remove"):
            try:
                self.var.trace_remove("write", self._trace_id)
            except Exception:
                pass
            self._trace_id = None

    def get(self) -> float:
        try:
            val = self.var.get()
            if isinstance(val, str):
                val = float(val.strip().replace(",", "."))
            return int(round(val)) if self.is_integer else float(val)
        except Exception:
            return self.from_

    def set(self, value: float, notify: bool = True):
        lo, hi = min(self.from_, self.to), max(self.from_, self.to)
        try:
            val = float(value)
            if not math.isfinite(val):
                val = lo
        except Exception:
            val = lo
        clamped = max(lo, min(hi, val))
        if self.is_integer:
            clamped = int(round(clamped))

        if isinstance(self.var, tk.StringVar):
            fmt = self._get_format()
            self.var.set(fmt.format(clamped))
        elif hasattr(self.var, "set"):
            self.var.set(clamped)

        self._draw_slider()
        if notify and self.command:
            try:
                self.command(clamped)
            except TypeError:
                self.command()

    def _get_format(self) -> str:
        if self.format_str:
            return self.format_str
        if self.is_integer:
            return "{:.0f}"
        if self.step < 0.001:
            return "{:.4f}"
        if self.step < 0.01:
            return "{:.3f}"
        if self.step < 0.1:
            return "{:.2f}"
        if self.step < 1.0:
            return "{:.1f}"
        return "{:.1f}"

    def _on_var_write(self, *args):
        self._draw_slider()

    def _on_configure(self, event=None):
        self._draw_slider()

    def _create_round_rect(self, x0, y0, x1, y1, r=4, **kwargs):
        if x1 <= x0 or y1 <= y0:
            return None
        r = min(int(r), int((x1 - x0) // 2), int((y1 - y0) // 2))
        if r <= 1:
            return self.create_rectangle(x0, y0, x1, y1, **kwargs)
        pts = [
            x0 + r, y0,
            x1 - r, y0,
            x1, y0,
            x1, y0 + r,
            x1, y1 - r,
            x1, y1,
            x1 - r, y1,
            x0 + r, y1,
            x0, y1,
            x0, y1 - r,
            x0, y0 + r,
            x0, y0,
        ]
        return self.create_polygon(pts, smooth=True, **kwargs)

    def _draw_slider(self):
        self.delete("all")
        w = max(1, self.winfo_width())
        h = max(1, self.winfo_height())
        r = min(4, max(2, h // 5))

        # Soft background rounded trough (seamless borderless)
        self._create_round_rect(0, 0, w, h, r=r, fill=self.bg_color, outline="", width=0, tags="bg")

        val = self.get()
        lo, hi = min(self.from_, self.to), max(self.from_, self.to)
        span = hi - lo
        fraction = max(0.0, min(1.0, (val - lo) / span)) if span > 1e-8 else 0.0

        fill_w = max(0, int(round(w * fraction)))
        if fill_w > 0:
            # Draw progress track fill with soft rounded corners
            self._create_round_rect(0, 0, fill_w, h, r=r, fill=self.fill_color, outline="", tags="fill")
            # Draw modern accent vertical progress marker / handle on boundary
            handle_w = max(2, min(5, int(w * 0.025)))
            hx0 = max(0, fill_w - handle_w)
            self._create_round_rect(hx0, 0, fill_w, h, r=min(r, handle_w), fill=self.handle_color, outline="", tags="handle")

        # Format text representation
        fmt = self._get_format()
        try:
            txt = fmt.format(val)
        except Exception:
            txt = str(val)

        # Draw centered crisp text with soft subtle drop shadow
        cx = w * 0.5
        cy = h * 0.5
        self.create_text(cx + 1, cy + 1, text=txt, fill="#040910", font=("Segoe UI Semibold", 9), tags="text")
        self.create_text(cx, cy, text=txt, fill=self.fg_color, font=("Segoe UI Semibold", 9), tags="text")

    def _on_button_1(self, event):
        self.focus_set()
        w = max(1, self.winfo_width())
        self._dragging = True
        self._drag_start_x = event.x
        self._drag_start_val = self.get()

        # Immediate jump/slider drag to clicked position
        lo, hi = min(self.from_, self.to), max(self.from_, self.to)
        frac = max(0.0, min(1.0, event.x / float(w)))
        new_val = lo + frac * (hi - lo)
        if self.step > 0:
            new_val = round(new_val / self.step) * self.step
        self.set(new_val, notify=True)

    def _on_b1_motion(self, event):
        if not self._dragging:
            return
        w = max(1, self.winfo_width())
        lo, hi = min(self.from_, self.to), max(self.from_, self.to)
        frac = max(0.0, min(1.0, event.x / float(w)))
        new_val = lo + frac * (hi - lo)
        if self.step > 0:
            new_val = round(new_val / self.step) * self.step
        self.set(new_val, notify=True)

    def _on_button_release_1(self, event):
        self._dragging = False

    def _on_double_click(self, event):
        self._start_inline_edit()

    def _step_value(self, dir_sign: int):
        cur = self.get()
        step = self.step if self.step > 0 else (1.0 if self.is_integer else 0.05)
        self.set(cur + dir_sign * step, notify=True)

    def _start_inline_edit(self):
        if self._entry is not None:
            return
        w = max(1, self.winfo_width())
        h = max(1, self.winfo_height())

        val = self.get()
        fmt = self._get_format()
        txt = fmt.format(val)

        var = tk.StringVar(value=txt)
        entry = tk.Entry(
            self,
            textvariable=var,
            bg="#181a1f",
            fg="#ffffff",
            insertbackground=ui_color('selection'),
            selectbackground=ui_color('selection'),
            selectforeground="#181818",
            relief="flat",
            justify="center",
            font=("Segoe UI", 9),
        )
        entry.place(x=0, y=0, width=w, height=h)
        entry.focus_set()
        entry.select_range(0, "end")

        def commit(event=None):
            raw = var.get().strip().replace(",", ".")
            try:
                new_v = float(raw)
                self.set(new_v, notify=True)
            except Exception:
                pass
            cleanup()

        def cancel(event=None):
            cleanup()

        def cleanup():
            nonlocal entry
            if entry is not None:
                try:
                    entry.destroy()
                except Exception:
                    pass
                entry = None
                self._entry = None
                self.focus_set()
                self._draw_slider()

        entry.bind("<Return>", commit)
        entry.bind("<KP_Enter>", commit)
        entry.bind("<Escape>", cancel)
        entry.bind("<FocusOut>", commit)
        self._entry = entry
