"""Usage: python -m fiberstrand.construction.cli --preset 'Feather / Peacock Branches' --out demo --size 384"""
import argparse
import json
from pathlib import Path
from ..model import Tile
from ..raster import render_tile
from .presets import PRESETS,make_preset
from .core import normalize_graph,GraphEvaluator

def main():
    ap=argparse.ArgumentParser(description='FSD Construction Graph V4 render CLI')
    ap.add_argument('--preset',choices=list(PRESETS),default='Feather / Peacock Branches')
    ap.add_argument('--graph',help='Load editable construction graph JSON')
    ap.add_argument('--out',default='construction_preview')
    ap.add_argument('--size',type=int,default=320)
    args=ap.parse_args()
    graph=json.loads(Path(args.graph).read_text('utf-8')) if args.graph else make_preset(args.preset)
    normalize_graph(graph)
    tile=Tile.create('Construction V4 Test')
    tile.construction_graph=graph;tile.width=args.size;tile.height=args.size
    result=render_tile(tile)
    dest=Path(args.out);dest.mkdir(parents=True,exist_ok=True)
    for key,im in result.maps.items():im.save(dest/(key+'.png'))
    (dest/'graph.json').write_text(json.dumps(graph,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Rendered',len(result.strands),'curves, maps:',', '.join(result.maps))
if __name__=='__main__':main()
