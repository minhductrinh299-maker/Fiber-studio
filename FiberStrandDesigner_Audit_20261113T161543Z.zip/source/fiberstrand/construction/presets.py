"""Editable sample graphs built from composable geometry and field operators."""
from copy import deepcopy


def node(nid,op,**kwargs):
    return dict(id=nid,op=op,inputs=kwargs.pop('inputs',{}),params=kwargs)


def _g(nodes,output):return {'format':'fsd-construction-graph','version':1,'nodes':nodes,'output':output}


def soft_fur():
    return _g([
        node('roots','scatter',count=190,x_min=.08,x_max=.92,y_min=.89,y_max=.97,seed=7),
        node('fur','grow',inputs={'points':'roots'},length=.37,width=2.8,angle=0.,bend=.15,curl=.018,waves=2.0,frizz=.03,points_per_curve=15,color='#ae9d83',seed=3),
        node('shape','taper',inputs={'curves':'fur'},tip_ratio=.025,power=1.5),
        node('pigment','color_field',mode='gradient',color_a='#382c2a',color_b='#ddc2a0',angle=90),
        node('paint','paint',inputs={'curves':'shape','color':'pigment'},strength=.95),
    ],'paint')


def curly_hair():
    return _g([
        node('roots','scatter',count=140,x_min=.10,x_max=.90,y_min=.86,y_max=.94,seed=19),
        node('locks','grow',inputs={'points':'roots'},length=.67,width=3.3,angle=0.,bend=.12,curl=.16,waves=3.6,points_per_curve=35,color='#61402d',seed=3),
        node('detail','deform',inputs={'curves':'locks'},bend=.09,curl=.06,waves=6),
        node('taper','taper',inputs={'curves':'detail'},tip_ratio=.025,power=.9),
        node('color','color_field',mode='stripes',color_a='#291e1a',color_b='#a87c54',frequency=5,angle=90,phase=.1),
        node('pigment','paint',inputs={'curves':'taper','color':'color'},strength=.35)
    ],'pigment')


def peacock_feather():
    return _g([
        node('rachis','path',x0=.50,y0=.95,x1=.53,y1=.09,bend=.025,points=35,width=2.8,color='#b79a54'),
        node('barb_roots','along',inputs={'curves':'rachis'},count=22,start=.12,end=.94,side='both'),
        node('barbs','grow',inputs={'points':'barb_roots'},length=.31,width=1.55,angle=69,bend=.1,curl=0.,points_per_curve=20,envelope='feather',color='#ae823f'),
        node('barbule_roots','along',inputs={'curves':'barbs'},count=24,start=.08,end=.97,side='both'),
        node('barbules','grow',inputs={'points':'barbule_roots'},length=.034,width=1.12,angle=68,bend=.008,points_per_curve=5,color='#83a56a'),
        node('merge_a','join',inputs={'a':'rachis','b':'barbs'}),
        node('merge_b','join',inputs={'a':'merge_a','b':'barbules'}),
        node('eye','color_field',mode='eye',center_x=.51,center_y=.43,radius_x=.31,radius_y=.26,skew=.12,
             palette=['#b1853f','#13b6ae','#05a9d9','#24205b'],rings=[1.0,.78,.55,.29]),
        node('colorize','paint',inputs={'curves':'merge_b','color':'eye'},strength=.97),
    ],'colorize')


def decorative_wreath():
    """Demonstrates instance operator (not a feather-specific hardcoded generator)."""
    return _g([
        node('base','path',x0=.50,y0=.92,x1=.50,y1=.74,points=15,width=4,color='#69b9a1'),
        node('sites','scatter',count=26,x_min=.18,x_max=.82,y_min=.22,y_max=.80,seed=4),
        node('copies','instance',inputs={'curves':'base','points':'sites'},scale=.42,limit=90),
        node('pattern','color_field',mode='noise',color_a='#165b67',color_b='#e4b16d',frequency=6.0),
        node('paint','paint',inputs={'curves':'copies','color':'pattern'},strength=.85)
    ],'paint')

PRESETS = {
 'Fur / Soft Undercoat':soft_fur,
 'Hair / Curly Locks':curly_hair,
 'Feather / Peacock Branches':peacock_feather,
 'Experimental / Instances':decorative_wreath,
}

def make_preset(name:str)->dict:return deepcopy(PRESETS[name]())
