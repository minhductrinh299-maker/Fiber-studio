"""Construction Studio V4: compact operator editing, typed connections, preview.

Designed for existing Tkinter app: no additional runtime dependencies.
"""
from __future__ import annotations
from ..ui_theme import color as ui_color
from ..navigation import MayaNavigation, HELP
from ..number_slider import NumberSlider
from ..rendercore.lighting import SHIFT_MASK, normalize_azimuth
from ..navigation import dolly_factor
from ..dpi import watch_window
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from pathlib import Path
from queue import Queue,Empty
import json
import threading
import tkinter as tk
from tkinter import ttk,filedialog,messagebox,colorchooser
from PIL import ImageTk,ImageDraw,Image
from .core import OPS,normalize_graph,GraphError,GraphEvaluator
from .presets import PRESETS,make_preset
from ..model import Tile
from ..raster import render_tile

from ..workspace_frame import WorkspaceFrame

BG=ui_color('background');PANEL=ui_color('panel');ACCENT=ui_color('selection');TEXT=ui_color('text')

class ConstructionStudio(WorkspaceFrame):
    def __init__(self,parent_or_owner,owner=None):
        self.owner=owner if owner is not None else parent_or_owner
        super().__init__(parent_or_owner,bg=BG)
        self.title('Fiber Strand Designer | Construction Studio V4')
        self.geometry('1360x810');self.minsize(1040,650)
        self.configure(bg=BG)
        self.tileid=self.owner.current_id
        tile=self.owner.project.find(self.tileid)
        if tile is None:raise ValueError('Select a tile first')
        self._preset_name='Feather / Peacock Branches' if tile.kind=='feather' else 'Fur / Soft Undercoat'
        from ..workflow import graph_from_tile
        self.graph=graph_from_tile(tile)
        self._received_tile=deepcopy(tile.to_dict())
        self._selected=self.graph['output']
        self._props={};self._inputs={}
        self._photo=None;self._preview=None;self._rev=0;self._pending=None
        self._evaluator=GraphEvaluator()
        from ..engine_v2.scheduler import LatestScheduler
        self._worker=LatestScheduler(workers=1)
        self._live_gpu=None
        self._queue=Queue();self._cancel=None
        self._undo=[];self._redo=[]
        self._dirty=False
        self.view_zoom=1.;self.view_pan=[0.,0.];self.view_angle=0.
        self._build()
        watch_window(self)
        self.bind('<<DpiChanged>>',lambda e:self._paint_preview())
        self._select(self._selected)
        self.after_idle(self._open_live_gpu)
        self._queue_render(180)
        self._poll_after=self.after(90,self._poll)
        self.protocol('WM_DELETE_WINDOW',self._close)

    def _build(self):
        bar=ttk.Frame(self,padding=(10,8));bar.pack(fill='x')
        ttk.Label(bar,text='CONSTRUCTION GRAPH V4',font=('Segoe UI Semibold',12)).pack(side='left',padx=(2,12))
        preset_box=ttk.Frame(bar)
        preset_box.pack(side='left',padx=4)
        self.preset=tk.StringVar(value=self._preset_name)
        pc=ttk.Combobox(preset_box,textvariable=self.preset,values=list(PRESETS),state='readonly',width=24)
        pc.pack(side='left',padx=2)
        ttk.Button(preset_box,text='Load',style='TButton',command=self._load_preset).pack(side='left',padx=2)
        io_box=ttk.Frame(bar)
        io_box.pack(side='left',padx=8)
        ttk.Button(io_box,text='Import JSON',style='TButton',command=self._import_json).pack(side='left',padx=2)
        ttk.Button(io_box,text='Export JSON',style='TButton',command=self._export_json).pack(side='left',padx=2)
        ttk.Button(bar,text='⚡ Apply to Tile',style='Primary.TButton',command=self._apply).pack(side='right',padx=6)
        ttk.Button(bar,text='Refresh Preview',style='TButton',command=lambda:self._queue_render(0)).pack(side='right',padx=3)
        body=ttk.PanedWindow(self,orient='horizontal');body.pack(fill='both',expand=True,padx=8,pady=(0,8))
        left=ttk.Frame(body,padding=7);center=ttk.Frame(body,padding=4);right=ttk.Frame(body,padding=8)
        body.add(left,weight=2);body.add(center,weight=5);body.add(right,weight=3)
        ttk.Label(left,text='OPERATORS',font=('Segoe UI Semibold',11)).pack(anchor='w',pady=5)
        self.nodes=tk.Listbox(left,bg=PANEL,fg=TEXT,selectbackground='#6a5035',selectforeground='white',
                              highlightthickness=0,activestyle='none',bd=0,font=('Consolas',10),exportselection=False)
        self.nodes.pack(fill='both',expand=True)
        self.nodes.bind('<<ListboxSelect>>',self._on_list_select)
        inline=ttk.Frame(left);inline.pack(fill='x',pady=8)
        self.op_add=tk.StringVar(value='grow')
        ttk.Combobox(inline,textvariable=self.op_add,state='readonly',values=list(OPS),width=17).pack(side='left',fill='x',expand=True)
        ttk.Button(inline,text='+',width=3,command=self._add).pack(side='left',padx=2)
        ttk.Button(inline,text='−',width=3,command=self._delete).pack(side='left',padx=2)
        ttk.Label(left,text='Output (final CurveSet)').pack(anchor='w')
        self.output_var=tk.StringVar()
        self.output_combo=ttk.Combobox(left,textvariable=self.output_var,state='readonly')
        self.output_combo.pack(fill='x',pady=(3,8))
        self.output_combo.bind('<<ComboboxSelected>>',self._change_output)
        ttk.Label(left,text='Click a node to edit; link its typed inputs on the right.\nDisconnected nodes are allowed until used.',wraplength=265,foreground='#aeb7c1',justify='left').pack(anchor='w',pady=8)
        ttk.Label(center,text='LIVE TILE PREVIEW',font=('Segoe UI Semibold',11)).pack(anchor='w',pady=5)
        self.map_var=tk.StringVar(value='color')
        top=ttk.Frame(center);top.pack(fill='x',pady=(0,8))
        ttk.Label(top,text='Map').pack(side='left')
        cb=ttk.Combobox(top,textvariable=self.map_var,state='readonly',width=14,values=['lit','color','alpha','normal','flow','ao','roughness','depth','id','rgb_mask'])
        cb.pack(side='left',padx=7);cb.bind('<<ComboboxSelected>>',lambda e:self._paint_preview())
        ttk.Label(top,text='Góc sáng').pack(side='left',padx=4)
        NumberSlider(top,variable=self.owner.lit_angle,from_=180,to=-180,step=1.0,width=140,height=22,
                     command=lambda v:self._paint_preview()).pack(side='left',padx=2)
        self.status=tk.StringVar(value='Ready')
        ttk.Label(top,textvariable=self.status,foreground='#aeb7c1').pack(side='right',padx=3)
        self.canvas=tk.Canvas(center,bg=ui_color('viewport'),highlightthickness=0,borderwidth=0,takefocus=1)
        self.canvas.pack(fill='both',expand=True)
        self.canvas.bind('<Enter>',lambda e:self.canvas.focus_set(),add='+')
        self.canvas.bind('<Configure>',lambda e:self._paint_preview())
        self.canvas.bind('<ButtonPress-3>',self._light_down)
        self.canvas.bind('<B3-Motion>',self._light_move)
        self.canvas.bind('<ButtonRelease-3>',self._light_up)
        for w in (self, self.canvas):
            w.bind('<KeyPress-f>',lambda e:self._nav_fit())
            w.bind('<KeyPress-F>',lambda e:self._nav_fit())
            w.bind('<Control-z>',lambda e:self._undo_graph())
            w.bind('<Control-Z>',lambda e:self._undo_graph())
            w.bind('<Control-Shift-Z>',lambda e:self._redo_graph())
            w.bind('<Control-Shift-z>',lambda e:self._redo_graph())
            w.bind('<Control-y>',lambda e:self._redo_graph())
            w.bind('<Control-Y>',lambda e:self._redo_graph())
        self.navigation=MayaNavigation(self.canvas,self._nav_orbit,self._nav_pan,self._nav_dolly)
        ttk.Label(center,text=HELP,wraplength=560).pack()
        ttk.Button(top,text='Fit',command=self._nav_fit).pack(side='left',padx=5)
        ttk.Label(center,text='Preview is asynchronous. Applying updates only the selected tile; other atlas tiles stay unchanged.',foreground=ui_color('muted'),wraplength=560).pack(anchor='w',pady=(9,0))
        ttk.Label(right,text='NODE INSPECTOR',font=('Segoe UI Semibold',11)).pack(anchor='w',pady=5)
        self.name_var=tk.StringVar()
        ttk.Label(right,textvariable=self.name_var,font=('Segoe UI Semibold',12)).pack(anchor='w',pady=(3,9))
        self.inspector_canvas=tk.Canvas(right,bg=BG,highlightthickness=0)
        scroll=ttk.Scrollbar(right,orient='vertical',command=self.inspector_canvas.yview)
        scroll.pack(side='right',fill='y');self.inspector_canvas.pack(fill='both',expand=True)
        self.inspector_canvas.configure(yscrollcommand=scroll.set)
        self.inspector=ttk.Frame(self.inspector_canvas)
        self.inwindow=self.inspector_canvas.create_window((0,0),window=self.inspector,anchor='nw')
        self.inspector.bind('<Configure>',lambda e:self.inspector_canvas.configure(scrollregion=self.inspector_canvas.bbox('all')))
        self.inspector_canvas.bind('<Configure>',lambda e:self.inspector_canvas.itemconfigure(self.inwindow,width=e.width))
        ttk.Button(right,text='Commit node parameters',command=self._commit_params).pack(fill='x',pady=7)
        self._relist()

    def _snapshot(self):
        self._undo.append(deepcopy(self.graph));self._undo=self._undo[-35:];self._redo.clear();self._dirty=True

    def _undo_graph(self):
        if not self._undo:return
        self._redo.append(deepcopy(self.graph));self.graph=self._undo.pop();self._relist();self._select(self._selected if any(n['id']==self._selected for n in self.graph['nodes']) else self.graph['output']);self._queue_render(150)
    def _redo_graph(self):
        if not self._redo:return
        self._undo.append(deepcopy(self.graph));self.graph=self._redo.pop();self._relist();self._select(self._selected if any(n['id']==self._selected for n in self.graph['nodes']) else self.graph['output']);self._queue_render(150)

    def _handle_global_key(self, event):
        if isinstance(getattr(event, 'widget', None), (ttk.Entry, ttk.Combobox, tk.Entry, tk.Spinbox, tk.Text)):
            return None
        k = event.keysym.lower() if getattr(event, 'keysym', None) else ''
        state = getattr(event, 'state', 0)
        ctrl = bool(state & 0x0004)
        shift = bool(state & 0x0001)
        if ctrl and shift and k == 'z':
            self._redo_graph()
            return 'break'
        elif ctrl and k == 'z':
            self._undo_graph()
            return 'break'
        elif ctrl and k == 'y':
            self._redo_graph()
            return 'break'
        elif k == 'f':
            self._nav_fit()
            return 'break'
        return None

    def _relist(self):
        self.nodes.delete(0,'end')
        for n in self.graph['nodes']:
            self.nodes.insert('end',f"{n['id']:<19} {n['op']}")
        opts=[n['id'] for n in self.graph['nodes'] if OPS[n['op']].output=='curves']
        self.output_combo['values']=opts;self.output_var.set(self.graph['output'])
        self._highlight()
    def _highlight(self):
        self.nodes.selection_clear(0,'end')
        for i,n in enumerate(self.graph['nodes']):
            if n['id']==self._selected:self.nodes.selection_set(i);self.nodes.see(i);break
    def _node(self,nid):return next(n for n in self.graph['nodes'] if n['id']==nid)
    def _on_list_select(self,event):
        sel=self.nodes.curselection()
        if sel:self._select(self.graph['nodes'][sel[0]]['id'])
    def _select(self,nid):
        if not any(n['id']==nid for n in self.graph['nodes']):return
        self._selected=nid;node=self._node(nid);spec=OPS[node['op']]
        self.name_var.set(f"{nid} · {spec.label}")
        for widget in list(self.inspector.winfo_children()):widget.destroy()
        self._props={};self._inputs={}
        ttk.Label(self.inspector,text='INPUT CONNECTIONS',font=('Segoe UI Semibold',10)).pack(anchor='w',pady=(2,7))
        if not spec.ports:
            ttk.Label(self.inspector,text='No incoming connections',foreground='#aab0b7').pack(anchor='w',pady=4)
        for port,typ in spec.ports.items():
            frame=ttk.Frame(self.inspector);frame.pack(fill='x',pady=3)
            ttk.Label(frame,text=f'{port} [{typ}]').pack(anchor='w')
            choices=['(none)']+[n['id'] for n in self.graph['nodes'] if n['id']!=nid and OPS[n['op']].output==typ]
            current=node.get('inputs',{}).get(port,'(none)')
            var=tk.StringVar(value=current);self._inputs[port]=var
            c=ttk.Combobox(frame,textvariable=var,state='readonly',values=choices)
            c.pack(fill='x');c.bind('<<ComboboxSelected>>',lambda e:self._commit_params())
        ttk.Separator(self.inspector).pack(fill='x',pady=10)
        ttk.Label(self.inspector,text='OPERATOR PARAMETERS',font=('Segoe UI Semibold',10)).pack(anchor='w',pady=(0,6))
        params=deepcopy(spec.defaults);params.update(node.get('params',{}))
        for key,value in params.items():
            frame=ttk.Frame(self.inspector);frame.pack(fill='x',pady=3)
            ttk.Label(frame,text=key.replace('_',' ')).pack(anchor='w')
            serialized=json.dumps(value,ensure_ascii=False) if isinstance(value,(list,dict,bool)) else str(value)
            var=tk.StringVar(value=serialized);self._props[key]=(var,value)
            inputrow=ttk.Frame(frame);inputrow.pack(fill='x')
            entry=ttk.Entry(inputrow,textvariable=var)
            entry.pack(side='left',fill='x',expand=True)
            entry.bind('<Return>',lambda e:self._commit_params())
            if isinstance(value,str) and value.startswith('#') and len(value)==7:
                ttk.Button(inputrow,text='Color',width=6,command=lambda v=var:self._choose_color(v)).pack(side='left',padx=3)
        ttk.Label(self.inspector,text='Press Enter or Commit after changes. Lists use JSON syntax.',foreground='#aab0b7',wraplength=275).pack(anchor='w',pady=12)
        self._highlight()
    def _choose_color(self,var):
        chosen=colorchooser.askcolor(color=var.get(),parent=self)
        if chosen and chosen[1]:var.set(chosen[1]);self._commit_params()
    def _typed(self,string,old):
        if isinstance(old,bool):return string.lower() in ('true','1','yes')
        if isinstance(old,int) and not isinstance(old,bool):return int(string)
        if isinstance(old,float):return float(string)
        if isinstance(old,(list,dict)):
            v=json.loads(string)
            if not isinstance(v,type(old)):raise ValueError('Expected '+type(old).__name__)
            return v
        return string
    def _commit_params(self):
        if not self._selected:return
        n=self._node(self._selected)
        try:
            props={key:self._typed(var.get(),old) for key,(var,old) in self._props.items()}
            links={key:var.get() for key,var in self._inputs.items() if var.get()!='(none)'}
            trial=deepcopy(self.graph)
            target=next(x for x in trial['nodes'] if x['id']==self._selected)
            target['params']=props;target['inputs']=links
            normalize_graph(trial)
        except (GraphError,ValueError,TypeError,json.JSONDecodeError) as exc:
            messagebox.showerror('Invalid node',str(exc),parent=self);return
        if n.get('params',{})==props and n.get('inputs',{})==links:return
        self._snapshot();n['params']=props;n['inputs']=links
        self._queue_render(250)
    def _add(self):
        op=self.op_add.get()
        if op not in OPS:return
        spec=OPS[op];nid=op
        i=2
        while any(n['id']==nid for n in self.graph['nodes']):nid=f'{op}_{i}';i+=1
        links={}
        for port,typ in spec.ports.items():
            if self._selected and OPS[self._node(self._selected)['op']].output==typ:links[port]=self._selected
            else:
                candidates=[n['id'] for n in self.graph['nodes'] if OPS[n['op']].output==typ]
                if candidates:links[port]=candidates[-1]
        self._snapshot();self.graph['nodes'].append(dict(id=nid,op=op,inputs=links,params=deepcopy(spec.defaults)))
        if spec.output=='curves' and all(port in links or port in ('length_field','width_field','mask') for port in spec.ports):
            self.graph['output']=nid
        self._relist();self._select(nid)
        self._queue_render(200)
    def _delete(self):
        nid=self._selected
        if nid==self.graph['output']:
            messagebox.showwarning('Output node','Select another output before removing this node.',parent=self);return
        if any(nid in n.get('inputs',{}).values() for n in self.graph['nodes']):
            messagebox.showwarning('Node in use','Disconnect downstream inputs before removing this node.',parent=self);return
        self._snapshot();self.graph['nodes']=[n for n in self.graph['nodes'] if n['id']!=nid]
        self._selected=self.graph['output'];self._relist();self._select(self._selected);self._queue_render(160)
    def _change_output(self,event):
        nid=self.output_var.get()
        if nid==self.graph['output']:return
        trial=deepcopy(self.graph);trial['output']=nid
        try:normalize_graph(trial)
        except GraphError as exc:
            self.output_var.set(self.graph['output']);messagebox.showerror('Invalid output',str(exc),parent=self);return
        self._snapshot();self.graph['output']=nid;self._queue_render(190)
    def _load_preset(self):
        self._snapshot();self.graph=make_preset(self.preset.get());self._selected=self.graph['output'];self._relist();self._select(self._selected);self._queue_render(120)
    def _import_json(self):
        path=filedialog.askopenfilename(parent=self,filetypes=[('Construction Graph','*.json')]);
        if not path:return
        try:
            graph=json.loads(Path(path).read_text(encoding='utf-8'))
            normalize_graph(graph)
        except (OSError,ValueError,TypeError) as exc:
            messagebox.showerror('Cannot import',str(exc),parent=self);return
        self._snapshot();self.graph=graph;self._selected=graph['output'];self._relist();self._select(self._selected);self._queue_render(120)
    def _export_json(self):
        path=filedialog.asksaveasfilename(parent=self,defaultextension='.json',filetypes=[('Construction Graph','*.json')]);
        if path:Path(path).write_text(json.dumps(self.graph,indent=2,ensure_ascii=False),encoding='utf-8')
    def _queue_render(self,delay=250):
        self._rev+=1
        if self._cancel:self._cancel.set()
        if self._pending is None:
            self._pending=self.after(min(delay,33),lambda:self._render(self._rev))

    def _open_live_gpu(self):
        if self._live_gpu is None or not self._live_gpu.winfo_exists():
            from ..engine_v2.preview import FiberPreviewViewport
            self._live_gpu=FiberPreviewViewport(self.canvas,show_header=False)
            self._live_gpu.place(x=0,y=0,relwidth=1,relheight=1)
        self._live_gpu.lift();self._queue_render(0)

    def _toggle_inline_render(self):
        from ..rendercore.inline_preview import toggle
        toggle(self,self.canvas,self.owner,'graph')

    def _render(self,rev):
        self._pending=None
        tile=self.owner.project.find(self.tileid)
        if tile is None:return
        try:normalize_graph(self.graph)
        except GraphError as exc:self.status.set(str(exc));return
        tile=deepcopy(tile);tile.construction_graph=deepcopy(self.graph)
        width=max(96,min(384,tile.width));height=max(96,min(448,tile.height))
        cancel=threading.Event();self._cancel=cancel
        self.status.set('Rendering tile...')
        publish=self._queue.put;evaluator=self._evaluator
        def work(token):
            try:
                stale=lambda:cancel.is_set() or token.is_set()
                if want_gpu:
                    from ..engine_v2.engine import ENGINE
                    from ..engine_v2.preview import pack_instances
                    truth,_=ENGINE.truth(tile,detail=20,cancel=stale,evaluator=evaluator)
                    instances=pack_instances(truth,tile.settings,stale)
                    if not stale():publish((rev,('truth',instances,(tile.width,tile.height)),None))
                result=render_tile(tile,size=(width,height),should_cancel=stale,graph_evaluator=evaluator)
                if not stale():publish((rev,result,None))
            except Exception as exc:
                if not cancel.is_set() and not token.is_set():publish((rev,None,str(exc)))
        want_gpu=self._live_gpu is not None and self._live_gpu.winfo_exists()
        self._worker.submit('graph-preview',work)
    def _poll(self):
        try:
            while True:
                rev,result,error=self._queue.get_nowait()
                if rev!=self._rev:continue
                if error:
                    if error!='Render cancelled':self.status.set('Error: '+error[:80])
                else:
                    if isinstance(result,tuple) and result[0]=='truth':
                        if self._live_gpu is not None and self._live_gpu.winfo_exists():
                            self._live_gpu.publish(self.tileid,rev,result[2],result[1])
                        continue
                    self._preview=result
                    self.status.set(f'{len(result.strands)} fibers · {result.width}×{result.height}')
                    self._paint_preview()
        except Empty:pass
        if not getattr(self,'_closing',False) and self.winfo_exists():
            self._poll_after=self.after(100,self._poll)
    def _light_down(self,event):
        if not (event.state & SHIFT_MASK):return
        self._light_drag = (event.x, event.y, float(self.owner.lit_angle.get()))
        return "break"

    def _light_move(self,event):
        drag = getattr(self, "_light_drag", None)
        if not drag:return
        start_x, start_y, start_ang = drag
        dx = event.x - start_x
        new_ang = normalize_azimuth(start_ang - dx * 0.42)
        self.owner.lit_angle.set(round(new_ang, 1))
        self._paint_preview()
        return "break"

    def _light_up(self,event):
        if getattr(self, "_light_drag", None) is not None:
            self._light_drag = None
            self._paint_preview()
            return "break"

    def _nav_orbit(self,dx,dy):
        self.view_angle=(self.view_angle-dx*.4)%360
        self._paint_preview()
    def _nav_pan(self,dx,dy):
        self.view_pan[0]+=dx;self.view_pan[1]+=dy
        self._paint_preview()
    def _nav_dolly(self,dx,dy):
        self.view_zoom=max(.1,min(8.,self.view_zoom/dolly_factor(dx)))
        self._paint_preview()
    def _nav_fit(self):
        self.view_zoom=1.;self.view_pan=[0.,0.];self.view_angle=0.
        self._paint_preview()
    def _paint_preview(self):
        if not self.winfo_exists():return
        self.canvas.delete('all')
        w=max(4,self.canvas.winfo_width());h=max(4,self.canvas.winfo_height())
        if self._preview is None:
            self.canvas.create_text(w/2,h/2,text='Render preview',fill=ui_color('muted'));return
        live=getattr(self,'_live_gpu',None)
        if live and live.winfo_exists():
            if self.map_var.get()=='lit':live.place_forget()
            elif self.map_var.get()=='color':live.place(x=0,y=0,relwidth=1,relheight=1)
            else:live.place_forget()
        if self.map_var.get()=='lit':
            from ..rendercore.lit_map import image_for
            pic=image_for(self,self.owner,self._preview.maps,('graph',self._rev,id(self._preview)),self._paint_preview,lambda:self.map_var.get()=='lit')
        else:pic=self._preview.maps[self.map_var.get()]
        scale=max(.01,min((w-30)/pic.width,(h-30)/pic.height)*self.view_zoom)
        size=(max(1,int(pic.width*scale)),max(1,int(pic.height*scale)))
        im=pic.resize(size,Image.Resampling.BILINEAR)
        if im.mode=='RGBA':
            checker=Image.new('RGBA',size,(43,46,50,255))
            d=ImageDraw.Draw(checker)
            for y in range(0,size[1],16):
                for x in range(0,size[0],16):
                    if (x//16+y//16)%2:d.rectangle((x,y,x+16,y+16),fill=(59,62,65,255))
            checker.alpha_composite(im)
            im=checker.convert('RGB')
        self._photo=ImageTk.PhotoImage(im.rotate(self.view_angle,expand=True,resample=Image.Resampling.BICUBIC))
        self.canvas.create_image(w/2+self.view_pan[0],h/2+self.view_pan[1],image=self._photo)
    def _apply(self):
        try:normalize_graph(self.graph)
        except GraphError as exc:messagebox.showerror('Graph error',str(exc),parent=self);return False
        tile=self.owner.project.find(self.tileid)
        if tile is None:return False
        if tile.to_dict()!=self._received_tile and tile.construction_graph!=self.graph:
            if not messagebox.askyesno('Source changed','This tile changed in another workspace. Replace its graph with this draft?',parent=self):return False
        if tile.construction_graph!=self.graph:
            self.owner._history();tile.construction_graph=deepcopy(self.graph);tile.revision+=1
            self.owner.modified=True;self.owner._schedule_render(0)
        self._dirty=False
        self._received_tile=deepcopy(tile.to_dict())
        self.status.set('Applied to tile / atlas')
        return True

    def receive_tile(self,tile_id):
        tile=self.owner.project.find(tile_id)
        if tile is None:return False
        if tile_id==self.tileid and tile.to_dict()==self._received_tile:return True
        if self._dirty:
            choice=messagebox.askyesnocancel('Continue with another source',
                'Apply the current graph draft before switching source?\nNo discards this draft; Cancel keeps it open.',parent=self)
            if choice is None:return False
            if choice and not self._apply():return False
        from ..workflow import graph_from_tile
        self.tileid=tile_id;self.graph=graph_from_tile(tile)
        self._received_tile=deepcopy(tile.to_dict())
        self._dirty=False;self._undo.clear();self._redo.clear()
        self._selected=self.graph['output'];self._relist();self._select(self._selected)
        self._queue_render(0)
        return True
    def pause(self):
        if getattr(self,'_poll_after',None) is not None:
            try:self.after_cancel(self._poll_after)
            except tk.TclError:pass
            self._poll_after=None

    def resume(self):
        if getattr(self,'_poll_after',None) is None:
            self._poll_after=self.after(90,self._poll)
        if hasattr(self.owner,'current_id'):
            self.receive_tile(self.owner.current_id)
        self._queue_render(0)

    def _close(self):
        self.pause()
        if getattr(self,'_lit_map',None):self._lit_map.close()
        panel=getattr(self,'_inline_render',None)
        if panel and panel.winfo_exists():panel.destroy();self._inline_render=None
        self._closing=True
        if self._dirty and messagebox.askyesno('Apply graph?','Apply the edited graph to the current tile before closing?',parent=self):self._apply()
        if self._pending is not None:
            try:self.after_cancel(self._pending)
            except tk.TclError:pass
        if self._cancel:self._cancel.set()
        self._worker.close(wait=True)
        if self._live_gpu is not None and self._live_gpu.winfo_exists():self._live_gpu.close()
        self.destroy()
        if hasattr(self.owner,'construction_window'):self.owner.construction_window=None
