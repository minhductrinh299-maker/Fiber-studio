"""Fiber Construction Graph V4: typed, bounded, deterministic procedural geometry.

CPU reference implementation for testing the composition model. No hidden
network calls, plugins or GPU requirements. Coordinates are tile local [0,1].
"""
from __future__ import annotations
from dataclasses import dataclass, field
from copy import deepcopy
import hashlib
import json
import math
import numpy as np
from typing import Any, Callable
from ..model import stable_int
from ..geometry import Strand, hex_rgb

MAX_CURVES = 120000
MAX_POINTS = 30000
MAX_VERTICES = 4000000

@dataclass
class Curve:
    key: str
    coords: np.ndarray
    radii: np.ndarray
    colors: np.ndarray
    depth: float = .5
    roughness: float = .5
    group: str = 'fiber'
    opacity: float = 1.
    depth_profile: np.ndarray | None = None

@dataclass
class CurveSet:
    curves: list[Curve] = field(default_factory=list)
    kind: str = 'curves'

@dataclass
class Point:
    key: str
    x: float
    y: float
    tangent: tuple[float,float] = (0.,-1.)
    side: int = 1
    u: float = 0.
    depth: float = .5

@dataclass
class PointSet:
    points: list[Point] = field(default_factory=list)
    kind: str = 'points'

@dataclass
class ColorField:
    mode: str
    params: dict
    kind: str = 'color_field'

    def sample(self, xy: np.ndarray) -> np.ndarray:
        x, y = np.asarray(xy,dtype=np.float32).T
        p = self.params
        c0=hex_rgb(p.get('color_a','#b99764'))
        c1=hex_rgb(p.get('color_b','#40bbd0'))
        if self.mode == 'eye':
            cx=float(p.get('center_x',.50));cy=float(p.get('center_y',.36))
            rx=max(.001,float(p.get('radius_x',.32)))
            ry=max(.001,float(p.get('radius_y',.24)))
            skew=float(p.get('skew',0.))
            qx=(x-cx-skew*(y-cy))/rx; qy=(y-cy)/ry
            d=np.sqrt(qx*qx+qy*qy)
            # Concentric eye feather colours, sampled on every geometric point.
            palette=[hex_rgb(c) for c in p.get('palette',['#b47c36','#06a7a2','#009bdd','#20165a'])]
            edges=p.get('rings',[1.,.76,.54,.30])
            out=np.broadcast_to(c0,(len(x),3)).copy()
            for limit,col in zip(edges,palette):
                out[d<float(limit)]=col
            return out.astype(np.float32)
        if self.mode == 'stripes':
            freq=float(p.get('frequency',7.))
            angle=math.radians(float(p.get('angle',0.)))
            phase=float(p.get('phase',0.))
            v=x*math.cos(angle)+y*math.sin(angle)
            f=(np.sin(2*math.pi*(freq*v+phase))>float(p.get('threshold',0.))).astype(np.float32)
            return ((1-f[:,None])*c0+f[:,None]*c1).astype(np.float32)
        if self.mode == 'gradient':
            angle=math.radians(float(p.get('angle',90.)))
            v=np.clip(x*math.cos(angle)+y*math.sin(angle),0,1)
            return ((1-v[:,None])*c0+v[:,None]*c1).astype(np.float32)
        if self.mode == 'noise':
            frequency=max(.1,float(p.get('frequency',9.)))
            phase=float(p.get('phase',0.))
            v=np.sin((x*127.1+y*311.7)*frequency*.03+phase)*43758.5453
            v=(v-np.floor(v)).astype(np.float32)
            v=np.clip((v-.25)*2.,0,1)
            return ((1-v[:,None])*c0+v[:,None]*c1).astype(np.float32)
        return np.broadcast_to(c0,(len(x),3)).copy()

@dataclass
class ScalarField:
    mode: str
    params: dict
    kind: str = 'scalar_field'

    def sample(self,xy:np.ndarray)->np.ndarray:
        p=self.params;x,y=np.asarray(xy,dtype=np.float32).T
        if self.mode=='constant': return np.full(len(x),float(p.get('value',1.)),np.float32)
        if self.mode=='gradient':
            axis=p.get('axis','y');v=x if axis=='x' else y
            return np.clip(float(p.get('start',0.))+(float(p.get('end',1.))-float(p.get('start',0.)))*v,0,3)
        if self.mode=='radial':
            dx=(x-float(p.get('cx',.5)))/max(.001,float(p.get('rx',.3)))
            dy=(y-float(p.get('cy',.5)))/max(.001,float(p.get('ry',.3)))
            return np.clip(1-np.sqrt(dx*dx+dy*dy),0,1)
        raise ValueError('Unknown scalar field')

@dataclass(frozen=True)
class OperatorSpec:
    output: str
    ports: dict[str,str]
    defaults: dict[str,Any]
    label: str

OPS:dict[str,OperatorSpec]={
 'kernel_source':OperatorSpec('curves',{},dict(assembly_id='',snapshot={},axes='xy'),'Unified Kernel Assembly'),
 'fiber_source':OperatorSpec('curves',{},dict(tile={}),'Fiber Studio Source'),
 'path':OperatorSpec('curves',{},dict(x0=.5,y0=.94,x1=.5,y1=.08,bend=.0,points=24,width=3.2,color='#a98857'),'Path / Guide'),
 'scatter':OperatorSpec('points',{},dict(count=160,x_min=.1,x_max=.9,y_min=.85,y_max=.95,angle=0.,seed=1),'Scatter Points'),
 'along':OperatorSpec('points',{'curves':'curves'},dict(count=12,start=.06,end=.91,side='both',offset=0.,seed=2),'Distribute Along'),
 'grow':OperatorSpec('curves',{'points':'points','length_field':'scalar_field'},dict(length=.28,width=1.7,angle=66.,bend=.04,curl=0.,waves=2.,frizz=.0,seed=3,points_per_curve=12,color='#9b825f'),'Grow / Branch'),
 'deform':OperatorSpec('curves',{'curves':'curves'},dict(bend=.08,curl=.03,waves=3.,seed=4),'Deform Curves'),
 'taper':OperatorSpec('curves',{'curves':'curves','width_field':'scalar_field'},dict(root_scale=1.0,tip_ratio=.07,power=1.3),'Width Profile'),
 'join':OperatorSpec('curves',{'a':'curves','b':'curves'},dict(),'Merge Geometry'),
 'instance':OperatorSpec('curves',{'curves':'curves','points':'points'},dict(scale=.5,limit=120),'Instance on Points'),
 'color_field':OperatorSpec('color_field',{},dict(mode='eye',center_x=.5,center_y=.36,radius_x=.31,radius_y=.28,skew=.0,palette=['#b47c36','#06a7a2','#009bdd','#20165a'],rings=[1.0,.77,.53,.28]),'Color / Pattern Field'),
 'scalar_field':OperatorSpec('scalar_field',{},dict(mode='constant',value=1.0),'Scalar / Mask Field'),
 'paint':OperatorSpec('curves',{'curves':'curves','color':'color_field'},dict(strength=1.),'Sample Pattern on Fibers'),
 'filter':OperatorSpec('curves',{'curves':'curves','mask':'scalar_field'},dict(threshold=.5,invert=False),'Filter by Field'),
}

class GraphError(ValueError): pass


def normalize_graph(g:dict)->dict:
    if not isinstance(g,dict):raise GraphError('Graph must be an object')
    nodes=g.get('nodes',[])
    if not isinstance(nodes,list) or len(nodes)>160:raise GraphError('Graph node count must be <= 160')
    ids={}
    for n in nodes:
        if not isinstance(n,dict) or not isinstance(n.get('id'),str):raise GraphError('Invalid node')
        if n['id'] in ids: raise GraphError('Duplicate node ID: '+n['id'])
        if n.get('op') not in OPS:raise GraphError('Unknown operator: '+str(n.get('op')))
        if not isinstance(n.get('inputs',{}),dict) or not isinstance(n.get('params',{}),dict):raise GraphError('Inputs and params must be objects')
        ids[n['id']]=n
    output=g.get('output')
    if output not in ids:raise GraphError('Output node does not exist')
    if OPS[ids[output]['op']].output!='curves':raise GraphError('Output must be CurveSet')
    visit:set[str]=set();done:set[str]=set();order=[]
    def walk(nodeid:str):
        if nodeid in done:return
        if nodeid in visit:raise GraphError('Cycle detected at '+nodeid)
        visit.add(nodeid);n=ids[nodeid];spec=OPS[n['op']]
        for port,upstream in n.get('inputs',{}).items():
            if port not in spec.ports:raise GraphError(f'{nodeid}: unknown input {port}')
            if not isinstance(upstream,str) or upstream not in ids:raise GraphError(f'{nodeid}: missing input node {upstream}')
            actual=OPS[ids[upstream]['op']].output
            if actual!=spec.ports[port]:raise GraphError(f'{nodeid}.{port}: expected {spec.ports[port]}, got {actual}')
            walk(upstream)
        for port in spec.ports:
            if port not in n.get('inputs',{}) and port not in OPTIONAL_PORTS:
                raise GraphError(f'{nodeid}: required input {port} not connected')
        visit.remove(nodeid);done.add(nodeid);order.append(nodeid)
    walk(output)
    return {'nodes':ids,'order':order,'output':output}

OPTIONAL_PORTS={'length_field','width_field','mask'}

def _bounds(value,lo,hi):return max(lo,min(hi,float(value)))

def _curve(key, coords, width, rgb, group='fiber',depth=.5):
    arr=np.asarray(coords,dtype=np.float32)
    if arr.ndim!=2 or arr.shape[1]!=2 or len(arr)<2:raise GraphError('Invalid curve points')
    if not np.isfinite(arr).all():raise GraphError('Non-finite geometry')
    if len(arr)>1024:raise GraphError('Too many samples in a curve')
    radii=np.full(len(arr),max(.03,float(width))/2,np.float32)
    color=hex_rgb(rgb) if isinstance(rgb,str) else np.asarray(rgb,dtype=np.float32)
    colors=np.broadcast_to(color,(len(arr),3)).copy()
    return Curve(key,arr,radii,colors,depth=float(depth),group=group)

def _evaluate(op:str,p:dict,inputs:dict,seed:int,nodeid:str):
    from ..fiberbake_x.graph import evaluate as gpu_evaluate
    gpu_value=gpu_evaluate(op,p,inputs,seed,nodeid)
    if gpu_value is not None:return gpu_value
    if op=='kernel_source':
        from ..kernel.workflows import curves_from_snapshot
        return curves_from_snapshot(p['snapshot'],p['assembly_id'],p.get('axes','xy'))
    if op=='fiber_source':
        from ..model import Tile
        from ..engine_v2.engine import ENGINE
        from ..raster import _shade_strand
        source=p.get('tile',{})
        if not source:raise GraphError('Choose a Fiber Studio tile as source')
        tile=Tile.from_dict(source)
        if tile.construction_graph:raise GraphError('Nested graph source is not supported')
        output=[]
        truth,_=ENGINE.truth(tile,detail=22)
        for strand in truth:
            t=getattr(strand,'t',np.linspace(0,1,len(strand.points),dtype=np.float32))
            colors=_shade_strand(strand,t[None,:],np.zeros((1,len(t)),np.float32),tile.settings)[0]
            output.append(Curve(strand.sid,strand.points.copy(),strand.radii.copy(),colors,
                                strand.depth,strand.roughness,strand.layer,
                                opacity=strand.opacity/max(tile.settings.strand_opacity,1e-8)))
        return CurveSet(output)
    if op=='path':
        t=np.linspace(0,1,max(4,min(160,int(p.get('points',24)))),dtype=np.float32)
        x0=float(p.get('x0',.5));y0=float(p.get('y0',.94));x1=float(p.get('x1',.5));y1=float(p.get('y1',.08))
        bx=float(p.get('bend',0.))
        x=x0+(x1-x0)*t+bx*np.sin(math.pi*t)
        y=y0+(y1-y0)*t
        return CurveSet([_curve(nodeid+':path',np.column_stack([x,y]),p.get('width',3.2),p.get('color','#a98857'),'guide',.75)])
    if op=='scatter':
        count=max(1,min(MAX_POINTS,int(p.get('count',160))))
        x0=float(p.get('x_min',.1));x1=float(p.get('x_max',.9));y0=float(p.get('y_min',.85));y1=float(p.get('y_max',.95))
        ang=math.radians(float(p.get('angle',0.)))
        # First N points are stable when count changes.
        points=[]
        for k in range(count):
            rng=np.random.default_rng(stable_int(seed,nodeid,'scatter',k,int(p.get('seed',1))))
            x=float(rng.uniform(min(x0,x1),max(x0,x1)))
            y=float(rng.uniform(min(y0,y1),max(y0,y1)))
            points.append(Point(f'{nodeid}:s{k}',x,y,(math.sin(ang),-math.cos(ang)),1,k/max(1,count),float(rng.uniform(.15,.85))))
        return PointSet(points)
    if op=='along':
        source:CurveSet=inputs['curves'];count=max(1,min(1500,int(p.get('count',12))))
        low=_bounds(p.get('start',.06),0,1);hi=_bounds(p.get('end',.91),0,1)
        side=p.get('side','both');sides=(-1,1) if side=='both' else ((-1,) if side=='left' else (1,))
        points=[]
        for c in source.curves:
            for j in range(count):
                u=low+(hi-low)*(j+.5)/count
                f=u*(len(c.coords)-1); i=min(len(c.coords)-2,int(f));a=f-i
                xy=c.coords[i]*(1-a)+c.coords[i+1]*a
                tan=c.coords[i+1]-c.coords[i]
                tan=tan/max(1e-7,float(np.linalg.norm(tan)))
                norm=np.array([-tan[1],tan[0]],dtype=np.float32)
                for sd in sides:
                    off=float(p.get('offset',0.))*sd
                    pos=xy+norm*off
                    points.append(Point(f'{nodeid}:{c.key}:a{j}:{sd}',float(pos[0]),float(pos[1]),(float(tan[0]),float(tan[1])),sd,u,c.depth))
                    if len(points)>MAX_POINTS:raise GraphError('Too many distributed points')
        return PointSet(points)
    if op=='grow':
        source:PointSet=inputs['points'];count=max(5,min(96,int(p.get('points_per_curve',12))))
        t=np.linspace(0,1,count,dtype=np.float32)
        arr=[]
        length_field=inputs.get('length_field')
        multipliers=(length_field.sample(np.array([[q.x,q.y] for q in source.points],np.float32)) if length_field and source.points else np.ones(len(source.points),np.float32))
        for i,q in enumerate(source.points):
            rng=np.random.default_rng(stable_int(seed,nodeid,q.key,int(p.get('seed',3))))
            rad=math.radians(float(p.get('angle',66.)))*q.side
            dx=q.tangent[0]*math.cos(rad)-q.tangent[1]*math.sin(rad)
            dy=q.tangent[0]*math.sin(rad)+q.tangent[1]*math.cos(rad)
            vector=np.array([dx,dy],np.float32)
            normal=np.array([-dy,dx],np.float32)
            length=_bounds(p.get('length',.28),.001,1.9)*float(np.clip(multipliers[i],0,3))
            # A feather vane envelope avoids rectangular fan ends.
            envelope=p.get('envelope','none')
            if envelope=='feather':length*=max(.09,math.sin(math.pi*(.04+.92*q.u))**.68)
            bend=float(p.get('bend',.04));curl=float(p.get('curl',0.));waves=float(p.get('waves',2.))
            frizz=float(p.get('frizz',0.))
            perturb=bend*np.sin(math.pi*t)*length + curl*np.sin(2*math.pi*waves*t)*np.sin(math.pi*t)*length
            perturb+=frizz*rng.normal(0,.15,len(t))*np.sin(math.pi*t)*length
            xy=np.array([q.x,q.y],np.float32)[None,:]+length*t[:,None]*vector+perturb[:,None]*normal
            c=_curve(f'{nodeid}:{q.key}',xy,p.get('width',1.7),p.get('color','#9b825f'),p.get('group','fiber'),q.depth)
            arr.append(c)
            if len(arr)>MAX_CURVES:raise GraphError('Too many curves')
        return CurveSet(arr)
    if op=='deform':
        out=[]
        for c in inputs['curves'].curves:
            n=len(c.coords);t=np.linspace(0,1,n,dtype=np.float32)
            d=c.coords[-1]-c.coords[0]; d=d/max(1e-7,float(np.linalg.norm(d)))
            normal=np.array([-d[1],d[0]],dtype=np.float32)
            amount=float(p.get('bend',0.))*t*(1-t)*4+float(p.get('curl',0.))*np.sin(2*math.pi*float(p.get('waves',3.))*t)*np.sin(math.pi*t)
            nc=deepcopy(c);nc.coords=c.coords+normal[None,:]*amount[:,None]*.12
            out.append(nc)
        return CurveSet(out)
    if op=='taper':
        src:CurveSet=inputs['curves'];f=inputs.get('width_field');out=[]
        for c in src.curves:
            t=np.linspace(0,1,len(c.radii),dtype=np.float32)
            ratio=_bounds(p.get('tip_ratio',.07),0,1)
            taper=(ratio+(1-ratio)*(1-t)**_bounds(p.get('power',1.3),.1,6))
            widths=(f.sample(c.coords) if f else 1.)
            n=deepcopy(c);n.radii=c.radii*taper*float(p.get('root_scale',1.))*widths
            out.append(n)
        return CurveSet(out)
    if op=='join':
        a:CurveSet=inputs['a'];b:CurveSet=inputs['b']
        return CurveSet(a.curves+b.curves)
    if op=='instance':
        src:CurveSet=inputs['curves'];points:PointSet=inputs['points'];out=[]
        limit=max(1,min(MAX_CURVES,int(p.get('limit',120))))
        for j,q in enumerate(points.points):
            for c in src.curves:
                coords=c.coords-c.coords[0]
                d=c.coords[-1]-c.coords[0];direction=d/max(1e-7,float(np.linalg.norm(d)))
                alpha=math.atan2(q.tangent[1],q.tangent[0])-math.atan2(direction[1],direction[0])
                r=np.array([[math.cos(alpha),-math.sin(alpha)],[math.sin(alpha),math.cos(alpha)]],np.float32)
                n=deepcopy(c);n.coords=coords@r.T*float(p.get('scale',.5))+np.array([q.x,q.y]);n.radii=c.radii*float(p.get('scale',.5));n.key=f'{nodeid}:{j}:{c.key}'
                if c.depth_profile is not None:n.depth_profile=(c.depth_profile-c.depth_profile[0])*float(p.get('scale',.5))+q.depth
                out.append(n)
                if len(out)>=limit:return CurveSet(out)
        return CurveSet(out)
    if op=='color_field':return ColorField(str(p.get('mode','eye')),p)
    if op=='scalar_field':return ScalarField(str(p.get('mode','constant')),p)
    if op=='paint':
        src:CurveSet=inputs['curves'];field:ColorField=inputs['color'];strength=_bounds(p.get('strength',1.),0,1);out=[]
        for c in src.curves:
            n=deepcopy(c);n.colors=np.clip(c.colors*(1-strength)+field.sample(c.coords)*strength,0,1);out.append(n)
        return CurveSet(out)
    if op=='filter':
        src:CurveSet=inputs['curves'];f=inputs.get('mask');threshold=float(p.get('threshold',.5));invert=bool(p.get('invert',False))
        if f is None:return src
        accepted=[]
        for c in src.curves:
            value=float(f.sample(c.coords[len(c.coords)//2:len(c.coords)//2+1])[0])
            if (value>=threshold) != invert:accepted.append(c)
        return CurveSet(accepted)
    raise GraphError('Unimplemented op '+op)


class GraphEvaluator:
    def __init__(self, cache=None):
        from ..engine_v2.cache import ByteLRU
        self._cache=cache if cache is not None else ByteLRU(32*1024*1024)
        self.last_computed:list[str]=[]
        self.last_reused:list[str]=[]

    def evaluate(self,graph:dict,seed:int=42,should_cancel=None)->CurveSet:
        plan=normalize_graph(graph)
        self.last_computed=[];self.last_reused=[]
        fingerprints={};values={}
        for nid in plan['order']:
            if should_cancel and should_cancel():raise RuntimeError('Render cancelled')
            node=plan['nodes'][nid];op=node['op']
            spec=OPS[op]
            params=deepcopy(spec.defaults)
            params.update(node.get('params',{}))
            sig={'op':op,'p':params,'seed':seed,'inputs':{port:fingerprints[dep] for port,dep in node.get('inputs',{}).items()}}
            digest=hashlib.blake2b(json.dumps(sig,sort_keys=True,ensure_ascii=False,default=str).encode(),digest_size=16).hexdigest()
            fingerprints[nid]=digest
            cached=self._cache.get((nid,digest))
            if cached is not None:
                result=cached;self.last_reused.append(nid)
            else:
                result=_evaluate(op,params,{p:values[d] for p,d in node.get('inputs',{}).items()},seed,nid)
                if isinstance(result,CurveSet):
                    if len(result.curves)>MAX_CURVES:raise GraphError(f'Exceeded {MAX_CURVES} curves')
                    if sum(len(c.coords) for c in result.curves)>MAX_VERTICES:raise GraphError('Exceeded vertex budget')
                self._cache.put((nid,digest),result);self.last_computed.append(nid)
            values[nid]=result
        return values[plan['output']]


def to_strands(curves:CurveSet,tile_id:str,roughness:float=.48,stable_ids:bool=False)->list[Strand]:
    items=[]
    occurrences={}
    for i,c in enumerate(curves.curves):
        colors=np.clip(c.colors,0,1).astype(np.float32)
        sid=f'{tile_id}:g{stable_int(c.key):016x}' if stable_ids else f'{tile_id}:{i}'
        if stable_ids:
            number=occurrences.get(sid,0)
            occurrences[sid]=number+1
            if number:sid+=f'_{number}'
        items.append(Strand(sid,np.asarray(c.coords,np.float32),np.asarray(c.radii,np.float32),
                            colors[0],colors[len(colors)//2],colors[-1],float(c.depth),float(c.roughness if c.roughness is not None else roughness),
                            False,c.group,opacity=c.opacity,sampled_colors=colors,depth_profile=c.depth_profile))
    return items
