"""Atlas transform math shared with legacy viewport behavior."""
import math

def transform_atlas(state,ax,ay,shift,atlas_size,gutter,grid_snap:int=0,free_space=False):
    mode=state["mode"]
    new_tf={}
    if mode=="move":
        dx_atlas=ax-state["start_ax"]
        dy_atlas=ay-state["start_ay"]
        if shift:
            if abs(dx_atlas)>=abs(dy_atlas):
                dy_atlas=0.0
            else:
                dx_atlas=0.0
        for tid,(ox,oy,ow,oh,orot) in state["orig"].items():
            nx=int(round(ox+dx_atlas))
            ny=int(round(oy+dy_atlas))
            if grid_snap>0:
                nx=int(round((nx-gutter)/grid_snap))*grid_snap+gutter
                ny=int(round((ny-gutter)/grid_snap))*grid_snap+gutter
            if not free_space:
                nx=max(gutter,min(atlas_size-ow-gutter,nx))
                ny=max(gutter,min(atlas_size-oh-gutter,ny))
            new_tf[tid]=(nx,ny,ow,oh,orot)
    elif mode=="scale":
        handle=state["handle"]
        px,py=state["pivot_x"],state["pivot_y"]
        gx0,gy0,gx1,gy1=state["group_box"]
        gw,gh=max(16.0,gx1-gx0),max(16.0,gy1-gy0)
        sx=sy=1.0
        if handle=="center":
            s=max(0.1,1.0+(ax-state["start_ax"])/max(64.0,gw))
            sx=sy=s
        else:
            if "e" in handle:
                sx=max(0.1,(ax-px)/max(16.0,gx1-px))
            elif "w" in handle:
                sx=max(0.1,(px-ax)/max(16.0,px-gx0))
            if "s" in handle:
                sy=max(0.1,(ay-py)/max(16.0,gy1-py))
            elif "n" in handle:
                sy=max(0.1,(py-ay)/max(16.0,py-gy0))
            if shift and len(handle)==2:
                s=max(sx,sy);sx=sy=s
        for tid,(ox,oy,ow,oh,orot) in state["orig"].items():
            nw=max(16,min(atlas_size-2*gutter,int(round(ow*sx))))
            nh=max(16,min(atlas_size-2*gutter,int(round(oh*sy))))
            nx=int(round(px+(ox-px)*sx))
            ny=int(round(py+(oy-py)*sy))
            if not free_space:
                nx=max(gutter,min(atlas_size-nw-gutter,nx))
                ny=max(gutter,min(atlas_size-nh-gutter,ny))
            new_tf[tid]=(nx,ny,nw,nh,orot)
    elif mode=="rotate":
        px,py=state["pivot_x"],state["pivot_y"]
        cur_ang=math.degrees(math.atan2(ay-py,ax-px))
        delta=((cur_ang-state["start_angle"]+180.0)%360.0)-180.0
        if shift:
            delta=round(delta/15.0)*15.0
        state["delta_deg"]=-delta
        rad=math.radians(delta)
        ca,sa=math.cos(rad),math.sin(rad)
        for tid,(ox,oy,ow,oh,orot) in state["orig"].items():
            nrot=(orot-delta)%360.0
            swap=(abs((nrot%180.0)-90.0)<45.0)!=(abs((orot%180.0)-90.0)<45.0)
            nw,nh=(oh,ow) if swap else (ow,oh)
            ocx,ocy=ox+ow*0.5,oy+oh*0.5
            dx,dy=ocx-px,ocy-py
            ncx=px+dx*ca-dy*sa
            ncy=py+dx*sa+dy*ca
            nx=int(round(ncx-nw*0.5));ny=int(round(ncy-nh*0.5))
            if not free_space:
                nx=max(gutter,min(atlas_size-nw-gutter,nx))
                ny=max(gutter,min(atlas_size-nh-gutter,ny))
            new_tf[tid]=(nx,ny,nw,nh,nrot)
    state["current"]=new_tf
    return new_tf
