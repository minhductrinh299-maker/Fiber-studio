"""Peacock UI tokens, semantic component roles and live widget registry.

All resources are resolved relative to source/bundled assets, never Downloads.
Scene colors, renderer materials and texture data are outside this registry.
"""
from pathlib import Path
import json
import weakref
import builtins
import tkinter as tk
from tkinter import ttk

ASSETS=Path(__file__).resolve().parents[1]/'assets'/'branding'
def read_theme():
    data=json.loads((ASSETS/'ui_theme.json').read_text(encoding='utf-8'))
    for key,value in data['colors'].items():
        if len(value)!=7 or value[0]!='#':raise ValueError('Invalid UI color: '+key)
        int(value[1:],16)
    for spec in data['assets'].values():
        if not (ASSETS/spec).resolve().is_relative_to(ASSETS.resolve()):raise ValueError('Asset escapes branding folder')
    return data
THEME=read_theme()
TOKEN_HISTORY={value.lower():key for key,value in THEME['colors'].items()}
def color(role):return THEME['colors'][role]

LEGACY={'#17191d':'background','#191b1f':'background','#202329':'panel','#24282e':'panel','#292d34':'control',
 '#20232a':'panel','#1b1e24':'viewport','#101215':'viewport','#101419':'viewport','#15191c':'viewport',
 '#161b22':'viewport','#171e27':'viewport','#eceef2':'text','#ebedf0':'text','#a6aeb8':'muted','#9ba3af':'muted',
 '#adb7c2':'muted','#b0b4bc':'muted','#d7a66f':'selection','#d9aa72':'selection','#ecc294':'cyan',
 '#83baa4':'success','#363b44':'border','#363a42':'border','#3c4049':'border','#3c404b':'border',
 '#3a3f48':'hover','#383c44':'border','#453825':'control','#5e4b39':'accent','#fff5e9':'text',
 '#344b60':'panel','#e2b368':'selection','#6ad8d0':'cyan','#edb66f':'selection','#efbf78':'selection'}

class UIRegistry:
    def __init__(self,root):
        self.root=root;self.widgets=weakref.WeakValueDictionary();self.records={};self.pending=None;self.closed=False
        self._pill_images={}
        self.install_styles();root.bind_all('<Map>',self.schedule,add='+')
        root.bind('<Destroy>',self.on_destroy,add='+');self.schedule()
    def _create_pill_image(self,fill,r=8,w=40,h=40):
        from PIL import Image,ImageDraw,ImageTk
        scale=4
        im=Image.new('RGBA',(w*scale,h*scale),(0,0,0,0))
        d=ImageDraw.Draw(im)
        d.rounded_rectangle([0,0,w*scale-1,h*scale-1],radius=r*scale,fill=fill)
        im=im.resize((w,h),Image.Resampling.LANCZOS)
        return ImageTk.PhotoImage(im,master=self.root)
    def _create_rounded_button_style(self,style_name,normal_bg,active_bg,pressed_bg,fg='#ffffff',r=8,border=8,pad=(10,5),font_spec=('Segoe UI',9)):
        s=ttk.Style(self.root)
        img_n=self._create_pill_image(normal_bg,r=r)
        img_a=self._create_pill_image(active_bg,r=r)
        img_p=self._create_pill_image(pressed_bg,r=r)
        self._pill_images[style_name]=(img_n,img_a,img_p)
        elem=f'{style_name}.button'
        try:
            s.element_create(elem,'image',img_n,('pressed',img_p),('active',img_a),border=border,sticky='nsew')
        except tk.TclError:pass
        s.layout(style_name,[(elem,{'sticky':'nsew','children':[('Button.padding',{'sticky':'nsew','children':[('Button.label',{'sticky':'nsew'})]})]})])
        s.configure(style_name,foreground=fg,font=font_spec,padding=pad)
    def install_styles(self):
        s=ttk.Style(self.root);c=THEME['colors']
        s.configure('.',background=c['background'],foreground=c['text'],bordercolor=c['background'],relief='flat',borderwidth=0)
        for style,bg,fg in [('TFrame','background','text'),('Panel.TFrame','panel','text'),('TLabel','background','text'),
              ('Panel.TLabel','panel','text'),('Muted.TLabel','panel','muted'),('Hero.TLabel','background','cyan'),
              ('Warning.TLabel','panel','selection'),('Success.TLabel','panel','success')]:
            s.configure(style,background=c[bg],foreground=c[fg],relief='flat',borderwidth=0)

        # Real 9-slice soft-rounded pill buttons
        self._create_rounded_button_style('Pill.TButton',c['control'],c['hover'],c['accent'],fg=c['muted'],r=10,border=10,pad=(12,5),font_spec=('Segoe UI',9))
        self._create_rounded_button_style('PillActive.TButton',c['accent'],c['cyan'],c['hover'],fg='#ffffff',r=10,border=10,pad=(12,5),font_spec=('Segoe UI Semibold',9))
        self._create_rounded_button_style('Primary.TButton',c['cyan'],c['text'],c['selection'],fg=c['background'],r=10,border=10,pad=(13,6),font_spec=('Segoe UI Semibold',9))
        self._create_rounded_button_style('TButton',c['control'],c['hover'],c['accent'],fg=c['text'],r=7,border=7,pad=(10,5),font_spec=('Segoe UI',9))
        self._create_rounded_button_style('Workspace.TButton',c['control'],c['hover'],c['accent'],fg=c['muted'],r=8,border=8,pad=(11,6),font_spec=('Segoe UI',9))
        self._create_rounded_button_style('Accent.TButton',c['accent'],c['cyan'],c['hover'],fg='#ffffff',r=8,border=8,pad=(12,6),font_spec=('Segoe UI Semibold',9))
        self._create_rounded_button_style('Tool.TButton',c['control'],c['hover'],c['accent'],fg=c['text'],r=6,border=6,pad=(7,4),font_spec=('Segoe UI',8))

        # Soft rounded container frame
        img_container=self._create_pill_image(c['control'],r=12)
        self._pill_images['container']=img_container
        try:s.element_create('PillContainer.field','image',img_container,border=12,sticky='nsew')
        except tk.TclError:pass
        s.layout('PillContainer.TFrame',[('PillContainer.field',{'sticky':'nsew','children':[('Frame.padding',{'sticky':'nsew'})]})])
        s.configure('PillContainer.TFrame',background=c['background'])

        # Soft rounded entry and combobox
        img_box=self._create_pill_image(c['control'],r=6)
        self._pill_images['box']=img_box
        try:s.element_create('RoundedBox.field','image',img_box,border=6,sticky='nsew')
        except tk.TclError:pass
        s.layout('TEntry',[('RoundedBox.field',{'sticky':'nsew','children':[('Entry.padding',{'sticky':'nsew','children':[('Entry.textarea',{'sticky':'nsew'})]})]})])
        s.layout('TCombobox',[('RoundedBox.field',{'sticky':'nsew','children':[('Combobox.downarrow',{'side':'right','sticky':'ns'}),('Combobox.padding',{'sticky':'nsew','children':[('Combobox.textarea',{'sticky':'nsew'})]})]})])
        for style in ('TEntry','TCombobox','TSpinbox'):
            s.configure(style,background=c['control'],fieldbackground=c['control'],foreground=c['text'],insertcolor=c['cyan'],selectbackground=c['accent'],selectforeground=c['text'],relief='flat',borderwidth=0,padding=4)
            s.map(style,fieldbackground=[('readonly',c['control']),('disabled',c['panel'])],foreground=[('readonly',c['text']),('disabled',c['muted'])])

        # Soft rounded Notebook tabs
        img_tab=self._create_pill_image(c['control'],r=6)
        img_tab_active=self._create_pill_image(c['accent'],r=6)
        self._pill_images['tab']=(img_tab,img_tab_active)
        try:s.element_create('RoundedTab.tab','image',img_tab,('selected',img_tab_active),border=6,sticky='nsew')
        except tk.TclError:pass
        s.layout('TNotebook.Tab',[('RoundedTab.tab',{'sticky':'nsew','children':[('Notebook.padding',{'side':'top','sticky':'nsew','children':[('Notebook.label',{'side':'top','sticky':''})]})]})])
        s.configure('TNotebook',background=c['panel'],relief='flat',borderwidth=0)
        s.configure('TNotebook.Tab',background=c['control'],foreground=c['muted'],relief='flat',borderwidth=0,padding=(12,6))
        s.map('TNotebook.Tab',foreground=[('selected','#ffffff'),('active',c['cyan'])])

        s.configure('Treeview',background=c['panel'],fieldbackground=c['panel'],foreground=c['text'],relief='flat',borderwidth=0)
        s.configure('Treeview.Heading',background=c['control'],foreground=c['cyan'],relief='flat',borderwidth=0)
        s.map('Treeview',background=[('selected',c['accent'])],foreground=[('selected',c['text'])])
        for style in ('TCheckbutton','TRadiobutton'):s.configure(style,background=c['panel'],foreground=c['text'],relief='flat',borderwidth=0);s.map(style,background=[('active',c['hover'])])
        for style in ('Horizontal.TScale','Vertical.TScale','TScrollbar','Horizontal.TProgressbar','TProgressbar'):
            s.configure(style,background=c['accent'],troughcolor=c['panel'],bordercolor=c['background'],relief='flat',borderwidth=0)
    def register(self,item_id,widget,role=None):
        existing=self.widgets.get(item_id)
        if existing is not None and existing is not widget and existing.winfo_exists():raise ValueError('Duplicate UI id: '+item_id)
        self.widgets[item_id]=widget
        self.records[item_id]={**self.records.get(item_id,{}),**dict(id=item_id,parent=str(widget.master) if widget.master else None,type=widget.winfo_class(),role=role or 'automatic')}
        if role in THEME['components'] and isinstance(widget,ttk.Widget):
            style=THEME['components'][role]['style']
            current=str(widget.cget('style'))
            if style.rsplit('.',1)[-1]==widget.winfo_class() and current!=style and not current.endswith('.'+style):
                widget.configure(style=style)
                dpi=getattr(self.root,'dpi_manager',None)
                if dpi:dpi.records.pop(str(widget),None)
        return widget
    def schedule(self,event=None):
        if not self.closed and self.pending is None:self.pending=self.root.after_idle(self.scan)
    def scan(self):
        self.pending=None
        if self.closed:return
        named={builtins.id(w):name for attr,name in [('card_window','workspace.cards'),('construction_window','workspace.graph'),('render_window','workspace.render'),('bodypane','workspace.fiber'),('_ui_theme_window','dialog.ui_theme')] if (w:=getattr(self.root,attr,None)) is not None}
        stack=[(self.root,'app')]
        while stack:
            widget,path=stack.pop();path=named.get(builtins.id(widget),path)
            if not widget.winfo_exists():continue
            self.register(path,widget,THEME['elements'].get(path,{}).get('role'))
            if not isinstance(widget,ttk.Widget):
                options=widget.keys();changes={};bindings=self.records[path].setdefault('color_tokens',{})
                for option in ('background','foreground','activebackground','activeforeground','highlightbackground','troughcolor','insertbackground'):
                    if option in options:
                        old=str(widget.cget(option)).lower()
                        role=bindings.get(option) or LEGACY.get(old) or TOKEN_HISTORY.get(old)
                        if role:
                            bindings[option]=role;changes[option]=color(role)
                if isinstance(widget,(tk.Tk,tk.Toplevel)):changes['background']=color('background')
                if isinstance(widget,(tk.Text,tk.Listbox,tk.Menu)):
                    changes.update(background=color('control'),foreground=color('text'))
                if changes:
                    try:widget.configure(**changes)
                    except tk.TclError:pass
            for attr in ('bg_color','fg_color','fill_color','handle_color','border_color','focus_border'):
                value=str(getattr(widget,attr,'')).lower();role=TOKEN_HISTORY.get(value) or LEGACY.get(value)
                if role:setattr(widget,attr,color(role))
            if hasattr(widget,'handle_color') and hasattr(widget,'_draw_slider'):widget._draw_slider()
            counts={}
            for child in widget.winfo_children():
                name=child.winfo_class();index=counts.get(name,0);counts[name]=index+1
                stack.append((child,path+'.'+name.lower()+'.'+str(index)))
        for id,spec in THEME['elements'].items():
            widget=getattr(self.root,spec.get('attribute',''),None)
            if widget is not None and widget.winfo_exists():self.register(id,widget,spec.get('role'))
        for id in list(self.records):
            widget=self.widgets.get(id)
            if widget is None or not widget.winfo_exists():self.records.pop(id,None)
    def export(self,path):
        self.scan();Path(path).write_text(json.dumps(dict(schema=1,theme=THEME['name'],elements=list(self.records.values())),indent=2)+'\n',encoding='utf-8')
    def reload(self):
        global THEME
        THEME=read_theme();TOKEN_HISTORY.update({v.lower():k for k,v in THEME['colors'].items()});self.install_styles();self.scan()
    def on_destroy(self,event):
        if event.widget is self.root:
            self.closed=True
            if self.pending:
                try:self.root.after_cancel(self.pending)
                except tk.TclError:pass
    def brand_header(self,parent):
        from PIL import Image,ImageTk
        size=max(32,round(float(self.root.winfo_fpixels('1i'))/96*40))
        image=Image.open(ASSETS/THEME['assets']['logo']).convert('RGBA');image.thumbnail((size,size))
        photo=ImageTk.PhotoImage(image,master=self.root);label=ttk.Label(parent,image=photo);label.image=photo
        label.pack(side='left',padx=(0,8));self.register('app.header.brand',label,'identity')
        return label

def install(root):
    registry=UIRegistry(root);root.ui_registry=registry
    icon=ASSETS/THEME['assets']['icon']
    if icon.is_file():
        try:root.iconbitmap(str(icon));root.iconbitmap(default=str(icon))
        except tk.TclError:pass
    return registry


def manage(root):
    from tkinter import colorchooser,messagebox,filedialog
    existing=getattr(root,'_ui_theme_window',None)
    if existing is not None and existing.winfo_exists():existing.lift();return existing
    registry=root.ui_registry;registry.scan()
    window=tk.Toplevel(root);window.title('Peacock · UI Registry');window.geometry('850x700')
    root._ui_theme_window=window
    tabs=ttk.Notebook(window);tabs.pack(fill='both',expand=True,padx=12,pady=12)
    palette_tab=ttk.Frame(tabs,padding=8);catalog=ttk.Frame(tabs,padding=12)
    tabs.add(palette_tab,text='Màu giao diện');tabs.add(catalog,text='UI Elements')
    scroll_host=ttk.Frame(palette_tab);scroll_host.pack(fill='both',expand=True)
    canvas=tk.Canvas(scroll_host,background=color('background'),highlightthickness=0)
    scroll=ttk.Scrollbar(scroll_host,command=canvas.yview);scroll.pack(side='right',fill='y')
    canvas.pack(side='left',fill='both',expand=True);canvas.configure(yscrollcommand=scroll.set)
    palette=ttk.Frame(canvas,padding=8);item=canvas.create_window((0,0),window=palette,anchor='nw')
    palette.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
    canvas.bind('<Configure>',lambda e:canvas.itemconfigure(item,width=e.width))
    def wheel(event):
        if str(event.widget).startswith(str(palette_tab)):canvas.yview_scroll(-int(event.delta/120),'units');return 'break'
    window.bind('<MouseWheel>',wheel,add='+')
    draft=json.loads(json.dumps(THEME));swatches={}
    for role,value in draft['colors'].items():
        row=ttk.Frame(palette);row.pack(fill='x',pady=3)
        ttk.Label(row,text=role,width=18).pack(side='left')
        var=tk.StringVar(value=value);ttk.Entry(row,textvariable=var,width=12).pack(side='left')
        def choose(role=role,var=var):
            result=colorchooser.askcolor(var.get(),parent=window)[1]
            if result:var.set(result)
        ttk.Button(row,text='Chọn màu…',command=choose).pack(side='left',padx=8)
        swatches[role]=var
    def save():
        try:
            for role,var in swatches.items():
                value=var.get()
                if len(value)!=7 or value[0]!='#':raise ValueError('Màu cần có dạng #RRGGBB: '+role)
                int(value[1:],16);draft['colors'][role]=value
            temp=ASSETS/'ui_theme.json.tmp';temp.write_text(json.dumps(draft,indent=2)+'\n',encoding='utf-8');temp.replace(ASSETS/'ui_theme.json')
            registry.reload()
        except Exception as error:messagebox.showerror('UI theme',str(error),parent=window)
    ttk.Button(palette_tab,text='Lưu & áp dụng toàn app',command=save).pack(fill='x',pady=12)
    list_frame=ttk.Frame(catalog);list_frame.pack(fill='both',expand=True)
    tree=ttk.Treeview(list_frame,columns=('type','role'),show='tree headings');tree.pack(side='left',fill='both',expand=True)
    tree.heading('#0',text='Registered UI ID');tree.heading('type',text='Widget type');tree.heading('role',text='Role')
    tree.column('#0',width=420);tree.column('type',width=100);tree.column('role',width=120)
    scroll=ttk.Scrollbar(list_frame,command=tree.yview);scroll.pack(side='right',fill='y');tree.configure(yscrollcommand=scroll.set)
    for id,record in sorted(registry.records.items()):tree.insert('','end',iid=id,text=id,values=(record['type'],record['role']))
    role=tk.StringVar(value='primary');ttk.Combobox(catalog,textvariable=role,values=list(THEME['components']),state='readonly').pack(fill='x',pady=5)
    def apply_role():
        for id in tree.selection():
            widget=registry.widgets.get(id)
            if widget is not None and isinstance(widget,ttk.Widget):
                if THEME['components'][role.get()]['style'].rsplit('.',1)[-1]!=widget.winfo_class():
                    messagebox.showinfo('UI role','Vai trò này không phù hợp loại widget đang chọn.',parent=window);continue
                registry.register(id,widget,role.get());draft['elements'][id]={**draft['elements'].get(id,{}),'role':role.get()}
                tree.set(id,'role',role.get())
    ttk.Button(catalog,text='Gán vai trò cho element được chọn',command=apply_role).pack(fill='x')
    def export():
        path=filedialog.asksaveasfilename(parent=window,defaultextension='.json',filetypes=[('UI registry','*.json')])
        if path:registry.export(path)
    ttk.Button(catalog,text='Xuất danh mục UI…',command=export).pack(fill='x',pady=5)
    return window
