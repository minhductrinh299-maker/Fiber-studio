"""Direct silhouette handles backed by ordinary card profiles and continuous edits."""
from .ui_theme import color as ui_color
import math
import tkinter as tk
from tkinter import ttk
import numpy as np

class VisualCardShape(ttk.Frame):
    def __init__(self,parent,editor):
        super().__init__(parent);self.editor=editor;self.drag=None;self.handles=[]
        ttk.Label(self,text='SHAPE · kéo để tạo dáng',font=('Segoe UI Semibold',11)).pack(anchor='w',pady=5)
        ttk.Label(self,text='Điểm xanh: uốn đường giữa · Điểm vàng: độ rộng',wraplength=270).pack(anchor='w')
        self.pad=tk.Canvas(self,height=260,width=240,bg=ui_color('viewport'),highlightthickness=0)
        self.pad.pack(fill='x',pady=8)
        self.pad.bind('<Configure>',lambda e:self.draw())
        self.pad.bind('<ButtonPress-1>',self.down);self.pad.bind('<B1-Motion>',self.move)
        self.pad.bind('<ButtonRelease-1>',self.up);self.pad.bind('<Escape>',self.cancel)
        row=ttk.Frame(self);row.pack(fill='x')
        ttk.Button(row,text='Kéo dáng trong viewport',command=self.viewport).pack(fill='x',pady=2)
        ttk.Button(row,text='Chải bằng brush',command=self.brush).pack(fill='x',pady=2)
        ttk.Label(self,text='Chọn card → kéo tay nắm → xem kết quả ngay. Esc hủy lượt kéo. Các lớp sculpt vẫn được giữ.',wraplength=270).pack(anchor='w',pady=5)
        self.job=self.after(200,self.poll)
        self.bind('<Destroy>',self.destroyed,add='+')
    def destroyed(self,event):
        if event.widget is self:
            try:self.after_cancel(self.job)
            except tk.TclError:pass
    def poll(self):
        if self.drag is None:self.draw()
        self.job=self.after(200,self.poll)
    def viewport(self):
        self.editor.selection_mode.set('Row');self.editor._set_tool('Move');self.editor.canvas.focus_set()
        self.editor.info.set('Chọn một hàng điểm trên card và kéo để uốn; Shift kéo chậm. Alt + chuột để di chuyển camera.')
    def brush(self):
        self.editor._set_mode('Groom');self.editor._set_tool('Comb');self.editor.brush.set(True);self.editor.canvas.focus_set()
    def draw(self):
        p=self.pad;p.delete('all');self.handles=[]
        cards=self.editor._selection()
        if not cards:p.create_text(max(120,p.winfo_width()/2),125,text='Chọn card để chỉnh hình',fill='#aeb9c7');return
        c=cards[0];w=max(180,p.winfo_width());scale=min(65,w*.25);self.scale=scale
        centers=[];left=[];right=[]
        for i in range(5):
            t=i/4;x=w/2+c.offsets[i][0]/max(c.length,.015)*scale
            y=230-t*195-c.offsets[i][1]/max(c.length,.015)*scale
            half=scale*.48*c.width_profile[i]*max(.03,1-c.taper*t*t)
            centers.append((x,y))
        from .kernel.surface import smooth_samples
        knots=np.linspace(0,1,5);sample=np.linspace(0,1,81)
        dense=smooth_samples(knots,np.asarray(centers),sample)
        tangent=np.gradient(dense,axis=0);tangent/=np.maximum(np.linalg.norm(tangent,axis=1,keepdims=True),1e-8)
        normals=np.column_stack((-tangent[:,1],tangent[:,0]))
        widths=scale*.48*np.interp(sample,knots,c.width_profile)*np.maximum(.03,1-c.taper*sample*sample)
        dl=dense-normals*widths[:,None];dr=dense+normals*widths[:,None]
        self.normals=normals[::20]
        left=dl[::20];right=dr[::20]
        p.create_polygon(*np.concatenate((dl,dr[::-1])).ravel(),fill=ui_color('panel'),outline=ui_color('selection'),width=2)
        p.create_line(*dense.ravel(),fill=ui_color('cyan'),width=2)
        for i,(center,l,r) in enumerate(zip(centers,left,right)):
            for kind,(x,y) in [('center',center),('left',l),('right',r)]:
                color=ui_color('cyan') if kind=='center' else ui_color('selection')
                p.create_oval(x-5,y-5,x+5,y+5,fill=color,outline='#151b22')
                self.handles.append((x,y,kind,i))
        p.create_text(8,12,text='NGỌN',anchor='nw',fill='#96a5b8');p.create_text(8,245,text='GỐC · khóa vị trí' if c.locked_root else 'GỐC',anchor='sw',fill='#96a5b8')
    def down(self,e):
        cards=self.editor._selection()
        if not cards or not self.handles:return
        hit=min(self.handles,key=lambda h:(h[0]-e.x)**2+(h[1]-e.y)**2)
        if (hit[0]-e.x)**2+(hit[1]-e.y)**2>225:return
        if hit[2]=='center' and hit[3]==0 and cards[0].locked_root:return
        self.pad.focus_set();self.drag=dict(x=e.x,y=e.y,hit=hit,normal=self.normals[hit[3]].copy(),sources={c.id:c.fast_copy() for c in cards},changed=False)
    def move(self,e):
        d=self.drag
        if not d:return
        if not d['changed']:
            if abs(e.x-d['x'])+abs(e.y-d['y'])<2:return
            self.editor._history();d['changed']=True
        dx=(e.x-d['x'])/self.scale;dy=-(e.y-d['y'])/self.scale
        _,_,kind,index=d['hit'];changed=[]
        for c in self.editor._selection():
            source=d['sources'].get(c.id)
            if source is None:continue
            if kind=='center':
                if index==0 and source.locked_root:continue
                c.offsets=[list(v) for v in source.offsets]
                c.offsets[index][0]+=dx*source.length;c.offsets[index][1]+=dy*source.length
            else:
                t=index/4;factor=max(.03,1-source.taper*t*t)
                c.width_profile=list(source.width_profile)
                c.width_profile[index]=float(np.clip(source.width_profile[index]+float(np.dot([e.x-d['x'],e.y-d['y']],d['normal']))/self.scale*(1 if kind=='right' else -1)/(.48*factor),.01,4))
            changed.append(c)
        if self.editor.view:self.editor.view.changed(changed)
        self.editor._render_soon(0);self.draw()
    def up(self,e=None):
        d=self.drag;self.drag=None
        if d and d['changed']:self.editor._save_cards();self.editor._sync_inspector()
        self.draw()
    def cancel(self,e=None):
        d=self.drag;self.drag=None
        if d and d['changed']:
            self.editor.cards=[d['sources'].get(c.id,c) for c in self.editor.cards]
            self.editor._save_cards()
            if self.editor.app._undo:self.editor.app._undo.pop()
            self.editor._sync_inspector();self.editor._render_soon(0)
        self.draw();return 'break'
