"""OpenGL 4.3+ persistent compute shader baker for Fiber Engine V2.

Executes tiled 32x32 analytic capsule coverage, 8-depth-bin geometric AO, and
all 15 physical/material output channels on a dedicated offscreen WGL thread.
Falls back silently to the CPU sub-rect reference baker when GL < 4.3,
headless/non-Win32, oversized, or per-length custom `attributes` are active.
"""
from __future__ import annotations

import atexit
import ctypes as C
import math
import queue
import re
import sys
import threading
import numpy as np
from PIL import Image

from ..model import MAP_NAMES, EXTRA_MAP_NAMES
from .samples import BLOCK, AO_RADIUS

GL_COMPUTE_SHADER = 0x91B9
GL_SHADER_STORAGE_BUFFER = 0x90D2
GL_SHADER_STORAGE_BARRIER_BIT = 0x00002000
GL_BUFFER_UPDATE_BARRIER_BIT = 0x00000200
GL_DYNAMIC_DRAW = 0x88E8
GL_STATIC_DRAW = 0x88E4
GL_COMPILE_STATUS = 0x8B81
GL_LINK_STATUS = 0x8B82
GL_VERSION = 0x1F02
GL_RENDERER = 0x1F01
GL_R32UI = 0x8236
GL_RED_INTEGER = 0x8D94
GL_UNSIGNED_INT = 0x1405

ALL_BAKE_CHANNELS = (
    'color', 'alpha', 'normal', 'flow', 'depth', 'ao', 'id', 'cluster_id',
    'roughness', 'rgb_mask', 'specular', 'anisotropy', 'transmission', 'scatter', 'iridescence',
)
CHANNEL_INDEX = {name: i for i, name in enumerate(ALL_BAKE_CHANNELS)}
PATTERN_MAP = {'solid': 0, 'banded': 1, 'agouti': 2, 'speckle': 3, 'ombre': 4}

STRAND_DTYPE = np.dtype([
    ('bbox', np.float32, 4),
    ('cr_rough', np.float32, 4),
    ('cm_op', np.float32, 4),
    ('ct_depth', np.float32, 4),
    ('extra1', np.float32, 4),
    ('extra2', np.float32, 4),
    ('ids', np.uint32, 4),
], align=False)  # 112 bytes exact (7 * 16B std430)

SEG_DTYPE = np.dtype([
    ('ab', np.float32, 4),
    ('rt', np.float32, 4),
], align=False)  # 32 bytes exact (2 * 16B std430)

SAMPLED_SEG_DTYPE = np.dtype([
    ('c0', np.float32, 4),
    ('c1', np.float32, 4),
], align=False)  # 32 bytes exact (2 * 16B std430)

COMPUTE_SOURCE = r"""#version 430 core
layout(local_size_x = 16, local_size_y = 16, local_size_z = 1) in;

struct StrandGPU {
    vec4 bbox;      // min_x, min_y, max_x, max_y (pixel space)
    vec4 cr_rough;  // color_root.rgb, roughness
    vec4 cm_op;     // color_mid.rgb, opacity
    vec4 ct_depth;  // color_tip.rgb, depth
    vec4 extra1;    // pattern_phase, specular, anisotropy, transmission
    vec4 extra2;    // scatter, iridescence, has_sampled_f, seg_pad
    uvec4 ids;      // seg_start, seg_count, numeric_id, cluster_id
};

struct SegGPU {
    vec4 ab;        // ax, ay, bx, by (pixel space)
    vec4 rt;        // r0, r1, t0, t1
};

struct SampledSegGPU {
    vec4 c0;        // sampled root endpoint rgb + unused
    vec4 c1;        // sampled tip endpoint rgb + unused
};

layout(std430, binding = 0) readonly buffer StrandBuf { StrandGPU strands[]; };
layout(std430, binding = 1) readonly buffer SegBuf { SegGPU segs[]; };
layout(std430, binding = 2) readonly buffer SampledBuf { SampledSegGPU sampled_segs[]; };
layout(std430, binding = 3) readonly buffer BlockBuf { uvec4 blocks[]; };
layout(std430, binding = 4) readonly buffer IndexBuf { uint bin_indices[]; };
layout(std430, binding = 5) writeonly buffer OutBuf { uint out_pixels[]; };

uniform int uWidth;
uniform int uHeight;
uniform int uBlockBase;
uniform int uBlockCount;
uniform uint uChannelMask;
uniform int uChannelSlots[15];
uniform float uAntialias;
uniform float uHalo;
uniform float uRoundness;
uniform int uPattern;
uniform float uBandCount;
uniform float uBandStrength;
uniform float uSpeckle;
uniform vec4 uDefaults0; // roughness, specular, anisotropy, transmission
uniform vec4 uDefaults1; // scatter, iridescence, 0, 0

float safe_tanh(float x) {
    float xc = clamp(x, -20.0, 20.0);
    float e = exp(-2.0 * abs(xc));
    float t = (1.0 - e) / (1.0 + e);
    return (xc >= 0.0) ? t : -t;
}

uint pack_byte4(float r, float g, float b, float a) {
    uint ur = uint(roundEven(clamp(r, 0.0, 1.0) * 255.0));
    uint ug = uint(roundEven(clamp(g, 0.0, 1.0) * 255.0));
    uint ub = uint(roundEven(clamp(b, 0.0, 1.0) * 255.0));
    uint ua = uint(roundEven(clamp(a, 0.0, 1.0) * 255.0));
    return ur | (ug << 8u) | (ub << 16u) | (ua << 24u);
}

uint pack_u24_rgb(uint id_val) {
    uint r = (id_val >> 16u) & 255u;
    uint g = (id_val >> 8u) & 255u;
    uint b = id_val & 255u;
    return r | (g << 8u) | (b << 16u) | (255u << 24u);
}

void main() {
    uint wg = gl_WorkGroupID.x;
    int blk_offset = int(wg >> 2u);
    if (blk_offset >= uBlockCount) return;
    uvec4 blk = blocks[uBlockBase + blk_offset];
    uint quad = wg & 3u;
    uint px = blk.x * 32u + (quad & 1u) * 16u + gl_LocalInvocationID.x;
    uint py = blk.y * 32u + (quad >> 1u) * 16u + gl_LocalInvocationID.y;
    if (int(px) >= uWidth || int(py) >= uHeight) return;

    vec2 p = vec2(float(px) + 0.5, float(py) + 0.5);
    float edge = max(0.3, uAntialias);
    float half_edge = 0.5 * edge;
    float halo = uHalo;
    uint bin_start = blk.z;
    uint bin_count = blk.w;

    bool need_ao = (uChannelMask & (1u << 5u)) != 0u;
    float ao_buckets[8];
    if (need_ao) {
        for (int z = 0; z < 8; ++z) ao_buckets[z] = 0.0;
        for (uint k = 0u; k < bin_count; ++k) {
            uint s_idx = bin_indices[bin_start + k];
            StrandGPU sh = strands[s_idx];
            if (p.x < sh.bbox.x || p.x > sh.bbox.z || p.y < sh.bbox.y || p.y > sh.bbox.w) continue;
            float prox = 0.0;
            uint s0 = sh.ids.x;
            uint sc = sh.ids.y;
            for (uint j = 0u; j < sc; ++j) {
                SegGPU sg = segs[s0 + j];
                vec2 a = sg.ab.xy;
                vec2 b = sg.ab.zw;
                float rmax = max(sg.rt.x, sg.rt.y) + halo;
                vec2 lo = min(a, b) - rmax;
                vec2 hi = max(a, b) + rmax;
                if (p.x < lo.x || p.x > hi.x || p.y < lo.y || p.y > hi.y) continue;
                vec2 d = b - a;
                float len2 = dot(d, d);
                if (len2 < 1e-10) continue;
                float u = clamp(dot(p - a, d) / len2, 0.0, 1.0);
                vec2 rv = p - a - u * d;
                float dist = length(rv);
                float rad = mix(sg.rt.x, sg.rt.y, u);
                float near_v = clamp(1.0 - max(0.0, dist - rad) / halo, 0.0, 1.0);
                prox = max(prox, near_v);
            }
            int zbin = clamp(int(sh.ct_depth.w * 8.0), 0, 7);
            ao_buckets[zbin] += prox * sh.cm_op.w;
        }
    }

    float weight = 0.0;
    vec3 acc_color = vec3(0.0);
    vec3 acc_normal = vec3(0.0);
    vec3 acc_flow = vec3(0.0);
    float acc_depth = 0.0;
    float acc_ao = 0.0;
    uint acc_id = 0u;
    uint acc_cluster = 0u;
    float acc_rough = 0.0;
    vec3 acc_rgbmask = vec3(0.0);
    float acc_spec = 0.0;
    float acc_aniso = 0.0;
    float acc_trans = 0.0;
    float acc_scat = 0.0;
    float acc_irid = 0.0;

    for (uint k = 0u; k < bin_count; ++k) {
        uint s_idx = bin_indices[bin_start + k];
        StrandGPU sh = strands[s_idx];
        if (p.x < sh.bbox.x || p.x > sh.bbox.z || p.y < sh.bbox.y || p.y > sh.bbox.w) continue;
        float best_cover = 0.0;
        float best_along = 0.0;
        float best_across = 0.0;
        float best_tx = 0.0;
        float best_ty = 0.0;
        float best_u = 0.0;
        uint best_seg = 0u;
        uint s0 = sh.ids.x;
        uint sc = sh.ids.y;
        for (uint j = 0u; j < sc; ++j) {
            uint seg_idx = s0 + j;
            SegGPU sg = segs[seg_idx];
            vec2 a = sg.ab.xy;
            vec2 b = sg.ab.zw;
            float rmax = max(sg.rt.x, sg.rt.y) + half_edge;
            vec2 lo = min(a, b) - rmax;
            vec2 hi = max(a, b) + rmax;
            if (p.x < lo.x || p.x > hi.x || p.y < lo.y || p.y > hi.y) continue;
            vec2 d = b - a;
            float len2 = dot(d, d);
            if (len2 < 1e-10) continue;
            float u = clamp(dot(p - a, d) / len2, 0.0, 1.0);
            vec2 rv = p - a - u * d;
            float dist = length(rv);
            float rad = mix(sg.rt.x, sg.rt.y, u);
            float c = clamp((rad - dist) / edge + 0.5, 0.0, 1.0);
            if (c > best_cover) {
                best_cover = c;
                best_along = mix(sg.rt.z, sg.rt.w, u);
                float inv_len = 1.0 / sqrt(len2);
                best_across = ((-d.y * rv.x + d.x * rv.y) * inv_len) / max(rad, 0.02);
                best_tx = d.x * inv_len;
                best_ty = d.y * inv_len;
                best_u = u;
                best_seg = seg_idx;
            }
        }
        float op_a = best_cover * sh.cm_op.w;
        if (op_a <= 0.0) continue;
        float over = 1.0 - op_a;

        if ((uChannelMask & (1u << 6u)) != 0u && op_a > 0.26) acc_id = sh.ids.z & 0xFFFFFFu;
        if ((uChannelMask & (1u << 7u)) != 0u && op_a > 0.26) acc_cluster = sh.ids.w & 0xFFFFFFu;

        if ((uChannelMask & 1u) != 0u) {
            vec3 col;
            if (sh.extra2.z > 0.5) {
                SampledSegGPU ssg = sampled_segs[best_seg];
                col = mix(ssg.c0.xyz, ssg.c1.xyz, best_u);
            } else {
                float t2 = clamp(best_along * 2.0, 0.0, 1.0);
                float t3 = clamp(best_along * 2.0 - 1.0, 0.0, 1.0);
                col = (best_along <= 0.5)
                    ? mix(sh.cr_rough.xyz, sh.cm_op.xyz, t2)
                    : mix(sh.cm_op.xyz, sh.ct_depth.xyz, t3);
                float phase = sh.extra1.x;
                if (uPattern == 1) {
                    float wave = sin(best_along * 6.28318530718 * uBandCount + phase * 6.28318530718);
                    float band = 0.5 + 0.5 * safe_tanh(wave * 4.0);
                    col *= (1.0 - uBandStrength * 0.68 * (1.0 - band));
                } else if (uPattern == 2) {
                    float wave = sin(best_along * 6.28318530718 * uBandCount + phase * 6.28318530718);
                    float dark = clamp(0.5 + 0.5 * wave, 0.0, 1.0);
                    col *= (1.0 - uBandStrength * 0.8 * dark);
                } else if (uPattern == 3) {
                    float freck = sin((best_along * 101.0 + phase * 19.0) * 3.3) * sin((best_along * 58.0 + best_across * 3.1) * 5.1);
                    float marks = clamp((freck - 0.38) * 2.9, 0.0, 1.0);
                    col *= (1.0 - uSpeckle * 0.62 * marks);
                } else if (uPattern == 4) {
                    col *= (0.76 + 0.24 * best_along);
                }
            }
            col *= (1.0 - 0.055 * clamp(best_across, -1.0, 1.0));
            col = clamp(col, 0.0, 1.0);
            acc_color = col * op_a + acc_color * over;
        }
        if ((uChannelMask & (1u << 2u)) != 0u) {
            float lat = clamp(best_across, -0.94, 0.94) * uRoundness;
            vec3 nrm = vec3(-best_ty * lat, best_tx * lat, sqrt(max(0.03, 1.0 - lat * lat)));
            acc_normal = nrm * op_a + acc_normal * over;
        }
        if ((uChannelMask & (1u << 3u)) != 0u) {
            acc_flow = vec3(best_tx, best_ty, 0.0) * op_a + acc_flow * over;
        }
        if ((uChannelMask & (1u << 4u)) != 0u) {
            acc_depth = sh.ct_depth.w * op_a + acc_depth * over;
        }
        if (need_ao) {
            int zbin = clamp(int(sh.ct_depth.w * 8.0), 0, 7);
            float optical = 0.0;
            for (int z = zbin + 1; z < 8; ++z) {
                optical += ao_buckets[z] * max(0.0, (float(z) + 0.5) / 8.0 - sh.ct_depth.w);
            }
            float ao_s = exp(-0.45 * optical);
            acc_ao = ao_s * op_a + acc_ao * over;
        }
        if ((uChannelMask & (1u << 8u)) != 0u) acc_rough = sh.cr_rough.w * op_a + acc_rough * over;
        if ((uChannelMask & (1u << 9u)) != 0u) {
            vec3 mk = vec3(1.0 - best_along, 4.0 * best_along * (1.0 - best_along), best_along);
            acc_rgbmask = mk * op_a + acc_rgbmask * over;
        }
        if ((uChannelMask & (1u << 10u)) != 0u) acc_spec = sh.extra1.y * op_a + acc_spec * over;
        if ((uChannelMask & (1u << 11u)) != 0u) acc_aniso = sh.extra1.z * op_a + acc_aniso * over;
        if ((uChannelMask & (1u << 12u)) != 0u) acc_trans = sh.extra1.w * op_a + acc_trans * over;
        if ((uChannelMask & (1u << 13u)) != 0u) acc_scat = sh.extra2.x * op_a + acc_scat * over;
        if ((uChannelMask & (1u << 14u)) != 0u) acc_irid = sh.extra2.y * op_a + acc_irid * over;

        weight = op_a + weight * over;
    }

    uint npix = uint(uWidth) * uint(uHeight);
    uint pidx = py * uint(uWidth) + px;
    bool empty = (weight <= 1e-6);
    float inv = empty ? 0.0 : (1.0 / weight);

    if (uChannelSlots[0] >= 0) {
        vec3 cv = empty ? vec3(0.0) : (acc_color * inv);
        out_pixels[uint(uChannelSlots[0]) * npix + pidx] = pack_byte4(cv.r, cv.g, cv.b, weight);
    }
    if (uChannelSlots[1] >= 0) {
        out_pixels[uint(uChannelSlots[1]) * npix + pidx] = pack_byte4(weight, weight, weight, 1.0);
    }
    if (uChannelSlots[2] >= 0) {
        vec3 nv = empty ? vec3(0.0, 0.0, 1.0) : (acc_normal * inv) / max(length(acc_normal * inv), 1e-8);
        nv = nv * 0.5 + 0.5;
        out_pixels[uint(uChannelSlots[2]) * npix + pidx] = pack_byte4(nv.x, nv.y, nv.z, 1.0);
    }
    if (uChannelSlots[3] >= 0) {
        vec3 fv = empty ? vec3(0.0) : (acc_flow * inv) / max(length(acc_flow * inv), 1e-8);
        fv = fv * 0.5 + 0.5;
        out_pixels[uint(uChannelSlots[3]) * npix + pidx] = pack_byte4(fv.x, fv.y, fv.z, 1.0);
    }
    if (uChannelSlots[4] >= 0) {
        float dv = empty ? 0.0 : (acc_depth * inv);
        out_pixels[uint(uChannelSlots[4]) * npix + pidx] = pack_byte4(dv, dv, dv, 1.0);
    }
    if (uChannelSlots[5] >= 0) {
        float av = empty ? 1.0 : (acc_ao * inv);
        out_pixels[uint(uChannelSlots[5]) * npix + pidx] = pack_byte4(av, av, av, 1.0);
    }
    if (uChannelSlots[6] >= 0) {
        out_pixels[uint(uChannelSlots[6]) * npix + pidx] = pack_u24_rgb(acc_id);
    }
    if (uChannelSlots[7] >= 0) {
        out_pixels[uint(uChannelSlots[7]) * npix + pidx] = pack_u24_rgb(acc_cluster);
    }
    if (uChannelSlots[8] >= 0) {
        float rv = empty ? uDefaults0.x : (acc_rough * inv);
        out_pixels[uint(uChannelSlots[8]) * npix + pidx] = pack_byte4(rv, rv, rv, 1.0);
    }
    if (uChannelSlots[9] >= 0) {
        vec3 mv = empty ? vec3(0.0) : (acc_rgbmask * inv);
        out_pixels[uint(uChannelSlots[9]) * npix + pidx] = pack_byte4(mv.x, mv.y, mv.z, 1.0);
    }
    if (uChannelSlots[10] >= 0) {
        float v = empty ? uDefaults0.y : (acc_spec * inv);
        out_pixels[uint(uChannelSlots[10]) * npix + pidx] = pack_byte4(v, v, v, 1.0);
    }
    if (uChannelSlots[11] >= 0) {
        float v = empty ? uDefaults0.z : (acc_aniso * inv);
        out_pixels[uint(uChannelSlots[11]) * npix + pidx] = pack_byte4(v, v, v, 1.0);
    }
    if (uChannelSlots[12] >= 0) {
        float v = empty ? uDefaults0.w : (acc_trans * inv);
        out_pixels[uint(uChannelSlots[12]) * npix + pidx] = pack_byte4(v, v, v, 1.0);
    }
    if (uChannelSlots[13] >= 0) {
        float v = empty ? uDefaults1.x : (acc_scat * inv);
        out_pixels[uint(uChannelSlots[13]) * npix + pidx] = pack_byte4(v, v, v, 1.0);
    }
    if (uChannelSlots[14] >= 0) {
        float v = empty ? uDefaults1.y : (acc_irid * inv);
        out_pixels[uint(uChannelSlots[14]) * npix + pidx] = pack_byte4(v, v, v, 1.0);
    }
}
"""


def _default_channel_clear_uint32(channel: str, settings) -> int:
    if channel == 'color':
        return 0
    if channel == 'normal':
        return 128 | (128 << 8) | (255 << 16) | (255 << 24)
    if channel == 'flow':
        return 128 | (128 << 8) | (128 << 16) | (255 << 24)
    if channel in ('id', 'cluster_id', 'rgb_mask'):
        return 255 << 24
    val = 1.0 if channel == 'ao' else (0.0 if channel == 'alpha' else getattr(settings, channel, 0.0))
    byte = max(0, min(255, int(round(float(val) * 255.0))))
    if channel == 'alpha':
        return 0 | (0 << 8) | (0 << 16) | (255 << 24)
    return byte | (byte << 8) | (byte << 16) | (255 << 24)


def _pack_gpu_geometry(batch, bins_data, size: tuple[int, int], antialias: float):
    w, h = int(size[0]), int(size[1])
    n = batch.count
    offsets = batch.offsets
    pts = batch.points
    rad = batch.radii
    t_arr = batch.t

    if batch.uniform_detail >= 2:
        d = batch.uniform_detail
        n_segs_per = d - 1
        pts_nd = pts.reshape(n, d, 2)
        rad_nd = rad.reshape(n, d)
        t_nd = t_arr.reshape(n, d)
        a_pts = pts_nd[:, :-1, :].reshape(-1, 2)
        b_pts = pts_nd[:, 1:, :].reshape(-1, 2)
        r0 = rad_nd[:, :-1].reshape(-1)
        r1 = rad_nd[:, 1:].reshape(-1)
        t0 = t_nd[:, :-1].reshape(-1)
        t1 = t_nd[:, 1:].reshape(-1)
        seg_start = np.arange(0, n * n_segs_per, n_segs_per, dtype=np.uint32)
        seg_count = np.full(n, n_segs_per, dtype=np.uint32)
        seg_counts_i = np.full(n, n_segs_per, dtype=np.int32)
        end_mask = None
        if batch.sampled_colors is not None:
            sc_nd = batch.sampled_colors.reshape(n, d, 3)
            sc0 = sc_nd[:, :-1, :].reshape(-1, 3)
            sc1 = sc_nd[:, 1:, :].reshape(-1, 3)
        else:
            sc0 = sc1 = None
    else:
        lengths = np.diff(offsets)
        seg_counts_i = np.maximum(0, lengths - 1).astype(np.int32)
        seg_start = np.empty(n, dtype=np.uint32)
        if n > 0:
            seg_start[0] = 0
            if n > 1:
                np.cumsum(seg_counts_i[:-1], out=seg_start[1:])
        seg_count = seg_counts_i.astype(np.uint32)
        total_v = len(pts)
        valid_pt = np.ones(max(0, total_v - 1), dtype=bool)
        if n > 1 and total_v > 1:
            cross = offsets[1:-1]
            cross = cross[(cross > 0) & (cross < total_v)] - 1
            valid_pt[cross] = False
        a_pts = pts[:-1][valid_pt]
        b_pts = pts[1:][valid_pt]
        r0 = rad[:-1][valid_pt]
        r1 = rad[1:][valid_pt]
        t0 = t_arr[:-1][valid_pt]
        t1 = t_arr[1:][valid_pt]
        end_mask = valid_pt
        if batch.sampled_colors is not None:
            sc0 = batch.sampled_colors[:-1][valid_pt]
            sc1 = batch.sampled_colors[1:][valid_pt]
        else:
            sc0 = sc1 = None

    total_segs = len(a_pts)
    rad_scale = w / 512.0
    segs_arr = np.empty(total_segs, dtype=SEG_DTYPE)
    if total_segs > 0:
        segs_arr['ab'][:, 0] = a_pts[:, 0] * w
        segs_arr['ab'][:, 1] = a_pts[:, 1] * h
        segs_arr['ab'][:, 2] = b_pts[:, 0] * w
        segs_arr['ab'][:, 3] = b_pts[:, 1] * h
        segs_arr['rt'][:, 0] = r0 * rad_scale
        segs_arr['rt'][:, 1] = r1 * rad_scale
        segs_arr['rt'][:, 2] = t0
        segs_arr['rt'][:, 3] = t1

    sampled_arr = None
    if sc0 is not None and total_segs > 0:
        sampled_arr = np.zeros(total_segs, dtype=SAMPLED_SEG_DTYPE)
        sampled_arr['c0'][:, :3] = sc0
        sampled_arr['c1'][:, :3] = sc1

    halo = max(0.5, AO_RADIUS * w / 512.0)
    reach = max(halo, 0.5 * max(0.3, float(antialias))) + 1.0
    bboxes = np.empty((n, 4), dtype=np.float32)
    _, _, boxes = bins_data
    if boxes and len(boxes) == n:
        boxes_np = np.asarray(boxes, dtype=np.float32)
        bboxes[:, 0] = boxes_np[:, 0] - reach
        bboxes[:, 1] = boxes_np[:, 1] - reach
        bboxes[:, 2] = boxes_np[:, 2] + reach
        bboxes[:, 3] = boxes_np[:, 3] + reach
    else:
        bboxes[:, 0] = 0.0
        bboxes[:, 1] = 0.0
        bboxes[:, 2] = float(w)
        bboxes[:, 3] = float(h)

    bins_dict = bins_data[0]
    sorted_items = sorted(bins_dict.items())
    num_blocks = len(sorted_items)
    blocks_arr = np.empty((num_blocks, 4), dtype=np.uint32)
    total_bin_indices = sum(len(idxs) for _, idxs in sorted_items)
    bin_indices_arr = np.empty(total_bin_indices, dtype=np.uint32)
    cursor = 0
    for bi, ((bx, by), idxs) in enumerate(sorted_items):
        cnt = len(idxs)
        blocks_arr[bi, 0] = bx
        blocks_arr[bi, 1] = by
        blocks_arr[bi, 2] = cursor
        blocks_arr[bi, 3] = cnt
        bin_indices_arr[cursor:cursor + cnt] = idxs
        cursor += cnt

    return seg_start, seg_count, bboxes, segs_arr, sampled_arr, blocks_arr, bin_indices_arr


def _pack_gpu_strands(batch, seg_start, seg_count, bboxes) -> np.ndarray:
    n = batch.count
    arr = np.zeros(n, dtype=STRAND_DTYPE)
    if n == 0:
        return arr
    arr['bbox'] = bboxes
    arr['cr_rough'][:, :3] = batch.color_root
    arr['cr_rough'][:, 3] = batch.roughness
    arr['cm_op'][:, :3] = batch.color_mid
    arr['cm_op'][:, 3] = batch.opacity
    arr['ct_depth'][:, :3] = batch.color_tip
    arr['ct_depth'][:, 3] = batch.depth
    arr['extra1'][:, 0] = batch.pattern_phase
    arr['extra1'][:, 1] = batch.specular
    arr['extra1'][:, 2] = batch.anisotropy
    arr['extra1'][:, 3] = batch.transmission
    arr['extra2'][:, 0] = batch.scatter
    arr['extra2'][:, 1] = batch.iridescence
    if batch.has_sampled is not None:
        arr['extra2'][:, 2] = batch.has_sampled.astype(np.float32)
    arr['ids'][:, 0] = seg_start
    arr['ids'][:, 1] = seg_count
    arr['ids'][:, 2] = batch.numeric_id.astype(np.uint32)
    arr['ids'][:, 3] = batch.cluster_id.astype(np.uint32)
    return arr


class _GPUBakeWorker:
    """Persistent offscreen Win32 WGL GL 4.3+ compute shader execution thread."""

    def __init__(self):
        self._queue: queue.Queue = queue.Queue()
        self._ready = threading.Event()
        self._available = False
        self._error: str | None = None
        self.renderer: str = ''
        self.version: str = ''
        self._thread = threading.Thread(target=self._run, name='fsd-gpu-bake', daemon=True)
        self._thread.start()
        self._ready.wait(timeout=10.0)
        atexit.register(self.close)

    def _run(self):
        hwnd = None
        ctx = None
        prog = None
        ssbos = None
        try:
            if sys.platform != 'win32':
                raise RuntimeError('Offscreen WGL compute baker requires Windows')
            user = C.WinDLL('user32', use_last_error=True)
            user.CreateWindowExW.restype = C.c_void_p
            user.CreateWindowExW.argtypes = [
                C.c_uint32, C.c_wchar_p, C.c_wchar_p, C.c_uint32,
                C.c_int, C.c_int, C.c_int, C.c_int,
                C.c_void_p, C.c_void_p, C.c_void_p, C.c_void_p,
            ]
            user.DestroyWindow.argtypes = [C.c_void_p]
            user.DestroyWindow.restype = C.c_int

            from ..rendercore.context import WGLContext
            from ..rendercore.glapi import GL

            hwnd = user.CreateWindowExW(
                0, 'STATIC', 'fsd_gpu_bake', 0x80000000 | 0x08000000,
                0, 0, 16, 16, None, None, None, None,
            )
            if not hwnd:
                raise RuntimeError('CreateWindowExW failed for GPU bake worker')
            ctx = WGLContext(hwnd, 16, 16)
            gl = GL(ctx)
            self.version = gl.version
            self.renderer = gl.renderer
            match = re.search(r'(\d+)\.(\d+)', self.version)
            if not match or tuple(map(int, match.groups())) < (4, 3):
                raise RuntimeError(f'Compute bake requires OpenGL 4.3+, found {self.version}')

            conv = C.WINFUNCTYPE
            extra_sigs = {
                'glDispatchCompute': (None, [C.c_uint, C.c_uint, C.c_uint]),
                'glMemoryBarrier': (None, [C.c_uint]),
                'glBindBufferBase': (None, [C.c_uint, C.c_uint, C.c_uint]),
                'glGetBufferSubData': (None, [C.c_uint, C.c_ssize_t, C.c_ssize_t, C.c_void_p]),
                'glClearBufferSubData': (None, [C.c_uint, C.c_uint, C.c_ssize_t, C.c_ssize_t,
                                                C.c_uint, C.c_uint, C.c_void_p]),
                'glUniform1ui': (None, [C.c_int, C.c_uint]),
                'glUniform4f': (None, [C.c_int, C.c_float, C.c_float, C.c_float, C.c_float]),
            }
            fns = {}
            for name, (ret, args) in extra_sigs.items():
                addr = ctx.get_proc(name)
                if not addr:
                    raise RuntimeError(f'Missing OpenGL 4.3 symbol: {name}')
                fns[name] = conv(ret, *args)(addr)

            sh = gl.glCreateShader(GL_COMPUTE_SHADER)
            src_b = COMPUTE_SOURCE.encode('utf-8')
            ptr = C.c_char_p(src_b)
            length = C.c_int(len(src_b))
            gl.glShaderSource(sh, 1, C.byref(ptr), C.byref(length))
            gl.glCompileShader(sh)
            ok = C.c_int()
            gl.glGetShaderiv(sh, GL_COMPILE_STATUS, C.byref(ok))
            if not ok.value:
                log = C.create_string_buffer(8192)
                gl.glGetShaderInfoLog(sh, 8192, None, log)
                gl.glDeleteShader(sh)
                raise RuntimeError('Compute GLSL compile error: ' + log.value.decode(errors='replace'))

            prog = gl.glCreateProgram()
            gl.glAttachShader(prog, sh)
            gl.glLinkProgram(prog)
            gl.glGetProgramiv(prog, GL_LINK_STATUS, C.byref(ok))
            gl.glDeleteShader(sh)
            if not ok.value:
                log = C.create_string_buffer(8192)
                gl.glGetProgramInfoLog(prog, 8192, None, log)
                gl.glDeleteProgram(prog)
                prog = None
                raise RuntimeError('Compute GLSL link error: ' + log.value.decode(errors='replace'))

            locs = {
                name: gl.glGetUniformLocation(prog, name.encode('ascii'))
                for name in (
                    'uWidth', 'uHeight', 'uBlockBase', 'uBlockCount', 'uChannelMask',
                    'uAntialias', 'uHalo', 'uRoundness', 'uPattern',
                    'uBandCount', 'uBandStrength', 'uSpeckle', 'uDefaults0', 'uDefaults1',
                )
            }
            slot_locs = [
                gl.glGetUniformLocation(prog, f'uChannelSlots[{i}]'.encode('ascii'))
                for i in range(len(ALL_BAKE_CHANNELS))
            ]

            ssbo_arr = (C.c_uint * 6)()
            gl.glGenBuffers(6, ssbo_arr)
            ssbos = [int(ssbo_arr[i]) for i in range(6)]
            capacities = [0] * 6
            last_geom_token = None
            cached_geom = None

            self._available = True
            self._ready.set()

            def ensure_upload(slot: int, arr: np.ndarray | None, usage=GL_DYNAMIC_DRAW):
                buf = ssbos[slot]
                gl.glBindBuffer(GL_SHADER_STORAGE_BUFFER, buf)
                nbytes = int(arr.nbytes) if (arr is not None and arr.nbytes > 0) else 32
                if nbytes > capacities[slot]:
                    cap = max(nbytes, 4096)
                    if arr is not None and arr.nbytes > 0:
                        if cap == nbytes:
                            gl.glBufferData(GL_SHADER_STORAGE_BUFFER, cap, arr.ctypes.data, usage)
                        else:
                            gl.glBufferData(GL_SHADER_STORAGE_BUFFER, cap, None, usage)
                            gl.glBufferSubData(GL_SHADER_STORAGE_BUFFER, 0, nbytes, arr.ctypes.data)
                    else:
                        gl.glBufferData(GL_SHADER_STORAGE_BUFFER, cap, None, usage)
                    capacities[slot] = cap
                elif arr is not None and arr.nbytes > 0:
                    gl.glBufferSubData(GL_SHADER_STORAGE_BUFFER, 0, nbytes, arr.ctypes.data)
                fns['glBindBufferBase'](GL_SHADER_STORAGE_BUFFER, slot, buf)

            while True:
                item = self._queue.get()
                if item is None:
                    break
                job, reply_q = item
                try:
                    batch, bins_data, geom_token, size, channels, settings, cancel = job
                    if cancel():
                        raise RuntimeError('Render cancelled')

                    if geom_token != last_geom_token or cached_geom is None:
                        cached_geom = _pack_gpu_geometry(batch, bins_data, size, settings.antialias)
                        seg_start, seg_count, bboxes, segs_arr, sampled_arr, blocks_arr, bin_indices_arr = cached_geom
                        ensure_upload(1, segs_arr, GL_STATIC_DRAW)
                        ensure_upload(2, sampled_arr, GL_STATIC_DRAW)
                        ensure_upload(3, blocks_arr, GL_STATIC_DRAW)
                        ensure_upload(4, bin_indices_arr, GL_STATIC_DRAW)
                        last_geom_token = geom_token
                    else:
                        seg_start, seg_count, bboxes, segs_arr, sampled_arr, blocks_arr, bin_indices_arr = cached_geom
                        for slot_i in (1, 2, 3, 4):
                            fns['glBindBufferBase'](GL_SHADER_STORAGE_BUFFER, slot_i, ssbos[slot_i])

                    strand_arr = _pack_gpu_strands(batch, seg_start, seg_count, bboxes)
                    ensure_upload(0, strand_arr, GL_DYNAMIC_DRAW)

                    w, h = int(size[0]), int(size[1])
                    npix = w * h
                    num_ch = len(channels)
                    out_bytes = num_ch * npix * 4
                    if out_bytes > 512 * 1024 * 1024:
                        reply_q.put((None, None))
                        continue

                    gl.glBindBuffer(GL_SHADER_STORAGE_BUFFER, ssbos[5])
                    if out_bytes > capacities[5]:
                        cap = out_bytes
                        gl.glBufferData(GL_SHADER_STORAGE_BUFFER, cap, None, GL_DYNAMIC_DRAW)
                        capacities[5] = cap
                    fns['glBindBufferBase'](GL_SHADER_STORAGE_BUFFER, 5, ssbos[5])

                    slot_map = [-1] * len(ALL_BAKE_CHANNELS)
                    mask = 0
                    clear_val = C.c_uint32()
                    for slot_idx, ch in enumerate(channels):
                        bit_idx = CHANNEL_INDEX[ch]
                        slot_map[bit_idx] = slot_idx
                        mask |= (1 << bit_idx)
                        clear_val.value = _default_channel_clear_uint32(ch, settings)
                        fns['glClearBufferSubData'](
                            GL_SHADER_STORAGE_BUFFER, GL_R32UI,
                            slot_idx * npix * 4, npix * 4,
                            GL_RED_INTEGER, GL_UNSIGNED_INT, C.byref(clear_val),
                        )

                    num_blocks = len(blocks_arr)
                    if num_blocks > 0:
                        fns['glMemoryBarrier'](GL_BUFFER_UPDATE_BARRIER_BIT)
                        gl.glUseProgram(prog)
                        gl.glUniform1i(locs['uWidth'], w)
                        gl.glUniform1i(locs['uHeight'], h)
                        loc_mask = locs['uChannelMask']
                        if loc_mask >= 0:
                            fns['glUniform1ui'](loc_mask, C.c_uint(mask))
                        gl.glUniform1f(locs['uAntialias'], float(settings.antialias))
                        gl.glUniform1f(locs['uHalo'], max(0.5, float(AO_RADIUS * w / 512.0)))
                        gl.glUniform1f(locs['uRoundness'], float(settings.fiber_roundness))
                        gl.glUniform1i(locs['uPattern'], PATTERN_MAP.get(settings.pattern, 0))
                        gl.glUniform1f(locs['uBandCount'], float(settings.band_count))
                        gl.glUniform1f(locs['uBandStrength'], float(settings.band_strength))
                        gl.glUniform1f(locs['uSpeckle'], float(settings.speckle))
                        loc_d0 = locs['uDefaults0']
                        loc_d1 = locs['uDefaults1']
                        if loc_d0 >= 0:
                            fns['glUniform4f'](loc_d0, float(settings.roughness), float(settings.specular),
                                               float(settings.anisotropy), float(settings.transmission))
                        if loc_d1 >= 0:
                            fns['glUniform4f'](loc_d1, float(settings.scatter), float(settings.iridescence), 0.0, 0.0)
                        for idx, s_loc in enumerate(slot_locs):
                            if s_loc >= 0:
                                gl.glUniform1i(s_loc, slot_map[idx])

                        # Chunk blocks at 8192 per dispatch so num_workgroups <= 32768 < 65535 limit
                        base = 0
                        while base < num_blocks:
                            if cancel():
                                raise RuntimeError('Render cancelled')
                            chunk = min(8192, num_blocks - base)
                            gl.glUniform1i(locs['uBlockBase'], base)
                            gl.glUniform1i(locs['uBlockCount'], chunk)
                            fns['glDispatchCompute'](chunk * 4, 1, 1)
                            base += chunk
                        fns['glMemoryBarrier'](GL_SHADER_STORAGE_BARRIER_BIT | GL_BUFFER_UPDATE_BARRIER_BIT)

                    if cancel():
                        raise RuntimeError('Render cancelled')

                    raw = np.empty((num_ch, h, w, 4), dtype=np.uint8)
                    gl.glBindBuffer(GL_SHADER_STORAGE_BUFFER, ssbos[5])
                    fns['glGetBufferSubData'](GL_SHADER_STORAGE_BUFFER, 0, out_bytes, raw.ctypes.data)
                    gl.glFinish()

                    images = {}
                    for slot_idx, ch in enumerate(channels):
                        plane = raw[slot_idx]
                        if ch == 'color':
                            images[ch] = Image.fromarray(np.ascontiguousarray(plane), 'RGBA')
                        elif ch in ('normal', 'flow', 'id', 'cluster_id', 'rgb_mask'):
                            images[ch] = Image.fromarray(np.ascontiguousarray(plane[:, :, :3]), 'RGB')
                        else:
                            images[ch] = Image.fromarray(np.ascontiguousarray(plane[:, :, 0]), 'L')
                    reply_q.put((images, None))
                except Exception as exc:
                    reply_q.put((None, exc))
        except Exception as exc:
            self._error = str(exc)
            self._available = False
            self._ready.set()
        finally:
            try:
                if ctx is not None:
                    ctx.activate()
                    if ssbos is not None:
                        from ..rendercore.glapi import GL
                        pass
            except Exception:
                pass
            if prog is not None and ctx is not None:
                try:
                    del_p = ctx.get_proc('glDeleteProgram')
                    if del_p:
                        C.WINFUNCTYPE(None, C.c_uint)(del_p)(prog)
                except Exception:
                    pass
            if ssbos is not None and ctx is not None:
                try:
                    del_b = ctx.get_proc('glDeleteBuffers')
                    if del_b:
                        arr = (C.c_uint * len(ssbos))(*ssbos)
                        C.WINFUNCTYPE(None, C.c_int, C.POINTER(C.c_uint))(del_b)(len(ssbos), arr)
                except Exception:
                    pass
            if ctx is not None:
                try:
                    ctx.close()
                except Exception:
                    pass
            if hwnd is not None:
                try:
                    C.WinDLL('user32').DestroyWindow(hwnd)
                except Exception:
                    pass

    @property
    def available(self) -> bool:
        return self._available

    def submit(self, job):
        if not self._available:
            return None
        reply_q: queue.Queue = queue.Queue(maxsize=1)
        self._queue.put((job, reply_q))
        images, err = reply_q.get()
        if isinstance(err, RuntimeError) and 'cancelled' in str(err).lower():
            raise err
        return images

    def close(self):
        if self._available:
            self._available = False
            try:
                self._queue.put(None)
            except Exception:
                pass


_WORKER: _GPUBakeWorker | None = None
_WORKER_LOCK = threading.Lock()


def _get_worker() -> _GPUBakeWorker | None:
    global _WORKER
    if sys.platform != 'win32':
        return None
    if _WORKER is None:
        with _WORKER_LOCK:
            if _WORKER is None:
                _WORKER = _GPUBakeWorker()
    return _WORKER if _WORKER.available else None


def gpu_backend_info() -> dict[str, object]:
    worker = _get_worker()
    if worker is None:
        return {'available': False, 'renderer': '', 'version': ''}
    return {'available': True, 'renderer': worker.renderer, 'version': worker.version}


def try_gpu_bake(strands, bins_data, geom_token, size, channels, settings, cancel):
    """Run GL 4.30 compute bake when available and free of custom attributes."""
    if not channels:
        return {}
    batch = getattr(strands, 'batch', None)
    if batch is None or batch.has_attributes:
        return None
    if any(ch not in CHANNEL_INDEX for ch in channels):
        return None
    worker = _get_worker()
    if worker is None:
        return None
    return worker.submit((batch, bins_data, geom_token, size, list(channels), settings, cancel))
