"""Independent channel compositing from shared geometric samples.

Painter order follows stable truth order for backward compatibility. Normals
and flow are normalized after compositing; continuous properties are visible
coverage-weighted; ID is the top contributing strand at coverage > .26.
AO is a finite-radius, depth-weighted geometric proximity approximation, not
blurred alpha, and is deliberately labelled 2.5D rather than physical ray AO.
"""
import hashlib
import struct
import numpy as np
from PIL import Image
from .samples import BLOCK, EMPTY_PATCH, SamplePatch, grid, sample_patch
from .dependencies import CHANNEL_SOURCES
from .gpu_bake import try_gpu_bake

VECTOR = {'color': 3, 'normal': 3, 'flow': 3, 'rgb_mask': 3,'material_mask':3}
IDENTITY = {'id', 'cluster_id', 'material_id'}
SCALAR = {'alpha', 'depth', 'ao', 'roughness', 'specular', 'anisotropy',
          'transmission', 'scatter', 'iridescence'}


def empty_map(channel, size, settings):
    if channel == 'color':
        return Image.new('RGBA', size)
    if channel in IDENTITY or channel in VECTOR:
        return Image.new('RGB', size, (128, 128, 255) if channel == 'normal'
                         else (128, 128, 128) if channel == 'flow' else (0, 0, 0))
    value = 1 if channel == 'ao' else getattr(settings, channel, 0) if channel != 'alpha' else 0
    return Image.new('L', size, round(value * 255))


def encode(channel, acc, weight, settings):
    inv = np.divide(1, weight, out=np.zeros_like(weight), where=weight > 1e-6)
    if channel in IDENTITY:
        return Image.fromarray(np.stack([(acc >> 16) & 255, (acc >> 8) & 255, acc & 255], -1).astype('uint8'), 'RGB')
    if channel == 'alpha':
        value = weight
    else:
        value = acc * (inv[..., None] if acc.ndim == 3 else inv)
    if channel in ('normal', 'flow'):
        value /= np.maximum(np.linalg.norm(value, axis=-1, keepdims=True), 1e-8)
        value[weight <= 1e-6] = [0, 0, 1] if channel == 'normal' else [0, 0, 0]
        value = value * .5 + .5
    if channel == 'ao':
        value[weight <= 1e-6] = 1
    elif channel in ('roughness', 'specular', 'anisotropy', 'transmission', 'scatter', 'iridescence'):
        value[weight <= 1e-6] = getattr(settings, channel)
    data = np.rint(np.clip(value, 0, 1) * 255).astype('uint8')
    if channel == 'color':
        data = np.dstack((data, np.rint(weight * 255).astype('uint8')))
    return Image.fromarray(data)


def _shade_subrect(strand, along: np.ndarray, across: np.ndarray, s):
    from ..raster import _shade_strand
    return _shade_strand(strand, along, across, s)


def block_composite(strands, indices, fetch_sample, shape, channels, settings, cancel):
    weight = np.zeros(shape, np.float32)
    accum = {c: np.zeros(shape + ((VECTOR[c],) if c in VECTOR else ()),
                         np.uint32 if c in IDENTITY else np.float32) for c in channels}
    need_ao = 'ao' in channels
    exact_ao=getattr(settings,'ao_mode','proximity')=='geometry'
    geometry_proximity={}
    depth_low=min(0.,min((float(np.min(s.depth_profile)) if s.depth_profile is not None else s.depth for s in strands),default=0.)) if exact_ao else 0.
    depth_high=max(1.,max((float(np.max(s.depth_profile)) if s.depth_profile is not None else s.depth for s in strands),default=1.)) if exact_ao else 1.
    depth_span=depth_high-depth_low
    buckets = np.zeros((8, *shape), np.float32) if need_ao else None
    patches = [None] * len(indices)

    if need_ao:
        for k, i in enumerate(indices):
            if cancel():
                raise RuntimeError('Render cancelled')
            strand = strands[i]
            sample_obj = fetch_sample(i)
            patches[k] = sample_obj
            if sample_obj is EMPTY_PATCH:
                continue
            zbin = int(np.clip(strand.depth * 8, 0, 7))
            if isinstance(sample_obj, SamplePatch):
                near_a = sample_obj.near_along.astype(np.float32)
                op_near = strand.attribute('opacity', near_a)
                proximity=sample_obj.proximity.astype(np.float32)*op_near
                slp=(slice(sample_obj.y0,sample_obj.y1),slice(sample_obj.x0,sample_obj.x1))
                if strand.depth_profile is None:buckets[zbin][slp]+=proximity
                else:
                    zbins=np.clip(np.asarray(strand.depth_at(near_a))*8,0,7).astype(int)
                    for z in range(8):buckets[z][slp]+=proximity*(zbins==z)
            else:
                buckets[zbin] += sample_obj[5] * strand.attribute('opacity', sample_obj[6])
            if exact_ao:
                proximity=np.zeros(shape,np.float32);depth=np.zeros(shape,np.float32)
                if isinstance(sample_obj,SamplePatch):
                    proximity[slp]=sample_obj.proximity.astype(np.float32)*op_near
                    depth[slp]=strand.depth_at(near_a)
                else:
                    proximity[:]=sample_obj[5]*strand.attribute('opacity',sample_obj[6]);depth[:]=strand.depth_at(sample_obj[6])
                geometry_proximity[i]=(proximity,depth)

    geometry_weights=np.zeros((32,*shape),np.float32) if need_ao and exact_ao else None
    geometry_moments=np.zeros((32,*shape),np.float32) if need_ao and exact_ao else None
    if need_ao and exact_ao:
        for proximity,depth in geometry_proximity.values():
            labels=np.clip(((depth-depth_low)/depth_span*32).astype(int),0,31)
            for z in range(32):
                mass=proximity*(labels==z);geometry_weights[z]+=mass;geometry_moments[z]+=mass*depth

    for k, i in enumerate(indices):
        if k % 16 == 0 and cancel():
            raise RuntimeError('Render cancelled')
        strand = strands[i]
        sample_obj = patches[k] if need_ao else fetch_sample(i)
        if sample_obj is EMPTY_PATCH:
            continue

        if isinstance(sample_obj, SamplePatch):
            if sample_obj.empty_cover:
                continue
            coverage = sample_obj.cover
            along = sample_obj.along
            across = sample_obj.across
            tx = sample_obj.tx
            ty = sample_obj.ty
            sl = (slice(sample_obj.cy0, sample_obj.cy1), slice(sample_obj.cx0, sample_obj.cx1))
        else:
            coverage, along, across, tx, ty, _, _ = sample_obj
            sl = (slice(None), slice(None))

        a = coverage * strand.attribute('opacity', along)
        if not np.any(a):
            continue
        over = 1.0 - a
        sub_shape = a.shape
        for channel in channels:
            if channel == 'alpha':
                continue
            target = accum[channel][sl]
            if channel in IDENTITY:
                number = strand.material_id if channel=='material_id' else strand.cluster_id if channel == 'cluster_id' else strand.numeric_id
                target[a > .26] = number & 0xFFFFFF
                continue
            if channel == 'color':
                source = _shade_subrect(strand, along, across, settings)
            elif channel == 'normal':
                lateral = np.clip(across, -.94, .94) * settings.fiber_roundness
                if strand.depth_profile is None:
                    source = np.stack((-ty * lateral, tx * lateral,np.sqrt(np.maximum(.03, 1-lateral*lateral))),-1)
                else:
                    tangent=np.gradient(strand.positions_3d,axis=0)
                    tangent/=np.maximum(np.linalg.norm(tangent,axis=1,keepdims=True),1e-8)
                    tz=np.interp(along,strand.t,tangent[:,2]);xy=np.sqrt(np.maximum(0,1-tz*tz))
                    side=np.stack((-ty,tx,np.zeros_like(tx)),-1)
                    front=np.stack((-tx*tz,-ty*tz,xy),-1)
                    source=side*lateral[...,None]+front*np.sqrt(np.maximum(.03,1-lateral*lateral))[...,None]
            elif channel == 'flow':
                if strand.depth_profile is None:source=np.stack((tx,ty,np.zeros_like(tx)),-1)
                else:
                    tangent=np.gradient(strand.positions_3d,axis=0)
                    tangent/=np.maximum(np.linalg.norm(tangent,axis=1,keepdims=True),1e-8)
                    source=np.stack([np.interp(along,strand.t,tangent[:,axis]) for axis in range(3)],-1)
            elif channel=='material_mask':
                source=strand.material_mask
            elif channel == 'rgb_mask':
                source = np.stack((1 - along, 4 * along * (1 - along), along), -1)
            elif channel == 'ao':
                local_depth=strand.depth_at(along)
                optical=np.zeros(sub_shape,np.float32)
                for z in range(8):
                    optical+=buckets[z][sl]*np.maximum(0.,(z+.5)/8.-local_depth)*(z>np.clip(np.asarray(local_depth)*8,0,7).astype(int))
                if exact_ao:
                    optical=np.zeros(sub_shape,np.float32)
                    own_proximity,own_depth=geometry_proximity.get(i,(np.zeros(shape,np.float32),np.zeros(shape,np.float32)))
                    own_labels=np.clip(((own_depth[sl]-depth_low)/depth_span*32).astype(int),0,31)
                    for z in range(32):
                        own=own_proximity[sl]*(own_labels==z)
                        mass=np.maximum(0.,geometry_weights[z][sl]-own);moment=geometry_moments[z][sl]-own*own_depth[sl]
                        center=moment/np.maximum(mass,1e-8);radius=np.maximum(0.,np.minimum(.5*depth_span/32.,np.minimum(center-(depth_low+z*depth_span/32.),depth_low+(z+1)*depth_span/32.-center)))
                        gap=center-local_depth
                        tail=np.where(radius<1e-8,np.maximum(0.,gap),np.where(gap>=radius,gap,np.where(gap<=-radius,0.,(radius+gap)**2/np.maximum(4*radius,1e-8))))
                        optical+=mass*tail
                source = np.exp(-.45 * optical)
            elif channel == 'depth':
                source = strand.depth_at(along)
            else:
                source = strand.attribute(channel, along)
            if target.ndim == 3:
                target[:] = source * a[..., None] + target * over[..., None]
            else:
                target[:] = source * a + target * over
        weight[sl] = a + weight[sl] * over
    return {c: encode(c, accum[c], weight, settings) for c in channels}


def _compute_local_sources(strands, sources, settings, cancel):
    """Build compact uint64 hash vectors per source channel without JSON serialization."""
    n = len(strands)
    if not sources or n == 0:
        return {s: np.empty(n, dtype=np.uint64) for s in sources}

    batch = getattr(strands, 'batch', None)
    pat_bytes = f'|{settings.pattern}|{settings.band_count:.6f}|{settings.band_strength:.6f}|{settings.speckle:.6f}'.encode()
    local_u64 = {s: np.empty(n, dtype=np.uint64) for s in sources}

    if batch is not None and not batch.has_attributes and batch.count == n:
        if 'color' in sources:
            c_arr = local_u64['color']
            cr = batch.color_root
            cm = batch.color_mid
            ct = batch.color_tip
            ph = batch.pattern_phase
            if batch.sampled_colors is None:
                # Vectorized binary fold over contiguous float views
                packed = np.empty((n, 10), dtype=np.float32)
                packed[:, 0:3] = cr
                packed[:, 3:6] = cm
                packed[:, 6:9] = ct
                packed[:, 9] = ph
                pat_hash = int.from_bytes(hashlib.blake2b(pat_bytes, digest_size=8).digest(), 'little')
                # Per-strand 8-byte digest over row bytes + pattern tag
                for i in range(n):
                    if i % 512 == 0 and cancel():
                        raise RuntimeError('Render cancelled')
                    c_arr[i] = int.from_bytes(
                        hashlib.blake2b(packed[i].tobytes(), digest_size=8).digest(), 'little'
                    ) ^ pat_hash
            else:
                for i, strand in enumerate(strands):
                    if i % 128 == 0 and cancel():
                        raise RuntimeError('Render cancelled')
                    h = hashlib.blake2b(digest_size=8)
                    h.update(cr[i].tobytes())
                    h.update(cm[i].tobytes())
                    h.update(ct[i].tobytes())
                    h.update(strand.sampled_colors.tobytes())
                    h.update(struct.pack('<f', float(ph[i])))
                    h.update(pat_bytes)
                    c_arr[i] = int.from_bytes(h.digest(), 'little')

        for source in sources:
            if source == 'color':
                continue
            arr = getattr(batch, source)
            # Deterministic uint64 bit pattern from float32 scalar + salt
            salt = int.from_bytes(hashlib.blake2b(source.encode(), digest_size=8).digest(), 'little')
            bits = arr.astype(np.float32, copy=False).view(np.uint32).astype(np.uint64)
            local_u64[source] = (bits * np.uint64(0x9E3779B97F4A7C15)) ^ np.uint64(salt)
        return local_u64

    for i, strand in enumerate(strands):
        if i % 64 == 0 and cancel():
            raise RuntimeError('Render cancelled')
        sid_b = strand.sid.encode()
        if 'color' in sources:
            h = hashlib.blake2b(sid_b, digest_size=8)
            h.update(strand.color_root.tobytes())
            h.update(strand.color_mid.tobytes())
            h.update(strand.color_tip.tobytes())
            if strand.sampled_colors is not None:
                h.update(strand.sampled_colors.tobytes())
            h.update(struct.pack('<f', float(strand.pattern_phase)))
            h.update(pat_bytes)
            local_u64['color'][i] = int.from_bytes(h.digest(), 'little')
        for source in sources:
            if source == 'color':
                continue
            h = hashlib.blake2b(sid_b, digest_size=8)
            h.update(source.encode())
            h.update(struct.pack('<d', float(getattr(strand, source))))
            for name, array in strand.attributes:
                if name == source:
                    h.update(array.tobytes())
            local_u64[source][i] = int.from_bytes(h.digest(), 'little')
    return local_u64


def bake_with_info(strands, bins_data, size, channels, keys, settings, sample_cache, block_cache,
                   cancel, progress=None, *, prefer_gpu: bool = True):
    if int(getattr(settings,'bake_samples',1))>1:
        from ..fiberbake_x.reference import supersample
        return supersample(strands,bins_data,size,channels,keys,settings,sample_cache,block_cache,cancel,progress)
    bins, signatures, _ = bins_data
    sources = {s for c in channels for s in CHANNEL_SOURCES[c]} - {'geometry', 'orientation','occlusion'}
    local_u64 = _compute_local_sources(strands, sources, settings, cancel)

    sig_u64 = np.fromiter((int(s[:16], 16) for s in signatures), dtype=np.uint64, count=len(signatures))
    sampling_b = str(keys['sampling']).encode()
    orient_b = str(keys.get('orientation', '')).encode()
    size_b = struct.pack('<II', int(size[0]), int(size[1]))

    sorted_bins = sorted(bins.items())
    block_versions = {c: {} for c in channels}
    block_meta = []

    for (bx, by), indices in sorted_bins:
        if cancel():
            raise RuntimeError('Render cancelled')
        rect = (bx * BLOCK, by * BLOCK, min(size[0], (bx + 1) * BLOCK), min(size[1], (by + 1) * BLOCK))
        idx_arr = np.asarray(indices, dtype=np.int32)
        hg = hashlib.blake2b(size_b, digest_size=16)
        hg.update(struct.pack('<iiii', *rect))
        hg.update(sampling_b)
        hg.update(sig_u64[idx_arr].tobytes())
        geom_digest = hg.digest()

        versions = {}
        for channel in channels:
            hc = hashlib.blake2b(geom_digest, digest_size=16)
            hc.update(channel.encode())
            for s in CHANNEL_SOURCES[channel]:
                if s == 'geometry':
                    continue
                if s == 'orientation':
                    hc.update(orient_b)
                elif s=='occlusion':hc.update(keys['occlusion'].encode())
                else:
                    hc.update(local_u64[s][idx_arr].tobytes())
            ver = hc.hexdigest()
            versions[channel] = ver
            block_versions[channel][(bx, by)] = ver
        block_meta.append(((bx, by), rect, indices, versions))

    if prefer_gpu:
        import os
        from ..fiberbake_x.service import try_bake
        mode=os.environ.get('FSD_FIBERBAKE_BACKEND','auto').lower()
        gpu_maps=None if mode in ('cpu','legacy-gpu') else try_bake(strands,bins_data,keys,size,channels,settings,cancel,progress)
        backend_name='fiberbake-x-opengl'
        if mode=='legacy-gpu':
            geom_token=(keys.get('geometry'),size,keys.get('sampling'))
            gpu_maps=try_gpu_bake(strands,bins_data,geom_token,size,channels,settings,cancel)
            backend_name='opengl-compute'
        if gpu_maps is not None:
            if progress:progress(1.0)
            return gpu_maps,block_versions,backend_name

    maps = {c: empty_map(c, size, settings) for c in channels}
    total_bins = max(1, len(block_meta))
    sampling_key = keys['sampling']
    for ordinal, ((bx, by), rect, indices, versions) in enumerate(block_meta):
        if cancel():
            raise RuntimeError('Render cancelled')
        missing = []
        for channel in channels:
            cached = block_cache.get(versions[channel])
            if cached is None:
                missing.append(channel)
            else:
                maps[channel].paste(cached, rect[:2])
        if missing:
            bh = rect[3] - rect[1]
            bw = rect[2] - rect[0]

            def fetch_patch(i):
                key = (signatures[i], size, rect, sampling_key)
                data = sample_cache.get(key)
                if data is None:
                    data = sample_patch(strands[i], size, rect, settings.antialias, cancel)
                    sample_cache.put(key, data)
                return data

            result = block_composite(strands, indices, fetch_patch, (bh, bw),
                                     missing, settings, cancel)
            for channel, image in result.items():
                block_cache.put(versions[channel], image)
                maps[channel].paste(image, rect[:2])
        if progress:
            progress((ordinal + 1) / total_bins)
    return maps, block_versions, 'numpy-subrect-cpu'


def bake(strands, bins_data, size, channels, keys, settings, sample_cache, block_cache,
         cancel, progress=None):
    maps, block_versions, _ = bake_with_info(
        strands, bins_data, size, channels, keys, settings,
        sample_cache, block_cache, cancel, progress, prefer_gpu=True,
    )
    return maps, block_versions
