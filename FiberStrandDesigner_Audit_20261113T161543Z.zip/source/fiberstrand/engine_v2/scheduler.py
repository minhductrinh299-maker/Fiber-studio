"""Bounded keyed latest-wins jobs; active preview is ahead of background tiles.

At most one pending job per tile. Superseding a running job signals its token.
Workers never invoke Tk or OpenGL. Publication must also check the token.
"""
from collections import OrderedDict
from collections import deque
from threading import Condition, Event, Thread, current_thread
from time import monotonic


class LatestScheduler:
    def __init__(self, workers=2, pending_limit=64):
        self.condition = Condition()
        self.pending = OrderedDict()
        self.running = {}
        self.limit = pending_limit
        self.closed = False
        self.errors=deque(maxlen=16)
        self.threads = [Thread(target=self._run, daemon=True, name=f'fiber-v2-{i}')
                        for i in range(workers)]
        for thread in self.threads:
            thread.start()

    def submit(self, key, function, priority=0, cancel_running=True):
        token = Event()
        with self.condition:
            if self.closed:
                token.set()
                return token
            previous = self.pending.pop(key, None)
            if previous:
                previous[2].set()
            if cancel_running and key in self.running:
                self.running[key].set()
            while len(self.pending) >= self.limit:
                # Drop the lowest-priority oldest request, never grow unbounded.
                victim = max(self.pending, key=lambda k: self.pending[k][0])
                self.pending.pop(victim)[2].set()
            self.pending[key] = (priority, function, token)
            self.condition.notify_all()
        return token

    def _run(self):
        while True:
            with self.condition:
                while not self.closed and not any(k not in self.running for k in self.pending):
                    self.condition.wait()
                if self.closed:
                    return
                key = min((k for k in self.pending if k not in self.running),
                          key=lambda k: self.pending[k][0])
                _, function, token = self.pending.pop(key)
                self.running[key] = token
            try:
                if not token.is_set():
                    function(token)
            except Exception as error:
                self.errors.append((key,str(error)))
            finally:
                with self.condition:
                    self.running.pop(key, None)
                    self.condition.notify_all()
    def close(self,wait=False,timeout=2.):
        with self.condition:
            self.closed = True
            for _, _, token in self.pending.values():
                token.set()
            for token in self.running.values():
                token.set()
            self.pending.clear()
            self.condition.notify_all()
        if wait:
            deadline=monotonic()+timeout
            for thread in self.threads:
                if thread is not current_thread():thread.join(timeout=max(0.,deadline-monotonic()))

