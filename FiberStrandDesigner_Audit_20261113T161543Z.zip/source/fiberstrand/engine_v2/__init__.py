"""Versioned strand truth, bounded CPU reference bake and interactive GPU path.

No OpenGL calls occur on the evaluation/bake workers. The CPU reference is
intentionally retained independently of the GPU display implementation.
"""

