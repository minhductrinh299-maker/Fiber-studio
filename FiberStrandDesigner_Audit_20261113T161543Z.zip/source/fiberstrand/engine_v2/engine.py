"""CPU reference engine, instrumentation and atomic revision publication."""
from threading import RLock
from time import perf_counter
from .cache import ByteLRU
from .dependencies import source_keys, channel_key, ALL_CHANNELS, dirty_mips
from .truth import build_geometry, apply_material
from .samples import build_bins, BLOCK
from .bake import bake_with_info


class FiberEngine:
    def __init__(self, budget_mb=384):
        budget = int(budget_mb*1024*1024)
        self.geometry = ByteLRU(budget*12//64)
        self.material = ByteLRU(budget*12//64)
        self.bins = ByteLRU(budget*12//64)
        self.samples = ByteLRU(budget*10//64)
        self.blocks = ByteLRU(budget*6//64)
        self.channels = ByteLRU(budget*6//64)
        self.history = ByteLRU(budget*2//64)
        self.graph = ByteLRU(budget*4//64)
        self.locks = [RLock() for _ in range(32)]

    def truth(self, tile, detail=22, cancel=lambda: False, evaluator=None):
        from ..construction.core import GraphEvaluator
        tile.settings.sanitize()
        keys = source_keys(tile, detail)
        geometry = self.geometry.get(keys['geometry'])
        if geometry is None:
            geometry = build_geometry(tile, detail, evaluator or GraphEvaluator(cache=self.graph), cancel)
            self.geometry.put(keys['geometry'], geometry)
        key = tuple(sorted(keys.items()))
        truth = self.material.get(key)
        if truth is None:
            pkey=('pigment',keys['geometry'],keys['color'])
            pigments=self.material.get(pkey)
            truth = apply_material(geometry, tile, cancel, pigments)
            from ..kernel.material_port import apply_colors
            truth=apply_colors(truth,tile)
            from .truth import apply_material_ids
            truth=apply_material_ids(truth,tile)
            if pigments is None:
                self.material.put(pkey,tuple((s.color_root,s.color_mid,s.color_tip) for s in truth))
            self.material.put(key, truth)
        return truth, keys

    def render(self, tile, size=None, detail=22, channels=None, progress=None,
               should_cancel=None, graph_evaluator=None):
        from ..raster import RenderResult
        from ..model import MAP_NAMES, stable_int
        size = tuple(map(int, size or (tile.width, tile.height)))
        if min(size) < 16:
            raise ValueError('Render dimensions too small')
        requested = tuple(channels or MAP_NAMES)
        unknown = set(requested)-set(ALL_CHANNELS)
        if unknown:
            raise ValueError(f'Unknown channels: {sorted(unknown)}')
        cancel = should_cancel or (lambda: False)
        # Same-tile publications are serialized, without locking other tiles/UI.
        lock = self.locks[stable_int(tile.id)%len(self.locks)]
        while not lock.acquire(timeout=.05):
            if cancel():
                raise RuntimeError('Render cancelled')
        try:
            started = perf_counter()
            truth, keys = self.truth(tile, detail, cancel, graph_evaluator)
            truth_end = perf_counter()
            if cancel():
                raise RuntimeError('Render cancelled')
            maps = {}
            missing = []
            versions = {}
            for channel in requested:
                cached = self.channels.get(channel_key(channel, keys, size))
                if cached is None:
                    missing.append(channel)
                else:
                    maps[channel], versions[channel] = cached
            bins_end = truth_end
            backend_used = 'cache-hit'
            if missing:
                import os
                mode=os.environ.get('FSD_FIBERBAKE_BACKEND','auto').lower()
                images=None
                if mode not in ('cpu','legacy-gpu'):
                    from ..fiberbake_x.service import try_bake
                    images=try_bake(truth,None,keys,size,missing,tile.settings,cancel,progress)
                if images is not None:
                    backend_used='fiberbake-x-opengl'
                    block_versions={c:{(x,y):channel_key(c,keys,size) for y in range((size[1]+BLOCK-1)//BLOCK) for x in range((size[0]+BLOCK-1)//BLOCK)} for c in missing}
                    bins_end=truth_end
                else:
                    bkey=(keys['geometry'],size);bins_data=self.bins.get(bkey)
                    if bins_data is None:
                        bins_data=build_bins(truth,size,cancel);self.bins.put(bkey,bins_data)
                    bins_end=perf_counter()
                    images,block_versions,backend_used=bake_with_info(truth,bins_data,size,missing,keys,tile.settings,self.samples,self.blocks,cancel,progress,prefer_gpu=mode=='legacy-gpu')
                maps.update(images)
                versions.update(block_versions)
                if cancel():
                    raise RuntimeError('Render cancelled')
                for channel in missing:
                    self.channels.put(channel_key(channel, keys, size), (maps[channel], versions[channel]))
            previous_record = self.history.get((tile.id, size, requested)) or {}
            previous=previous_record.get('blocks',{})
            dirty = {}
            for channel in requested:
                old = previous.get(channel, {})
                current = versions[channel]
                changed = [b for b in set(old)|set(current) if old.get(b) != current.get(b)]
                dirty[channel] = [(x*BLOCK, y*BLOCK, min(size[0], (x+1)*BLOCK),
                                   min(size[1], (y+1)*BLOCK)) for x, y in sorted(changed)]
                if not previous:
                    dirty[channel] = [(0, 0, *size)]
            if cancel():
                raise RuntimeError('Render cancelled')
            current_channels={c:channel_key(c,keys,size) for c in requested}
            self.history.put((tile.id, size, requested), dict(blocks=versions,channels=current_channels))
            elapsed = perf_counter()
            metadata = dict(engine='FiberBake X / canonical Fiber Engine V2', backend=backend_used,
                revision=tile.revision, source_versions=keys, strand_count=len(truth), resolution=list(size),
                baked_channels=missing, dirty_regions=dirty,
                dirty_mips={c: [dirty_mips(r, size) for r in rects] for c, rects in dirty.items()},
                timings_ms=dict(truth=(truth_end-started)*1000, bins=(bins_end-truth_end)*1000,
                                bake=(elapsed-bins_end)*1000, total=(elapsed-started)*1000),
                caches={name: getattr(self, name).stats() for name in
                        ('geometry', 'material', 'bins', 'samples', 'blocks', 'channels', 'history', 'graph')},
                channel_versions=current_channels,
                base_channel_versions=previous_record.get('channels',{}),
                id_table={str(s.numeric_id):s.sid for s in truth},
                note='Canonical curves with optional depth profiles; stable painter-order attributes; source-geometry finite-radius AO (8-bin preview or 32-moment continuous-depth final approximation), not path-traced multiple scattering')
            if backend_used=='fiberbake-x-opengl':
                from ..fiberbake_x.service import device
                metadata['fiberbake_x']=dict(device(False).backend.last_metrics)
            if progress:
                progress(1)
            return RenderResult(tile.id, tile.revision, *size, maps, list(truth), metadata)
        finally:
            lock.release()


ENGINE = FiberEngine()
