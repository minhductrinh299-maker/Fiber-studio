"""Shared native live-fiber shaders; imported by both Qt and Tk hosts."""
STRIDE_FLOATS = 24

PATTERN_IDS = {'solid': 0, 'banded': 1, 'agouti': 2, 'speckle': 3, 'ombre': 4}

OVERLAY_VERTEX = '''#version 330 core
layout(location=0) in vec2 inPos;
uniform vec2 viewport;
uniform vec2 tileSize;
uniform vec2 pan;
uniform float zoom;
uniform float angle;
void main(){
    vec2 pPx = inPos * tileSize;
    vec2 centered = pPx - 0.5 * tileSize;
    float c = cos(angle), s = sin(angle);
    float fit = min(viewport.x / tileSize.x, viewport.y / tileSize.y) * 0.9 * zoom;
    vec2 screenV = mat2(c, -s, s, c) * centered * fit + pan;
    gl_Position = vec4(screenV.x * 2.0 / viewport.x, -screenV.y * 2.0 / viewport.y, 0.0, 1.0);
}'''

OVERLAY_FRAGMENT = '''#version 330 core
uniform vec4 uColor;
out vec4 outColor;
void main(){
    outColor = uColor;
}'''

VERTEX = '''#version 330 core
layout(location=0) in vec4 segPts;      // ax, ay, bx, by (normalized [0..1])
layout(location=1) in vec4 joinDirs;    // tx_prev, ty_prev, tx_next, ty_next (normalized space)
layout(location=2) in vec4 radT;        // r0, r1, t0, t1
layout(location=3) in vec4 colorRootP;  // root.rgb (or sc0), pattern_phase
layout(location=4) in vec4 colorMidOp;  // mid.rgb, opacity
layout(location=5) in vec4 colorTipM;   // tip.rgb (or sc1), mode (0=ramp+pat, 1=sampled)

uniform vec2 viewport;
uniform vec2 tileSize;
uniform vec2 pan;
uniform float zoom;
uniform float angle;
uniform float uAntialias;

out vec2 vQ;
flat out vec4 vSegPx;      // ax_px, ay_px, bx_px, by_px
flat out vec4 vNormals;    // nA.x, nA.y, nB.x, nB.y (inward join bisectors; zero at ends)
flat out vec4 vRadT;       // r0_px, r1_px, t0, t1
flat out vec4 vColorRootP;
flat out vec4 vColorMidOp;
flat out vec4 vColorTipM;
flat out float vFit;

void main(){
    vec2 aPx = segPts.xy * tileSize;
    vec2 bPx = segPts.zw * tileSize;
    vec2 d = bPx - aPx;
    float len = length(d);
    if (len < 1e-5) {
        gl_Position = vec4(2.0, 2.0, 0.0, 1.0);
        return;
    }
    vec2 dir = d / len;
    vec2 perp = vec2(-dir.y, dir.x);
    float rScale = tileSize.x / 512.0;
    float r0Px = radT.x * rScale;
    float r1Px = radT.y * rScale;
    float fit = min(viewport.x / tileSize.x, viewport.y / tileSize.y) * 0.9 * zoom;
    float edge = max(0.3, uAntialias) * clamp(1.0 / max(fit, 1e-4), 0.25, 4.0);
    float minRad = 0.55 / max(fit, 1e-4);
    float margin = max(max(r0Px, r1Px), minRad) + edge * 0.6 + 0.75;

    int corner = gl_VertexID % 6;
    bool isEnd = (corner == 1 || corner == 2 || corner == 4);
    float side = (corner == 0 || corner == 1 || corner == 5) ? -1.0 : 1.0;
    vec2 q = (isEnd ? (bPx + dir * margin) : (aPx - dir * margin)) + perp * (side * margin);

    vec2 centered = q - 0.5 * tileSize;
    float c = cos(angle), s = sin(angle);
    vec2 screenV = mat2(c, -s, s, c) * centered * fit + pan;
    gl_Position = vec4(screenV.x * 2.0 / viewport.x, -screenV.y * 2.0 / viewport.y, 0.0, 1.0);

    vec2 nA = vec2(0.0);
    if (dot(joinDirs.xy, joinDirs.xy) > 0.1) {
        vec2 tp = normalize(joinDirs.xy * tileSize);
        vec2 sumA = tp + dir;
        nA = (dot(sumA, sumA) > 1e-6) ? normalize(sumA) : dir;
    }
    vec2 nB = vec2(0.0);
    if (dot(joinDirs.zw, joinDirs.zw) > 0.1) {
        vec2 tn = normalize(joinDirs.zw * tileSize);
        vec2 sumB = dir + tn;
        nB = (dot(sumB, sumB) > 1e-6) ? -normalize(sumB) : -dir;
    }

    vQ = q;
    vSegPx = vec4(aPx, bPx);
    vNormals = vec4(nA, nB);
    vRadT = vec4(r0Px, r1Px, radT.z, radT.w);
    vColorRootP = colorRootP;
    vColorMidOp = colorMidOp;
    vColorTipM = colorTipM;
    vFit = fit;
}'''

FRAGMENT = '''#version 330 core
in vec2 vQ;
flat in vec4 vSegPx;
flat in vec4 vNormals;
flat in vec4 vRadT;
flat in vec4 vColorRootP;
flat in vec4 vColorMidOp;
flat in vec4 vColorTipM;
flat in float vFit;

uniform float uAntialias;
uniform int uPattern;
uniform float uBandCount;
uniform float uBandStrength;
uniform float uSpeckle;
uniform float uOpacityScale;
uniform vec3 uLightDirection;

out vec4 outColor;

float safe_tanh(float x) {
    float xc = clamp(x, -20.0, 20.0);
    float e = exp(-2.0 * abs(xc));
    float t = (1.0 - e) / (1.0 + e);
    return (xc >= 0.0) ? t : -t;
}

void main(){
    vec2 a = vSegPx.xy;
    vec2 b = vSegPx.zw;
    if (dot(vNormals.xy, vNormals.xy) > 0.5 && dot(vQ - a, vNormals.xy) < 0.0) discard;
    if (dot(vNormals.zw, vNormals.zw) > 0.5 && dot(vQ - b, vNormals.zw) < 0.0) discard;

    vec2 d = b - a;
    float len2 = dot(d, d);
    if (len2 < 1e-8) discard;
    float u = clamp(dot(vQ - a, d) / len2, 0.0, 1.0);
    vec2 rv = vQ - a - u * d;
    float dist = length(rv);
    float rad = mix(vRadT.x, vRadT.y, u);
    float minScreenRad = 0.55 / max(vFit, 1e-4);
    float effRad = max(rad, minScreenRad);
    float thinAtten = clamp(max(rad, 0.025) / max(effRad, 1e-5), 0.0, 1.0);
    float edge = max(0.3, uAntialias) * clamp(1.0 / max(vFit, 1e-4), 0.25, 4.0);
    float linCov = clamp((effRad - dist) / edge + 0.5, 0.0, 1.0);
    float cover = (linCov * linCov * (3.0 - 2.0 * linCov)) * thinAtten;
    if (cover <= 0.0) discard;

    float along = mix(vRadT.z, vRadT.w, u);
    float invLen = inversesqrt(len2);
    vec2 dir2 = d * invLen;
    vec2 perp2 = vec2(-dir2.y, dir2.x);
    float across = ((-d.y * rv.x + d.x * rv.y) * invLen) / max(effRad, 0.02);

    vec3 col;
    if (vColorTipM.w > 0.5) {
        col = mix(vColorRootP.rgb, vColorTipM.rgb, u);
    } else {
        float t2 = clamp(along * 2.0, 0.0, 1.0);
        float t3 = clamp(along * 2.0 - 1.0, 0.0, 1.0);
        col = (along <= 0.5)
            ? mix(vColorRootP.rgb, vColorMidOp.rgb, t2)
            : mix(vColorMidOp.rgb, vColorTipM.rgb, t3);
        float phase = vColorRootP.w;
        if (uPattern == 1) {
            float wave = sin(along * 6.28318530718 * uBandCount + phase * 6.28318530718);
            float band = 0.5 + 0.5 * safe_tanh(wave * 4.0);
            col *= (1.0 - uBandStrength * 0.68 * (1.0 - band));
        } else if (uPattern == 2) {
            float wave = sin(along * 6.28318530718 * uBandCount + phase * 6.28318530718);
            float dark = clamp(0.5 + 0.5 * wave, 0.0, 1.0);
            col *= (1.0 - uBandStrength * 0.8 * dark);
        } else if (uPattern == 3) {
            float freck = sin((along * 101.0 + phase * 19.0) * 3.3) * sin((along * 58.0 + across * 3.1) * 5.1);
            float marks = clamp((freck - 0.38) * 2.9, 0.0, 1.0);
            col *= (1.0 - uSpeckle * 0.62 * marks);
        } else if (uPattern == 4) {
            col *= (0.76 + 0.24 * along);
        }
    }
    // Subtle cylindrical strand form shading + cuticle sheen along tangent
    float lat = clamp(across, -1.0, 1.0);
    vec3 cylN = normalize(vec3(perp2 * (lat * 0.85), sqrt(max(0.08, 1.0 - 0.72 * lat * lat))));
    vec3 L1 = normalize(uLightDirection);
    vec3 T3 = vec3(dir2, 0.0);
    vec3 H1 = normalize(L1 + vec3(0.0, 0.0, 1.0));
    float cylWrap = 0.84 + 0.18 * clamp(dot(cylN, L1), -1.0, 1.0);
    float rootDepth = 0.90 + 0.10 * smoothstep(0.0, 0.32, along);
    float lon = dot(T3, H1) + 0.065;
    float sheenLobe = exp(-lon * lon * 14.0) * pow(max(0.0, cylN.z), 0.85) * 0.14 * (0.35 + 0.65 * along);
    vec3 sheenTint = mix(col + vec3(0.18), vec3(1.0), 0.45);
    col = col * (cylWrap * rootDepth) + sheenTint * sheenLobe;
    col = clamp(col, 0.0, 1.0);
    float op = clamp(vColorMidOp.w * uOpacityScale, 0.0, 1.0);
    outColor = vec4(col, cover * op);
}'''

