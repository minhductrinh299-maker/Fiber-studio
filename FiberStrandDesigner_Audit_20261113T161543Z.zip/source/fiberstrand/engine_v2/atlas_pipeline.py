"""Single-owner asynchronous CPU atlas staging; complete map sets publish atomically.

GPU tile residency/subimage upload remains owned by the existing Render Studio
context. This class performs no GL work and does not use the paused editor.
"""
from .scheduler import LatestScheduler


class AtlasPipeline:
    def __init__(self, cache, publish):
        self.cache = cache
        self.publish = publish
        self.scheduler = LatestScheduler(workers=1)

    def submit(self, result, generation):
        def stage(token):
            if token.is_set():
                return
            try:
                staged = self.cache.staged_tile(result)
            except Exception as error:
                if not token.is_set():self.publish(('atlas',generation,None,str(error)))
                return
            if not token.is_set():
                self.cache = staged
                self.publish(('atlas', generation, staged, None))
        self.scheduler.submit(result.tile_id, stage)

    def close(self):
        self.scheduler.close()
