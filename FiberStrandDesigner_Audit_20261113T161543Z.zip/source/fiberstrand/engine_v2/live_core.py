"""Shared live-fiber GPU core. Hosts supply a surface, status sink and redraw hook.
No Tk/Qt widgets are constructed here; context calls remain on the owner thread.
"""
import ctypes as C
import math
import numpy as np
from .live_shaders import *
from ..rendercore.glapi import GL_FLOAT

class LiveFiberGPUCore:
    def __init__(self,surface,message,native_owner='tk'):
        self.context = None
        self.gl = None
        self.count = 0
        self.pending = None
        self.revision = None
        self.zoom, self.angle, self.pan = 1., 0., [0., 0.]
        self.tile_size = (512, 512)
        self.job = None
        self.selected_points = None
        self.selected_nodes = None
        self._overlay_vbo = None
        self._overlay_prog = None
        self.show_hud = True
        self.show_axis_gizmo = True
        self.up_axis = 'Y-Up'
        self.hud_lines = ()
        self.hud_dpr = 1.0
        self._hud_renderer = None
        self.mat_state = {
            'uAntialias': 1.0,
            'uPattern': 0,
            'uBandCount': 4.0,
            'uBandStrength': 0.5,
            'uSpeckle': 0.25,
            'uOpacityScale': 1.0,
        }
        self._published_opacity = 1.0
        self.surface=surface;self.message=message;self.native_owner=native_owner
        self.program=self.vao=self.vbo=self._overlay_vao=0

    def initialize(self):
        try:
            from ..rendercore.context import WGLContext
            from ..rendercore.glapi import GL, GL_ARRAY_BUFFER, GL_FLOAT
            self.context = WGLContext(self.surface.winfo_id(),install_tk_paint_hook=getattr(self,'native_owner','tk')=='tk')
            g = self.gl = GL(self.context)
            self.program = g.program(VERTEX, FRAGMENT)
            self._overlay_prog = g.program(OVERLAY_VERTEX, OVERLAY_FRAGMENT)
            self.vao, self.vbo = g.name('VertexArrays'), g.name('Buffers')
            self._overlay_vbo = g.name('Buffers')
            self._overlay_vao = g.name('VertexArrays')
            factory = getattr(C, 'WINFUNCTYPE', C.CFUNCTYPE)
            self.divisor = factory(None, C.c_uint, C.c_uint)(self.context.get_proc('glVertexAttribDivisor'))
            self.draw_instances = factory(None, C.c_uint, C.c_int, C.c_int, C.c_int)(
                self.context.get_proc('glDrawArraysInstanced'))
            g.glBindVertexArray(self.vao)
            g.glBindBuffer(GL_ARRAY_BUFFER, self.vbo)
            for location, width, offset in ((0, 4, 0), (1, 4, 4), (2, 4, 8), (3, 4, 12), (4, 4, 16), (5, 4, 20)):
                g.glEnableVertexAttribArray(location)
                g.glVertexAttribPointer(location, width, GL_FLOAT, False, STRIDE_FLOATS * 4, C.c_void_p(offset * 4))
                self.divisor(location, 1)
            self.device = g.glGetString(0x1F01).decode(errors='replace')
            self.request_frame()
        except Exception as error:
            self.message.set(f'GPU preview unavailable: {error} · CPU bake remains available')
            self.gl = None

    def set_selection(self, points, nodes=None, multi_points=None, box=None):
        self.selected_points = np.ascontiguousarray(points, dtype=np.float32) if points is not None else None
        self.selected_nodes = np.ascontiguousarray(nodes, dtype=np.float32) if nodes is not None else None
        self.selected_multi_points = [np.ascontiguousarray(p, dtype=np.float32) for p in multi_points] if multi_points else []
        self.selection_box = box  # (x0, y0, x1, y1) in screen pixels or None
        self.request_frame()

    def set_material(self, settings, *, update_opacity: bool = False):
        """Fast 0ms uniform update without touching vertex/instance VBO."""
        self.mat_state['uAntialias'] = float(settings.antialias)
        self.mat_state['uPattern'] = PATTERN_IDS.get(settings.pattern, 0)
        self.mat_state['uBandCount'] = float(settings.band_count)
        self.mat_state['uBandStrength'] = float(settings.band_strength)
        self.mat_state['uSpeckle'] = float(settings.speckle)
        if update_opacity and self._published_opacity > 1e-4:
            self.mat_state['uOpacityScale'] = float(settings.strand_opacity) / self._published_opacity
        elif not update_opacity:
            self.mat_state['uOpacityScale'] = 1.0
        self.request_frame()

    def publish(self, tile_id, revision, size, data, settings=None):
        self.pending = data  # coalesce to one newest upload, retain no upload queue
        self.tile_size = size
        self.revision = (tile_id, revision)
        if settings is not None:
            self._published_opacity = float(settings.strand_opacity)
            self.set_material(settings, update_opacity=False)
        else:
            self.mat_state['uOpacityScale'] = 1.0
            self.request_frame()

    def frame(self):
        self.job = None
        if self.gl is None:
            return
        from ..rendercore.glapi import GL_ARRAY_BUFFER, GL_DYNAMIC_DRAW, GL_COLOR_BUFFER_BIT
        from ..rendercore.glapi import GL_BLEND, GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_TRIANGLES
        try:
            self.context.activate()
            g = self.gl
            if self.pending is not None:
                data, self.pending = self.pending, None
                g.glBindBuffer(GL_ARRAY_BUFFER, self.vbo)
                # Orphan the storage instead of synchronously overwriting in-use data.
                g.glBufferData(GL_ARRAY_BUFFER, data.nbytes, data.ctypes.data_as(C.c_void_p), GL_DYNAMIC_DRAW)
                self.count = len(data)
            width, height = max(1, self.surface.winfo_width()), max(1, self.surface.winfo_height())
            g.glViewport(0, 0, width, height)
            g.glClearColor(.07, .08, .10, 1.)
            g.glClear(GL_COLOR_BUFFER_BIT)
            g.glEnable(GL_BLEND)
            g.glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
            g.glUseProgram(self.program)
            for name, value in dict(viewport=(width, height), tileSize=self.tile_size, pan=self.pan,
                                    zoom=self.zoom, angle=self.angle, uLightDirection=getattr(self,"light_direction",(.42,-.64,.64)), **self.mat_state).items():
                g.uniform(self.program, name, value)
            g.glBindVertexArray(self.vao)
            self.draw_instances(GL_TRIANGLES, 0, 6, self.count)

            # Draw selected strand outline / sculpt nodes overlay
            has_multi = bool(getattr(self, 'selected_multi_points', None))
            has_single = (self.selected_points is not None or self.selected_nodes is not None)
            has_box = bool(getattr(self, 'selection_box', None))
            if self._overlay_prog and (has_single or has_multi or has_box):
                g.glBindVertexArray(self._overlay_vao)
                fit = min(width / self.tile_size[0], height / self.tile_size[1]) * 0.9 * self.zoom
                g.glUseProgram(self._overlay_prog)
                for name, value in dict(viewport=(width, height), tileSize=self.tile_size, pan=self.pan,
                                        zoom=self.zoom, angle=self.angle).items():
                    g.uniform(self._overlay_prog, name, value)
                g.glBindBuffer(GL_ARRAY_BUFFER, self._overlay_vbo)
                g.glEnableVertexAttribArray(0)

                # Multi-selected strands ribbons
                if has_multi:
                    g.uniform(self._overlay_prog, 'uColor', (0.84, 0.65, 0.44, 0.75))  # Gold ACCENT
                    for pts in self.selected_multi_points:
                        if len(pts) >= 2:
                            ribbon = self._build_ribbon_triangles(pts, 2.5, self.tile_size, fit)
                            if len(ribbon) > 0:
                                g.glBufferData(GL_ARRAY_BUFFER, ribbon.nbytes, ribbon.ctypes.data_as(C.c_void_p), GL_DYNAMIC_DRAW)
                                g.glVertexAttribPointer(0, 2, GL_FLOAT, False, 8, None)
                                if self.divisor: self.divisor(0, 0)
                                g.glDrawArrays(GL_TRIANGLES, 0, len(ribbon))

                # Primary selected strand line strip rendered as triangle ribbon
                if self.selected_points is not None and len(self.selected_points) >= 2:
                    ribbon = self._build_ribbon_triangles(self.selected_points, 3.5, self.tile_size, fit)
                    if len(ribbon) > 0:
                        g.glBufferData(GL_ARRAY_BUFFER, ribbon.nbytes, ribbon.ctypes.data_as(C.c_void_p), GL_DYNAMIC_DRAW)
                        g.glVertexAttribPointer(0, 2, GL_FLOAT, False, 8, None)
                        if self.divisor: self.divisor(0, 0)
                        g.uniform(self._overlay_prog, 'uColor', (0.95, 0.75, 0.35, 0.95))  # Bright Gold
                        g.glDrawArrays(GL_TRIANGLES, 0, len(ribbon))

                # Sculpt nodes rendered as circular disks
                if self.selected_nodes is not None and len(self.selected_nodes) > 0:
                    disks = self._build_nodes_triangles(self.selected_nodes, 5.0, self.tile_size, fit)
                    if len(disks) > 0:
                        g.glBufferData(GL_ARRAY_BUFFER, disks.nbytes, disks.ctypes.data_as(C.c_void_p), GL_DYNAMIC_DRAW)
                        g.glVertexAttribPointer(0, 2, GL_FLOAT, False, 8, None)
                        if self.divisor: self.divisor(0, 0)
                        g.uniform(self._overlay_prog, 'uColor', (1.0, 0.35, 0.20, 1.0))  # Node orange-red
                        g.glDrawArrays(GL_TRIANGLES, 0, len(disks))

                # Selection rectangle box in screen space
                if has_box:
                    bx0, by0, bx1, by1 = self.selection_box
                    min_x, max_x = min(bx0, bx1), max(bx0, bx1)
                    min_y, max_y = min(by0, by1), max(by0, by1)
                    # Convert screen pixels directly to NDC [-1, 1]
                    ndc_l = (min_x * 2.0 / width) - 1.0
                    ndc_r = (max_x * 2.0 / width) - 1.0
                    ndc_t = 1.0 - (min_y * 2.0 / height)
                    ndc_b = 1.0 - (max_y * 2.0 / height)
                    # Draw filled semi-transparent box + border lines
                    # Map to dummy points for standard overlay vertex shader when angle=0, pan=0
                    # Alternatively, draw screen-space quad using identity uniforms
                    for name, value in dict(viewport=(2.0, 2.0), tileSize=(2.0, 2.0), pan=(0.0, 0.0),
                                            zoom=1.0, angle=0.0).items():
                        g.uniform(self._overlay_prog, name, value)
                    # Coordinates in [-1, 1] range mapped through shader:
                    # pPx = inPos * 2.0; centered = pPx - 1.0;
                    # We can pass inPos such that inPos * 2.0 - 1.0 = ndc => inPos = (ndc + 1.0) / 2.0
                    u0, u1 = min_x / width, max_x / width
                    v0, v1 = 1.0 - max_y / height, 1.0 - min_y / height
                    # Quad triangles: (u0, v0), (u1, v0), (u1, v1), (u0, v0), (u1, v1), (u0, v1)
                    quad = np.array([
                        [u0, v0], [u1, v0], [u1, v1],
                        [u0, v0], [u1, v1], [u0, v1],
                        # Border outline as thin quads
                        [u0, v0], [u1, v0], [u1, v0 + 1.5/height], [u0, v0], [u1, v0 + 1.5/height], [u0, v0 + 1.5/height],
                        [u0, v1 - 1.5/height], [u1, v1 - 1.5/height], [u1, v1], [u0, v1 - 1.5/height], [u1, v1], [u0, v1],
                        [u0, v0], [u0 + 1.5/width, v0], [u0 + 1.5/width, v1], [u0, v0], [u0 + 1.5/width, v1], [u0, v1],
                        [u1 - 1.5/width, v0], [u1, v0], [u1, v1], [u1 - 1.5/width, v0], [u1, v1], [u1 - 1.5/width, v1]
                    ], dtype=np.float32)
                    g.glBufferData(GL_ARRAY_BUFFER, quad.nbytes, quad.ctypes.data_as(C.c_void_p), GL_DYNAMIC_DRAW)
                    g.glVertexAttribPointer(0, 2, GL_FLOAT, False, 8, None)
                    if self.divisor: self.divisor(0, 0)
                    # Draw fill
                    g.uniform(self._overlay_prog, 'uColor', (0.9, 0.7, 0.4, 0.15))
                    g.glDrawArrays(GL_TRIANGLES, 0, 6)
                    # Draw border
                    g.uniform(self._overlay_prog, 'uColor', (0.95, 0.75, 0.35, 0.90))
                    g.glDrawArrays(GL_TRIANGLES, 6, len(quad) - 6)

            if self.show_hud or self.show_axis_gizmo:
                if self._hud_renderer is None:
                    from ..rendercore.hud import ViewportOverlayRenderer
                    self._hud_renderer = ViewportOverlayRenderer(g)
                dpr = max(1.0, float(getattr(self, 'hud_dpr', 1.0)))
                if self.show_axis_gizmo:
                    c_a, s_a = math.cos(self.angle), math.sin(self.angle)
                    rot2 = np.array([[c_a, -s_a, 0.0], [s_a, c_a, 0.0], [0.0, 0.0, 1.0]], dtype=np.float32)
                    self._hud_renderer.draw_axis_gizmo(width, height, dpr, rot2, self.up_axis)
                if self.show_hud and self.hud_lines:
                    self._hud_renderer.draw_hud(width, height, dpr, self.hud_lines)

            self.context.present()
            self.message.set(f'{self.device} · {self.count:,} SDF segments · truth revision {self.revision} · pigment preview, no AO bake')
        except Exception as error:
            self.message.set(f'GPU frame failed: {error}')

    def _build_ribbon_triangles(self, pts_norm, width_px, tileSize, fit):
        if len(pts_norm) < 2 or fit <= 1e-5:
            return np.empty((0, 2), dtype=np.float32)
        scale_x = 1.0 / max(1e-4, tileSize[0] * fit)
        w_half = 0.5 * width_px * scale_x
        diffs = pts_norm[1:] - pts_norm[:-1]
        norms = np.linalg.norm(diffs, axis=1, keepdims=True)
        unit_tan = np.where(norms > 1e-8, diffs / np.maximum(norms, 1e-8), 0.0)
        normals = np.zeros_like(pts_norm)
        normals[:-1] += np.column_stack([-unit_tan[:, 1], unit_tan[:, 0]])
        normals[1:] += np.column_stack([-unit_tan[:, 1], unit_tan[:, 0]])
        n_norms = np.linalg.norm(normals, axis=1, keepdims=True)
        normals = np.where(n_norms > 1e-8, normals / np.maximum(n_norms, 1e-8), 0.0)
        left = (pts_norm + normals * w_half).astype(np.float32)
        right = (pts_norm - normals * w_half).astype(np.float32)
        triangles = []
        for i in range(len(pts_norm) - 1):
            triangles.extend([left[i], right[i], left[i+1], left[i+1], right[i], right[i+1]])
        return np.ascontiguousarray(triangles, dtype=np.float32)

    def _build_nodes_triangles(self, nodes_norm, radius_px, tileSize, fit, segments=12):
        if len(nodes_norm) == 0 or fit <= 1e-5:
            return np.empty((0, 2), dtype=np.float32)
        scale_x = 1.0 / max(1e-4, tileSize[0] * fit)
        r_norm = radius_px * scale_x
        theta = np.linspace(0, 2 * np.pi, segments, endpoint=False, dtype=np.float32)
        cos_t, sin_t = np.cos(theta), np.sin(theta)
        triangles = []
        for center in nodes_norm:
            ring = np.stack([center[0] + r_norm * cos_t, center[1] + r_norm * sin_t], axis=1)
            for i in range(segments):
                triangles.extend([center, ring[i], ring[(i + 1) % segments]])
        return np.ascontiguousarray(triangles, dtype=np.float32)

    def screen_to_tile(self,screen_x,screen_y):
        w=max(1,self.surface.winfo_width());h=max(1,self.surface.winfo_height())
        fit=min(w/self.tile_size[0],h/self.tile_size[1])*.9*self.zoom
        x=(screen_x-w*.5-self.pan[0])/max(fit,1e-12);y=(screen_y-h*.5-self.pan[1])/max(fit,1e-12)
        c,s=math.cos(self.angle),math.sin(self.angle)
        return (c*x-s*y)/self.tile_size[0]+.5,(s*x+c*y)/self.tile_size[1]+.5

    def request_frame(self):
        raise NotImplementedError('The native host must schedule redraws')

    def close_gpu(self):
        if self.context is None:return
        self.context.activate()
        if self.gl:
            g=self.gl
            if self._hud_renderer:self._hud_renderer.close();self._hud_renderer=None
            for name in (self.program,self._overlay_prog):
                if name:g.glDeleteProgram(name)
            for kind,names in (('Buffers',(self.vbo,self._overlay_vbo)),('VertexArrays',(self.vao,self._overlay_vao))):
                for name in names:
                    if name:value=C.c_uint(name);getattr(g,'glDelete'+kind)(1,C.byref(value))
        self.context.close();self.context=None;self.gl=None
