"""Direct WGL strand preview: analytic capsule SDF with Voronoi join clipping.

CPU preparation builds a compact per-segment instance buffer containing endpoints,
adjacent segment tangents for exact mitered Voronoi join partitioning, radii,
parameter bounds, and per-strand pigments. Fragment evaluation computes exact
pixel-space capsule coverage and procedural/sampled pigment patterns at full
viewport resolution without double-blending at interior vertices.
"""
import ctypes as C
import math
import tkinter as tk
from tkinter import ttk
import numpy as np
from ..navigation import MayaNavigation, dolly_factor, HELP
from .live_shaders import *
from .live_core import LiveFiberGPUCore







def pack_instances(strands, settings, cancel):
    """24 floats per segment for Voronoi capsule SDF + exact fragment shading."""
    if not strands:
        empty = np.empty((0, STRIDE_FLOATS), np.float32)
        empty.setflags(write=False)
        return empty
    if cancel():
        raise RuntimeError('Render cancelled')

    batch = getattr(strands, 'batch', None)
    if batch is not None and not batch.has_attributes and batch.count == len(strands):
        n = batch.count
        if batch.uniform_detail >= 2:
            d = batch.uniform_detail
            n_segs = d - 1
            total_segs = n * n_segs
            if total_segs * STRIDE_FLOATS * 4 > 256 * 1024 * 1024:
                raise MemoryError('GPU preview instance budget 256 MiB exceeded; full bake remains available')
            pts = batch.points.reshape(n, d, 2)
            rad = batch.radii.reshape(n, d)
            ts = batch.t.reshape(n, d)
            diffs = pts[:, 1:] - pts[:, :-1]
            norms = np.linalg.norm(diffs, axis=2, keepdims=True)
            unit_tan = np.where(norms > 1e-8, diffs / np.maximum(norms, 1e-8), 0.0).astype(np.float32)

            data = np.empty((n, n_segs, STRIDE_FLOATS), np.float32)
            data[..., 0:2] = pts[:, :-1]
            data[..., 2:4] = pts[:, 1:]
            data[:, 0, 4:6] = 0.0
            if n_segs > 1:
                data[:, 1:, 4:6] = unit_tan[:, :-1]
                data[:, :-1, 6:8] = unit_tan[:, 1:]
            data[:, -1, 6:8] = 0.0
            data[..., 8] = rad[:, :-1]
            data[..., 9] = rad[:, 1:]
            data[..., 10] = ts[:, :-1]
            data[..., 11] = ts[:, 1:]

            if batch.sampled_colors is not None and batch.has_sampled is not None:
                sc = batch.sampled_colors.reshape(n, d, 3)
                hs = (batch.has_sampled > 0)[:, None]
                cr = np.where(hs[..., None], sc[:, :-1], batch.color_root[:, None, :])
                ct = np.where(hs[..., None], sc[:, 1:], batch.color_tip[:, None, :])
                data[..., 12:15] = cr
                data[..., 20:23] = ct
                data[..., 23] = hs.astype(np.float32)
            else:
                data[..., 12:15] = batch.color_root[:, None, :]
                data[..., 20:23] = batch.color_tip[:, None, :]
                data[..., 23] = 0.0
            data[..., 15] = batch.pattern_phase[:, None]
            data[..., 16:19] = batch.color_mid[:, None, :]
            data[..., 19] = batch.opacity[:, None]
            flat = data.reshape(-1, STRIDE_FLOATS)
            flat.setflags(write=False)
            return flat

        # Ragged vectorized packing (feather with barbules / Graph V4)
        offsets = batch.offsets
        lengths = np.diff(offsets)
        seg_counts = np.maximum(0, lengths - 1)
        total_segs = int(np.sum(seg_counts))
        if total_segs * STRIDE_FLOATS * 4 > 256 * 1024 * 1024:
            raise MemoryError('GPU preview instance budget 256 MiB exceeded; full bake remains available')
        data = np.empty((total_segs, STRIDE_FLOATS), np.float32)
        if total_segs > 0:
            total_v = len(batch.points)
            valid = np.ones(max(0, total_v - 1), dtype=bool)
            if n > 1 and total_v > 1:
                cross = offsets[1:-1]
                cross = cross[(cross > 0) & (cross < total_v)] - 1
                valid[cross] = False
            a_pts = batch.points[:-1][valid]
            b_pts = batch.points[1:][valid]
            diffs = b_pts - a_pts
            norms = np.linalg.norm(diffs, axis=1, keepdims=True)
            unit_tan = np.where(norms > 1e-8, diffs / np.maximum(norms, 1e-8), 0.0).astype(np.float32)
            strand_ids = np.repeat(np.arange(n, dtype=np.int32), seg_counts)
            same_prev = np.zeros(total_segs, dtype=bool)
            same_next = np.zeros(total_segs, dtype=bool)
            if total_segs > 1:
                same = (strand_ids[1:] == strand_ids[:-1])
                same_prev[1:] = same
                same_next[:-1] = same
            data[:, 0:2] = a_pts
            data[:, 2:4] = b_pts
            data[:, 4:6] = 0.0
            data[:, 6:8] = 0.0
            if total_segs > 1:
                data[1:, 4:6] = np.where(same_prev[1:, None], unit_tan[:-1], 0.0)
                data[:-1, 6:8] = np.where(same_next[:-1, None], unit_tan[1:], 0.0)
            data[:, 8] = batch.radii[:-1][valid]
            data[:, 9] = batch.radii[1:][valid]
            data[:, 10] = batch.t[:-1][valid]
            data[:, 11] = batch.t[1:][valid]
            if batch.sampled_colors is not None and batch.has_sampled is not None:
                hs = (batch.has_sampled[strand_ids] > 0)
                sc0 = batch.sampled_colors[:-1][valid]
                sc1 = batch.sampled_colors[1:][valid]
                data[:, 12:15] = np.where(hs[:, None], sc0, batch.color_root[strand_ids])
                data[:, 20:23] = np.where(hs[:, None], sc1, batch.color_tip[strand_ids])
                data[:, 23] = hs.astype(np.float32)
            else:
                data[:, 12:15] = batch.color_root[strand_ids]
                data[:, 20:23] = batch.color_tip[strand_ids]
                data[:, 23] = 0.0
            data[:, 15] = batch.pattern_phase[strand_ids]
            data[:, 16:19] = batch.color_mid[strand_ids]
            data[:, 19] = batch.opacity[strand_ids]
        data.setflags(write=False)
        return data

    # Fallback loop (custom per-length attribute overrides or plain test strands)
    count = sum(max(0, len(s.points) - 1) for s in strands)
    if count * STRIDE_FLOATS * 4 > 256 * 1024 * 1024:
        raise MemoryError('GPU preview instance budget 256 MiB exceeded; full bake remains available')
    data = np.empty((count, STRIDE_FLOATS), np.float32)
    offset = 0
    for k, strand in enumerate(strands):
        if k % 32 == 0 and cancel():
            raise RuntimeError('Render cancelled')
        n_seg = len(strand.points) - 1
        if n_seg <= 0:
            continue
        target = data[offset:offset + n_seg]
        a_pts = strand.points[:-1]
        b_pts = strand.points[1:]
        diffs = b_pts - a_pts
        norms = np.linalg.norm(diffs, axis=1, keepdims=True)
        unit_tan = np.where(norms > 1e-8, diffs / np.maximum(norms, 1e-8), 0.0)
        target[:, 0:2] = a_pts
        target[:, 2:4] = b_pts
        target[:, 4:6] = 0.0
        target[:, 6:8] = 0.0
        if n_seg > 1:
            target[1:, 4:6] = unit_tan[:-1]
            target[:-1, 6:8] = unit_tan[1:]
        target[:, 8] = strand.radii[:-1]
        target[:, 9] = strand.radii[1:]
        target[:, 10] = strand.t[:-1]
        target[:, 11] = strand.t[1:]
        if strand.sampled_colors is not None and len(strand.sampled_colors) == len(strand.points):
            target[:, 12:15] = strand.sampled_colors[:-1]
            target[:, 20:23] = strand.sampled_colors[1:]
            target[:, 23] = 1.0
        else:
            target[:, 12:15] = strand.color_root
            target[:, 20:23] = strand.color_tip
            target[:, 23] = 0.0
        target[:, 15] = strand.pattern_phase
        target[:, 16:19] = strand.color_mid
        op_arr = np.broadcast_to(strand.attribute('opacity', strand.t), strand.t.shape)
        target[:, 19] = 0.5 * (op_arr[:-1] + op_arr[1:])
        offset += n_seg
    data.setflags(write=False)
    return data


class FiberPreviewViewport(ttk.Frame, LiveFiberGPUCore):
    """Embeddable or standalone WGL strand viewport."""
    def __init__(self, master, show_header=False):
        super().__init__(master)
        self.context = None
        self.gl = None
        self.count = 0
        self.pending = None
        self.revision = None
        self.zoom, self.angle, self.pan = 1., 0., [0., 0.]
        self.tile_size = (512, 512)
        self.job = None
        self.selected_points = None
        self.selected_nodes = None
        self._overlay_vbo = None
        self._overlay_prog = None
        self.show_hud = True
        self.show_axis_gizmo = True
        self.up_axis = 'Y-Up'
        self.hud_lines = ()
        self.hud_dpr = 1.0
        self._hud_renderer = None
        self.mat_state = {
            'uAntialias': 1.0,
            'uPattern': 0,
            'uBandCount': 4.0,
            'uBandStrength': 0.5,
            'uSpeckle': 0.25,
            'uOpacityScale': 1.0,
        }
        self._published_opacity = 1.0
        self.message = tk.StringVar(value='Waiting for strand truth · no export maps required')
        if show_header:
            ttk.Label(self, textvariable=self.message).pack(fill='x')
            ttk.Label(self, text=HELP).pack(fill='x')
        self.surface = tk.Frame(self, bg='#17191d')
        self.surface.pack(fill='both', expand=True)
        self.nav = MayaNavigation(self.surface, self.orbit, self.move, self.dolly)
        self.surface.bind('<Configure>', lambda e: self.request_frame())
        self.after_idle(self.initialize)





    def request_frame(self):
        if self.job is None and self.winfo_exists():
            self.job = self.after(16, self.frame)


    def orbit(self, dx, dy, snap=False):
        raw = getattr(self, '_raw_angle', self.angle)
        raw -= math.radians(dx * .4)
        self._raw_angle = raw
        if snap:
            snap_step = math.pi / 2.0  # 90 degrees
            self.angle = round(raw / snap_step) * snap_step
        else:
            self.angle = raw
        self.request_frame()

    def move(self, dx, dy):
        self.pan[0] += dx
        self.pan[1] += dy
        self.request_frame()

    def dolly(self, dx, dy):
        self.zoom = min(100, max(.02, self.zoom / dolly_factor(dx)))
        self.request_frame()

    def reset_view(self):
        self.zoom, self.angle, self.pan = 1., 0., [0., 0.]
        self._raw_angle = 0.
        self.request_frame()




    def close(self):
        if self.job is not None:
            try:
                self.after_cancel(self.job)
            except tk.TclError:
                pass
            self.job = None
        if self.context:
            try:
                self.context.activate()
                if self.gl:
                    if getattr(self, '_hud_renderer', None) is not None:
                        self._hud_renderer.close()
                        self._hud_renderer = None
                    self.gl.glDeleteProgram(self.program)
                    if self._overlay_prog:
                        self.gl.glDeleteProgram(self._overlay_prog)
                        self._overlay_prog = None
                    for kind, handle in (('Buffers', self.vbo), ('Buffers', self._overlay_vbo), ('VertexArrays', self.vao),('VertexArrays',getattr(self,'_overlay_vao',0))):
                        if handle:
                            value = C.c_uint(handle)
                            getattr(self.gl, 'glDelete' + kind)(1, C.byref(value))
            except Exception:
                pass
            finally:
                try:
                    self.context.close()
                except Exception:
                    pass
                self.context = None
                self.gl = None
        try:
            self.destroy()
        except tk.TclError:
            pass


class FiberPreview(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title('Fiber Engine V2 · Live Strand GPU Preview')
        self.geometry('850x720')
        self.viewport = FiberPreviewViewport(self, show_header=True)
        self.viewport.pack(fill='both', expand=True)
        self.message = self.viewport.message
        self.protocol('WM_DELETE_WINDOW', self.close)

    def set_material(self, settings, *, update_opacity: bool = False):
        self.viewport.set_material(settings, update_opacity=update_opacity)

    def publish(self, tile_id, revision, size, data, settings=None):
        self.viewport.publish(tile_id, revision, size, data, settings)

    def request_frame(self):
        self.viewport.request_frame()

    def set_selection(self, points, nodes=None):
        self.viewport.set_selection(points, nodes)

    def close(self):
        self.viewport.close()
        try:
            self.destroy()
        except tk.TclError:
            pass
