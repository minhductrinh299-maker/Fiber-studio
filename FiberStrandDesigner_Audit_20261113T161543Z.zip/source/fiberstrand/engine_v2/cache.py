"""Byte-budgeted, thread-safe LRU. Oversized entries are returned but not kept."""
from collections import OrderedDict
from threading import RLock
import numpy as np


def bytes_used(value, seen=None):
    if value is None or isinstance(value, (int, float, bool, str)):
        return 64
    nbytes_fn = getattr(type(value), '__nbytes__', None)
    if nbytes_fn is not None:
        return int(nbytes_fn(value))
    if seen is None:
        seen = set()
    if isinstance(value, np.ndarray):
        base = value.base
        if isinstance(base, np.ndarray):
            ptr = id(base)
            if ptr in seen:
                return 0
            seen.add(ptr)
            return base.nbytes
        ptr = value.ctypes.data
        if ptr in seen:
            return 0
        seen.add(ptr)
        return value.nbytes
    if isinstance(value, (tuple, list)):
        total = 0
        for v in value:
            total += bytes_used(v, seen)
        return total
    if isinstance(value, dict):
        total = 0
        for v in value.values():
            total += bytes_used(v, seen)
        return total
    if hasattr(value, 'mode') and hasattr(value, 'size'):
        return value.width * value.height * len(value.getbands())
    d = getattr(value, '__dict__', None)
    if d is not None:
        total = 0
        for k, v in d.items():
            if k in ('sid', 'region_id', 'layer'):
                total += 64
            elif isinstance(v, (int, float, bool)):
                total += 64
            elif v is None:
                total += 64
            elif isinstance(v, np.ndarray):
                base = v.base
                if isinstance(base, np.ndarray):
                    ptr = id(base)
                    if ptr not in seen:
                        seen.add(ptr)
                        total += base.nbytes
                else:
                    ptr = v.ctypes.data
                    if ptr not in seen:
                        seen.add(ptr)
                        total += v.nbytes
            else:
                total += bytes_used(v, seen)
        return total
    return 64


class ByteLRU:
    def __init__(self, budget):
        self.budget = int(budget)
        self.used = self.hits = self.misses = self.evictions = 0
        self.entries = OrderedDict()
        self.lock = RLock()

    def get(self, key):
        with self.lock:
            item = self.entries.pop(key, None)
            if item is None:
                self.misses += 1
                return None
            self.entries[key] = item
            self.hits += 1
            return item[0]

    def put(self, key, value):
        cost = bytes_used(value)
        with self.lock:
            old = self.entries.pop(key, None)
            if old:
                self.used -= old[1]
            if cost > self.budget:
                return value
            while self.entries and self.used + cost > self.budget:
                _, (_, size) = self.entries.popitem(last=False)
                self.used -= size
                self.evictions += 1
            self.entries[key] = (value, cost)
            self.used += cost
        return value

    def stats(self):
        with self.lock:
            return dict(bytes=self.used, budget=self.budget, entries=len(self.entries),
                        hits=self.hits, misses=self.misses, evictions=self.evictions)

