"""Explicit source dependencies; outputs never depend on other output maps."""
import hashlib
import json
from dataclasses import asdict

COLOR_FIELDS = frozenset(('color_root', 'color_mid', 'color_tip', 'hue_variation',
    'saturation_variation', 'value_variation', 'pattern', 'band_count', 'band_strength', 'speckle'))
MATERIAL_FIELDS = COLOR_FIELDS | {'bake_samples','ao_mode','roughness', 'strand_opacity', 'fiber_roundness',
    'specular', 'anisotropy', 'transmission', 'scatter', 'iridescence'}
OVERRIDE_MATERIAL = ('color', 'opacity', 'attributes', 'material_id', 'material_mask')
ALL_CHANNELS = ('color', 'alpha', 'normal', 'flow', 'depth', 'ao', 'id', 'roughness',
    'rgb_mask', 'specular', 'anisotropy', 'transmission', 'scatter', 'iridescence', 'cluster_id', 'material_id', 'material_mask')
CHANNEL_SOURCES = {
    'color': ('geometry', 'color', 'opacity'), 'alpha': ('geometry', 'opacity'),
    'normal': ('geometry', 'orientation', 'opacity'), 'flow': ('geometry', 'opacity'),
    'depth': ('geometry', 'opacity'), 'ao': ('geometry', 'opacity', 'occlusion'),
    'id': ('geometry', 'opacity'), 'cluster_id': ('geometry', 'opacity'),
    'material_id': ('geometry', 'material_id', 'opacity'),
    'material_mask': ('geometry','material_id','material_mask','opacity'),
    'rgb_mask': ('geometry', 'opacity'), 'roughness': ('geometry', 'roughness', 'opacity'),
    'specular': ('geometry', 'specular', 'opacity'),
    'anisotropy': ('geometry', 'anisotropy', 'opacity'),
    'transmission': ('geometry', 'transmission', 'opacity'),
    'scatter': ('geometry', 'scatter', 'opacity'),
    'iridescence': ('geometry', 'iridescence', 'opacity'),
}


def digest(value):
    return hashlib.blake2b(json.dumps(value, sort_keys=True, separators=(',', ':'),
        ensure_ascii=False).encode(), digest_size=16).hexdigest()


def source_keys(tile, detail):
    from ..kernel.material_port import geometry_graph,colors_key
    settings = asdict(tile.settings)
    geometry_settings = {k: v for k, v in settings.items()
                         if k not in MATERIAL_FIELDS and k != 'antialias'}
    # Per-strand material overrides must not invalidate the curve cache.
    geometry_overrides = {k: {a: b for a, b in v.items() if a not in OVERRIDE_MATERIAL}
                          for k, v in tile.overrides.items()}
    geometry_overrides = {k: v for k, v in geometry_overrides.items() if v}
    geometry = digest((tile.id, tile.seed, tile.kind, detail, geometry_settings,
                       geometry_overrides, geometry_graph(tile.construction_graph)))
    keys = {'geometry': geometry,
        'color': digest(([settings[k] for k in sorted(COLOR_FIELDS)],
                          {k: v.get('color') for k, v in tile.overrides.items() if 'color' in v},colors_key(tile.construction_graph))),
        'opacity': digest((settings['strand_opacity'],
                          {k: v.get('opacity') for k, v in tile.overrides.items() if 'opacity' in v})),
        'orientation': digest(settings['fiber_roundness'])}
    for key in ('roughness', 'specular', 'anisotropy', 'transmission', 'scatter', 'iridescence'):
        keys[key] = digest((settings[key], {k:v.get('attributes',{}).get(key)
                           for k,v in tile.overrides.items() if key in v.get('attributes',{})}))
    keys['opacity'] = digest((keys['opacity'], {k:v.get('attributes',{}).get('opacity')
                             for k,v in tile.overrides.items() if 'opacity' in v.get('attributes',{})}))
    keys['material_id']=digest({key:value.get('material_id') for key,value in tile.overrides.items() if 'material_id' in value})
    keys['material_mask']=digest({key:value.get('material_mask') for key,value in tile.overrides.items() if 'material_mask' in value})
    keys['occlusion']=digest(tile.settings.ao_mode)
    keys['sampling'] = digest((tile.settings.antialias,max(1,min(16,int(tile.settings.bake_samples)))))
    return keys


def channel_key(channel, keys, size):
    return digest((channel, size, keys['sampling'],
                   [keys[s] for s in CHANNEL_SOURCES[channel]]))


def dirty_mips(rect, size):
    """Expand one filter texel at every level, clipped to this tile only."""
    result = []
    x0, y0, x1, y1 = rect
    w, h = size
    while True:
        result.append((max(0, x0-1), max(0, y0-1), min(w, x1+1), min(h, y1+1)))
        if w == h == 1:
            return result
        x0, y0, x1, y1 = x0//2, y0//2, (x1+1)//2, (y1+1)//2
        w, h = max(1, w//2), max(1, h//2)

