"""Immutable snapshots adapted from both procedural fibers and Graph V4.

Material randomness has its own stable stream. Editing pigment/roughness never
reruns geometry and cannot shift depth, topology or stable strand identities.
The current generator supplies planar curves with a constant per-strand depth;
the adapter explicitly records that 2.5D limitation rather than inventing 3D.
"""
from collections.abc import Sequence
from copy import deepcopy
from dataclasses import dataclass, replace
import colorsys
import numpy as np
from ..geometry import generate_strands, color_jitter, hex_rgb, hsv_to_rgb_batch
from ..model import FiberSettings, stable_int
from .dependencies import MATERIAL_FIELDS, OVERRIDE_MATERIAL


def frozen(array):
    value = np.ascontiguousarray(array, dtype=np.float32)
    value.setflags(write=False)
    return value


@dataclass(frozen=True)
class StrandTruth:
    sid: str
    cluster_id: int
    region_id: str
    points: np.ndarray
    radii: np.ndarray
    t: np.ndarray
    tangent: np.ndarray
    frame: np.ndarray
    depth: float
    color_root: np.ndarray
    color_mid: np.ndarray
    color_tip: np.ndarray
    roughness: float
    opacity: float
    specular: float
    anisotropy: float
    transmission: float
    scatter: float
    iridescence: float
    guard: bool
    layer: str
    pattern_phase: float
    sampled_colors: np.ndarray | None
    attributes: tuple = ()  # immutable (name, per-control-point source samples)
    numeric_id: int = 0
    depth_profile: np.ndarray | None = None
    material_id: int = 0
    material_mask: np.ndarray | None = None

    @property
    def root(self):
        return self.points[0]

    @property
    def positions_3d(self):
        return frozen(np.column_stack((self.points, self.depth_profile if self.depth_profile is not None else np.full(len(self.points), self.depth))))

    def depth_at(self,along):
        return np.interp(along,self.t,self.depth_profile) if self.depth_profile is not None else self.depth

    def attribute(self, name, along):
        for key, values in self.attributes:
            if key == name:
                return np.interp(along, self.t, values).astype(np.float32)
        return getattr(self, name)


@dataclass(frozen=True)
class TruthBatch:
    """Structure-of-Arrays backing storage for StrandTruth sequences (CSR ragged)."""
    count: int
    offsets: np.ndarray          # (N + 1,) int32
    points: np.ndarray           # (V, 2) float32
    radii: np.ndarray            # (V,) float32
    t: np.ndarray                # (V,) float32
    tangent: np.ndarray          # (V, 2) float32
    frame: np.ndarray            # (V, 2) float32
    depth: np.ndarray            # (N,) float32
    roughness: np.ndarray        # (N,) float32
    opacity: np.ndarray          # (N,) float32
    specular: np.ndarray         # (N,) float32
    anisotropy: np.ndarray       # (N,) float32
    transmission: np.ndarray     # (N,) float32
    scatter: np.ndarray          # (N,) float32
    iridescence: np.ndarray      # (N,) float32
    pattern_phase: np.ndarray    # (N,) float32
    cluster_id: np.ndarray       # (N,) int32
    numeric_id: np.ndarray       # (N,) int32
    color_root: np.ndarray       # (N, 3) float32
    color_mid: np.ndarray        # (N, 3) float32
    color_tip: np.ndarray        # (N, 3) float32
    sampled_colors: np.ndarray | None = None  # (V, 3) float32 or None
    has_sampled: np.ndarray | None = None     # (N,) uint8 or None
    has_attributes: bool = False
    material_id: np.ndarray | None = None
    material_mask: np.ndarray | None = None
    uniform_detail: int = 0      # >0 when every strand has identical point count

    def __nbytes__(self) -> int:
        total = (self.offsets.nbytes + self.points.nbytes + self.radii.nbytes +
                 self.t.nbytes + self.tangent.nbytes + self.frame.nbytes +
                 self.depth.nbytes + self.roughness.nbytes + self.opacity.nbytes +
                 self.specular.nbytes + self.anisotropy.nbytes + self.transmission.nbytes +
                 self.scatter.nbytes + self.iridescence.nbytes + self.pattern_phase.nbytes +
                 self.cluster_id.nbytes + self.numeric_id.nbytes +
                 self.color_root.nbytes + self.color_mid.nbytes + self.color_tip.nbytes)
        if self.sampled_colors is not None:
            total += self.sampled_colors.nbytes
        if self.has_sampled is not None:
            total += self.has_sampled.nbytes
        if self.material_id is not None:total+=self.material_id.nbytes
        if self.material_mask is not None:total+=self.material_mask.nbytes
        return int(total)


class TruthView(Sequence):
    """Immutable Sequence of StrandTruth paired with a contiguous SoA TruthBatch."""
    __slots__ = ('strands', 'batch', '_sid_index', '_noise_cache')

    def __init__(self, strands: tuple[StrandTruth, ...], batch: TruthBatch | None = None,
                 sid_index: dict[str, int] | None = None):
        self.strands = tuple(strands)
        self.batch = batch
        self._sid_index = sid_index
        self._noise_cache: dict[int, np.ndarray] = {}

    def __len__(self) -> int:
        return len(self.strands)

    def __getitem__(self, index):
        return self.strands[index]

    def __iter__(self):
        return iter(self.strands)

    def __nbytes__(self) -> int:
        base = self.batch.__nbytes__() if self.batch is not None else 0
        return base + len(self.strands) * 192

    def override_index(self) -> dict[str, tuple[int, ...]]:
        if self._sid_index is None:
            tmp: dict[str, list[int]] = {}
            for i, s in enumerate(self.strands):
                key = s.sid.split(':', 2)[1] if ':' in s.sid else s.sid
                bucket = tmp.get(key)
                if bucket is None:
                    tmp[key] = [i]
                else:
                    bucket.append(i)
            self._sid_index = {k: tuple(v) for k, v in tmp.items()}
        return self._sid_index

    def material_noise(self, seed_val: int) -> np.ndarray:
        cached = self._noise_cache.get(seed_val)
        if cached is not None:
            return cached
        n = len(self.strands)
        normals = np.empty((n, 3, 3), dtype=np.float64)
        for i, strand in enumerate(self.strands):
            rng = np.random.default_rng(stable_int(seed_val, strand.sid, 'material-v2'))
            normals[i] = rng.standard_normal((3, 3))
        normals.setflags(write=False)
        self._noise_cache[seed_val] = normals
        return normals


def _freeze(array, dtype=np.float32):
    value = np.ascontiguousarray(array, dtype=dtype)
    value.setflags(write=False)
    return value


def build_geometry(tile, detail, evaluator, cancel):
    if cancel():
        raise RuntimeError('Render cancelled')
    neutral = deepcopy(tile)
    defaults = FiberSettings()
    for key in MATERIAL_FIELDS:
        setattr(neutral.settings, key, getattr(defaults, key))
    neutral.overrides = {k: {a: b for a, b in v.items() if a not in OVERRIDE_MATERIAL}
                         for k, v in tile.overrides.items()}
    is_graph = bool(tile.construction_graph)
    if is_graph:
        from ..construction.core import to_strands
        strands = to_strands(evaluator.evaluate(tile.construction_graph, seed=tile.seed,
                                               should_cancel=cancel), tile.id,
                             defaults.roughness, stable_ids=True)
    else:
        strands = generate_strands(neutral, detail, should_cancel=cancel, _skip_color=True)

    if not strands:
        return TruthView((), None)

    allocated = set()
    identifiers = {}
    for sid in sorted(s.sid for s in strands):
        suffix = sid.rsplit(':', 1)[-1]
        number = int(suffix) + 1 if suffix.isdigit() else (stable_int(sid) & 0xFFFFFF) or 1
        while number in allocated:
            number = (number % 0xFFFFFF) + 1
        allocated.add(number)
        identifiers[sid] = number

    cluster_cache = {}
    for layer in ('undercoat', 'guard', 'flyaway', 'feather'):
        cluster_cache[layer] = stable_int(tile.id, layer) & 0xFFFFFF

    n = len(strands)
    any_sampled = any(s.sampled_colors is not None for s in strands)
    first_len = len(strands[0].points)
    uniform = (first_len >= 2 and all(len(s.points) == first_len and len(s.radii) == first_len for s in strands))

    if uniform:
        d = first_len
        pts_all = _freeze(np.stack([s.points for s in strands], axis=0), np.float32)
        radii_all = _freeze(np.stack([s.radii for s in strands], axis=0), np.float32)
        tang_raw = np.empty((n, d, 2), dtype=np.float32)
        tang_raw[:, 1:-1] = (pts_all[:, 2:] - pts_all[:, :-2]) * 0.5
        tang_raw[:, 0] = pts_all[:, 1] - pts_all[:, 0]
        tang_raw[:, -1] = pts_all[:, -1] - pts_all[:, -2]
        norms = np.linalg.norm(tang_raw, axis=2, keepdims=True)
        tang_raw /= np.maximum(norms, 1e-8)
        tang_raw.setflags(write=False)
        frame_all = _freeze(np.stack((-tang_raw[..., 1], tang_raw[..., 0]), axis=-1), np.float32)
        diffs = np.linalg.norm(pts_all[:, 1:] - pts_all[:, :-1], axis=2)
        dist_all = np.concatenate([np.zeros((n, 1), dtype=np.float32), np.cumsum(diffs, axis=1)], axis=1)
        param_all = _freeze(dist_all / np.maximum(dist_all[:, -1:], 1e-8), np.float32)
        offsets = _freeze(np.arange(0, (n + 1) * d, d, dtype=np.int32), np.int32)
        pts_flat = pts_all.reshape(-1, 2)
        radii_flat = radii_all.reshape(-1)
        t_flat = param_all.reshape(-1)
        tang_flat = tang_raw.reshape(-1, 2)
        frame_flat = frame_all.reshape(-1, 2)
    else:
        lengths = np.fromiter((len(s.points) for s in strands), dtype=np.int32, count=n)
        offsets_mut = np.empty(n + 1, dtype=np.int32)
        offsets_mut[0] = 0
        np.cumsum(lengths, out=offsets_mut[1:])
        offsets_mut.setflags(write=False)
        offsets = offsets_mut
        total_pts = int(offsets[-1])
        pts_mut = np.empty((total_pts, 2), dtype=np.float32)
        rad_mut = np.empty(total_pts, dtype=np.float32)
        t_mut = np.empty(total_pts, dtype=np.float32)
        tang_mut = np.empty((total_pts, 2), dtype=np.float32)
        frame_mut = np.empty((total_pts, 2), dtype=np.float32)
        for i, strand in enumerate(strands):
            if i % 64 == 0 and cancel():
                raise RuntimeError('Render cancelled')
            o0 = int(offsets[i])
            o1 = int(offsets[i + 1])
            p = np.asarray(strand.points, dtype=np.float32)
            r = np.asarray(strand.radii, dtype=np.float32)
            tangent = np.gradient(p, axis=0) if len(p) >= 2 else np.array([[0.0, -1.0]], dtype=np.float32)
            tangent = tangent / np.maximum(np.linalg.norm(tangent, axis=1, keepdims=True), 1e-8)
            frame = np.column_stack((-tangent[:, 1], tangent[:, 0]))
            if len(p) >= 2:
                distance = np.r_[0.0, np.cumsum(np.linalg.norm(np.diff(p, axis=0), axis=1))]
                parameter = distance / max(float(distance[-1]), 1e-8)
            else:
                parameter = np.zeros(len(p), dtype=np.float32)
            pts_mut[o0:o1] = p
            rad_mut[o0:o1] = r
            t_mut[o0:o1] = parameter
            tang_mut[o0:o1] = tangent
            frame_mut[o0:o1] = frame
        pts_mut.setflags(write=False)
        rad_mut.setflags(write=False)
        t_mut.setflags(write=False)
        tang_mut.setflags(write=False)
        frame_mut.setflags(write=False)
        pts_flat, radii_flat, t_flat, tang_flat, frame_flat = pts_mut, rad_mut, t_mut, tang_mut, frame_mut

    depth_arr = _freeze([s.depth for s in strands], np.float32)
    rough_arr = _freeze([s.roughness for s in strands], np.float32)
    op_arr = _freeze([s.opacity for s in strands], np.float32)
    spec_arr = _freeze(np.full(n, defaults.specular, dtype=np.float32), np.float32)
    aniso_arr = _freeze(np.full(n, defaults.anisotropy, dtype=np.float32), np.float32)
    trans_arr = _freeze(np.full(n, defaults.transmission, dtype=np.float32), np.float32)
    scat_arr = _freeze(np.full(n, defaults.scatter, dtype=np.float32), np.float32)
    irid_arr = _freeze(np.full(n, defaults.iridescence, dtype=np.float32), np.float32)
    phase_arr = _freeze([s.pattern_phase for s in strands], np.float32)
    cr_arr = _freeze(np.stack([s.color_root for s in strands], axis=0), np.float32)
    cm_arr = _freeze(np.stack([s.color_mid for s in strands], axis=0), np.float32)
    ct_arr = _freeze(np.stack([s.color_tip for s in strands], axis=0), np.float32)
    cids = []
    nids = []
    for s in strands:
        cid = cluster_cache.get(s.layer)
        if cid is None:
            cid = cluster_cache[s.layer] = stable_int(tile.id, s.layer) & 0xFFFFFF
        cids.append(cid)
        nids.append(identifiers[s.sid])
    cid_arr = _freeze(cids, np.int32)
    nid_arr = _freeze(nids, np.int32)

    sampled_flat = None
    has_sampled = None
    if any_sampled:
        sampled_mut = np.zeros((len(pts_flat), 3), dtype=np.float32)
        hs_mut = np.zeros(n, dtype=np.uint8)
        for i, strand in enumerate(strands):
            if strand.sampled_colors is not None:
                o0, o1 = int(offsets[i]), int(offsets[i + 1])
                sampled_mut[o0:o1] = strand.sampled_colors[:(o1 - o0)]
                hs_mut[i] = 1
        sampled_mut.setflags(write=False)
        hs_mut.setflags(write=False)
        sampled_flat = sampled_mut
        has_sampled = hs_mut

    result = []
    for i, strand in enumerate(strands):
        if i % 128 == 0 and cancel():
            raise RuntimeError('Render cancelled')
        o0, o1 = int(offsets[i]), int(offsets[i + 1])
        sc_view = sampled_flat[o0:o1] if (has_sampled is not None and has_sampled[i]) else None
        result.append(StrandTruth(
            strand.sid, int(cid_arr[i]), strand.layer,
            pts_flat[o0:o1], radii_flat[o0:o1], t_flat[o0:o1],
            tang_flat[o0:o1], frame_flat[o0:o1], float(depth_arr[i]),
            cr_arr[i], cm_arr[i], ct_arr[i],
            float(rough_arr[i]), float(op_arr[i]), defaults.specular, defaults.anisotropy,
            defaults.transmission, defaults.scatter, defaults.iridescence,
            strand.guard, strand.layer, float(phase_arr[i]),
            sc_view, numeric_id=int(nid_arr[i]),depth_profile=frozen(strand.depth_profile) if strand.depth_profile is not None else None))

    batch = TruthBatch(
        count=n, offsets=offsets, points=pts_flat, radii=radii_flat, t=t_flat,
        tangent=tang_flat, frame=frame_flat, depth=depth_arr, roughness=rough_arr,
        opacity=op_arr, specular=spec_arr, anisotropy=aniso_arr, transmission=trans_arr,
        scatter=scat_arr, iridescence=irid_arr, pattern_phase=phase_arr,
        cluster_id=cid_arr, numeric_id=nid_arr, color_root=cr_arr, color_mid=cm_arr,
        color_tip=ct_arr, sampled_colors=sampled_flat, has_sampled=has_sampled,
        has_attributes=any(s.depth_profile is not None for s in strands), uniform_detail=first_len if uniform else 0)
    return TruthView(tuple(result), batch)


def apply_material(geometry, tile, cancel, pigments=None):
    if len(geometry) == 0:
        return TruthView((), None) if isinstance(geometry, TruthView) else ()
    if cancel():
        raise RuntimeError('Render cancelled')
    s = tile.settings
    roots = [frozen(hex_rgb(getattr(s, key))) for key in ('color_root', 'color_mid', 'color_tip')]
    graph = bool(tile.construction_graph)
    overrides = tile.overrides
    seed_val = tile.seed
    zero_jitter = (s.hue_variation == 0.0 and s.saturation_variation == 0.0 and s.value_variation == 0.0)
    rough_delta = s.roughness - FiberSettings.roughness
    spec = s.specular
    aniso = s.anisotropy
    trans = s.transmission
    scat = s.scatter
    irid = s.iridescence
    op_base = s.strand_opacity

    batch = geometry.batch if isinstance(geometry, TruthView) else None
    n = len(geometry)
    if batch is not None and len(batch.roughness) == n:
        if graph:
            colors_all = None
            r_arr = batch.roughness
            op_arr = np.clip(batch.opacity * op_base, 0.0, 1.0).astype(np.float32)
        else:
            if pigments is not None:
                colors_all = np.array(pigments, dtype=np.float32)
            elif zero_jitter:
                base3 = np.stack(roots, axis=0)
                colors_all = np.broadcast_to(base3[None, :, :], (n, 3, 3)).copy()
            else:
                normals = geometry.material_noise(seed_val)
                base_hsv = np.array(
                    [colorsys.rgb_to_hsv(float(c[0]), float(c[1]), float(c[2])) for c in roots],
                    dtype=np.float64,
                )
                hsv = np.empty((n, 3, 3), dtype=np.float64)
                hsv[:, :, 0] = np.mod(base_hsv[None, :, 0] + normals[:, :, 0] * (s.hue_variation * 0.5), 1.0)
                hsv[:, :, 1] = np.clip(base_hsv[None, :, 1] + normals[:, :, 1] * (s.saturation_variation / 3.0), 0.0, 1.0)
                hsv[:, :, 2] = np.clip(base_hsv[None, :, 2] * (1.0 + normals[:, :, 2] * (s.value_variation / 3.0)), 0.0, 1.0)
                colors_all = hsv_to_rgb_batch(hsv)
            r_arr = np.clip(batch.roughness + rough_delta, 0.0, 1.0).astype(np.float32)
            op_arr = np.full(n, max(0.0, min(1.0, op_base)), dtype=np.float32)

        attrs_map: dict[int, tuple] = {}
        any_attrs = False
        if overrides:
            sid_map = geometry.override_index()
            if colors_all is None:
                colors_all = np.stack((batch.color_root, batch.color_mid, batch.color_tip), axis=1).copy()
            op_mut = op_arr.copy()
            for okey, override in overrides.items():
                indices = sid_map.get(okey)
                if not indices:
                    continue
                for idx in indices:
                    if override.get('color'):
                        try:
                            c = hex_rgb(override['color'])
                            colors_all[idx, 0] = c
                            colors_all[idx, 1] = c
                            colors_all[idx, 2] = c
                        except (ValueError, IndexError):
                            pass
                    if 'opacity' in override:
                        op_v = float(batch.opacity[idx] * op_base if graph else op_base) * float(override.get('opacity', 1.0))
                        op_mut[idx] = 0.0 if op_v < 0.0 else (1.0 if op_v > 1.0 else op_v)
                    raw_attrs = override.get('attributes')
                    if raw_attrs:
                        strand_t = geometry[idx].t
                        attrs_list = []
                        for name, values in raw_attrs.items():
                            if name not in ('opacity', 'roughness', 'specular', 'anisotropy', 'transmission', 'scatter', 'iridescence'):
                                continue
                            array = np.asarray(values, dtype=np.float32).reshape(-1)
                            if not len(array) or not np.isfinite(array).all():
                                raise ValueError(f'Invalid source attribute {name} on {geometry[idx].sid}')
                            knots = np.linspace(0, 1, len(array))
                            attrs_list.append((name, frozen(np.clip(np.interp(strand_t, knots, array), 0, 1))))
                        if attrs_list:
                            attrs_map[idx] = tuple(attrs_list)
                            any_attrs = True
            op_arr = op_mut

        if colors_all is None:
            cr_arr, cm_arr, ct_arr = batch.color_root, batch.color_mid, batch.color_tip
        else:
            cr_arr = _freeze(colors_all[:, 0, :], np.float32)
            cm_arr = _freeze(colors_all[:, 1, :], np.float32)
            ct_arr = _freeze(colors_all[:, 2, :], np.float32)
        r_arr = _freeze(r_arr, np.float32)
        op_arr = _freeze(op_arr, np.float32)
        spec_arr = _freeze(np.full(n, spec, dtype=np.float32), np.float32)
        aniso_arr = _freeze(np.full(n, aniso, dtype=np.float32), np.float32)
        trans_arr = _freeze(np.full(n, trans, dtype=np.float32), np.float32)
        scat_arr = _freeze(np.full(n, scat, dtype=np.float32), np.float32)
        irid_arr = _freeze(np.full(n, irid, dtype=np.float32), np.float32)

        if cancel():
            raise RuntimeError('Render cancelled')

        if attrs_map:
            result = tuple(
                replace(
                    strand,
                    color_root=cr_arr[i], color_mid=cm_arr[i], color_tip=ct_arr[i],
                    roughness=float(r_arr[i]), opacity=float(op_arr[i]),
                    specular=spec, anisotropy=aniso, transmission=trans,
                    scatter=scat, iridescence=irid, attributes=attrs_map.get(i, ()),
                )
                for i, strand in enumerate(geometry)
            )
        else:
            result = tuple(
                replace(
                    strand,
                    color_root=cr_arr[i], color_mid=cm_arr[i], color_tip=ct_arr[i],
                    roughness=float(r_arr[i]), opacity=float(op_arr[i]),
                    specular=spec, anisotropy=aniso, transmission=trans,
                    scatter=scat, iridescence=irid, attributes=(),
                )
                for i, strand in enumerate(geometry)
            )
        new_batch = replace(
            batch,
            roughness=r_arr, opacity=op_arr, specular=spec_arr, anisotropy=aniso_arr,
            transmission=trans_arr, scatter=scat_arr, iridescence=irid_arr,
            color_root=cr_arr, color_mid=cm_arr, color_tip=ct_arr,
            has_attributes=any_attrs or any(s.depth_profile is not None for s in geometry),
        )
        return TruthView(result, new_batch, geometry._sid_index)

    no_overrides = not overrides
    result = []
    for i, strand in enumerate(geometry):
        if i % 64 == 0 and cancel():
            raise RuntimeError('Render cancelled')
        if pigments is not None:
            colors = pigments[i]
        elif graph:
            colors = (strand.color_root, strand.color_mid, strand.color_tip)
        elif zero_jitter:
            colors = roots
        else:
            rng = np.random.default_rng(stable_int(seed_val, strand.sid, 'material-v2'))
            colors = [frozen(color_jitter(c, rng, s.hue_variation, s.saturation_variation,
                                          s.value_variation)) for c in roots]
        override = None if no_overrides else overrides.get(strand.sid.split(':', 2)[1] if ':' in strand.sid else strand.sid)
        attributes = ()
        if override:
            if override.get('color'):
                colors = [frozen(hex_rgb(override['color']))] * 3
            raw_attrs = override.get('attributes')
            if raw_attrs:
                attrs_list = []
                for name, values in raw_attrs.items():
                    if name not in ('opacity', 'roughness', 'specular', 'anisotropy', 'transmission', 'scatter', 'iridescence'):
                        continue
                    array = np.asarray(values, dtype=np.float32).reshape(-1)
                    if not len(array) or not np.isfinite(array).all():
                        raise ValueError(f'Invalid source attribute {name} on {strand.sid}')
                    knots = np.linspace(0, 1, len(array))
                    attrs_list.append((name, frozen(np.clip(np.interp(strand.t, knots, array), 0, 1))))
                attributes = tuple(attrs_list)
        if graph:
            r_val = strand.roughness
            op_raw = strand.opacity * op_base * (float(override.get('opacity', 1)) if override else 1.0)
        else:
            r_raw = strand.roughness + rough_delta
            r_val = 0.0 if r_raw < 0.0 else (1.0 if r_raw > 1.0 else float(r_raw))
            op_raw = op_base * (float(override.get('opacity', 1)) if override else 1.0)
        op_val = 0.0 if op_raw < 0.0 else (1.0 if op_raw > 1.0 else float(op_raw))
        result.append(replace(strand,
            color_root=strand.color_root if graph else colors[0],
            color_mid=strand.color_mid if graph else colors[1],
            color_tip=strand.color_tip if graph else colors[2],
            roughness=r_val, opacity=op_val,
            specular=spec, anisotropy=aniso, transmission=trans,
            scatter=scat, iridescence=irid, attributes=attributes))
    return tuple(result)


def apply_material_ids(truth, tile):
    """Explicit source labels, independent of pigment and output texture colors."""
    items=[]
    for strand in truth:
        suffix=strand.sid.split(':',1)[-1]
        override=tile.overrides.get(suffix,{})
        value=override.get('material_id',strand.material_id or stable_int('material',strand.region_id)&0xFFFFFF)
        number=int(value)&0xFFFFFF if isinstance(value,(int,float)) else stable_int('material',value)&0xFFFFFF
        number=number or 1
        mask=np.asarray(override.get('material_mask',np.eye(3,dtype=np.float32)[number%3]),np.float32)
        if mask.shape!=(3,) or not np.isfinite(mask).all():raise ValueError('Material mask must contain three finite source weights')
        items.append(replace(strand,material_id=number,material_mask=frozen(np.clip(mask,0,1))))
    batch=getattr(truth,'batch',None)
    if batch is not None:batch=replace(batch,material_id=_freeze([s.material_id for s in items],np.int32),material_mask=frozen([s.material_mask for s in items]))
    return TruthView(tuple(items),batch,getattr(truth,'_sid_index',None))
