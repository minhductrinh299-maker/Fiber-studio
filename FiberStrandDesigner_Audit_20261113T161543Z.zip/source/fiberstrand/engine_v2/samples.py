"""Tile-local spatial bins and compact analytic segment samples.

The pixel grid is evaluated over tight per-strand active sub-rectangles inside
each 32x32 block using vectorized active-segment batches. Cover attributes are
cropped strictly to cover bounds (without AO halo inflation) and proximity uses
half-precision storage, cutting sample cache footprint ~3-4x while preserving
reference accuracy.
"""
import hashlib
import math
import struct
import numpy as np
from threading import local
from contextlib import contextmanager
_SAMPLE_ORIGIN=local()

@contextmanager
def sample_origin(offset):
    previous=getattr(_SAMPLE_ORIGIN,"value",(.5,.5));_SAMPLE_ORIGIN.value=offset
    try:yield
    finally:_SAMPLE_ORIGIN.value=previous

from .dependencies import digest

BLOCK = 32
AO_RADIUS = 6.0  # reference pixels at 512 wide; finite geometry-space support


def strand_signature(strand):
    h = hashlib.blake2b(strand.sid.encode(), digest_size=16)
    h.update(struct.pack('<d', float(strand.depth)))
    h.update(strand.points.tobytes())
    h.update(strand.radii.tobytes())
    if strand.depth_profile is not None:h.update(strand.depth_profile.tobytes())
    return h.hexdigest()


def bounds(strand, size, halo=0):
    w, h = size
    p = strand.points * [w, h]
    pad = float(np.max(strand.radii)) * w / 512 + halo + 3
    return (max(0, math.floor(float(p[:, 0].min()) - pad)),
            max(0, math.floor(float(p[:, 1].min()) - pad)),
            min(w, math.ceil(float(p[:, 0].max()) + pad)),
            min(h, math.ceil(float(p[:, 1].max()) + pad)))


def build_bins(strands, size, cancel):
    w, h = int(size[0]), int(size[1])
    bins = {}
    signatures = []
    boxes = []
    rad_scale = w / 512.0
    halo_pad = AO_RADIUS * rad_scale
    pad_extra = halo_pad + 3.0

    batch = getattr(strands, 'batch', None)
    n = len(strands)
    if batch is not None and batch.uniform_detail >= 2 and batch.count == n and n > 0:
        d = batch.uniform_detail
        pts_nd = batch.points.reshape(n, d, 2)
        rad_nd = batch.radii.reshape(n, d)
        px = pts_nd[..., 0] * w
        py = pts_nd[..., 1] * h
        rad_px = rad_nd * rad_scale
        strand_pad = rad_px.max(axis=1) + pad_extra
        bx0 = np.maximum(0, np.floor(px.min(axis=1) - strand_pad).astype(np.int32))
        by0 = np.maximum(0, np.floor(py.min(axis=1) - strand_pad).astype(np.int32))
        bx1 = np.minimum(w, np.ceil(px.max(axis=1) + strand_pad).astype(np.int32))
        by1 = np.minimum(h, np.ceil(py.max(axis=1) + strand_pad).astype(np.int32))

        seg_pad = np.maximum(rad_px[:, :-1], rad_px[:, 1:]) + pad_extra
        sl = np.maximum(0, np.floor(np.minimum(px[:, :-1], px[:, 1:]) - seg_pad).astype(np.int32))
        st = np.maximum(0, np.floor(np.minimum(py[:, :-1], py[:, 1:]) - seg_pad).astype(np.int32))
        sr = np.minimum(w, np.ceil(np.maximum(px[:, :-1], px[:, 1:]) + seg_pad).astype(np.int32))
        sb = np.minimum(h, np.ceil(np.maximum(py[:, :-1], py[:, 1:]) + seg_pad).astype(np.int32))
        valid = (sl < sr) & (st < sb)
        gx0 = sl // BLOCK
        gy0 = st // BLOCK
        gx1 = (sr + BLOCK - 1) // BLOCK
        gy1 = (sb + BLOCK - 1) // BLOCK

        depths = batch.depth
        for i in range(n):
            if i % 128 == 0 and cancel():
                raise RuntimeError('Render cancelled')
            strand = strands[i]
            sig = hashlib.blake2b(strand.sid.encode(), digest_size=16)
            sig.update(struct.pack('<d', float(depths[i])))
            sig.update(pts_nd[i].tobytes())
            sig.update(rad_nd[i].tobytes())
            if strand.depth_profile is not None:sig.update(strand.depth_profile.tobytes())
            signatures.append(sig.hexdigest())
            boxes.append((int(bx0[i]), int(by0[i]), int(bx1[i]), int(by1[i])))
            touched = set()
            vi = valid[i]
            xs0, ys0, xs1, ys1 = gx0[i], gy0[i], gx1[i], gy1[i]
            for j in range(d - 1):
                if not vi[j]:
                    continue
                for y in range(int(ys0[j]), int(ys1[j])):
                    for x in range(int(xs0[j]), int(xs1[j])):
                        touched.add((x, y))
            for block in sorted(touched):
                bins.setdefault(block, []).append(i)
        return {key:np.asarray(value,dtype=np.int32) for key,value in bins.items()}, tuple(signatures), tuple(boxes)

    size_vec = np.array([w, h], dtype=np.float32)
    for i, strand in enumerate(strands):
        if i % 32 == 0 and cancel():
            raise RuntimeError('Render cancelled')
        signatures.append(strand_signature(strand))
        boxes.append(bounds(strand, size, halo_pad))
        points = strand.points * size_vec
        radii = strand.radii * rad_scale
        touched = set()
        for j in range(len(points) - 1):
            pad = max(float(radii[j]), float(radii[j + 1])) + pad_extra
            ax, ay = float(points[j, 0]), float(points[j, 1])
            bx, by = float(points[j + 1, 0]), float(points[j + 1, 1])
            l = max(0, math.floor(min(ax, bx) - pad))
            t = max(0, math.floor(min(ay, by) - pad))
            r = min(w, math.ceil(max(ax, bx) + pad))
            b = min(h, math.ceil(max(ay, by) + pad))
            if l >= r or t >= b:
                continue
            for y in range(t // BLOCK, (b + BLOCK - 1) // BLOCK):
                for x in range(l // BLOCK, (r + BLOCK - 1) // BLOCK):
                    touched.add((x, y))
        for block in sorted(touched):
            bins.setdefault(block, []).append(i)
    return {key:np.asarray(value,dtype=np.int32) for key,value in bins.items()}, tuple(signatures), tuple(boxes)


def grid(rect):
    l, t, r, b = rect
    y, x = np.mgrid[t:b, l:r].astype(np.float32)
    dx,dy=getattr(_SAMPLE_ORIGIN,"value",(.5,.5))
    return x+dx,y+dy


EMPTY_BLOCK = np.zeros((BLOCK, BLOCK), np.float32)
EMPTY_BLOCK.setflags(write=False)
EMPTY_SAMPLE = (EMPTY_BLOCK, EMPTY_BLOCK, EMPTY_BLOCK, EMPTY_BLOCK, EMPTY_BLOCK, EMPTY_BLOCK, EMPTY_BLOCK)


class SamplePatch:
    """Compact dual-box sample: ultra-tight cover float32 + halo proximity float16."""
    __slots__ = (
        'y0', 'y1', 'x0', 'x1', 'prox_buf', 'proximity', 'near_along',
        'cy0', 'cy1', 'cx0', 'cx1', 'cov_buf', 'cover', 'along', 'across', 'tx', 'ty',
        'empty_cover',
    )

    def __init__(self, y0: int, y1: int, x0: int, x1: int, prox_buf: np.ndarray,
                 cy0: int, cy1: int, cx0: int, cx1: int, cov_buf: np.ndarray | None):
        self.y0, self.y1, self.x0, self.x1 = y0, y1, x0, x1
        self.prox_buf = prox_buf
        ph, pw = y1 - y0, x1 - x0
        npix_p = ph * pw
        self.proximity = prox_buf[0:npix_p].reshape(ph, pw)
        self.near_along = prox_buf[npix_p:2 * npix_p].reshape(ph, pw)

        self.cy0, self.cy1, self.cx0, self.cx1 = cy0, cy1, cx0, cx1
        self.cov_buf = cov_buf
        if cov_buf is None or cy0 >= cy1 or cx0 >= cx1:
            self.empty_cover = True
            self.cover = self.along = self.across = self.tx = self.ty = None
        else:
            self.empty_cover = False
            ch, cw = cy1 - cy0, cx1 - cx0
            npix_c = ch * cw
            self.cover = cov_buf[0:npix_c].reshape(ch, cw)
            self.along = cov_buf[npix_c:2 * npix_c].reshape(ch, cw)
            self.across = cov_buf[2 * npix_c:3 * npix_c].reshape(ch, cw)
            self.tx = cov_buf[3 * npix_c:4 * npix_c].reshape(ch, cw)
            self.ty = cov_buf[4 * npix_c:5 * npix_c].reshape(ch, cw)

    def __nbytes__(self) -> int:
        total = int(self.prox_buf.nbytes) + 160
        if self.cov_buf is not None:
            total += int(self.cov_buf.nbytes)
        return total


class _EmptyPatch:
    __slots__ = ()

    def __nbytes__(self) -> int:
        return 64


EMPTY_PATCH = _EmptyPatch()


def sample_patch(strand, size, rect, anti, cancel):
    """Evaluate a strand over tight proximity & cover sub-rectangles inside a block."""
    l, t, r, b = rect
    bh, bw = b - t, r - l
    if bh <= 0 or bw <= 0:
        return EMPTY_PATCH
    points = strand.points * size
    radii = strand.radii * (size[0] / 512.0)
    halo = max(.5, AO_RADIUS * size[0] / 512.0)
    edge = max(.3, anti)
    half_edge = 0.5 * edge
    reach = max(halo, half_edge)

    pad_max = float(radii.max()) + reach
    if (points[:, 0].min() - pad_max > r or points[:, 0].max() + pad_max < l or
            points[:, 1].min() - pad_max > b or points[:, 1].max() + pad_max < t):
        return EMPTY_PATCH

    px0 = points[:-1, 0]
    px1 = points[1:, 0]
    py0 = points[:-1, 1]
    py1 = points[1:, 1]
    rmax_seg = np.maximum(radii[:-1], radii[1:])
    seg_pad = rmax_seg + reach
    seg_min_x = np.minimum(px0, px1) - seg_pad
    seg_max_x = np.maximum(px0, px1) + seg_pad
    seg_min_y = np.minimum(py0, py1) - seg_pad
    seg_max_y = np.maximum(py0, py1) + seg_pad

    active = np.where((seg_min_x <= r) & (seg_max_x >= l) &
                      (seg_min_y <= b) & (seg_max_y >= t))[0]
    if len(active) == 0:
        return EMPTY_PATCH

    ux0 = max(0, math.floor(float(seg_min_x[active].min()) - l))
    ux1 = min(bw, math.ceil(float(seg_max_x[active].max()) - l))
    uy0 = max(0, math.floor(float(seg_min_y[active].min()) - t))
    uy1 = min(bh, math.ceil(float(seg_max_y[active].max()) - t))
    if ux0 >= ux1 or uy0 >= uy1:
        return EMPTY_PATCH

    dx_all = px1[active] - px0[active]
    dy_all = py1[active] - py0[active]
    len2_all = dx_all * dx_all + dy_all * dy_all
    keep = len2_all >= 1e-10
    if not np.any(keep):
        return EMPTY_PATCH
    active = active[keep]
    dx_a = dx_all[keep][:, None, None]
    dy_a = dy_all[keep][:, None, None]
    inv_len2 = (1.0 / len2_all[keep])[:, None, None]
    inv_len = np.sqrt(inv_len2)

    ax_a = px0[active][:, None, None]
    ay_a = py0[active][:, None, None]
    r0_a = radii[active][:, None, None]
    dr_a = (radii[active + 1] - radii[active])[:, None, None]
    strand_t = strand.t
    t0_a = strand_t[active][:, None, None]
    dt_a = (strand_t[active + 1] - strand_t[active])[:, None, None]

    if cancel():
        raise RuntimeError('Render cancelled')

    # Vectorized evaluation over (K_active, ph, pw) inside L1 cache
    ph, pw = uy1 - uy0, ux1 - ux0
    dx,dy=getattr(_SAMPLE_ORIGIN,"value",(.5,.5))
    gx = (np.arange(l + ux0, l + ux1, dtype=np.float32) + dx)[None, None, :]
    gy = (np.arange(t + uy0, t + uy1, dtype=np.float32) + dy)[None, :, None]

    u = ((gx - ax_a) * dx_a + (gy - ay_a) * dy_a) * inv_len2
    np.maximum(0.0, u, out=u)
    np.minimum(1.0, u, out=u)
    rx = gx - ax_a - u * dx_a
    ry = gy - ay_a - u * dy_a
    distance = np.hypot(rx, ry)
    rad = r0_a + u * dr_a

    # Proximity (AO)
    near_mat = 1.0 - np.maximum(0.0, distance - rad) / halo
    np.maximum(0.0, near_mat, out=near_mat)
    np.minimum(1.0, near_mat, out=near_mat)
    best_near_idx = np.argmax(near_mat, axis=0)
    proximity = np.take_along_axis(near_mat, best_near_idx[None, :, :], axis=0)[0]
    has_prox = bool(np.any(proximity > 0.0))
    u_near = np.take_along_axis(u, best_near_idx[None, :, :], axis=0)[0]
    t0_2d = t0_a[:, 0, 0][best_near_idx]
    dt_2d = dt_a[:, 0, 0][best_near_idx]
    near_along = t0_2d + u_near * dt_2d

    # Cover & geometric shading inputs (tightly cropped to nonzero cover!)
    c_mat = (rad - distance) / edge + 0.5
    np.maximum(0.0, c_mat, out=c_mat)
    np.minimum(1.0, c_mat, out=c_mat)
    best_cov_idx = np.argmax(c_mat, axis=0)
    cover_full = np.take_along_axis(c_mat, best_cov_idx[None, :, :], axis=0)[0]
    nz_y, nz_x = np.nonzero(cover_full > 0.0)
    if not has_prox and len(nz_y) == 0:
        return EMPTY_PATCH

    npix_p = ph * pw
    prox_buf = np.empty(2 * npix_p, np.float16)
    prox_buf[0:npix_p] = proximity.ravel()
    prox_buf[npix_p:2 * npix_p] = near_along.ravel()
    prox_buf.setflags(write=False)

    if len(nz_y) == 0:
        return SamplePatch(uy0, uy1, ux0, ux1, prox_buf, 0, 0, 0, 0, None)

    ly0 = int(nz_y.min())
    ly1 = int(nz_y.max()) + 1
    lx0 = int(nz_x.min())
    lx1 = int(nz_x.max()) + 1
    sl = (slice(ly0, ly1), slice(lx0, lx1))
    b_idx = best_cov_idx[sl]
    ch, cw = ly1 - ly0, lx1 - lx0
    npix_c = ch * cw
    cov_buf = np.empty(5 * npix_c, np.float32)

    u_cov = np.take_along_axis(u[:, ly0:ly1, lx0:lx1], b_idx[None, :, :], axis=0)[0]
    rx_cov = np.take_along_axis(rx[:, ly0:ly1, lx0:lx1], b_idx[None, :, :], axis=0)[0]
    ry_cov = np.take_along_axis(ry[:, ly0:ly1, lx0:lx1], b_idx[None, :, :], axis=0)[0]
    rad_cov = np.take_along_axis(rad[:, ly0:ly1, lx0:lx1], b_idx[None, :, :], axis=0)[0]

    dx_2d = dx_a[:, 0, 0][b_idx]
    dy_2d = dy_a[:, 0, 0][b_idx]
    inv_len_2d = inv_len[:, 0, 0][b_idx]
    t0_c = t0_a[:, 0, 0][b_idx]
    dt_c = dt_a[:, 0, 0][b_idx]

    cov_buf[0:npix_c] = cover_full[sl].ravel()
    cov_buf[npix_c:2 * npix_c] = (t0_c + u_cov * dt_c).ravel()
    cov_buf[2 * npix_c:3 * npix_c] = (((-dy_2d * rx_cov + dx_2d * ry_cov) * inv_len_2d) / np.maximum(rad_cov, 0.02)).ravel()
    cov_buf[3 * npix_c:4 * npix_c] = (dx_2d * inv_len_2d).ravel()
    cov_buf[4 * npix_c:5 * npix_c] = (dy_2d * inv_len_2d).ravel()
    cov_buf.setflags(write=False)

    return SamplePatch(uy0, uy1, ux0, ux1, prox_buf, uy0 + ly0, uy0 + ly1, ux0 + lx0, ux0 + lx1, cov_buf)


def sample(strand, size, xy, anti, cancel):
    x, y = xy
    shape = x.shape
    l = math.floor(float(x[0, 0]))
    t = math.floor(float(y[0, 0]))
    r = l + shape[1]
    b = t + shape[0]
    patch = sample_patch(strand, size, (l, t, r, b), anti, cancel)
    if patch is EMPTY_PATCH:
        if shape == (BLOCK, BLOCK):
            return EMPTY_SAMPLE
        empty = np.zeros(shape, np.float32)
        empty.setflags(write=False)
        return (empty, empty, empty, empty, empty, empty, empty)
    npix = shape[0] * shape[1]
    buf = np.zeros(7 * npix, np.float32)
    out = [buf[k * npix:(k + 1) * npix].reshape(shape) for k in range(7)]
    if not patch.empty_cover:
        cys, cxs = slice(patch.cy0, patch.cy1), slice(patch.cx0, patch.cx1)
        out[0][cys, cxs] = patch.cover
        out[1][cys, cxs] = patch.along
        out[2][cys, cxs] = patch.across
        out[3][cys, cxs] = patch.tx
        out[4][cys, cxs] = patch.ty
    pys, pxs = slice(patch.y0, patch.y1), slice(patch.x0, patch.x1)
    out[5][pys, pxs] = patch.proximity
    out[6][pys, pxs] = patch.near_along
    buf.setflags(write=False)
    for arr in out:
        arr.setflags(write=False)
    return tuple(out)
