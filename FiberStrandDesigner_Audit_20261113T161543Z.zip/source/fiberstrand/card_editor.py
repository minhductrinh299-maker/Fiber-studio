"""Fast, compact 3D card editor for Fiber Strand Designer.

Persistent GPU viewport with indexed geometry and independent editing state.
Does NOT re-bake any fiber tile while editing card geometry.
"""
from __future__ import annotations
from .ui_theme import color as ui_color
from .navigation import MayaNavigation, HELP, dolly_factor, pan_target
from .dpi import watch_window,pixels,window_dpi,font_pixels
from copy import deepcopy
import math
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import numpy as np
from .cards import HairCard, change_segments, export_obj
from .editor_scene import card_signature
from .editor_scheduler import LatestFrameScheduler
from .editor_viewport import GPUCardViewport
from .number_slider import NumberSlider
from .settings import to_display_coords

BG=ui_color('background');SIDEBAR=ui_color('panel');CARD=ui_color('control');FG=ui_color('text');MUTED=ui_color('muted');ACCENT=ui_color('selection')
PIES={
 'Select':['Move','Rotate','Scale','Duplicate','Delete','Make Unique'],
 'Shape':['Bend','Width','Length','Twist','Root','Lift'],
 'Groom':['Comb','Relax','Spread','Smooth','Lift','Noise'],
 'Mesh':['Vertex','Insert Row','Remove Row','Relax','Root','Width']}
PARAMS=[('length','Length',.015,20),('width','Width',.002,20),('bend','Bend',-5,5),
        ('twist','Twist (rad)',-25,25),('lift','Lift',-5,5),('yaw','Yaw (rad)',-50,50),
        ('tilt','Tilt (rad)',-2.8,2.8),('taper','Taper',0,1),('segments','Segments',1,64),('width_segments','Width Segments',1,16)]

from .workspace_frame import WorkspaceFrame


class CardEditor(WorkspaceFrame):
    def __init__(self,parent_or_app,app=None):
        self.app=app if app is not None else parent_or_app
        super().__init__(parent_or_app,bg=BG)
        self.title('Fiber Strand Designer  ·  CARD EDITOR')
        from .object_workspace import workspace
        workspace(self.app)
        self.geometry('1410x860');self.minsize(1010,580);self.configure(bg=BG)
        self.cards=[HairCard.from_dict(x) for x in self.app.project.cards]
        self.selected=set()
        self.component_selected={}
        self._active_card=None
        self._card_lookup={c.id:c for c in self.cards}
        raw={d['id']:d for d in app.project.cards}
        self._serialized_cards={c.id:((card_signature(c),c.name,c.locked_root,c.locked),raw[c.id]) for c in self.cards}
        self.view=None;self._gpu_error=None;self._atlas_dirty=True;self._scheduler=None
        self._pie_window=None
        self.mode=tk.StringVar(value='Shape')
        self.selection_mode=tk.StringVar(value='Card')
        self.tool=tk.StringVar(value='Bend')
        self.tile_choice=tk.StringVar()
        self.tile_assignment_status=tk.StringVar(value='Select cards to assign a tile.')
        self.property_vars={}
        self.brush=tk.BooleanVar(value=False)
        self.radius=115
        self.show_wire=tk.BooleanVar(value=False)
        self.root_lock=tk.BooleanVar(value=True)
        self.yaw=-.18;self.pitch=.10;self.distance=4.8
        self.camera_target=[0.,.7,0.]
        self._drag=None
        self._pie_origin=None;self._pie_visible=False;self._pie_after=None
        self._hover_after=None
        self._space=False;self._s_down=False
        self._last_transform=None
        self._inspector_lock=False
        self._build()
        self._scheduler=LatestFrameScheduler(self,self._draw_frame,interval_ms=0)
        self._set_mode('Shape')
        self._refresh_tiles()
        self._refresh_tree()
        self._render_soon(80)
        self._install_events()
        watch_window(self)
        self.bind('<<DpiChanged>>',lambda e:self._render_soon(0))
        self.bind('<FocusIn>',self._on_focus_in)
        self.protocol('WM_DELETE_WINDOW',self._close)
        self.focus_set()

    def _build(self):
        bar=ttk.Frame(self,padding=(12,7));bar.pack(fill='x')
        ttk.Label(bar,text='CARD EDITOR 3D',font=('Segoe UI Semibold',12)).pack(side='left',padx=(2,12))
        mode_box=ttk.Frame(bar,style="PillContainer.TFrame",padding=(2,2))
        mode_box.pack(side='left',padx=4)
        self._mode_buttons={}
        for label,action in [('Select','Select'),('Groom','Groom'),('Shape','Shape'),('Mesh','Mesh')]:
            b=ttk.Button(mode_box,text=label,style="PillActive.TButton" if action=='Shape' else "Pill.TButton",
                         command=lambda a=action:self._set_mode(a))
            b.pack(side='left',padx=1)
            self._mode_buttons[action]=b
        self.mode_label=tk.Label(bar,text='SHAPE  ·  Bend',bg=ui_color('background'),fg=ui_color('cyan'),font=('Segoe UI Semibold',9))
        self.mode_label.pack(side='left',padx=12)
        ttk.Button(bar,text='Outliner / Import Models',style='TButton',command=lambda:self.app.object_workspace.show(self)).pack(side='right',padx=3)
        ttk.Button(bar,text='Export OBJ',style='Primary.TButton',command=self.export).pack(side='right',padx=3)
        main=ttk.PanedWindow(self,orient='horizontal');main.pack(expand=True,fill='both',padx=8,pady=(0,6))
        left=ttk.Frame(main,style='Panel.TFrame',width=216)
        center=ttk.Frame(main)
        right=ttk.Frame(main,style='Panel.TFrame',width=256)
        main.add(left,weight=1);main.add(center,weight=5);main.add(right,weight=1)
        self.mainpane=main
        right_panel=right
        inspector_canvas=tk.Canvas(right_panel,bg=SIDEBAR,highlightthickness=0,width=240)
        inspector_scroll=ttk.Scrollbar(right_panel,orient='vertical',command=inspector_canvas.yview)
        inspector_scroll.pack(side='right',fill='y');inspector_canvas.pack(side='left',fill='both',expand=True)
        inspector_canvas.configure(yscrollcommand=inspector_scroll.set)
        right=ttk.Frame(inspector_canvas,style='Panel.TFrame')
        inspector_content=inspector_canvas.create_window((0,0),window=right,anchor='nw')
        right.bind('<Configure>',lambda e:inspector_canvas.configure(scrollregion=inspector_canvas.bbox('all')))
        inspector_canvas.bind('<Configure>',lambda e:inspector_canvas.itemconfigure(inspector_content,width=e.width))
        def inspector_wheel(event):
            if str(event.widget).startswith(str(right_panel)+'.'):
                inspector_canvas.yview_scroll(-int(event.delta/120),'units');return 'break'
        self.bind('<MouseWheel>',inspector_wheel,add='+')
        ttk.Label(left,text='CARD LIST',font=('Segoe UI Semibold',11),style='Panel.TLabel').pack(anchor='w',padx=10,pady=(14,7))
        self.tree=ttk.Treeview(left,show='tree',selectmode='extended',height=16)
        self.tree.pack(fill='both',expand=True,padx=6)
        self.tree.bind('<<TreeviewSelect>>',self._tree_select)
        row=ttk.Frame(left,style='Panel.TFrame');row.pack(fill='x',padx=6,pady=8)
        for title,call in [('+ Add',self.add_card),('Copy',self.duplicate),('Delete',self.delete_selected)]:
            ttk.Button(row,text=title,style='TButton',command=call).pack(side='left',expand=True,fill='x',padx=2)
        ttk.Label(left,text='ASSIGN TILE',style='Panel.TLabel').pack(anchor='w',padx=10,pady=(12,5))
        self.tilebox=ttk.Combobox(left,textvariable=self.tile_choice,state='readonly',
                                  postcommand=self._update_tile_choices)
        self.tilebox.pack(fill='x',padx=9)
        self.assign_tile_button=ttk.Button(left,text='Assign Tile to Selected Cards',style='Accent.TButton',command=self._apply_tile)
        self.assign_tile_button.pack(fill='x',padx=9,pady=(6,3))
        ttk.Label(left,textvariable=self.tile_assignment_status,style='Muted.TLabel',
                  wraplength=202).pack(anchor='w',padx=10,pady=(2,4))
        ttk.Button(left,text='Make Tile Unique',style='TButton',command=self.make_unique).pack(fill='x',padx=9,pady=9)
        ttk.Label(left,text='Texture is read from atlas cache.\nCard shape never re-bakes fibers.',
                  style='Muted.TLabel',wraplength=202).pack(anchor='w',padx=10,pady=(8,10))

        stagebar=ttk.Frame(center,padding=(7,6));stagebar.pack(fill='x')
        ttk.Label(stagebar,text='3D VIEW · Perspective',font=('Segoe UI Semibold',10)).pack(side='left')
        self.component_box=ttk.Combobox(stagebar,textvariable=self.selection_mode,
            values=['Card','Root','Row','Vertex','Edge','Face'],state='readonly',width=8)
        self.component_box.pack(side='left',padx=8);self.component_box.bind('<<ComboboxSelected>>',lambda e:self._render_soon(0))
        ttk.Button(stagebar,text='Frame (F)',style='TButton',command=self.frame_selected).pack(side='right',padx=2)
        ttk.Button(stagebar,text='Fit All',style='TButton',command=self.frame_all).pack(side='right',padx=2)
        ttk.Checkbutton(stagebar,text='Wire',variable=self.show_wire,command=lambda:self._render_soon(0)).pack(side='right',padx=4)
        self.show_stats=tk.BooleanVar(value=False)
        ttk.Checkbutton(stagebar,text='Stats',variable=self.show_stats,command=self._toggle_stats).pack(side='right',padx=4)
        self.canvas=tk.Frame(center,bg=ui_color('viewport'),highlightthickness=0,borderwidth=0,takefocus=True)
        self.canvas.pack(fill='both',expand=True,padx=6,pady=(0,4))
        tools=ttk.Frame(center,padding=4);tools.pack(fill='x')
        self.tool_buttons={}
        tool_pill=ttk.Frame(tools,style="PillContainer.TFrame",padding=(2,2))
        tool_pill.pack(side='left')
        for name in ['Select','Move','Rotate','Scale','Comb']:
            b=ttk.Button(tool_pill,text=name,style='PillActive.TButton' if name==self.tool.get() else 'Pill.TButton',
                         command=lambda n=name:self._set_tool(n))
            b.pack(side='left',padx=1)
            self.tool_buttons[name]=b
        self.info=tk.StringVar(value=HELP+'  ·  Space pie  ·  F frame')
        ttk.Label(center,textvariable=self.info,foreground=MUTED).pack(anchor='w',padx=10,pady=5)
        self.stats_text=tk.StringVar(value='')
        self.stats_label=ttk.Label(center,textvariable=self.stats_text,foreground=MUTED,justify='left',wraplength=700)

        from .kernel.workbench import KernelWorkbench
        self._kernel_window=KernelWorkbench(self,parent=right)
        right=self._kernel_window.basic_frame
        from .visual_card_shape import VisualCardShape
        self.visual_shape=VisualCardShape(right,self);self.visual_shape.pack(fill='x',padx=4,pady=5)
        ttk.Label(right,text='SHAPE & SCULPT',style='Panel.TLabel',font=('Segoe UI Semibold',11)).pack(anchor='w',pady=8)
        ttk.Label(right,text='1. Select cards  →  2. Shape  →  3. Refine surface',wraplength=260).pack(anchor='w',pady=4)
        ttk.Button(right,text='Shape presets & sculpt…',command=self._open_easy_shape).pack(fill='x',pady=5)
        ttk.Button(right,text='Sculpt layers…',command=self._sculpt_layers).pack(fill='x',pady=4)
        form=ttk.Frame(right,style='Panel.TFrame');form.pack(fill='x',padx=8)
        self.property_sliders={}
        for key,label,lo,hi in PARAMS:
            row=ttk.Frame(form,style='Panel.TFrame');row.pack(fill='x',pady=3)
            ttk.Label(row,text=label,style='Panel.TLabel',width=13).pack(side='left')
            var=tk.StringVar(value='—');self.property_vars[key]=var
            is_int = key in ('segments','width_segments')
            step = 1.0 if is_int else (0.001 if key in ('length','width') else 0.01)
            slider = NumberSlider(row,variable=var,from_=lo,to=hi,step=step,is_integer=is_int,
                                  width=160,height=22,command=lambda v,k=key:self._apply_property(k))
            slider.pack(side='right',fill='x',expand=True)
            self.property_sliders[key]=slider
        ttk.Checkbutton(right,text='Root Lock (default)',variable=self.root_lock,
                        command=self._apply_root_lock).pack(anchor='w',padx=12,pady=(10,4))
        ttk.Checkbutton(right,text='Groom Brush  (B)',variable=self.brush,
                        command=lambda:self._render_soon(0)).pack(anchor='w',padx=12,pady=4)
        brush_row=ttk.Frame(right,style='Panel.TFrame');brush_row.pack(fill='x',padx=12,pady=(9,4))
        ttk.Label(brush_row,text='Brush Radius',style='Panel.TLabel',width=13).pack(side='left')
        self.brush_var=tk.DoubleVar(value=self.radius)
        NumberSlider(brush_row,variable=self.brush_var,from_=25,to=320,step=1.0,is_integer=True,
                     width=160,height=22,command=lambda v:setattr(self,'radius',float(v))).pack(side='right',fill='x',expand=True)
        ttk.Separator(right).pack(fill='x',padx=9,pady=(14,8))
        ttk.Label(right,text='PRECISION MESH',style='Panel.TLabel').pack(anchor='w',padx=12,pady=(3,7))
        rr=ttk.Frame(right,style='Panel.TFrame');rr.pack(fill='x',padx=9)
        for title,fn in [('Row +',lambda:self.change_segment(1)),('Row −',lambda:self.change_segment(-1))]:
            ttk.Button(rr,text=title,command=fn).pack(side='left',expand=True,fill='x',padx=2)
        ttk.Button(right,text='Edit Width Profile…',command=self.edit_width_profile).pack(fill='x',padx=11,pady=5)
        ttk.Button(right,text='Reset Vertex Overrides',command=self.reset_overrides).pack(fill='x',padx=11,pady=4)
        ttk.Label(right,text='1 Card · 2 Root · 3 Row · 4 Vertex · 5 Edge · 6 Face\n'
                  'Q Select  ·  W Move  ·  E Rotate  ·  R Scale\n'
                  'Shift+D Duplicate  ·  Ctrl+Z Undo\n'
                  'Space hold + flick → Pie Menu\n'
                  'S + drag → Brush radius\n'
                  'Tab hide Inspector',style='Muted.TLabel',wraplength=240).pack(anchor='w',padx=12,pady=15)
        self.right=right_panel
        self.after(250,self._position_sashes)

    def _position_sashes(self):
        try:
            w=self.mainpane.winfo_width()
            if w>pixels(self,900):self.mainpane.sashpos(0,pixels(self,214));self.mainpane.sashpos(1,w-pixels(self,260))
        except tk.TclError:pass

    def _install_events(self):
        c=self.canvas
        c.bind('<ButtonPress-1>',self._pointer_down)
        c.bind('<B1-Motion>',self._pointer_move)
        c.bind('<ButtonRelease-1>',self._pointer_up)
        c.bind('<ButtonPress-3>',self._right_menu)
        self.navigation=MayaNavigation(c,self._nav_orbit,self._nav_pan,self._nav_dolly,
                                       on_start=self._navigation_start,on_end=self._navigation_end)
        c.bind('<MouseWheel>',self._zoom)
        c.bind('<Button-4>',lambda e:self._zoom_factor(.86))
        c.bind('<Button-5>',lambda e:self._zoom_factor(1.16))
        c.bind('<Configure>',lambda e:self._render_soon(0))
        c.bind('<Expose>',lambda e:self._render_soon(0))
        c.bind('<Motion>',self._hover)
        c.bind('<Leave>',lambda e:self._clear_hover())
        c.bind('<Enter>',lambda e:self.canvas.focus_set(),add='+')
        c.bind('<FocusOut>',lambda e:self._pointer_up(None) if self._drag else None,add='+')
        # Normal keyboard shortcuts are bound inside Card Editor on both window and canvas.
        for widget in (self, self.canvas):
            widget.bind('<KeyPress-space>',self._pie_press)
            widget.bind('<KeyRelease-space>',self._pie_release)
            widget.bind('<KeyPress-s>',self._s_press)
            widget.bind('<KeyPress-S>',self._s_press)
            widget.bind('<KeyRelease-s>',self._s_release)
            widget.bind('<KeyRelease-S>',self._s_release)
            widget.bind('<Escape>',lambda e:self._cancel())
            widget.bind('<Delete>',lambda e:self.delete_selected())
            widget.bind('<BackSpace>',lambda e:self.delete_selected())
            widget.bind('<Control-z>',lambda e:self._undo())
            widget.bind('<Control-Z>',lambda e:self._undo())
            widget.bind('<Control-Shift-Z>',lambda e:self._redo())
            widget.bind('<Control-Shift-z>',lambda e:self._redo())
            widget.bind('<Control-y>',lambda e:self._redo())
            widget.bind('<Control-Y>',lambda e:self._redo())
            widget.bind('<Shift-D>',lambda e:self.duplicate())
            widget.bind('<Shift-d>',lambda e:self.duplicate())
            widget.bind('<KeyPress-q>',lambda e:self._key_tool(e,'Select'))
            widget.bind('<KeyPress-Q>',lambda e:self._key_tool(e,'Select'))
            widget.bind('<KeyPress-w>',lambda e:self._key_tool(e,'Move'))
            widget.bind('<KeyPress-W>',lambda e:self._key_tool(e,'Move'))
            widget.bind('<KeyPress-e>',lambda e:self._key_tool(e,'Rotate'))
            widget.bind('<KeyPress-E>',lambda e:self._key_tool(e,'Rotate'))
            widget.bind('<KeyPress-r>',lambda e:self._key_tool(e,'Scale'))
            widget.bind('<KeyPress-R>',lambda e:self._key_tool(e,'Scale'))
            widget.bind('<KeyPress-b>',lambda e:self._key_brush(e))
            widget.bind('<KeyPress-B>',lambda e:self._key_brush(e))
            widget.bind('<KeyPress-f>',lambda e:self._key_action(e,self.frame_selected))
            widget.bind('<KeyPress-F>',lambda e:self._key_action(e,self.frame_selected))
            widget.bind('<KeyPress-g>',lambda e:self._key_action(e,self.repeat_last))
            widget.bind('<KeyPress-G>',lambda e:self._key_action(e,self.repeat_last))
            for k in ('1','2','3','4','5','6'):
                widget.bind(f'<KeyPress-{k}>',lambda e,num=k:self._key_select(e,{'1':'Card','2':'Root','3':'Row','4':'Vertex','5':'Edge','6':'Face'}[num]))
                widget.bind(f'<KeyPress-KP_{k}>',lambda e,num=k:self._key_select(e,{'1':'Card','2':'Root','3':'Row','4':'Vertex','5':'Edge','6':'Face'}[num]))
            widget.bind('<Tab>',lambda e:self._toggle_inspector())
            widget.bind('<Control-a>',lambda e:self.select_all())
            widget.bind('<Control-A>',lambda e:self.select_all())
        # Keyboard shortcut routing is suspended in text/number editing widgets.
        self.bind_class('TEntry','<KeyPress-space>',lambda e:None,add='+')

    def _handle_global_key(self, event, release=None):
        if self._entry_focused(event):
            return None
        keysym = getattr(event, 'keysym', '')
        state = getattr(event, 'state', 0)
        ctrl = bool(state & 0x0004)
        shift = bool(state & 0x0001)

        if release is not None:
            is_release = bool(release)
        else:
            ev_type = str(getattr(event, 'type', ''))
            is_release = ('KeyRelease' in ev_type) or (ev_type == str(tk.EventType.KeyRelease)) or (ev_type == '3')
        if is_release:
            if keysym in ('space', 'Space'):
                return self._pie_release(event)
            elif keysym in ('s', 'S'):
                return self._s_release(event)
            return

        # KeyPress
        if keysym in ('space', 'Space'):
            return self._pie_press(event)
        elif keysym in ('s', 'S') and not ctrl:
            return self._s_press(event)
        elif keysym == 'Escape':
            return self._cancel()
        elif keysym in ('Delete', 'BackSpace'):
            self.delete_selected()
            return 'break'
        elif (keysym in ('z', 'Z') and ctrl and not shift):
            return self._undo()
        elif (keysym in ('Z', 'z') and ctrl and shift) or (keysym in ('y', 'Y') and ctrl):
            return self._redo()
        elif keysym in ('d', 'D') and shift:
            self.duplicate()
            return 'break'
        elif keysym in ('a', 'A') and ctrl:
            self.select_all()
            return 'break'
        elif keysym in ('q', 'Q'):
            self._set_tool('Select')
            return 'break'
        elif keysym in ('w', 'W'):
            self._set_tool('Move')
            return 'break'
        elif keysym in ('e', 'E'):
            self._set_tool('Rotate')
            return 'break'
        elif keysym in ('r', 'R'):
            self._set_tool('Scale')
            return 'break'
        elif keysym in ('b', 'B'):
            self.brush.set(not self.brush.get())
            return 'break'
        elif keysym in ('f', 'F'):
            self.frame_selected()
            return 'break'
        elif keysym in ('g', 'G'):
            self.repeat_last()
            return 'break'
        elif keysym in ('1', 'KP_1'):
            self.selection_mode.set('Card'); self._render_soon(0); return 'break'
        elif keysym in ('2', 'KP_2'):
            self.selection_mode.set('Root'); self._render_soon(0); return 'break'
        elif keysym in ('3', 'KP_3'):
            self.selection_mode.set('Row'); self._render_soon(0); return 'break'
        elif keysym in ('4', 'KP_4'):
            self.selection_mode.set('Vertex'); self._render_soon(0); return 'break'
        elif keysym in ('5', 'KP_5'):
            self.selection_mode.set('Edge'); self._render_soon(0); return 'break'
        elif keysym in ('6', 'KP_6'):
            self.selection_mode.set('Face'); self._render_soon(0); return 'break'
        elif keysym == 'Tab':
            return self._toggle_inspector()

    def _entry_focused(self,event):
        return isinstance(event.widget,(ttk.Entry,ttk.Combobox,tk.Entry,tk.Spinbox))

    def _key_tool(self,event,tool):
        if not self._entry_focused(event):self._set_tool(tool)

    def _key_select(self,event,what):
        if not self._entry_focused(event):
            self.selection_mode.set(what)
            self._render_soon(0)

    def _key_brush(self,event):
        if not self._entry_focused(event):self.brush.set(not self.brush.get())

    def _key_action(self,event,callback):
        if not self._entry_focused(event):callback()

    def _toggle_inspector(self):
        if self.right.winfo_manager():self.mainpane.forget(self.right)
        else:self.mainpane.add(self.right,weight=1)
        return 'break'

    def _set_mode(self,mode):
        self.mode.set(mode)
        if hasattr(self, '_mode_buttons'):
            for m, btn in self._mode_buttons.items():
                btn.configure(style='PillActive.TButton' if m==mode else 'Pill.TButton')
        defaults={'Select':'Select','Groom':'Comb','Shape':'Bend','Mesh':'Vertex'}
        self._set_tool(defaults[mode]);self._render_soon(0)

    def _set_tool(self,tool):
        self.tool.set(tool)
        if hasattr(self, 'tool_buttons'):
            for t, btn in self.tool_buttons.items():
                btn.configure(style='PillActive.TButton' if t==tool else 'Pill.TButton')
        if tool=='Vertex':self.selection_mode.set('Vertex')
        self.mode_label.configure(text=f'{self.mode.get().upper()}  ·  {tool}')
        self.info.set(f'{tool}  ·  Drag to edit  ·  Shift fine  ·  Space pie')
        if tool=='Insert Row':self.change_segment(1)
        if tool=='Remove Row':self.change_segment(-1)
        if tool=='Duplicate':self.duplicate()
        if tool=='Delete':self.delete_selected()
        if tool=='Make Unique':self.make_unique()
        self._render_soon(0)

    def _cards(self):return self.cards

    def _save_cards(self, atlas_dirty: bool = False):
        from .kernel.surface import capture_vertices
        for card in self.cards:capture_vertices(card)
        # Serialize only changed cards; keep unchanged source dictionaries.
        serialized={}
        for c in self.cards:
            signature=(card_signature(c),c.name,c.locked_root,c.locked)
            cached=self._serialized_cards.get(c.id)
            serialized[c.id]=(signature,cached[1] if cached and cached[0]==signature else c.to_dict())
        self._serialized_cards=serialized
        self.app.project.cards=[serialized[c.id][1] for c in self.cards]
        from .kernel.scene import kernel
        kernel(self.app.project).synchronize()
        self._card_lookup={c.id:c for c in self.cards}
        if self.view:self.view.reconcile(self.cards)
        if atlas_dirty:
            self._atlas_dirty=True
        self.app.modified=True
        studio=getattr(self.app,'render_window',None)
        if studio and studio.winfo_exists() and studio.renderer:
            studio.renderer.load_cards(self.app.project.cards,self.app._atlas.layout.placements,self.app._atlas.layout.size)
            studio._frame_later(0)

    def _history(self):self.app._history()

    def _selection(self):return [self._card_lookup[cid] for cid in self.selected if cid in self._card_lookup and not self._card_lookup[cid].locked]

    def _open_kernel(self):
        window=getattr(self,'_kernel_window',None)
        if window is not None and window.winfo_exists():window.refresh();window.show_page('Guides');window.lift();return
        from .kernel.workbench import KernelWorkbench
        self._kernel_window=KernelWorkbench(self)

    def begin_guide_draw(self,callback):
        self._guide_draw={'points':[],'callback':callback,'preview':None}
        self.canvas.focus_set()
        self.bind('<Return>',self._accept_guide_draw,add='+')
        self.info.set('DRAW GUIDE · Click camera-plane points · Enter commit · Escape cancel')

    def _update_guide_preview(self):
        d=self._guide_draw
        if d['preview'] is not None:self.cards=[c for c in self.cards if c.id!=d['preview']]
        if len(d['points'])>=2:
            c=HairCard.create(self.app.current_id,'Guide preview');c.id='__guide_preview__'
            c.guide_points=d['points'];c.bend=0.;c.width=.012;c.segments=32
            d['preview']=c.id;self.cards=[*self.cards,c]
        if self.view:self.view.reconcile(self.cards)
        self._render_soon(0)

    def _accept_guide_draw(self,event=None):
        if getattr(self,'_guide_draw',None) is not None:self.finish_guide_draw(True);return 'break'

    def finish_guide_draw(self,accept):
        d=self._guide_draw;self._guide_draw=None
        if d['preview'] is not None:self.cards=[c for c in self.cards if c.id!=d['preview']]
        if self.view:self.view.reconcile(self.cards)
        self._render_soon(0);d['callback'](d['points'] if accept else [])

    def _open_easy_shape(self):
        if not self._selection():
            self.info.set('Select one or more cards, then open Easy Shape.')
            return
        window=getattr(self,'_easy_shape',None)
        if window is not None and window.winfo_exists():
            window.rebase();window.lift();return
        from .card_shape_tools import EasyShape
        self._easy_shape=EasyShape(self)

    def _edit_shared_guide(self):
        cards=self._selection()
        if not cards:return
        import json
        from .cards import ribbon_mesh
        source=cards[0]
        points=source.guide_points or [[0,0,0],[0,.33,0],[0,.66,0],[0,1,0]]
        raw=simpledialog.askstring('Shared Guide',
            'Local guide points as JSON [[x,y,z],…].\nApplied to selected cards; existing shared dependents also update.\nProfiles/sculpt stay intact; use Undo to restore.',
            initialvalue=json.dumps(points),parent=self)
        if raw is None:return
        try:
            from .kernel.guides import set_guide
            points=json.loads(raw)
            # Validate on an independent project record before publishing/history.
            from copy import copy
            from .kernel.scene import fork_project
            trial=fork_project(self.app.project)
            set_guide(trial,points,[c.id for c in cards],source.guide_id)
        except (ValueError,TypeError,KeyError) as ex:
            messagebox.showerror('Guide',str(ex),parent=self);return
        self._history();self.app.project.cards=trial.cards;self.app.project.kernel_data=trial.kernel_data
        self.app.modified=True;self.refresh()

    def _unique_guide(self):
        cards=self._selection()
        if not cards:return
        from copy import copy
        from .kernel.guides import make_unique
        from .kernel.scene import fork_project
        trial=fork_project(self.app.project)
        try:
            for card in cards:make_unique(trial,card.id)
        except ValueError as error:
            self.info.set(str(error));return
        self._history();self.app.project.cards=trial.cards;self.app.project.kernel_data=trial.kernel_data
        self.app.modified=True;self.refresh()

    def _sculpt_layers(self):
        cards=self._selection()
        if len(cards)!=1:
            self.info.set('Select one unlocked card to manage sculpt layers.');return
        cid=cards[0].id
        popup=tk.Toplevel(self);popup.title('Sculpt Layers');popup.geometry('420x350')
        tree=ttk.Treeview(popup,columns=('enabled','samples'),show='tree headings')
        tree.heading('#0',text='Source layer');tree.heading('enabled',text='Enabled');tree.heading('samples',text='Knots')
        tree.column('enabled',width=65);tree.column('samples',width=60);tree.pack(fill='both',expand=True)
        def refresh():
            tree.delete(*tree.get_children())
            card=self._card_lookup.get(cid)
            if card is None:return
            for i,layer in enumerate(card.deformation_layers):
                tree.insert('','end',iid=layer['id'],text=f'Sculpt {i+1}',
                            values=('On' if layer.get('enabled',True) else 'Off',len(layer['u'])))
        def toggle():
            card=self._card_lookup.get(cid)
            if card is None or card.locked:return
            selected=set(tree.selection())
            if not selected:return
            self._history()
            card.deformation_layers=[{**layer,'enabled':not layer.get('enabled',True)} if layer['id'] in selected else layer
                                     for layer in card.deformation_layers]
            self._save_cards();self._render_soon(0);refresh()
        ttk.Button(popup,text='Toggle Selected Layers',command=toggle).pack(fill='x',padx=8,pady=8)
        refresh()

    def _workflow_context(self):
        cards=self._selection()
        active=self._card_lookup.get(self._active_card)
        card=active if any(c is active for c in cards) else next(iter(cards),None)
        return (card.tile_id if card else self.app.current_id,[c.id for c in cards])

    def _on_focus_in(self,event=None):
        if event is not None and event.widget is not self:
            return
        self._refresh_tiles()

    def _refresh_tiles(self):
        self._update_tile_choices()
        self._sync_tile()
        used={c.tile_id for c in self.cards}
        requested=getattr(self,'_atlas_bake_requested',None)
        if requested is None:
            requested={};self._atlas_bake_requested=requested
        # Automatically bake/update any stale or missing atlas tiles on entering Card Editor,
        # prioritizing tiles actively used by cards first.
        ordered=sorted(self.app.project.tiles,key=lambda t:t.id not in used)
        frame_rev=self.app._frame_revision
        for tile in ordered:
            result=self.app._results.get(tile.id)
            version=self.app._atlas._tile_version.get(tile.id)
            sig=(frame_rev,tile.revision,tile.width,tile.height)
            if result is None or result.revision!=tile.revision or version!=(tile.revision,tile.width,tile.height):
                if requested.get(tile.id)!=sig:
                    requested[tile.id]=sig
                    self.app._submit_preview(tile,show_status=False,force_atlas=True)
            else:
                requested[tile.id]=sig

    def _update_tile_choices(self):
        # Resolve by ID when names/order change while this editor stays open.
        previous=getattr(self,'tile_lookup',{}).get(self.tile_choice.get())
        self.tile_lookup={f'{i+1:02d} · {tile.name}':tile.id for i,tile in enumerate(self.app.project.tiles)}
        self.tilebox.configure(values=list(self.tile_lookup))
        self.tile_choice.set(next((label for label,tid in self.tile_lookup.items() if tid==previous),''))
        self.assign_tile_button.configure(state='normal' if self._selection() and self.tile_lookup else 'disabled')

    def _sync_tile(self):
        current=self._selection()
        self.assign_tile_button.configure(state='normal' if current and self.tile_lookup else 'disabled')
        if not current:
            self.tile_assignment_status.set('Choose a default tile for new cards, or select cards to assign.')
            return
        assigned={c.tile_id for c in current}
        if len(assigned)>1:
            self.tile_choice.set('')
            self.tile_assignment_status.set(f'{len(current)} cards · multiple tiles. Choose a tile to replace all.')
            return
        for key,value in self.tile_lookup.items():
            if value==current[0].tile_id:
                self.tile_choice.set(key)
                self.tile_assignment_status.set(f'{len(current)} selected · assigned to {key}')
                return
        self.tile_choice.set('')
        self.tile_assignment_status.set(f'{len(current)} selected · missing tile. Choose a replacement.')

    def _apply_tile(self,e=None):
        tile_id=self.tile_lookup.get(self.tile_choice.get())
        tile=self.app.project.find(tile_id) if tile_id else None
        if tile is None:
            self._update_tile_choices();self._sync_tile()
            return
        cards=self._selection()
        if not cards:return
        if all(c.tile_id==tile_id for c in cards):
            self._sync_tile()
            return
        self._history()
        for c in cards:c.tile_id=tile_id
        self._save_cards(atlas_dirty=True);self._refresh_tree();self._render_soon(0)
        result=self.app._results.get(tile_id)
        if result is None or result.revision!=tile.revision:
            self.tile_assignment_status.set(f'Assigned to {tile.name} · preparing texture…')
            self.app._submit_preview(tile,show_status=False)

    def _refresh_tree(self):
        old=self.tree.selection()
        self.tree.delete(*self.tree.get_children())
        tiles={t.id:t.name for t in self.app.project.tiles}
        for c in self.cards:
            self.tree.insert('', 'end',iid=c.id,
                             text=f'{c.name}  ·  {tiles.get(c.tile_id,"Missing tile")}')
        self._sync_tree()
        self._sync_inspector()

    def _sync_tree(self):
        ids=[cid for cid in self.selected if self.tree.exists(cid)]
        self.tree.selection_set(ids)

    def _tree_select(self,e=None):
        ids=set(self.tree.selection())
        if ids==self.selected:return
        self.selected=ids
        self._active_card=next(iter(ids),None)
        self._sync_inspector();self._render_soon(0)

    def _sync_inspector(self):
        cards=self._selection()
        self._inspector_lock=True
        if cards:
            c=cards[0]
            for key,var in self.property_vars.items():
                val=getattr(c,key)
                var.set(str(val) if isinstance(val,int) else f'{val:.4f}')
            self.root_lock.set(c.locked_root)
        else:
            for var in self.property_vars.values():var.set('—')
        self._sync_tile()
        self._inspector_lock=False

    def _apply_property(self,key):
        if self._inspector_lock:return
        cards=self._selection()
        if not cards:return
        try:
            value=float(self.property_vars[key].get().strip())
            if key in ('segments','width_segments'):value=int(value)
            if not math.isfinite(value):raise ValueError()
        except (ValueError,TypeError):self._sync_inspector();return
        lo,hi=next((p[2],p[3]) for p in PARAMS if p[0]==key)
        value=max(lo,min(hi,value))
        if all(getattr(c,key)==value for c in cards):return
        self._history()
        for c in cards:
            if key=='segments':change_segments(c,int(value))
            elif key=='width_segments':
                from .cards import change_width_segments
                change_width_segments(c,int(value))
            else:setattr(c,key,value)
            c.sanitize()
        self._save_cards();self._sync_inspector();self._render_soon(0)

    def _apply_root_lock(self):
        cards=self._selection()
        if not cards:return
        new=bool(self.root_lock.get())
        if all(c.locked_root==new for c in cards):return
        self._history()
        for c in cards:c.locked_root=new
        self._save_cards()

    def add_card(self):
        if not self.app.project.tiles:
            messagebox.showwarning('No tile','Create a fiber tile first.',parent=self);return
        tid=self.tile_lookup.get(self.tile_choice.get(),self.app.project.tiles[0].id)
        self._history()
        n=len(self.cards)
        c=HairCard.create(tid,f'Card {n+1:03d}',[(n%7-3)*.29,0,-(n//7)*.09])
        c.bend=(n%3-1)*.075
        self.cards.append(c);self.selected={c.id}
        self._save_cards();self._refresh_tree();self._render_soon(0)

    def duplicate(self):
        selected=self._selection()
        if not selected:return
        self._history();news=[c.duplicate() for c in selected]
        self.cards.extend(news);self.selected={c.id for c in news}
        self._save_cards();self._refresh_tree();self._render_soon(0)

    def delete_selected(self):
        editable={c.id for c in self._selection()}
        if not editable:return
        self._history();self.cards=[c for c in self.cards if c.id not in editable]
        self.selected=set();self._save_cards();self._refresh_tree();self._render_soon(0)

    def select_all(self):
        self.selected={c.id for c in self.cards};self._sync_tree();self._sync_inspector();self._render_soon(0)
        return 'break'

    def make_unique(self):
        from .model import Tile
        cards=self._selection()
        if not cards:return
        if len(cards)>24 and not messagebox.askyesno('Make Unique',f'Create {len(cards)} new texture tiles?',parent=self):return
        self._history()
        for c in cards:
            src=self.app.project.find(c.tile_id)
            if src is None:continue
            new=src.clone();new.name=f'{src.name} / {c.name}';self.app.project.tiles.append(new)
            c.tile_id=new.id
        self._save_cards(atlas_dirty=True)
        self.app._invalidate_atlas();self.app._fill_tree()
        self._refresh_tiles();self._render_soon(0)

    def change_segment(self,delta):
        cards=self._selection()
        if not cards:return
        self._history()
        for c in cards:change_segments(c,c.segments+delta)
        self._save_cards();self._sync_inspector();self._render_soon(0)

    def edit_width_profile(self):
        selected=self._selection()
        if not selected:return
        popup=tk.Toplevel(self);popup.title('Card Width Profile  ·  Root → Tip')
        popup.configure(bg=SIDEBAR);popup.geometry('330x340')
        popup.transient(self)
        profile=list(selected[0].width_profile)
        history=[False]
        knobs=[]
        tk.Label(popup,text='Width along the card',bg=SIDEBAR,fg=FG,
                 font=('Segoe UI Semibold',12)).pack(anchor='w',padx=15,pady=(15,8))
        for i,caption in enumerate(['Root','Lower 25%','Middle 50%','Upper 75%','Tip']):
            row=ttk.Frame(popup,style='Panel.TFrame');row.pack(fill='x',padx=12,pady=4)
            ttk.Label(row,text=caption,width=12,style='Panel.TLabel').pack(side='left')
            val=tk.DoubleVar(value=profile[i]);knobs.append(val)
            def modify(value,idx=i):
                if not history[0]:self._history();history[0]=True
                for card in selected:card.width_profile[idx]=float(value)
                if self.view:self.view.changed(selected,time.perf_counter())
                self._scheduler.request(input_event=True)
                self._save_cards()
            slider=NumberSlider(row,from_=.02,to=3.0,step=0.01,variable=val,height=22,command=modify)
            slider.pack(side='right',fill='x',expand=True)
        def finish():
            self._save_cards();self._sync_inspector();self._render_soon(0);popup.destroy()
        ttk.Button(popup,text='Done',command=finish).pack(fill='x',padx=15,pady=14)
        popup.protocol('WM_DELETE_WINDOW',finish);watch_window(popup)

    def reset_overrides(self):
        cards=self._selection()
        if not cards or not any(c.deformation_layers or c.vertex_offsets or any(np.any(k) for k in c.offsets) for c in cards):return
        self._history()
        for c in cards:
            c.vertex_offsets={};c.deformation_layers=[];c.offsets=[[0.,0.,0.] for _ in range(5)]
        self._save_cards();self._render_soon(0)

    def _render_soon(self,delay=32,fast=False):
        # Compatibility arguments intentionally do not debounce or lower quality.
        if self._scheduler:self._scheduler.request()

    def _render_now(self,fast=False):
        self._render_soon(0)

    def _hud_lines(self):
        settings=getattr(self.app,'app_settings',None)
        up_axis=settings.up_axis if settings else 'Y-Up'
        s=self.view.renderer.editor_stats if self.view else None
        fps_str=f'{s.active_fps:.0f} FPS · CPU {s.cpu_ms:.1f}ms' if s else 'Initializing...'
        gpu_str=(f' · GPU {s.gpu_ms:.1f}ms' if (s and s.gpu_ms>=0) else '')
        vis=f'{s.visible_cards}/{s.total_cards}' if s else f'{len(self.cards)}'
        quads=f'{s.quads:,}' if s else f'{sum(c.segments for c in self.cards):,}'
        tris=f'{s.triangles:,}' if s else f'{sum(c.segments*c.width_segments*2 for c in self.cards):,}'
        lines=[
            f'CARD EDITOR · {up_axis} · {self.tool.get()} ({self.selection_mode.get()})',
            f'Cards: {vis} · Sel: {len(self.selected)} · Quads: {quads} · Tris: {tris}',
        ]
        sel=self._selection()
        if sel:
            sel_quads=sum(c.segments*c.width_segments for c in sel)
            sel_tris=sel_quads*2
            c=sel[0]
            dx,dy,dz=to_display_coords(c.root,up_axis)
            if len(sel)==1:
                lines.append(f'{c.name}: Pos ({dx:.2f}, {dy:.2f}, {dz:.2f}) · L {c.length:.2f} · W {c.width:.2f} · Yaw {math.degrees(c.yaw):.1f}°')
            else:
                lines.append(f'Selected ({len(sel)}): Quads {sel_quads:,} · Tris {sel_tris:,} · Active: {c.name}')
        lines.append(fps_str+gpu_str)
        return tuple(lines)

    def _toggle_inline_render(self):
        from .rendercore.inline_preview import toggle
        toggle(self,self.canvas,self.app,'cards')
        self._render_soon(0)

    def _draw_frame(self,received=None):
        panel=getattr(self,'_inline_render',None)
        if panel and panel.winfo_exists():return False
        if not self.canvas.winfo_exists() or self._gpu_error:return False
        try:
            if self.view is None:
                self.view=GPUCardViewport(self.canvas);self.view.reconcile(self.cards)
            if self._atlas_dirty or self.view.renderer._atlas_cache is not self.app._atlas:
                self.view.bind_atlas(self.app._atlas);self._atlas_dirty=False
            more=self.view.frame(self,received)
            s=self.view.renderer.editor_stats
            warning=(' · '+s.gpu_warning) if s.gpu_warning else ''
            self.info.set(f'{s.gpu} · {len(self.selected)} selected / {s.total_cards} cards'+warning)
            if self.show_stats.get():
                self.stats_label.configure(wraplength=max(100,self.canvas.winfo_width()))
                latency_note=' (pending)' if s.input_pending else ''
                vram=f'{s.vram_global_used_mib:.0f} MiB approximate GPU-global' if s.vram_global_used_mib>=0 else 'n/a'
                self.stats_text.set(f'{s.active_fps:.1f} active FPS · CPU {s.cpu_ms:.1f} / GPU {s.gpu_ms:.1f} ms · '
                    f'last applied input→Present {s.input_to_present_return_ms:.1f} ms{latency_note}\n'
                    f'visible {s.visible_cards}/{s.total_cards} · {s.vertices} verts / {s.triangles} tris · '
                    f'{s.draw_calls} API batch calls / {s.subdraws} draw commands\n'
                    f'VB/IB {s.geometry_upload_bytes} B · transforms {s.transform_upload_bytes} B · overlays {s.overlay_upload_bytes} B · atlas {s.atlas_upload_bytes} B · '
                    f'CPU P95/99 {s.cpu_p95_ms:.1f}/{s.cpu_p99_ms:.1f} · GPU P95/99 {s.gpu_p95_ms:.1f}/{s.gpu_p99_ms:.1f}\n'
                    f'{s.physical_width}×{s.physical_height} px · buffers {s.gpu_buffer_reserved_mib:.1f} MiB reserved / '
                    f'tiles {s.tile_payload_mib:.1f} MiB payload · VRAM {vram}\n'
                    f'{self.view.renderer.info.aa_status}')
            return more
        except Exception as exc:
            self._gpu_error=str(exc)
            self.info.set('GPU Card Editor unavailable: '+str(exc))
            return False

    def _toggle_stats(self):
        if self.show_stats.get():self.stats_label.pack(anchor='w',fill='x',padx=10,pady=3)
        else:self.stats_label.pack_forget()
        self._render_soon(0)

    def export_viewport_report(self):
        if self.view is None:return
        path=filedialog.asksaveasfilename(parent=self,title='Viewport telemetry',defaultextension='.json',
                                         filetypes=[('JSON','*.json'),('CSV','*.csv')])
        if path:self.view.export_report(path)

    def _hover(self,event):
        if self.view is None or self._drag or self.navigation.active is not None or self._space:return
        prev_comp=self.view.scene.hover_component
        self.view.hover(event.x,event.y)
        if self.view.scene.hover_component!=prev_comp:
            self._render_soon(0)
            return
        if self._hover_after is None:
            self._hover_after=self.after(35,self._poll_hover)

    def _poll_hover(self):
        self._hover_after=None
        if self.view is None or not self.canvas.winfo_exists() or self._gpu_error:return
        r=self.view.renderer
        if r.poll_hover():
            self._render_soon(0)
        elif r._hover_request is not None or any(s['fence'] for s in r._hover_slots):
            self._hover_after=self.after(35,self._poll_hover)

    def _clear_hover(self):
        if self.view:
            self.view.scene.hover=None;self.view.scene.hover_component=None
            self.view.renderer._hover_request=None;self.view.renderer._latest_pointer=None;self._render_soon(0)

    def _navigation_start(self):
        if self._drag:self._cancel()
        self._clear_hover()

    def _navigation_end(self):
        if self._scheduler:self._scheduler.active(False)
        self._render_soon(0)

    def refresh(self):
        """Called after global undo/redo or project reload."""
        self.cards=[HairCard.from_dict(d) for d in self.app.project.cards]
        self._card_lookup={c.id:c for c in self.cards}
        valid={c.id for c in self.cards};self.selected&=valid
        self.component_selected={cid:v for cid,v in self.component_selected.items() if cid in valid}
        if self.view:self.view.reconcile(self.cards)
        self._atlas_dirty=True
        panel=getattr(self,'_kernel_window',None)
        if panel and panel.winfo_exists():panel.refresh()
        self._refresh_tiles();self._refresh_tree();self._render_soon(0)

    def refresh_texture(self):
        if 'preparing texture' in self.tile_assignment_status.get():
            cards=self._selection()
            if cards:
                result=self.app._results.get(cards[0].tile_id)
                version=self.app._atlas._tile_version.get(cards[0].tile_id)
                if result is not None and version==(result.revision,result.width,result.height):
                    self._sync_tile()
        self._atlas_dirty=True;self._render_soon(0)

    def _pointer_down(self,event):
        self.canvas.focus_set()
        if getattr(self,'_guide_draw',None) is not None:
            if self.view:
                d=self._guide_draw;anchor=np.asarray(self.camera_target,float)
                point=anchor+self.view.world_delta(event.x-self.canvas.winfo_width()/2,event.y-self.canvas.winfo_height()/2,anchor)
                if not d['points'] or np.linalg.norm(point-np.asarray(d['points'][-1]))>1e-5:
                    d['points'].append(point.tolist());self._update_guide_preview()
            return 'break' 
        if self._space:return
        if self._s_down:
            self._drag={'brush_size':True,'x':event.x,'r':self.radius};return
        if self.view is None:return
        self.view.scene.select(self.selected,self.component_selected)
        cid,part=self.view.pick(event.x,event.y,self.selection_mode.get())
        shift=bool(event.state & 0x0001)
        ctrl=bool(event.state & 0x0004)
        mode=self.selection_mode.get()
        if cid:
            self._active_card=cid
            if ctrl:
                if mode=='Card':self.selected.discard(cid)
            elif shift:
                self.selected.add(cid)
            elif cid not in self.selected:
                self.selected={cid}
        elif not shift and not ctrl and not self.brush.get():
            self.selected.clear()
        if mode!='Card' and cid and part is not None:
            if not shift and not ctrl:self.component_selected={}
            parts=self.component_selected.setdefault(cid,set())
            if ctrl:
                parts.discard((mode,part))
            elif shift:
                parts.add((mode,part))
            else:
                parts.add((mode,part))
        elif not shift and not ctrl:self.component_selected={}
        self._sync_tree();self._sync_inspector()
        if self.brush.get():
            hits=self.view.brush_hits(event.x,event.y,pixels(self,self.radius))
            if hits:
                if ctrl: self.selected.difference_update(hits)
                elif shift: self.selected.update(hits)
                else: self.selected=hits
                self._sync_tree();self._sync_inspector()
        if cid is None and not self.brush.get():
            self._drag={'box':True,'x':event.x,'y':event.y,'current_x':event.x,'current_y':event.y,
                        'additive':shift,'subtractive':ctrl,'original_selection':set(self.selected)}
            self.view.scene.selection_box=(event.x,event.y,event.x,event.y)
            self._render_soon(0);return
        if not self.selected or self.tool.get()=='Select':
            self._render_soon(0);return
        snap={c.id:c.fast_copy() for c in self._selection()}
        self._drag={'x':event.x,'y':event.y,'current_x':event.x,'current_y':event.y,'orig':snap,
                    'part':part,'card_id':cid,'history':False,'changed':False,'tool':self.tool.get(),
                    'components':{k:set(v) for k,v in self.component_selected.items()}}
        self._scheduler.request(input_event=True)

    def _pointer_move(self,event):
        received=time.perf_counter()
        d=self._drag
        if d is None:return
        if d.get('box'):
            d['current_x']=event.x;d['current_y']=event.y
            self.view.scene.selection_box=(d['x'],d['y'],event.x,event.y)
            self._scheduler.request(input_event=True);return
        if d.get('brush_size'):
            self.radius=float(np.clip(d['r']+(event.x-d['x'])/(window_dpi(self)/96.),25,320));self.brush_var.set(self.radius);return
        dx=(event.x-d['x']);dy=(event.y-d['y'])
        ratio=window_dpi(self)/96.;dx/=ratio;dy/=ratio
        if abs(dx)+abs(dy)<2:return
        if not d['history']:
            self._history();d['history']=True
        k=.18 if event.state & 0x0001 else 1.
        dx*=k;dy*=k
        targets=self._selection()
        self._apply_drag(d,dx,dy,event.x,event.y,targets=targets)
        d['changed']=True;d['current_x']=event.x;d['current_y']=event.y
        # Geometry jobs coalesce per selected card; presentation never drops texture.
        if self.view:self.view.changed(targets,received)
        self._scheduler.request(input_event=True)

    def _apply_drag(self,drag,dx,dy,x,y,targets=None):
        tool=drag['tool']
        origins=drag['orig']
        # Geometry stays in scene units (approx. 180-240 px / world unit at default zoom).
        unit=.004*self.distance/4.8
        if targets is None:targets=self._selection()
        basis=self.view.world_delta_basis() if (self.view and tool in ('Move','Root','Vertex')) else None
        use_brush=bool(self.brush.get() and self.view)
        brush_r2=max(1.0,pixels(self,self.radius))**2 if use_brush else 1.0
        centroid_x=sum(origins[c.id].root[0] for c in targets)/max(1,len(targets)) if tool=='Spread' else 0.0
        for card in targets:
            source=origins[card.id]
            falloff=1.
            if use_brush:
                p=self.view.screen_center(card.id)
                if p is not None:
                    r2=(x-p[0])**2+(y-p[1])**2
                    falloff=max(0.,1.-r2/brush_r2)**2
            if falloff<=0:continue
            ddx=dx*falloff;ddy=dy*falloff
            component_mode=self.selection_mode.get()
            if tool=='Vertex' or (self.mode.get()=='Mesh' and component_mode!='Card' and tool=='Move'):
                parts=drag.get('components',{}).get(card.id,set())
                if card.id not in drag.get('components',{}) and card.id==drag.get('card_id') and drag.get('part') is not None:
                    parts={(component_mode,drag['part'])}
                indices=set()
                for kind,part in parts:
                    if isinstance(part,tuple):indices.update(part)
                    elif kind=='Vertex':indices.add(int(part))
                    elif kind=='Root':indices.update(range(card.width_segments+1))
                    elif kind=='Row':indices.update(range(int(part)*(card.width_segments+1),(int(part)+1)*(card.width_segments+1)))
                if basis is not None:
                    eye,forward,right,up,k_scale=basis
                    depth=max(.01,float(np.dot(np.asarray(source.root)-eye,forward)))
                    delta=(right*ddx-up*ddy)*(depth*k_scale)
                else:
                    delta=np.array([ddx*unit,-ddy*unit,0])
                for index in indices:
                    if not 0<=index<(card.width_segments+1)*(card.segments+1):continue
                    row,side=divmod(index,card.width_segments+1)
                    if row==0 and card.locked_root and component_mode!='Root':continue
                    key=f'{row}:{side}';base=source.vertex_offsets.get(key,[0.,0.,0.])
                    card.vertex_offsets[key]=[base[0]+float(delta[0]),base[1]+float(delta[1]),base[2]+float(delta[2])]
            elif tool in ('Move','Root'):
                if basis is not None:
                    eye,forward,right,up,k_scale=basis
                    depth=max(.01,float(np.dot(np.asarray(source.root)-eye,forward)))
                    delta=(right*ddx-up*ddy)*(depth*k_scale)
                    card.root=[source.root[0]+float(delta[0]),source.root[1]+float(delta[1]),source.root[2]+float(delta[2])]
                else:
                    card.root=[source.root[0]+ddx*unit,source.root[1]-ddy*unit,source.root[2]]
            elif tool=='Rotate':card.yaw=source.yaw+ddx*.012
            elif tool=='Scale':
                s=max(.05,1+(ddx-ddy)*.005)
                card.length=source.length*s;card.width=source.width*s
            elif tool=='Length':card.length=max(.015,source.length-ddy*unit)
            elif tool=='Width':card.width=max(.002,source.width+ddx*unit)
            elif tool=='Bend':card.bend=source.bend+ddx*.004
            elif tool=='Twist':card.twist=source.twist+ddx*.012
            elif tool=='Lift':card.lift=source.lift-ddy*.006
            elif tool=='Comb':card.tilt=source.tilt+ddx*.008
            elif tool in ('Relax','Smooth'):
                amount=min(.99,(abs(dx)+abs(dy))*.004)
                card.bend=source.bend*(1-amount)
                card.twist=source.twist*(1-amount)
                card.lift=source.lift*(1-.5*amount)
            elif tool=='Spread':
                card.root[0]=source.root[0]+(source.root[0]-centroid_x)*ddx*.008
            elif tool=='Noise':
                sign=1 if int(card.id[:4],16)%2 else -1
                card.bend=source.bend+sign*ddx*.0025
            card.sanitize()

            if getattr(self,'snap_mesh_id',None) and (tool=='Root' or
                (tool=='Move' and not (self.mode.get()=='Mesh' and component_mode!='Card'))):
                self.app.object_workspace.live_snap(self,card)

    def _pointer_up(self,event):
        d=self._drag;self._drag=None
        if self._scheduler:self._scheduler.active(False)
        if d and d.get('box'):
            box=(d['x'],d['y'],d['current_x'],d['current_y'])
            moved=abs(box[2]-box[0])+abs(box[3]-box[1])>=pixels(self,3)
            box_hits=self.view.select_box(box) if moved else set()
            if d.get('subtractive'):
                self.selected=d['original_selection']-box_hits
            elif d.get('additive'):
                self.selected=d['original_selection']|box_hits
            else:
                self.selected=box_hits
            self.view.scene.selection_box=None;self.component_selected={}
            self._sync_tree();self._sync_inspector();self._render_soon(0);return
        if d and d.get('changed'):
            dx=d['current_x']-d['x'];dy=d['current_y']-d['y']
            ratio=window_dpi(self)/96.;dx/=ratio;dy/=ratio
            self._last_transform=(d['tool'],dx,dy)
            self._save_cards();self._sync_inspector()
            if getattr(self,'snap_mesh_id',None) and d.get('tool') in ('Move','Root'):
                try:
                    self.app.object_workspace.snap(self,self.snap_mesh_id,False,
                        getattr(self,'snap_offset',.002),getattr(self,'snap_max_distance',float('inf')))
                except ValueError:pass
        self._render_soon(25)

    def repeat_last(self):
        if not self._last_transform or not self.selected or self._last_transform[0]=='Vertex':return
        tool,dx,dy=self._last_transform
        self._history()
        d={'tool':tool,'orig':{c.id:deepcopy(c) for c in self._selection()},'part':None}
        self._apply_drag(d,dx,dy,0,0)
        self._save_cards();self._sync_inspector();self._render_soon(0)

    def _right_menu(self,event):
        menu=tk.Menu(self,tearoff=0,bg=CARD,fg=FG,activebackground='#5c4c38')
        for label,cmd in [('Add Card',self.add_card),('Duplicate',self.duplicate),('Delete',self.delete_selected),
                          ('Make Tile Unique',self.make_unique),('Insert Row',lambda:self.change_segment(1)),
                          ('Remove Row',lambda:self.change_segment(-1)),('Reset Overrides',self.reset_overrides)]:
            menu.add_command(label=label,command=cmd)
        menu.tk_popup(event.x_root,event.y_root)
        menu.grab_release()

    def _pie_press(self,event):
        if self._entry_focused(event):return
        if self._space:return 'break'
        self._space=True
        x,y=self.canvas.winfo_pointerxy();x-=self.canvas.winfo_rootx();y-=self.canvas.winfo_rooty()
        self._pie_origin=(x,y);self._pie_visible=False
        self._pie_after=self.after(150,self._show_pie)
        return 'break'

    def _show_pie(self):
        if not self._space or self._pie_origin is None:return
        self._pie_visible=True
        self._hide_pie()
        cx,cy=self._pie_origin
        w=self.canvas.winfo_width();h=self.canvas.winfo_height()
        margin=pixels(self,145)
        cx=max(margin,min(w-margin,cx));cy=max(margin,min(h-margin,cy))
        self._pie_origin=(cx,cy)
        # A separate UI popup; the GPU surface never receives Canvas geometry.
        size=margin*2
        popup=tk.Toplevel(self);popup.withdraw();popup.overrideredirect(True)
        popup.transient(self)
        popup.geometry(f'{size}x{size}{self.canvas.winfo_rootx()+int(cx)-margin:+d}{self.canvas.winfo_rooty()+int(cy)-margin:+d}')
        menu=tk.Canvas(popup,width=size,height=size,bg=SIDEBAR,highlightthickness=1,highlightbackground=ACCENT)
        menu.pack(fill='both',expand=True)
        self._pie_window=popup
        cx=cy=margin
        r=pixels(self,39)
        menu.create_oval(cx-r,cy-r,cx+r,cy+r,fill='#4a4f59',outline=ACCENT,width=max(1,pixels(self,1)))
        menu.create_text(cx,cy,text=self.mode.get()+'\nSpace',fill=FG,justify='center',font=('Segoe UI',font_pixels(self,9)))
        for i,name in enumerate(PIES[self.mode.get()]):
            a=math.radians(-90+i*60)
            px=cx+pixels(self,101)*math.cos(a);py=cy+pixels(self,101)*math.sin(a)
            rx,ry=pixels(self,40),pixels(self,22)
            menu.create_oval(px-rx,py-ry,px+rx,py+ry,fill='#454a52',outline='#747a84')
            menu.create_text(px,py,text=name,fill=FG,font=('Segoe UI',font_pixels(self,10),'bold'))
        popup.deiconify();popup.lift()

    def _hide_pie(self):
        if self._pie_window is not None:
            self._pie_window.destroy();self._pie_window=None

    def _pie_release(self,event):
        if not self._space:return
        self._space=False
        if self._pie_after:
            self.after_cancel(self._pie_after);self._pie_after=None
        if self._pie_origin:
            x,y=self.canvas.winfo_pointerxy();x-=self.canvas.winfo_rootx();y-=self.canvas.winfo_rooty()
            ox,oy=self._pie_origin;dx=x-ox;dy=y-oy
            if math.hypot(dx,dy)>pixels(self,34):
                angle=math.degrees(math.atan2(dy,dx))
                slot=round((angle+90)/60)%6
                name=PIES[self.mode.get()][slot]
                self._set_tool(name)
        self._hide_pie()
        self._pie_origin=None;self._pie_visible=False
        return 'break'

    def _s_press(self,event):
        if self._entry_focused(event):return
        self._s_down=True
    def _s_release(self,event):self._s_down=False

    def _cancel(self):
        if getattr(self,'_guide_draw',None) is not None:self.finish_guide_draw(False);return 'break'
        if self._space:
            self._space=False;self._pie_origin=None
            if self._pie_after:self.after_cancel(self._pie_after)
            self._hide_pie()
        if self._drag:
            d=self._drag
            if d.get('box') and self.view:
                self.view.scene.selection_box=None;self.selected=d['original_selection']
            if d.get('changed'):
                self.cards=[deepcopy(d['orig'][c.id]) if c.id in d['orig'] else c for c in self.cards]
                self._save_cards()
                if d.get('history') and self.app._undo:
                    self.app._undo.pop()
            self._drag=None
            self._render_soon(0)
        if self._scheduler:self._scheduler.active(False)
        return 'break'

    def _nav_orbit(self,dx,dy):
        self.yaw-=dx*.008
        self.pitch=float(np.clip(self.pitch+dy*.006,-1.2,1.2))
        self._scheduler.request(input_event=True)
    def _nav_pan(self,dx,dy):
        # Same projection used by the editor GPU and component queries.
        import math
        h=max(100,self.canvas.winfo_height());w=max(100,self.canvas.winfo_width())
        fov=2*math.atan(h/(2*max(100,min(w,h)*1.45)))
        self.camera_target=pan_target(self.camera_target,self.yaw,self.pitch,self.distance,h,dx,dy,fov)
        self._scheduler.request(input_event=True)
    def _nav_dolly(self,dx,dy):self._zoom_factor(dolly_factor(dx))
    def _zoom(self,event):self._zoom_factor(.86 if event.delta>0 else 1.16)
    def _zoom_factor(self,m):
        distance=self.distance*float(m)
        if not math.isfinite(distance) or distance<=0:return
        # No scene-scale upper limit; keep only a small positive orbit distance.
        self.distance=max(1e-5,distance)
        self._scheduler.request(input_event=True)
    def frame_all(self):
        self.yaw=-.18;self.pitch=.10
        if self.view:self.camera_target,self.distance=self.view.focus_bounds()
        else:self.camera_target=[0.,.7,0.];self.distance=4.8
        self._render_soon(0)
    def frame_selected(self):
        if not self.selected:self.frame_all();return
        if self.view:
            self.camera_target,self.distance=self.view.focus_bounds(self.selected);self._render_soon(0);return
        arr=np.array([c.root for c in self._selection()]);spread=np.max(arr,axis=0)-np.min(arr,axis=0)
        self.camera_target=list(np.mean(arr,axis=0)+[0,.5,0])
        self.distance=float(max(spread[0],spread[1],spread[2],1.)*3.2)
        self._render_soon(0)

    def _undo(self):self.app._undo_action();return 'break'
    def _redo(self):self.app._redo_action();return 'break'

    def export(self):
        folder=filedialog.askdirectory(parent=self,title='Export OBJ / MTL and cached atlas preview')
        if not folder:return
        try:
            path=export_obj(self.cards,self.app.project,self.app._atlas,folder)
            messagebox.showinfo('OBJ exported',f'{path}\n\nFor full quality textures, also use Export Atlas in Fiber Studio.',parent=self)
        except Exception as ex:messagebox.showerror('OBJ export failed',str(ex),parent=self)

    def pause(self):
        if self._scheduler:
            self._scheduler.active(False)
        if getattr(self,'_hover_after',None):
            try:self.after_cancel(self._hover_after)
            except tk.TclError:pass
            self._hover_after=None

    def resume(self):
        self.refresh()
        self._render_soon(0)

    def _close(self):
        self.pause()
        panel=getattr(self,'_inline_render',None)
        if panel and panel.winfo_exists():panel.destroy();self._inline_render=None
        kernel_window=getattr(self,'_kernel_window',None)
        if kernel_window is not None and kernel_window.winfo_exists():kernel_window.close()
        easy=getattr(self,'_easy_shape',None)
        if easy is not None and easy.winfo_exists():easy.close()
        self.app.card_window=None
        if self._scheduler:self._scheduler.close()
        if self._pie_after:
            try:self.after_cancel(self._pie_after)
            except tk.TclError:pass
        if self._hover_after:
            try:self.after_cancel(self._hover_after)
            except tk.TclError:pass
        self._hide_pie()
        try:
            if self.view:self.view.close()
        finally:self.view=None;self.destroy()
