"""Small, reversible shape controls over the existing card model, no tile bake."""
from copy import deepcopy
import math
import tkinter as tk
from tkinter import ttk
import numpy as np
from .cards import HairCard
from .number_slider import NumberSlider,change_segments

SHAPE_FIELDS=('length','width','bend','lift','twist','tilt','taper','width_profile','offsets')
PRESETS={
    'Natural Flow':dict(bend=.12,lift=.08,twist=.16,taper=.52,profile=[.8,1.,1.,.8,.45]),
    'Soft C':dict(bend=.3,lift=.03,twist=0.,taper=.4,profile=[.85,1.,1.,.9,.65]),
    'S Curve':dict(bend=0.,lift=.06,twist=.18,taper=.5,profile=[.8,1.,.95,.8,.5],sway=.2),
    'Leaf':dict(bend=.08,lift=.12,twist=.12,taper=.85,profile=[.45,1.2,1.4,1.,.35]),
    'Fine Tuft':dict(bend=.06,lift=.05,twist=.25,taper=.92,profile=[1.,1.1,.9,.55,.2]),
    'Flat Ribbon':dict(bend=0.,lift=0.,twist=0.,taper=.1,profile=[1.]*5),
}
CONTROLS=(('side','Side Sweep',-.5,.5),('depth','Depth / Puff',-.5,.5),
          ('wave','S Flow',-.4,.4),('length','Length Change · %',-60,100),
          ('width','Width Change · %',-75,150),('twist','Twist Change · °',-180,180),
          ('taper','Tip Taper Change',-.8,.8),('fullness','Middle Fullness',-.7,1.5))


def sculpt(source,values,region):
    c=HairCard.from_dict(source.to_dict())
    t=np.linspace(0,1,5)
    weight={'Whole':t,'Root':(1-t)**2,'Middle':np.sin(np.pi*t)**2,'Tip':t*t}[region].copy()
    if c.locked_root:weight[0]=0.
    lateral=np.array([math.cos(c.yaw),0.,-math.sin(c.yaw)])
    direction=np.array([math.sin(c.tilt),math.cos(c.tilt),0.])
    front=np.cross(lateral,direction);front/=max(np.linalg.norm(front),1e-8)
    offsets=np.asarray(c.offsets,dtype=float)
    offsets+=c.length*(values['side']*weight+values['wave']*np.sin(2*np.pi*t)*t)[:,None]*lateral
    offsets+=c.length*values['depth']*weight[:,None]*front
    c.offsets=offsets.tolist()
    c.length*=1+values['length']/100
    c.width*=1+values['width']/100
    c.twist+=math.radians(values['twist'])
    c.taper+=values['taper']
    c.width_profile=(np.asarray(c.width_profile)*(1+values['fullness']*np.sin(np.pi*t)**2)).tolist()
    c.sanitize()
    return c


class EasyShape(tk.Toplevel):
    def __init__(self,editor):
        super().__init__(editor)
        self.editor=editor;self.title('Easy Shape · Hair Cards');self.geometry('410x740')
        self.origins={};self.variables={};self.entries={};self.transaction=False;self.lock=False
        self.region=tk.StringVar(value='Tip');self.mix=tk.DoubleVar(value=1.)
        self.note=tk.StringVar()
        ttk.Label(self,textvariable=self.note,wraplength=380).pack(fill='x',padx=12,pady=8)
        ttk.Button(self,text='Use Current Selection',command=self.rebase).pack(fill='x',padx=12)
        tabs=ttk.Notebook(self);tabs.pack(fill='both',expand=True,padx=10,pady=8)
        quick=ttk.Frame(tabs,padding=10);shape=ttk.Frame(tabs,padding=10)
        tabs.add(quick,text='Beautiful Shapes');tabs.add(shape,text='Shape Controls')
        shape_canvas=tk.Canvas(shape,highlightthickness=0)
        shape_scroll=ttk.Scrollbar(shape,orient='vertical',command=shape_canvas.yview)
        shape_scroll.pack(side='right',fill='y');shape_canvas.pack(fill='both',expand=True)
        shape_canvas.configure(yscrollcommand=shape_scroll.set)
        shape=ttk.Frame(shape_canvas,padding=8)
        window=shape_canvas.create_window((0,0),window=shape,anchor='nw')
        shape.bind('<Configure>',lambda e:shape_canvas.configure(scrollregion=shape_canvas.bbox('all')))
        shape_canvas.bind('<Configure>',lambda e:shape_canvas.itemconfigure(window,width=e.width))
        ttk.Label(quick,text='Pick a shape, then refine in Shape Controls.',wraplength=340).pack(pady=8)
        for name in PRESETS:
            ttk.Button(quick,text=name,command=lambda n=name:self.preset(n)).pack(fill='x',pady=5)
        ttk.Label(quick,text='Preset blend · 0 keeps shape, 1 replaces parametric shape').pack(pady=(15,2))
        NumberSlider(quick,variable=self.mix,from_=0,to=1,step=0.01,height=22).pack(fill='x')
        ttk.Button(quick,text='Smooth Silhouette · 12 Rows',command=self.refine).pack(fill='x',pady=8)
        ttk.Label(quick,text='Roots, placement, tile and painted vertex details stay intact.\nPresets work on all cards captured by Use Current Selection.',wraplength=340).pack(pady=12)
        ttk.Label(shape,text='Sweep / Puff region').pack(anchor='w')
        region=ttk.Combobox(shape,textvariable=self.region,values=['Whole','Root','Middle','Tip'],state='readonly')
        region.pack(fill='x',pady=4)
        region.bind('<<ComboboxSelected>>',lambda e:self.apply_once())
        for key,label,lo,hi in CONTROLS:
            row=ttk.Frame(shape);row.pack(fill='x',pady=3)
            ttk.Label(row,text=label).pack(side='left')
            var=tk.DoubleVar(value=0.);self.variables[key]=var
            def on_change(v,k=key):
                self.begin()
                self.update(k)
                self.end()
            slider=NumberSlider(row,variable=var,from_=lo,to=hi,step=0.01,width=155,height=22,command=on_change)
            slider.pack(side='right',fill='x',expand=True)
            self.entries[key]=var
        footer=ttk.Frame(self,padding=10);footer.pack(fill='x')
        ttk.Button(footer,text='Undo',command=self.undo).pack(side='left')
        ttk.Button(footer,text='Rebase Controls',command=lambda:self.rebase(True)).pack(side='left',padx=6)
        ttk.Button(footer,text='Done',command=self.close).pack(side='right')
        self.protocol('WM_DELETE_WINDOW',self.close)
        self.rebase()

    def rebase(self,keep_targets=False):
        self.end();self.lock=True
        cards=self.targets() if keep_targets else self.editor._selection()
        self.origins={c.id:HairCard.from_dict(c.to_dict()) for c in cards}
        for key,var in self.variables.items():var.set(0.);self.entries[key].set('0')
        self.lock=False
        self.note.set(f'{len(self.origins)} cards · live preview · root lock respected\nDrag to shape, type for precision. One Undo per drag.')

    def targets(self):
        return [self.editor._card_lookup[cid] for cid in self.origins if cid in self.editor._card_lookup and not self.editor._card_lookup[cid].locked]

    def begin(self):
        if not self.transaction and self.targets():
            self.editor._history();self.transaction=True

    def end(self):
        if self.transaction:
            self.editor._save_cards();self.editor._sync_inspector();self.editor._render_soon(0)
            self.transaction=False

    def update(self,key=None):
        if self.lock:return
        if key:self.entries[key].set(f'{self.variables[key].get():.3g}')
        self.begin()
        values={k:v.get() for k,v in self.variables.items()}
        for card in self.targets():
            shaped=sculpt(self.origins[card.id],values,self.region.get())
            for field in SHAPE_FIELDS:setattr(card,field,deepcopy(getattr(shaped,field)))
        if self.editor.view:self.editor.view.changed(self.targets())
        self.editor._render_soon(0)

    def apply_once(self):
        self.update();self.end()

    def numeric(self,key,lo,hi):
        try:
            value=float(self.entries[key].get().replace(',','.'))
            if not math.isfinite(value):raise ValueError()
        except ValueError:
            self.entries[key].set(f'{self.variables[key].get():.3g}');return
        value=max(lo,min(hi,value))
        if abs(value-self.variables[key].get())<1e-9:return
        self.lock=True;self.variables[key].set(value);self.lock=False
        self.update(key);self.end()

    def preset(self,name):
        self.end()
        amount=self.mix.get()
        if amount<=0:return
        self.begin();p=PRESETS[name]
        for card in self.targets():
            for field in ('bend','lift','twist','taper'):
                setattr(card,field,(1-amount)*getattr(card,field)+amount*p[field])
            offsets=np.zeros((5,3))
            t=np.linspace(0,1,5)
            lateral=np.array([math.cos(card.yaw),0.,-math.sin(card.yaw)])
            offsets+=p.get('sway',0.)*card.length*(np.sin(2*np.pi*t)*t)[:,None]*lateral
            if card.locked_root:offsets[0]=card.offsets[0]
            card.offsets=((1-amount)*np.asarray(card.offsets)+amount*offsets).tolist()
            card.width_profile=((1-amount)*np.asarray(card.width_profile)+amount*np.asarray(p['profile'])).tolist()
            card.sanitize()
        self.end();self.rebase(True)

    def refine(self):
        self.end()
        cards=[c for c in self.targets() if c.segments<12]
        if not cards:return
        self.begin()
        for card in cards:change_segments(card,12)
        self.end();self.rebase(True)

    def undo(self):
        self.end();self.editor.app._undo_action();self.rebase(True)

    def close(self):
        self.end();self.destroy()
