"""Shared Maya-style viewport navigation, independent of editing tools."""
import math

ALT_MASK = 0x0008 | 0x20000  # X11 Mod1 / Windows Tk Alt
HELP = 'Alt + LMB: rotate  ·  Alt + MMB: pan  ·  Alt + RMB horizontal: zoom'


def dolly_factor(dx):
    """Rightward drag approaches the subject; vertical movement has no effect."""
    return math.exp(max(-20., min(20., -float(dx) * .01)))


def pan_target(target, yaw, pitch, distance, height, dx, dy, fov=math.pi/4):
    """Translate an orbit pivot in the camera plane, keeping rotation unchanged."""
    scale = 2 * distance * math.tan(fov/2) / max(1, height)
    right = (math.cos(yaw), 0., -math.sin(yaw))
    up = (-math.sin(yaw)*math.sin(pitch), math.cos(pitch), -math.cos(yaw)*math.sin(pitch))
    return [target[i] + (-dx*right[i] + dy*up[i])*scale for i in range(3)]


def rotate_point(x, y, cx, cy, angle):
    a = math.radians(angle)
    c, s = math.cos(a), math.sin(a)
    return cx+(x-cx)*c+(y-cy)*s, cy-(x-cx)*s+(y-cy)*c


def rotate_overlays(canvas, cx, cy, angle, tag=None):
    """Rotate 2D selection overlays with the displayed image, preserving picking."""
    if not angle:
        return
    items = canvas.find_withtag(tag) if tag else canvas.find_all()
    for item in items:
        kind = canvas.type(item)
        if kind == 'image':
            continue
        coords = canvas.coords(item)
        if kind == 'rectangle':
            x, y, x2, y2 = coords
            points = [rotate_point(px, py, cx, cy, angle) for px, py in ((x,y),(x2,y),(x2,y2),(x,y2))]
            canvas.create_polygon(*[v for p in points for v in p], fill=canvas.itemcget(item,'fill'),
                                  outline=canvas.itemcget(item,'outline'), width=canvas.itemcget(item,'width'),
                                  tags=canvas.gettags(item))
            canvas.delete(item)
        elif kind == 'oval':
            x, y, x2, y2 = coords
            mx, my = rotate_point((x+x2)/2, (y+y2)/2, cx, cy, angle)
            canvas.coords(item, mx-(x2-x)/2, my-(y2-y)/2, mx+(x2-x)/2, my+(y2-y)/2)
        else:
            canvas.coords(item, *[v for i in range(0,len(coords),2)
                                 for v in rotate_point(coords[i],coords[i+1],cx,cy,angle)])
            if kind == 'text':
                canvas.itemconfigure(item, angle=angle)


class MayaNavigation:
    """A leading bindtag consumes Alt gestures before selection/sculpt/context menus.

    Gesture ownership is latched on press, so releasing Alt before the mouse
    cannot accidentally edit geometry. Ordinary mouse events keep their handlers.
    """
    def __init__(self, widget, orbit, pan, dolly, on_start=None, on_end=None):
        self.widget = widget
        self.actions = {1: orbit, 2: pan, 3: dolly}
        self.on_start, self.on_end = on_start, on_end
        self.active = None
        self.last = (0, 0)
        self.tag = f'MayaNavigation_{id(self)}'
        widget.bindtags((self.tag, *widget.bindtags()))
        self.sequences = []
        for button in (1, 2, 3):
            self._bind(f'<ButtonPress-{button}>', lambda e, b=button: self.press(e,b))
            self._bind(f'<B{button}-Motion>', self.move)
            self._bind(f'<ButtonRelease-{button}>', lambda e, b=button: self.release(e,b))
        self._bind('<FocusOut>', lambda e: self.cancel())
        self._bind('<Escape>', lambda e: self.cancel())
        widget.bind('<Destroy>', self._destroy, add='+')

    def _bind(self, sequence, callback):
        self.sequences.append(sequence)
        self.widget.bind_class(self.tag, sequence, callback)

    def press(self, event, button):
        if self.active is not None:
            return 'break'
        if not event.state & ALT_MASK:
            return
        self.widget.focus_set()
        if self.on_start:
            self.on_start()
        self.active = button
        self.last = (event.x, event.y)
        return 'break'

    def move(self, event):
        if self.active is None:
            return
        dx, dy = event.x-self.last[0], event.y-self.last[1]
        self.last = (event.x, event.y)
        if self.active in (1,3) and getattr(self.widget._root(),'dpi_manager',None):
            from .dpi import window_dpi
            ratio=window_dpi(self.widget)/96.
            dx/=ratio;dy/=ratio
        action = self.actions[self.active]
        if self.active == 1:
            shift = bool(event.state & 0x0001)
            try:
                action(dx, dy, snap=shift)
            except TypeError:
                action(dx, dy)
        else:
            action(dx, dy)
        return 'break'

    def release(self, event, button):
        if self.active is None:
            return
        if button == self.active:
            self.move(event)
            self.cancel()
        return 'break'

    def cancel(self):
        if self.active is not None:
            self.active = None
            if self.on_end:
                self.on_end()

    def _destroy(self, event):
        if event.widget == self.widget:
            self.active = None
            for seq in self.sequences:
                self.widget.unbind_class(self.tag,seq)
