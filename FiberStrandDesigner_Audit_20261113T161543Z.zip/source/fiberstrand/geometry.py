"""Deterministic strand geometry in tile-local coordinates.

All random variation is derived from stable identity and independent per strand.
This makes the first N strands unchanged when increasing strand count.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterator
import colorsys
import math
import numpy as np
from .model import Tile, stable_int


@dataclass
class Strand:
    sid: str
    points: np.ndarray  # N x 2 normalized tile coordinates, root to tip
    radii: np.ndarray  # N radii in reference pixels (512px tile width)
    color_root: np.ndarray  # RGB linear? values 0..1 in output sRGB for artistic painter
    color_mid: np.ndarray
    color_tip: np.ndarray
    depth: float
    roughness: float
    guard: bool
    layer: str
    pattern_phase: float = 0.0
    opacity: float = 1.0
    sampled_colors: np.ndarray | None = None  # graph-sampled per-point pigment
    depth_profile: np.ndarray | None = None


def hex_rgb(text: str) -> np.ndarray:
    return np.array([int(text[x:x+2],16) / 255 for x in (1,3,5)],dtype=np.float32)


def hsv_to_rgb_batch(hsv: np.ndarray) -> np.ndarray:
    """Vectorized HSV->RGB matching colorsys.hsv_to_rgb for shape (..., 3)."""
    arr = np.asarray(hsv, dtype=np.float64)
    h = np.mod(arr[..., 0], 1.0)
    s = np.clip(arr[..., 1], 0.0, 1.0)
    v = np.clip(arr[..., 2], 0.0, 1.0)
    hf = h * 6.0
    i = np.floor(hf).astype(np.int32)
    f = hf - i
    p = v * (1.0 - s)
    q = v * (1.0 - s * f)
    t = v * (1.0 - s * (1.0 - f))
    i_mod = np.mod(i, 6)
    r = np.choose(i_mod, (v, q, p, p, t, v))
    g = np.choose(i_mod, (t, v, v, q, p, p))
    b = np.choose(i_mod, (p, p, t, v, v, q))
    zero_s = (s == 0.0)
    if np.any(zero_s):
        r = np.where(zero_s, v, r)
        g = np.where(zero_s, v, g)
        b = np.where(zero_s, v, b)
    return np.stack((r, g, b), axis=-1).astype(np.float32)


def recommended_detail(tile: Tile, base: int = 22) -> int:
    """Return Nyquist-safe point count along each strand for curl/frizz frequencies."""
    s = tile.settings.sanitize()
    detail = max(8, int(base))
    if abs(float(s.curl)) > 1e-4:
        detail = max(detail, int(math.ceil(float(s.curl_frequency) * 8.0)) + 2)
    if abs(float(s.frizz)) > 1e-4:
        nodes = max(3, int(s.frizz_frequency + 2))
        detail = max(detail, nodes * 3)
    return min(96, detail)


def color_jitter(rgb: np.ndarray, rng: np.random.Generator, hue: float, sat: float, value: float) -> np.ndarray:
    h,s,v = colorsys.rgb_to_hsv(float(rgb[0]), float(rgb[1]), float(rgb[2]))
    h = (h + float(rng.normal(0, hue / 2))) % 1.0
    s = s + float(rng.normal(0, sat / 3))
    s = 0.0 if s < 0.0 else (1.0 if s > 1.0 else s)
    v = v * (1.0 + float(rng.normal(0, value / 3)))
    v = 0.0 if v < 0.0 else (1.0 if v > 1.0 else v)
    return np.array(colorsys.hsv_to_rgb(h, s, v), dtype=np.float32)


def width_profile(t: np.ndarray, root: float, taper: float, tip_width: float, bulge: float) -> np.ndarray:
    # End width is independent and an exact zero if requested.
    t = np.asarray(t, dtype=np.float32)
    linear_taper = (1.0 - t)**taper
    mid_factor = np.maximum(.02, 1.0 + bulge * 4 * t*(1-t))
    return np.maximum(0.0, root * (tip_width + (1-tip_width)*linear_taper) * mid_factor)


def smooth_noise(t: np.ndarray, rng: np.random.Generator, nodes: int) -> np.ndarray:
    xp = np.linspace(0, 1, max(3,nodes))
    random_values = rng.normal(0,1,len(xp)).astype(np.float32)
    random_values[0] = 0
    # smooth discrete random noise with local cubic smootherstep between nodes
    j = np.clip(np.searchsorted(xp,t,side="right")-1,0,len(xp)-2)
    local_t = (t-xp[j])/(xp[j+1]-xp[j])
    f = local_t**2*(3-2*local_t)
    output = random_values[j]*(1-f)+random_values[j+1]*f
    return output.astype(np.float32)


def guide_centers(tile: Tile):
    s = tile.settings
    macro = []
    for i in range(s.macro_clumps):
        rng = np.random.default_rng(stable_int(tile.seed,"macro",i))
        x = .10 + .80*((i + .5)/s.macro_clumps)
        x += float(rng.uniform(-.16,.16)) / max(1,math.sqrt(s.macro_clumps))
        macro.append((float(np.clip(x,.08,.92)),float(rng.normal(.0,.18)),float(rng.normal(.0,.2))))
    micro = []
    for i in range(s.micro_clumps):
        rng = np.random.default_rng(stable_int(tile.seed,"micro",i))
        parent = i % len(macro)
        base = macro[parent]
        x = np.clip(base[0] + rng.normal(0,.09), .07, .93)
        micro.append((float(x),parent,float(rng.normal(0,.12))))
    return macro,micro


def _get_override(tile: Tile, index: int) -> dict:
    # Stable key independent of thread/process and tile count.
    return tile.overrides.get(str(index), {})


def generate_strands(tile: Tile, detail: int = 22, should_cancel=None, *, _skip_color: bool = False) -> list[Strand]:
    if tile.kind == "feather":
        return list(generate_feather(tile, detail, should_cancel, _skip_color=_skip_color))
    s = tile.settings.sanitize()
    root_color,mid_color,tip_color = hex_rgb(s.color_root),hex_rgb(s.color_mid),hex_rgb(s.color_tip)
    macro,micro = guide_centers(tile)
    n_micro = len(micro)
    t = np.linspace(0,1,max(8,int(detail)),dtype=np.float32)
    nodes = max(3, int(s.frizz_frequency + 2))
    xp = np.linspace(0, 1, nodes)
    j_idx = np.clip(np.searchsorted(xp, t, side="right") - 1, 0, nodes - 2)
    local_t = (t - xp[j_idx]) / (xp[j_idx + 1] - xp[j_idx])
    f_noise = (local_t ** 2 * (3.0 - 2.0 * local_t)).astype(np.float32)
    one_minus_f = (1.0 - f_noise).astype(np.float32)

    base_radii = (width_profile(t, 1.0, s.taper, s.tip_width, s.mid_bulge) *
                  np.interp(t, np.linspace(0, 1, 5), s.width_profile)).astype(np.float32)

    is_hair = (tile.kind == "hair")
    is_fuzz = (tile.kind == "fuzz")
    is_stylized = (tile.kind == "stylized")
    curl_gain = 0.28 if is_hair else 0.48
    root_mix = s.clump_attraction * (0.93 if is_hair else 0.55)
    common_phases = [float(np.random.default_rng(stable_int(tile.seed, "curl-phase", m)).uniform(-np.pi, np.pi))
                     for m in range(n_micro)] if is_hair else None

    hsv_r = colorsys.rgb_to_hsv(float(root_color[0]), float(root_color[1]), float(root_color[2]))
    hsv_m = colorsys.rgb_to_hsv(float(mid_color[0]), float(mid_color[1]), float(mid_color[2]))
    hsv_t = colorsys.rgb_to_hsv(float(tip_color[0]), float(tip_color[1]), float(tip_color[2]))
    hue_half = s.hue_variation * 0.5
    sat_third = s.saturation_variation / 3.0
    val_third = s.value_variation / 3.0

    N = s.count
    if N <= 0:
        return []
    overrides = tile.overrides
    seed_val = tile.seed
    tile_id = tile.id

    root_x_arr = np.empty(N, np.float32)
    tip_x_arr = np.empty(N, np.float32)
    length_arr = np.empty(N, np.float32)
    root_y_arr = np.empty(N, np.float32)
    c_ph_arr = np.empty(N, np.float32)
    s_ph_arr = np.empty(N, np.float32)
    cy_ph_arr = np.empty(N, np.float32)
    sy_ph_arr = np.empty(N, np.float32)
    rv_arr = np.empty((N, nodes), np.float32)
    rad_mult_arr = np.empty(N, np.float32)
    ov_indices = []
    meta = []

    def _jitter(hsv, rng):
        h = (hsv[0] + float(rng.normal(0, hue_half))) % 1.0
        ss = hsv[1] + float(rng.normal(0, sat_third))
        ss = 0.0 if ss < 0.0 else (1.0 if ss > 1.0 else ss)
        vv = hsv[2] * (1.0 + float(rng.normal(0, val_third)))
        vv = 0.0 if vv < 0.0 else (1.0 if vv > 1.0 else vv)
        return np.array(colorsys.hsv_to_rgb(h, ss, vv), dtype=np.float32)

    k = 0
    for index in range(N):
        if should_cancel and index % 16 == 0 and should_cancel():
            raise RuntimeError('Render cancelled')
        ov = overrides.get(str(index)) if overrides else None
        if ov and ov.get("hidden", False):
            continue
        rng = np.random.default_rng(stable_int(seed_val, "strand", index))
        midx = index % n_micro
        guide_x, parent, guide_slope = micro[midx]
        macro_x, macro_slope, macro_bend = macro[parent]

        standalone = rng.uniform(.06, .94)
        rx = standalone * (1.0 - root_mix) + guide_x * root_mix
        rx = .5 + (rx - .5) * s.root_spread + float(rng.normal(0, .014))

        is_flyaway = bool(rng.random() < s.flyaway)
        guard = bool(rng.random() < s.guard_ratio)
        layer = "flyaway" if is_flyaway else ("guard" if guard else "undercoat")

        l_norm = 1.0 + float(rng.normal(0, s.length_variation * .47))
        length_scale = .18 if l_norm < .18 else (2.4 if l_norm > 2.4 else l_norm)
        ln = s.length * length_scale
        if guard: ln *= s.guard_length
        if is_flyaway: ln *= 1.15
        if is_fuzz: ln *= .66
        if ov: ln *= float(ov.get("length_scale", 1.0))
        ln = .018 if ln < .018 else (.94 if ln > .94 else float(ln))

        ry_norm = .93 + float(rng.normal(0, .022))
        ry = .85 if ry_norm < .85 else (.97 if ry_norm > .97 else ry_norm)

        local_angle = s.root_angle * .23 + macro_slope * .18 + guide_slope * .14 + float(rng.normal(0, .10))
        if is_flyaway: local_angle += float(rng.normal(0, .35))

        ct_raw = guide_x + (macro_bend + s.bend) * .12
        clump_target = .06 if ct_raw < .06 else (.94 if ct_raw > .94 else ct_raw)
        tx = rx + local_angle * ln + (clump_target - rx) * s.clump_tip * .90

        phase = (common_phases[midx] + float(rng.normal(0, .23))) if is_hair else float(rng.uniform(-np.pi, np.pi))

        rv = rng.normal(0, 1, nodes).astype(np.float32)
        rv[0] = 0.0
        y_ph = float(rng.uniform(0, 2.0 * np.pi))

        w = s.root_width * (1.0 + float(rng.normal(0, s.width_variation * .40)))
        if guard: w *= s.guard_width
        if is_stylized: w *= 1.10
        if ov: w *= float(ov.get("width_scale", 1.0))

        if _skip_color:
            rng.normal(0, 1, 9)
            c0 = c1 = c2 = root_color
        else:
            c0 = _jitter(hsv_r, rng)
            c1 = _jitter(hsv_m, rng)
            c2 = _jitter(hsv_t, rng)
        if ov and ov.get("color"):
            try: c0 = c1 = c2 = hex_rgb(str(ov["color"]))
            except (ValueError, IndexError): pass

        depth = float(rng.random())
        r_val = s.roughness + float(rng.normal(0, .09))
        r_val = 0.0 if r_val < 0.0 else (1.0 if r_val > 1.0 else r_val)
        pat_ph = float(rng.random())
        op_raw = s.strand_opacity * (float(ov.get("opacity", 1.0)) if ov else 1.0)
        op = 0.0 if op_raw < 0.0 else (1.0 if op_raw > 1.0 else float(op_raw))

        root_x_arr[k] = rx
        tip_x_arr[k] = tx
        length_arr[k] = ln
        root_y_arr[k] = ry
        c_ph_arr[k] = math.cos(phase)
        s_ph_arr[k] = math.sin(phase)
        cy_ph_arr[k] = math.cos(y_ph)
        sy_ph_arr[k] = math.sin(y_ph)
        rv_arr[k] = rv
        rad_mult_arr[k] = (.1 if w < .1 else w) * .5
        if ov: ov_indices.append((k, ov))
        meta.append((index, c0, c1, c2, depth, r_val, guard, layer, pat_ph, op))
        k += 1

    if k == 0:
        return []
    from .fiberbake_x.evaluation import fiber_points
    gpu_geometry=fiber_points(s,tile.kind,t,root_x_arr[:k],tip_x_arr[:k],length_arr[:k],root_y_arr[:k],c_ph_arr[:k],s_ph_arr[:k],cy_ph_arr[:k],sy_ph_arr[:k],rv_arr[:k],rad_mult_arr[:k],ov_indices,j_idx,f_noise)
    if gpu_geometry is not None:
        pts_all,radii_all=gpu_geometry;pts_all.setflags(write=False);radii_all.setflags(write=False)
    else:
        t_row = t[None, :]
        sin_pi_t = np.sin(np.pi * t_row).astype(np.float32)
        bend_curve = (s.bend * .18 * sin_pi_t).astype(np.float32)
        curl_w = (2.0 * np.pi * s.curl_frequency * t_row).astype(np.float32)
        sin_curl_w = np.sin(curl_w).astype(np.float32)
        cos_curl_w = np.cos(curl_w).astype(np.float32)
        sag_curve = ((s.sag * .16) * (t_row ** 2)).astype(np.float32)
        twist_curve = (s.twist * .07 * np.sin(2.0 * np.pi * (s.curl_frequency * .5) * t_row) * (t_row ** .8)).astype(np.float32)
        frizz_gain = (s.frizz * .085 * (np.maximum(0.0, sin_pi_t) ** .4)).astype(np.float32)
    
        rx_v = root_x_arr[:k, None]
        tx_v = tip_x_arr[:k, None]
        ln_v = length_arr[:k, None]
        ry_v = root_y_arr[:k, None]
    
        base_x = rx_v + (tx_v - rx_v) * t_row + bend_curve * ln_v
        sway = (s.curl * curl_gain) * (sin_curl_w * c_ph_arr[:k, None] + cos_curl_w * s_ph_arr[:k, None]) * sin_pi_t
        rv_k = rv_arr[:k]
        noise = rv_k[:, j_idx] * one_minus_f[None, :] + rv_k[:, j_idx + 1] * f_noise[None, :]
        x_all = base_x + sway + twist_curve + frizz_gain * noise
        y_all = ry_v - ln_v * t_row + sag_curve + (.004 * s.curl) * (sin_curl_w * cy_ph_arr[:k, None] + cos_curl_w * sy_ph_arr[:k, None])
    
        if ov_indices:
            knots5 = np.linspace(0, 1, 5)
            sin_pi_t_t = (sin_pi_t[0] * t).astype(np.float32)
            for ki, ov in ov_indices:
                ov_nodes = ov.get("curve_nodes")
                if isinstance(ov_nodes, list) and len(ov_nodes) == 5:
                    try:
                        warp = np.array(ov_nodes, dtype=np.float32)
                        if warp.shape == (5, 2) and np.isfinite(warp).all():
                            x_all[ki] += np.interp(t, knots5, warp[:, 0])
                            y_all[ki] += np.interp(t, knots5, warp[:, 1])
                    except (ValueError, TypeError):
                        pass
                if "offset_x" in ov: x_all[ki] += float(ov["offset_x"])
                if "offset_y" in ov: y_all[ki] += float(ov["offset_y"])
                if "bend_add" in ov: x_all[ki] += float(ov["bend_add"]) * sin_pi_t_t
    
        # Guarantee margin bounds so strands and their thickness never clip at tile boundaries:
        # Curves + stroke radius are strictly kept within [0.035, 0.965] in X and [0.030, 0.970] in Y.
        # Non-linear adaptive squeeze maintains interior dynamics while strictly bounding tips and outer curls.
        xmin = x_all.min(axis=1, keepdims=True)
        xmax = x_all.max(axis=1, keepdims=True)
        span = xmax - xmin
        wide = (span > .90)
        x_wide = .5 + (x_all - (xmin + xmax) * .5) * (.90 / np.maximum(span, 1e-8))
        x_shift = x_all + (np.maximum(0.0, .05 - xmin) - np.maximum(0.0, xmax - .95))
        x_all = np.where(wide, x_wide, x_shift)
        x_all = np.clip(x_all, 0.035, 0.965)
    
        ymin = y_all.min(axis=1, keepdims=True)
        ymax = y_all.max(axis=1, keepdims=True)
        y_all += np.maximum(0.0, .035 - ymin)
        y_all -= np.maximum(0.0, ymax - .965)
        y_all = np.clip(y_all, 0.030, 0.970)
    
        pts_all = np.stack((x_all, y_all), axis=-1).astype(np.float32)
        radii_all = (rad_mult_arr[:k, None] * base_radii[None, :]).astype(np.float32)
        pts_all.setflags(write=False)
        radii_all.setflags(write=False)
    
    output = []
    for ki in range(k):
        idx, c0, c1, c2, depth, r_val, guard, layer, pat_ph, op = meta[ki]
        output.append(Strand(sid=f"{tile_id}:{idx}", points=pts_all[ki], radii=radii_all[ki],
                             color_root=c0, color_mid=c1, color_tip=c2,
                             depth=depth, roughness=r_val, guard=guard, layer=layer,
                             pattern_phase=pat_ph, opacity=op))
    return output


def _vdc(number: int) -> float:
    # Van der Corput ordering keeps existing feather barbs stationary as count grows.
    value = 0.0
    factor = 0.5
    while number:
        value += (number % 2) * factor
        number //= 2
        factor *= 0.5
    return value


def _generate_feather_reference(tile: Tile, detail: int = 24, should_cancel=None, *, _skip_color: bool = False) -> Iterator[Strand]:
    s = tile.settings.sanitize()
    root, mid, tip = hex_rgb(s.color_root), hex_rgb(s.color_mid), hex_rgb(s.color_tip)
    knots5 = np.linspace(0.0, 1.0, 5, dtype=np.float32)
    shaft_x = 0.50
    shaft_y0 = 0.95
    length = min(0.90, s.length)
    t = np.linspace(0.0, 1.0, max(12, int(detail)), dtype=np.float32)
    center_x = shaft_x + s.bend * 0.12 * np.sin(np.pi * t) * t
    center_y = shaft_y0 - length * t
    shaft = np.column_stack((center_x, center_y)).astype(np.float32)
    root_rad = max(0.5, s.root_width * 0.70)
    shaft_radius = (width_profile(t, root_rad, 0.85, 0.08, 0.1) * np.interp(t, knots5, s.width_profile)).astype(np.float32)
    yield Strand(f"{tile.id}:0", shaft, shaft_radius, root, mid, tip,
                 0.92, s.roughness, True, "rachis", opacity=s.strand_opacity)
    n = s.count
    if n <= 0:
        return
    alpha = np.linspace(0.0, 1.0, max(9, int(detail) // 2), dtype=np.float32)
    alpha_pow86 = (alpha ** 0.86).astype(np.float32)
    alpha_pow15 = (alpha ** 1.5).astype(np.float32)
    alpha_3pi = (alpha * (3.0 * math.pi)).astype(np.float32)
    base_barb_radius = (width_profile(alpha, 1.0, 0.75, 0.01, 0.1) * np.interp(alpha, knots5, s.width_profile)).astype(np.float32)
    barbule_base_radius = width_profile(np.array([0.0, 1.0], dtype=np.float32), 1.0, 0.85, 0.01, 0.0)
    barbule_count = s.feather_barbules
    barbule_u = [0.20 + 0.60 * (k + 0.5) / max(1, barbule_count) for k in range(barbule_count)]
    seed_val = tile.seed
    tile_id = tile.id
    overrides = tile.overrides
    frizz_gain = s.frizz * 0.015
    len_var = s.length_variation * 0.18
    f_width = s.feather_width * 0.43
    f_asym = s.feather_asymmetry * 0.5
    base_thick = max(0.45, s.root_width * 0.28)
    for index in range(1, n + 1):
        if should_cancel and index % 16 == 0 and should_cancel():
            raise RuntimeError('Render cancelled')
        ov = overrides.get(str(index), {})
        if ov.get("hidden", False):
            continue
        rng = np.random.default_rng(stable_int(seed_val, "feather", index))
        side = -1 if index % 2 == 0 else 1
        u = 0.11 + 0.80 * _vdc((index - 1) // 2 + 1)
        u = 0.04 if u < 0.04 else (0.97 if u > 0.97 else u)
        base_x = float(np.interp(u, t, center_x))
        base_y = float(np.interp(u, t, center_y))
        envelope = math.sin(math.pi * u) ** 0.85
        scale_rnd = 1.0 + float(rng.normal(0.0, len_var))
        scale_rnd = 0.6 if scale_rnd < 0.6 else (1.5 if scale_rnd > 1.5 else scale_rnd)
        width = f_width * envelope * (1.0 + side * f_asym) * scale_rnd
        if u > 0.85:
            width *= max(0.12, (1.0 - u) / 0.15)
        tip_x = float(np.clip(base_x + side * width, 0.04, 0.96))
        tip_y = float(np.clip(base_y - length * (0.07 + 0.08 * (1.0 - u)), 0.04, 0.96))
        x = np.clip((base_x + (tip_x - base_x) * alpha_pow86).astype(np.float32), 0.035, 0.965)
        y = np.clip((base_y + (tip_y - base_y) * alpha).astype(np.float32), 0.030, 0.970)
        phase_rnd = float(rng.random())
        if frizz_gain != 0.0:
            x = np.clip(x + (side * frizz_gain) * np.sin(alpha_3pi + phase_rnd) * alpha_pow15, 0.035, 0.965)
        nodes = ov.get("curve_nodes")
        if isinstance(nodes, list) and len(nodes) == 5:
            try:
                warp = np.array(nodes, dtype=np.float32)
                if warp.shape == (5, 2) and np.isfinite(warp).all():
                    x = np.clip(x + np.interp(alpha, knots5, warp[:, 0]), 0.035, 0.965)
                    y = np.clip(y + np.interp(alpha, knots5, warp[:, 1]), 0.030, 0.970)
            except (ValueError, TypeError):
                pass
        ox = float(ov.get("offset_x", 0.0))
        oy = float(ov.get("offset_y", 0.0))
        if ox != 0.0:
            x = np.clip(x + ox, 0.035, 0.965)
        if oy != 0.0:
            y = np.clip(y + oy, 0.030, 0.970)
        thick = base_thick * float(ov.get("width_scale", 1.0))
        radius = base_barb_radius * thick
        if _skip_color:
            rng.normal(0.0, 1.0, 9)
            c0 = root
            c1 = mid
            c2 = tip
        else:
            c0 = color_jitter(root, rng, s.hue_variation, s.saturation_variation, s.value_variation)
            c1 = color_jitter(mid, rng, s.hue_variation, s.saturation_variation, s.value_variation)
            c2 = color_jitter(tip, rng, s.hue_variation, s.saturation_variation, s.value_variation)
        if ov.get("color"):
            try:
                c0 = c1 = c2 = hex_rgb(ov["color"])
            except (ValueError, IndexError):
                pass
        depth = 0.1 + float(rng.random()) * 0.70
        pat_ph = float(rng.random())
        yield Strand(f"{tile_id}:{index}", np.column_stack((x, y)).astype(np.float32),
                     radius, c0, c1, c2, depth, s.roughness, False, "barb", pat_ph,
                     opacity=s.strand_opacity)
        if barbule_count > 0:
            br = barbule_base_radius * max(0.22, thick * 0.38)
            dx_b = side * width * 0.09
            dy_b = -length * 0.008
            for k, bu in enumerate(barbule_u):
                px = float(np.interp(bu, alpha, x))
                py = float(np.interp(bu, alpha, y))
                pts = np.array([[px, py], [px + dx_b, py + dy_b]], dtype=np.float32)
                yield Strand(f"{tile_id}:{index}:{k}", pts, br, c0, c1, c2,
                             0.04, s.roughness, False, "barbule", opacity=s.strand_opacity)


def generate_feather(tile: Tile,detail: int=24,should_cancel=None,*,_skip_color: bool=False):
    from .fiberbake_x.feather import generate
    value=generate(tile,detail,should_cancel,_skip_color)
    if value is not None:yield from value
    else:yield from _generate_feather_reference(tile,detail,should_cancel,_skip_color=_skip_color)
