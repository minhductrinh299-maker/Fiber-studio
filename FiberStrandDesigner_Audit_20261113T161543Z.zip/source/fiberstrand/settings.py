"""Global application settings, coordinate system helpers, and Settings UI."""
from __future__ import annotations

from dataclasses import dataclass, asdict
import json
from pathlib import Path
import tkinter as tk
from tkinter import ttk
from typing import Callable

UP_AXES = ("Y-Up", "Z-Up")
SETTINGS_PATH = Path.home() / ".fsd_settings.json"


@dataclass
class AppSettings:
    up_axis: str = "Y-Up"
    show_hud: bool = True
    show_axis_gizmo: bool = True
    show_grid: bool = True
    render_studio_topmost: bool = True
    fast_drag_viewport: bool = True
    default_atlas_size: int = 2048
    default_padding: int = 8

    def sanitize(self) -> "AppSettings":
        if self.up_axis not in UP_AXES:
            self.up_axis = "Y-Up"
        self.show_hud = bool(self.show_hud)
        self.show_axis_gizmo = bool(self.show_axis_gizmo)
        self.show_grid = bool(self.show_grid)
        self.render_studio_topmost = bool(self.render_studio_topmost)
        self.fast_drag_viewport = bool(self.fast_drag_viewport)
        try:
            sz = int(self.default_atlas_size)
        except (TypeError, ValueError):
            sz = 2048
        self.default_atlas_size = max(512, min(8192, sz))
        try:
            pad = int(self.default_padding)
        except (TypeError, ValueError):
            pad = 8
        self.default_padding = max(0, min(64, pad))
        return self

    @classmethod
    def load(cls, path: Path = SETTINGS_PATH) -> "AppSettings":
        try:
            if path.exists():
                raw = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    valid = {k: v for k, v in raw.items() if k in cls.__dataclass_fields__}
                    return cls(**valid).sanitize()
        except Exception:
            pass
        return cls().sanitize()

    def save(self, path: Path = SETTINGS_PATH) -> None:
        self.sanitize()
        try:
            path.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")
        except Exception:
            pass


def to_display_coords(xyz, up_axis: str = "Y-Up") -> tuple[float, float, float]:
    """Convert canonical internal Y-Up (x, y, z) to display convention without moving objects."""
    x, y, z = float(xyz[0]), float(xyz[1]), float(xyz[2])
    if up_axis == "Z-Up":
        return (x, -z, y)
    return (x, y, z)


def from_display_coords(xyz, up_axis: str = "Y-Up") -> tuple[float, float, float]:
    """Convert display convention back to canonical internal Y-Up (x, y, z)."""
    x, y, z = float(xyz[0]), float(xyz[1]), float(xyz[2])
    if up_axis == "Z-Up":
        return (x, z, -y)
    return (x, y, z)


class SettingsDialog(tk.Toplevel):
    """Unified Settings window for coordinate system, HUD, gizmo, atlas, and performance."""

    def __init__(self, app, on_apply: Callable[[], None] | None = None):
        super().__init__(app)
        self.app = app
        self.on_apply = on_apply
        self.title("Fiber Strand Designer  ·  SETTINGS")
        self.geometry("460x470")
        self.resizable(False, False)
        self.configure(bg="#18191d")
        self.transient(app)

        s = app.app_settings
        self.up_axis_var = tk.StringVar(value=s.up_axis)
        self.show_hud_var = tk.BooleanVar(value=s.show_hud)
        self.show_gizmo_var = tk.BooleanVar(value=s.show_axis_gizmo)
        self.show_grid_var = tk.BooleanVar(value=s.show_grid)
        self.topmost_var = tk.BooleanVar(value=s.render_studio_topmost)
        self.fast_drag_var = tk.BooleanVar(value=s.fast_drag_viewport)
        self.atlas_size_var = tk.StringVar(value=str(app.project.atlas_size))
        self.padding_var = tk.StringVar(value=str(app.project.padding))

        self._build()
        self.grab_set()
        self.focus_set()

    def _build(self):
        pad = dict(padx=16, pady=6)
        hdr = ttk.Frame(self, padding=(16, 14))
        hdr.pack(fill="x")
        ttk.Label(hdr, text="APPLICATION SETTINGS", font=("Segoe UI Semibold", 13)).pack(anchor="w")
        ttk.Label(
            hdr,
            text="Configure coordinate system, viewport HUD, gizmo, and project defaults.",
            foreground="#a7a096",
        ).pack(anchor="w", pady=(2, 0))

        body = ttk.Frame(self, style="Panel.TFrame", padding=(16, 12))
        body.pack(fill="both", expand=True, padx=14, pady=(0, 10))

        # Section: 3D Coordinate System
        ttk.Label(body, text="3D COORDINATE SYSTEM", style="Panel.TLabel", font=("Segoe UI Semibold", 10)).pack(
            anchor="w", pady=(2, 4)
        )
        row_axis = ttk.Frame(body, style="Panel.TFrame")
        row_axis.pack(fill="x", pady=4)
        ttk.Label(row_axis, text="Up Axis (keeps object positions)", style="Panel.TLabel").pack(side="left")
        ttk.Combobox(
            row_axis,
            textvariable=self.up_axis_var,
            values=list(UP_AXES),
            state="readonly",
            width=10,
        ).pack(side="right")

        ttk.Separator(body).pack(fill="x", pady=10)

        # Section: Viewport Overlays
        ttk.Label(body, text="VIEWPORT DISPLAY & HUD", style="Panel.TLabel", font=("Segoe UI Semibold", 10)).pack(
            anchor="w", pady=(0, 4)
        )
        for text, var in (
            ("Show top-left HUD info display", self.show_hud_var),
            ("Show corner axis gizmo (X / Y / Z)", self.show_gizmo_var),
            ("Show 3D floor grid", self.show_grid_var),
        ):
            tk.Checkbutton(
                body,
                text=text,
                variable=var,
                bg="#202228",
                fg="#ecebe8",
                selectcolor="#282b33",
                activebackground="#202228",
                activeforeground="#ecebe8",
            ).pack(anchor="w", pady=2)

        ttk.Separator(body).pack(fill="x", pady=10)

        # Section: Windows & Performance
        ttk.Label(body, text="WINDOW & PERFORMANCE", style="Panel.TLabel", font=("Segoe UI Semibold", 10)).pack(
            anchor="w", pady=(0, 4)
        )
        for text, var in (
            ("Render Studio always on top", self.topmost_var),
            ("Fast interactive Card Editor transforms", self.fast_drag_var),
        ):
            tk.Checkbutton(
                body,
                text=text,
                variable=var,
                bg="#202228",
                fg="#ecebe8",
                selectcolor="#282b33",
                activebackground="#202228",
                activeforeground="#ecebe8",
            ).pack(anchor="w", pady=2)

        ttk.Separator(body).pack(fill="x", pady=10)

        # Section: Atlas Project Settings
        ttk.Label(body, text="PROJECT ATLAS SETTINGS", style="Panel.TLabel", font=("Segoe UI Semibold", 10)).pack(
            anchor="w", pady=(0, 4)
        )
        row_atlas = ttk.Frame(body, style="Panel.TFrame")
        row_atlas.pack(fill="x", pady=3)
        ttk.Label(row_atlas, text="Atlas Size (px)", style="Panel.TLabel").pack(side="left")
        ttk.Combobox(
            row_atlas,
            textvariable=self.atlas_size_var,
            values=["512", "1024", "2048", "4096"],
            state="readonly",
            width=10,
        ).pack(side="right")

        row_pad = ttk.Frame(body, style="Panel.TFrame")
        row_pad.pack(fill="x", pady=3)
        ttk.Label(row_pad, text="Tile Padding / Gutter (px)", style="Panel.TLabel").pack(side="left")
        ttk.Combobox(
            row_pad,
            textvariable=self.padding_var,
            values=["0", "2", "4", "8", "16", "32"],
            state="readonly",
            width=10,
        ).pack(side="right")

        btns = ttk.Frame(self, padding=(14, 6))
        btns.pack(fill="x", side="bottom", pady=(0, 10))
        ttk.Button(btns, text="Cancel", command=self.destroy).pack(side="right", padx=(6, 0))
        ttk.Button(btns, text="Apply", command=self._apply).pack(side="right", padx=4)
        ttk.Button(btns, text="OK", style="Accent.TButton", command=self._ok).pack(side="right", padx=4)

    def _apply(self):
        s = self.app.app_settings
        s.up_axis = self.up_axis_var.get()
        s.show_hud = bool(self.show_hud_var.get())
        s.show_axis_gizmo = bool(self.show_gizmo_var.get())
        s.show_grid = bool(self.show_grid_var.get())
        s.render_studio_topmost = bool(self.topmost_var.get())
        s.fast_drag_viewport = bool(self.fast_drag_var.get())
        try:
            new_atlas_size = max(512, min(8192, int(self.atlas_size_var.get())))
        except ValueError:
            new_atlas_size = self.app.project.atlas_size
        try:
            new_padding = max(0, min(64, int(self.padding_var.get())))
        except ValueError:
            new_padding = self.app.project.padding
        s.default_atlas_size = new_atlas_size
        s.default_padding = new_padding
        s.save()

        atlas_changed = (
            self.app.project.atlas_size != new_atlas_size
            or self.app.project.padding != new_padding
        )
        if atlas_changed:
            self.app._history()
            self.app.project.atlas_size = new_atlas_size
            self.app.project.padding = new_padding
            self.app._invalidate_atlas()
            if self.app.mode.get() == "Atlas":
                for tile in self.app.project.tiles:
                    self.app._submit_preview(tile, show_status=False)

        if self.on_apply:
            self.on_apply()

    def _ok(self):
        self._apply()
        self.destroy()
