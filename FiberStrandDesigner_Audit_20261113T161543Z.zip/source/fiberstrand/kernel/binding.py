"""Shared attachment evaluation for editor, renderer, bake/export snapshots."""
from copy import deepcopy
import hashlib
import numpy as np
from .attachments import topology_signature,InvalidAnchor


def object_matrix(obj):
    matrix=np.eye(4);matrix[:3,:3]*=obj.get('scale',1);matrix[:3,3]=obj.get('position',[0,0,0]);return matrix


def frame(anchor,objects,joints=None):
    kind=anchor.get('kind','free')
    if kind=='free':return np.eye(4)
    obj=next((o for o in objects if o['id']==anchor['object_id']),None)
    if obj is None:raise InvalidAnchor('Attachment target was deleted')
    transform=object_matrix(obj)
    if kind=='object':return transform
    if kind=='joint':
        key=(obj['id'],anchor['joint'])
        if not joints or key not in joints:raise InvalidAnchor('Joint pose is unavailable; evaluate its animation source first')
        return transform@np.asarray(joints[key])
    if kind not in ('surface','skinned'):raise InvalidAnchor('Unknown attachment kind')
    vertices=np.asarray(obj['vertices'],float);faces=np.asarray(obj['triangles'],np.int32)
    if (obj.get('_topology_signature') or topology_signature(vertices,faces))!=anchor['topology']:raise InvalidAnchor('Topology changed: remap attachment explicitly')
    tri=vertices[faces[anchor['face']]]
    tri=(np.column_stack((tri,np.ones(3)))@transform.T)[:,:3]
    x=tri[1]-tri[0];z=np.cross(x,tri[2]-tri[0])
    if np.linalg.norm(x)<1e-10 or np.linalg.norm(z)<1e-10:raise InvalidAnchor('Degenerate surface anchor')
    x/=np.linalg.norm(x);z/=np.linalg.norm(z);y=np.cross(z,x)
    matrix=np.eye(4);matrix[:3,:3]=np.column_stack((x,y,z))
    matrix[:3,3]=np.asarray(anchor['barycentric'])@tri+z*anchor.get('offset',0)
    return matrix


def bind(card,obj,point,kind='surface',offset=0.,joint=None,joints=None):
    anchor=dict(kind=kind,object_id=obj['id'],offset=float(offset))
    if kind in ('surface','skinned'):
        from ..surface_snap import SurfaceBVH
        bvh=SurfaceBVH(obj);hit=bvh.nearest(point)
        if hit is None:raise InvalidAnchor('Cannot bind empty surface')
        target=hit[0]
        triangles=bvh.triangles
        from ..surface_snap import closest
        # BVH gives a point; resolve a stable face using bounded batches.
        best=float('inf');face=0
        for begin in range(0,len(triangles),4096):
            tri=triangles[begin:begin+4096]
            a,b,c=tri[:,0],tri[:,1],tri[:,2]
            ab,ac=b-a,c-a;n=np.cross(ab,ac);n2=np.sum(n*n,1)
            ap=target-a;d0=np.sum(ab*ab,1);d1=np.sum(ab*ac,1);d2=np.sum(ac*ac,1)
            denom=np.maximum(d0*d2-d1*d1,1e-30)
            u=(np.sum(ap*ab,1)*d2-np.sum(ap*ac,1)*d1)/denom
            v=(np.sum(ap*ac,1)*d0-np.sum(ap*ab,1)*d1)/denom
            error=np.sum((a+u[:,None]*ab+v[:,None]*ac-target)**2,1)
            valid=(u>=-1e-6)&(v>=-1e-6)&(u+v<=1+1e-6)&(n2>1e-20)
            error[~valid]=np.inf;i=int(np.argmin(error))
            if error[i]<best:best=error[i];face=begin+i;weights=[1-u[i]-v[i],u[i],v[i]]
        if not np.isfinite(best):raise InvalidAnchor('Could not resolve barycentric anchor')
        anchor.update(face=int(face),barycentric=np.clip(weights,0,1).tolist(),topology=topology_signature(obj['vertices'],obj['triangles']))
        w=np.asarray(anchor['barycentric']);anchor['barycentric']=(w/w.sum()).tolist()
    elif kind=='joint':anchor['joint']=joint or ''
    matrix=frame(anchor,[obj],joints)
    anchor['bind_frame']=matrix.tolist();anchor['id']='attachment:'+__import__('uuid').uuid4().hex
    return anchor


def resolved_card(card,objects,joints=None,strict=False):
    overrides=[m for m in card.modifiers if m.get('enabled',True) and m.get('op') in ('attach','bind')]
    if not card.attachment and not overrides:return card
    result=card.fast_copy()
    if overrides:result.attachment=deepcopy(overrides[-1].get('params',{}).get('anchor'))
    if not result.attachment:return result
    anchor=result.attachment
    try:matrix=frame(anchor,objects,joints)@np.linalg.inv(np.asarray(anchor['bind_frame']))
    except InvalidAnchor as error:
        if strict:raise
        anchor.pop('_evaluated_matrix',None);anchor['_invalid_reason']=str(error)
        return result
    anchor.pop('_invalid_reason',None)
    anchor['_evaluated_matrix']=matrix.tolist()
    return result
