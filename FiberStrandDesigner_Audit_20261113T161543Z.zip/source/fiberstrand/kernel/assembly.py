"""Universal guide assemblies. Feather is a hierarchy of ordinary branch guides."""
import hashlib
import uuid
import numpy as np
from .registry import Registry
from .surface import transport
from .card_surface import profile


def identity(namespace,*parts):
    return hashlib.blake2b((namespace+':'+':'.join(map(str,parts))).encode(),digest_size=12).hexdigest()


def sample_guide(points,u):
    points=np.asarray(points,float)
    lengths=np.r_[0,np.cumsum(np.linalg.norm(np.diff(points,axis=0),axis=1))]
    if lengths[-1]<1e-10:raise ValueError('Zero-length guide')
    k=lengths/lengths[-1]
    position=np.array([np.interp(u,k,points[:,axis]) for axis in range(3)])
    tangent,normal,binormal=transport(points)
    t=np.array([np.interp(u,k,tangent[:,axis]) for axis in range(3)]);t/=np.linalg.norm(t)
    n=np.array([np.interp(u,k,normal[:,axis]) for axis in range(3)]);n-=t*(n@t);n/=np.linalg.norm(n)
    return position,np.column_stack((n,t,np.cross(n,t)))


def evaluate_guide(records,id,cache=None):
    cache={} if cache is None else cache
    if id in cache:return cache[id]
    record=records[id]
    if record['kind']!='guide':raise ValueError('Not a guide: '+id)
    p=record['payload']
    if 'legacy_source' in p:
        from ..cards import HairCard,_legacy_ribbon_mesh
        source=records.get(p.get('origin_card_id'),{}).get('payload',{}).get('source',p['legacy_source'])
        from .operations import evaluate_card_modifiers
        card=evaluate_card_modifiers(HairCard.from_dict(source));card.deformation_layers=[];card.vertex_offsets={}
        points=_legacy_ribbon_mesh(card)[3].astype(float)
    else:points=np.array(p['points'],float)
    parent=p.get('parent')
    if parent:
        base=evaluate_guide(records,parent,cache)
        position,frame=sample_guide(base,float(p.get('parent_u',0)))
        points=points@frame.T+position
    for modifier in p.get('modifiers',[]):
        if not modifier.get('enabled',True):continue
        op=modifier['op'];params=modifier.get('params',{});t=np.linspace(0,1,len(points))
        if op in ('deform','groom'):
            points[:,0]+=float(params.get('bend',0))*np.sin(np.pi*t)
            points[:,2]+=float(params.get('lift',0))*t*t
        elif op=='transform':
            matrix=np.asarray(params.get('matrix',np.eye(4)),float)
            points=(np.column_stack((points,np.ones(len(points))))@matrix.T)[:,:3]
        elif op=='clump':
            target=evaluate_guide(records,params['guide'],cache)
            sampled=np.stack([sample_guide(target,u)[0] for u in t])
            weight=profile(params.get('strength',[0,1]),t)
            points=points*(1-weight[:,None])+sampled*weight[:,None]
        else:raise ValueError('Unsupported guide operation: '+op)
    transport(points);cache[id]=points
    return points


def create_assembly(registry,workflow='Hair',count=12,seed=42,id=None):
    if workflow not in ('Hair','Fur','Free Fiber','Feather'):raise ValueError('Unknown workflow preset')
    if not 1<=count<=20000:raise ValueError('Assembly count must be 1..20000')
    if workflow=='Feather' and 1+4*count>20000:raise ValueError('Feather is limited to 4999 barbs / 20000 total strand structures')
    aid=id or 'assembly:'+uuid.uuid4().hex;rng=np.random.default_rng(seed)
    guide_ids=[];structure_ids=[];t=np.linspace(0,1,12)
    with registry.transaction('Create '+workflow) as edit:
        rachis=identity(aid,'rachis')
        if workflow=='Feather':
            points=np.column_stack((.06*np.sin(np.pi*t),t,np.zeros(len(t))))
            edit.put('guide',dict(points=points.tolist(),role='rachis'),id=rachis);guide_ids.append(rachis)
            shaft=identity(aid,'rachis-structure');structure_ids.append(shaft)
            edit.put('structure',dict(guide_id=rachis,radius=[.015,.002],attributes={
                'color':[[.22,.14,.07],[.6,.4,.2]],'roughness':[.5,.5],'opacity':[1,1]}),inputs=[rachis],id=shaft)
        for index in range(count):
            gid=identity(aid,'guide',index);parent=None;inputs=[]
            if workflow=='Feather':
                u=.08+.84*(index//2+.5)/max(1,(count+1)//2);side=-1 if index%2 else 1
                length=.4*np.sin(np.pi*u)
                points=np.column_stack((side*length*t,.12*t,np.zeros(len(t))))
                parent=rachis;inputs=[rachis]
                payload=dict(points=points.tolist(),parent=parent,parent_u=float(u),role='barb')
            else:
                root=rng.uniform(-.4,.4,3);root[1]=0
                length=.4 if workflow=='Fur' else 1.
                points=np.column_stack((.06*np.sin(2*np.pi*t+rng.uniform(0,6))*t,length*t,.04*np.sin(np.pi*t)))+root
                payload=dict(points=points.tolist(),role='strand-guide')
            edit.put('guide',payload,inputs=inputs,id=gid);guide_ids.append(gid)
            sid=identity(aid,'structure',index);structure_ids.append(sid)
            edit.put('structure',dict(guide_id=gid,radius=[.012,.001],
                attributes={'color':[[.18,.1,.05],[.55,.35,.18]],'opacity':[1,1],
                            'roughness':[.5,.5],'specular':[.5,.5],'anisotropy':[.8,.8],
                            'transmission':[.2,.2],'scatter':[.2,.2],'iridescence':[0,0]}),inputs=[gid],id=sid)
            if workflow=='Feather':
                for branch in range(3):
                    child=identity(aid,'barbule',index,branch);cu=(branch+1)/4
                    cp=np.column_stack((.035*t,.055*t,np.zeros(len(t))))
                    edit.put('guide',dict(points=cp.tolist(),parent=gid,parent_u=cu,role='barbule'),inputs=[gid],id=child)
                    guide_ids.append(child)
                    bs=identity(aid,'barbule-structure',index,branch);structure_ids.append(bs)
                    edit.put('structure',dict(guide_id=child,radius=[.002,.0002],attributes={
                        'color':[[.24,.15,.08],[.6,.4,.2]],'roughness':[.5,.5],'opacity':[1,1]}),inputs=[child],id=bs)
        edit.put('assembly',dict(workflow=workflow,seed=seed,guides=guide_ids,structures=structure_ids),
                 inputs=guide_ids+structure_ids,id=aid)
    return aid


def interpolate_guides(records,a,b,weight=.5,samples=24):
    if not 0<=weight<=1:raise ValueError('Invalid interpolation weight')
    pa,pb=evaluate_guide(records,a),evaluate_guide(records,b)
    return np.stack([(1-weight)*sample_guide(pa,u)[0]+weight*sample_guide(pb,u)[0] for u in np.linspace(0,1,samples)])
