"""Shared construction/evaluation ports, independent of any window or renderer."""
from copy import deepcopy
import uuid
import numpy as np
from .assembly import evaluate_guide,identity,sample_guide,interpolate_guides
from .surface import transport
from .card_surface import profile


def structures(records,assembly_id):
    assembly=records[assembly_id]
    if assembly['kind']!='assembly':raise ValueError('Expected assembly')
    cache={};result=[]
    for sid in assembly['payload']['structures']:
        p=deepcopy(records[sid]['payload'])
        if not p.get('enabled',True):continue
        points=evaluate_guide(records,p['guide_id'],cache)
        t=np.linspace(0,1,len(points));attributes=p.get('attributes',{})
        radius=profile(p.get('radius',[.01,.001]),t)
        if np.any(radius<0):raise ValueError('Negative strand radius')
        color=np.asarray(attributes.get('color',[[.3,.2,.1],[.7,.5,.3]]),float)
        if color.ndim!=2 or color.shape[1]!=3:raise ValueError('Expected RGB profile')
        colors=np.stack([np.interp(t,np.linspace(0,1,len(color)),color[:,i]) for i in range(3)],-1)
        attrs={key:profile(value,t).tolist() for key,value in attributes.items() if key!='color'}
        result.append(dict(id=sid,guide_id=p['guide_id'],points=points,radius=radius,
                           colors=np.clip(colors,0,1),attributes=attrs,attachment=p.get('attachment')))
    return result


def curves_from_snapshot(snapshot,assembly_id,axes='xy',fit=True):
    """Explicit 3D→texture-plane projection; the 3D source stays untouched."""
    from ..construction.core import Curve,CurveSet
    records=snapshot.get('records',snapshot);items=structures(records,assembly_id)
    if not items:return CurveSet([])
    a,b={'xy':(0,1),'xz':(0,2),'yz':(1,2)}[axes]
    xyz=np.concatenate([item['points'] for item in items]);lo=xyz.min(0);hi=xyz.max(0)
    scale=.86/max(float(hi[a]-lo[a]),float(hi[b]-lo[b]),1e-6) if fit else 1.
    center=(lo+hi)*.5 if fit else np.zeros(3);output=[]
    for item in items:
        points=item['points'];uv=(points[:,[a,b]]-center[[a,b]])*scale
        if fit:uv+=.5
        uv[:,1]=1-uv[:,1]
        attrs=item['attributes']
        output.append(Curve(item['id'],uv.astype(np.float32),(item['radius']*scale*512).astype(np.float32),
                            item['colors'].astype(np.float32),float(np.mean(points[:,3-a-b])),
                            float(np.mean(attrs.get('roughness',[.5]))),assembly_id,
                            1.,depth_profile=np.clip(.5+(points[:,3-a-b]-center[3-a-b])*scale,0,1).astype(np.float32)))
    return CurveSet(output)


def cards_from_assembly(project,assembly_id,tile_id,width=.035):
    from ..cards import HairCard
    from .scene import kernel
    service=kernel(project);records=service.synchronize().records
    items=structures(records,assembly_id);existing={c['id']:c for c in project.cards};cards=[]
    for index,item in enumerate(items):
        cid=identity(assembly_id,'card',item['id'])
        if cid in existing:continue
        card=HairCard.create(tile_id,f'{records[assembly_id]["payload"]["workflow"]} {index+1}')
        card.id=cid;card.guide_id=item['guide_id'];card.guide_points=item['points'].tolist()
        card.length=1.;card.bend=0.;card.width=float(width);card.segments=16
        card.attachment=deepcopy(item.get('attachment'))
        cards.append(card.to_dict())
    project.cards=[*project.cards,*cards];service.synchronize()
    return [c['id'] for c in cards]


def publish_to_tile(project,assembly_id,tile_id,axes='xy'):
    from .scene import kernel
    tile=project.find(tile_id)
    if tile is None:raise ValueError('Select a texture tile')
    registry=kernel(project).synchronize();frozen=registry.freeze([assembly_id])
    source=dict(records=frozen.decode())
    node=dict(id='kernel',op='kernel_source',inputs={},params=dict(
        assembly_id=assembly_id,snapshot=source,axes=axes,source_versions=list(frozen.versions)))
    tile.construction_graph=dict(nodes=[node],output='kernel');tile.revision+=1
    update_tile_attributes(tile,source,assembly_id)


def update_tile_attributes(tile,snapshot,assembly_id):
    from ..model import stable_int
    # Optical profiles travel as source attributes into the existing truth baker.
    overrides=dict(tile.overrides)
    for item in structures(snapshot.get('records',snapshot),assembly_id):
        suffix=f'g{stable_int(item["id"]):016x}'
        overrides[suffix]={**overrides.get(suffix,{}),'attributes':item['attributes']}
    tile.overrides=overrides


def guide_from_edges(obj,indices):
    indices=list(map(int,indices))
    if not 2<=len(indices)<=256:raise ValueError('Choose 2..256 ordered vertex indices')
    vertices=np.asarray(obj['vertices'],float)
    if min(indices)<0 or max(indices)>=len(vertices):raise ValueError('Vertex index outside mesh')
    edges={tuple(sorted(pair)) for face in obj['triangles'] for pair in
           ((face[0],face[1]),(face[1],face[2]),(face[2],face[0]))}
    if any(tuple(sorted(pair)) not in edges for pair in zip(indices,indices[1:])):
        raise ValueError('Indices must follow connected mesh edges')
    points=vertices[indices]*obj.get('scale',1)+np.asarray(obj.get('position',[0,0,0]))
    transport(points);return points


def assembly_from_tile(project,tile_id,limit=20000,cancel=lambda:False):
    """Graph/Fiber truth → editable 3D guide/strand sources, with stable origin IDs."""
    from ..engine_v2.engine import ENGINE
    from .scene import kernel
    tile=project.find(tile_id)
    if tile is None:raise ValueError('Source tile no longer exists')
    truth,_=ENGINE.truth(tile,cancel=cancel)
    if len(truth)>limit:raise ValueError(f'Source has {len(truth)} strands; reduce to {limit} before card conversion')
    service=kernel(project);registry=service.synchronize();aid='assembly:'+uuid.uuid4().hex
    guides=[];sources=[]
    with registry.transaction('Continue tile structures as guides') as edit:
        for strand in truth:
            if cancel():raise RuntimeError('Conversion cancelled')
            gid=identity(aid,'guide',strand.sid);sid=identity(aid,'structure',strand.sid)
            points=np.column_stack((strand.points[:,0]-.5,1-strand.points[:,1],np.full(len(strand.points),strand.depth-.5)))
            attrs={key:np.asarray(strand.attribute(key,strand.t)).reshape(-1).tolist() for key in
                   ('roughness','opacity','specular','anisotropy','transmission','scatter','iridescence')}
            colors=strand.sampled_colors if strand.sampled_colors is not None else np.stack((strand.color_root,strand.color_mid,strand.color_tip))
            attrs['color']=colors.tolist()
            edit.put('guide',dict(points=points.tolist(),origin_strand_id=strand.sid),id=gid)
            edit.put('structure',dict(guide_id=gid,radius=(strand.radii/512).tolist(),attributes=attrs,
                                     origin_tile=tile_id,origin_strand_id=strand.sid),inputs=[gid],id=sid)
            guides.append(gid);sources.append(sid)
        edit.put('assembly',dict(workflow='Free Fiber',guides=guides,structures=sources,
                                 origin_tile=tile_id,origin_revision=tile.revision),inputs=guides+sources,id=aid)
    service.publish_registry(registry)
    return aid


def assembly_from_cards(project,card_ids):
    """Explicit guide→strand conversion; card mesh is never treated as strand truth."""
    from .scene import kernel
    service=kernel(project);registry=service.synchronize();aid='assembly:'+uuid.uuid4().hex
    guides=[];sources=[];selected=set(card_ids)
    with registry.transaction('Card guides to strand structures') as edit:
        for card in project.cards:
            if card['id'] not in selected:continue
            gid=identity(aid,'placed-guide',card['id']);sid=identity(aid,'structure',card['id'])
            legacy={k:deepcopy(v) for k,v in card.items() if k not in ('modifiers','attachment','deformation_layers','vertex_offsets')}
            edit.put('guide',dict(legacy_source=legacy,origin_card_id=card['id']),inputs=[card['id']],id=gid)
            edit.put('structure',dict(guide_id=gid,radius=[.006,.0005],attributes={}),inputs=[gid],id=sid)
            guides.append(gid);sources.append(sid)
        if not sources:raise ValueError('Select cards to convert their guides')
        edit.put('assembly',dict(workflow='Free Fiber',guides=guides,structures=sources),inputs=guides+sources,id=aid)
    service.publish_registry(registry);return aid


def operate(registry,op,inputs=(),params=None):
    """Typed atomic construction operations. Returns one stable output ID."""
    from .operations import SPECS,modifier
    params=deepcopy(params or {});records=registry.records
    if op not in SPECS:raise ValueError('Unknown operation: '+op)
    actual=tuple(records[key]['kind'] for key in inputs)
    expected=SPECS[op].inputs
    if actual!=expected:raise ValueError(f'{op}: expected {expected}, got {actual}')
    key=params.pop('id',None) or uuid.uuid4().hex
    with registry.transaction(op) as edit:
        if op in ('create','draw'):
            points=np.asarray(params.get('points',[[0,0,0],[0,1,0]]),float);transport(points)
            edit.put('guide',dict(points=points.tolist()),id=key)
        elif op in ('guide','groom','clump','branch','grow'):
            parent=inputs[0]
            if op in ('branch','grow'):
                points=params.get('points',[[0,0,0],[.2,.3,0]])
                transport(points)
                payload=dict(points=points,parent=parent,parent_u=float(params.get('u',.5)))
            else:
                payload=deepcopy(records[parent]['payload'])
                payload.setdefault('modifiers',[]).append(dict(id=uuid.uuid4().hex,op='groom' if op=='guide' else op,
                                                              enabled=True,params=params))
            deps=list(records[parent]['inputs']) if op not in ('branch','grow') else [parent]
            if op=='clump':deps=list(dict.fromkeys([*deps,params['guide']]))
            edit.put('guide',payload,inputs=deps,id=key)
        elif op=='instance':
            from ..cards import HairCard
            card=HairCard.create(params.get('tile_id',''),params.get('name','Instance'))
            card.id=key;card.guide_id=inputs[0];card.guide_points=evaluate_guide(records,inputs[0]).tolist()
            card.bend=0.;edit.put('card',dict(source=card.to_dict()),inputs=inputs,id=key)
        elif op in ('filter','mask'):
            p=deepcopy(records[inputs[0]]['payload']);keep=set(params.get('keep',p['structures']))
            p['structures']=[sid for sid in p['structures'] if sid in keep]
            edit.put('assembly',p,inputs=p.get('guides',[])+p['structures'],id=key)
        elif op in ('material','attribute'):
            p=deepcopy(records[inputs[0]]['payload']);p.setdefault('attributes',{}).update(params)
            edit.put('structure',p,inputs=records[inputs[0]]['inputs'],id=key)
        elif op in ('distribute','scatter'):
            surface=records[inputs[0]]['payload'];vertices=np.asarray(surface.get('vertices',[]),float)
            faces=np.asarray(surface.get('triangles',[]),int)
            if vertices.ndim!=2 or faces.ndim!=2:raise ValueError('Surface operation needs a geometry snapshot')
            count=int(params.get('count',100))
            if not 1<=count<=20000:raise ValueError('Distribution count must be 1..20000')
            tri=vertices[faces];area=np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1)
            if area.sum()<1e-12:raise ValueError('Surface has no nondegenerate triangles')
            rng=np.random.default_rng(int(params.get('seed',42)));ids=[];guides=[]
            for index,face in enumerate(rng.choice(len(tri),count,p=area/area.sum())):
                u,v=rng.random(2)
                if u+v>1:u,v=1-u,1-v
                root=tri[face,0]*(1-u-v)+tri[face,1]*u+tri[face,2]*v
                normal=np.cross(tri[face,1]-tri[face,0],tri[face,2]-tri[face,0]);normal/=np.linalg.norm(normal)
                gid=identity(key,'guide',index);sid=identity(key,'structure',index)
                edit.put('guide',dict(points=[root.tolist(),(root+normal*float(params.get('length',.2))).tolist()]),inputs=inputs,id=gid)
                payload=dict(guide_id=gid,radius=[.008,.0005],attributes={});deps=[gid]
                if surface.get('asset_id'):
                    from .attachments import topology_signature
                    from .binding import frame
                    anchor=dict(id=identity(key,'attachment',index),kind='surface',object_id=surface['asset_id'],
                                topology=topology_signature(vertices,faces),face=int(face),barycentric=[1-u-v,u,v],offset=0.)
                    anchor['bind_frame']=frame(anchor,[dict(id=surface['asset_id'],vertices=vertices,triangles=faces)]).tolist()
                    edit.put('attachment',dict(anchor=anchor),inputs=inputs,id=anchor['id']);deps.append(anchor['id'])
                    payload['attachment']=anchor
                edit.put('structure',payload,inputs=deps,id=sid)
                ids.append(sid);guides.append(gid)
            edit.put('assembly',dict(workflow='Fur',guides=guides,structures=ids),inputs=guides+ids,id=key)
        else:
            p=deepcopy(records[inputs[0]]['payload']);source=p['source'];source['id']=key
            if op in ('attach','bind'):params['anchor']=deepcopy(records[inputs[1]]['payload'].get('anchor',records[inputs[1]]['payload']))
            source.setdefault('modifiers',[]).append(modifier(op,params))
            edit.put('card',p,inputs=inputs,id=key)
    return key
