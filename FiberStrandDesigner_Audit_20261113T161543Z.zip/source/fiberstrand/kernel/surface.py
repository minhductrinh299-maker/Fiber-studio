"""Continuous deformation grids and deterministic parallel-transport frames."""
import numpy as np


def capture_vertices(card):
    """Freeze legacy edits as a parameter grid; never resample the source grid."""
    if not card.vertex_offsets:return
    columns=getattr(card,'width_segments',1)+1
    values=np.zeros((card.segments+1,columns,3),dtype=float)
    for key,value in card.vertex_offsets.items():
        row,side=map(int,key.split(':'))
        if not 0<=row<=card.segments or not 0<=side<columns:raise ValueError('Invalid sculpt vertex')
        values[row,side]=value
    card.deformation_layers.append(dict(id=__import__('uuid').uuid4().hex,enabled=True,space='world',
        u=np.linspace(0,1,card.segments+1).tolist(),v=np.linspace(0,1,columns).tolist(),delta=values.tolist()))
    card.vertex_offsets={}


def deformation(layers,u,v):
    u,v=np.broadcast_arrays(np.asarray(u,float),np.asarray(v,float))
    result=np.zeros(u.shape+(3,))
    for layer in layers:
        if not layer.get('enabled',True):continue
        knots_u=np.asarray(layer['u'],float);knots_v=np.asarray(layer['v'],float)
        data=np.asarray(layer['delta'],float)
        if len(knots_u)<2 or len(knots_v)<2 or data.shape!=(len(knots_u),len(knots_v),3):raise ValueError('Invalid deformation grid')
        if not np.isfinite(data).all() or not np.isfinite(knots_u).all() or not np.isfinite(knots_v).all():raise ValueError('Nonfinite deformation')
        if np.any(np.diff(knots_u)<=0) or np.any(np.diff(knots_v)<=0):raise ValueError('Unordered deformation knots')
        for axis in range(3):
            across=np.stack([np.interp(u,knots_u,data[:,j,axis]) for j in range(len(knots_v))],axis=-1)
            j=np.clip(np.searchsorted(knots_v,v,side='right')-1,0,len(knots_v)-2)
            weight=np.clip((v-knots_v[j])/(knots_v[j+1]-knots_v[j]),0,1)
            a=np.take_along_axis(across,j[...,None],axis=-1)[...,0]
            b=np.take_along_axis(across,(j+1)[...,None],axis=-1)[...,0]
            result[...,axis]+=a*(1-weight)+b*weight
    return result


def smooth_samples(knots,values,parameters):
    """C1 Hermite interpolation through source anchors, without resampling source."""
    knots=np.asarray(knots,float);values=np.asarray(values,float);q=np.asarray(parameters,float)
    if len(knots)<2 or np.any(np.diff(knots)<=0):raise ValueError('Unordered curve anchors')
    slopes=np.gradient(values,knots,axis=0)
    i=np.clip(np.searchsorted(knots,q,side='right')-1,0,len(knots)-2)
    span=knots[i+1]-knots[i];t=np.clip((q-knots[i])/span,0,1)
    dims=(...,)+(None,)*(values.ndim-1);u=t[dims];h=span[dims]
    return (2*u**3-3*u*u+1)*values[i]+(u**3-2*u*u+u)*h*slopes[i]+(-2*u**3+3*u*u)*values[i+1]+(u**3-u*u)*h*slopes[i+1]


def transport(points,initial_normal=None):
    points=np.asarray(points,float)
    if points.ndim!=2 or points.shape[1]!=3 or len(points)<2 or not np.isfinite(points).all():raise ValueError('Invalid guide')
    tangent=np.gradient(points,axis=0)
    length=np.linalg.norm(tangent,axis=1)
    if np.any(length<1e-10):raise ValueError('Guide has degenerate tangent')
    tangent/=length[:,None]
    normal=np.empty_like(tangent)
    seed=np.asarray(initial_normal,float) if initial_normal is not None else np.eye(3)[np.argmin(abs(tangent[0]))]
    if np.linalg.norm(seed-tangent[0]*(seed@tangent[0]))<1e-8:seed=np.eye(3)[np.argmin(abs(tangent[0]))]
    normal[0]=seed-tangent[0]*(seed@tangent[0]);normal[0]/=np.linalg.norm(normal[0])
    for i in range(1,len(points)):
        a,b=tangent[i-1],tangent[i];axis=np.cross(a,b);s=np.linalg.norm(axis);c=np.clip(a@b,-1,1)
        n=normal[i-1]
        if s>1e-10:
            axis/=s;n=n*c+np.cross(axis,n)*s+axis*(axis@n)*(1-c)
        elif c<0:raise ValueError('Guide reverses 180 degrees; split/remap the cusp')
        n-=b*(n@b);normal[i]=n/np.linalg.norm(n)
    return tangent,normal,np.cross(tangent,normal)


def evaluate_surface(guide,segments=16,width_segments=1,width=(.2,.2),twist=(0.,0.),left=None,right=None,camber=0.,layers=()):
    points=np.asarray(guide,float)
    if segments<1 or width_segments<1 or segments>4096 or width_segments>128:raise ValueError('Surface topology outside budget')
    distances=np.r_[0,np.cumsum(np.linalg.norm(np.diff(points,axis=0),axis=1))]
    if distances[-1]<1e-9:raise ValueError('Zero-length guide')
    knots=distances/distances[-1];u=np.linspace(0,1,segments+1);v=np.linspace(0,1,width_segments+1)
    centers=smooth_samples(knots,points,u)
    _,n,b=transport(centers)
    angle=np.interp(u,np.linspace(0,1,len(twist)),twist)
    wing=n*np.cos(angle[:,None])+b*np.sin(angle[:,None])
    up=-n*np.sin(angle[:,None])+b*np.cos(angle[:,None])
    w=np.interp(u,np.linspace(0,1,len(width)),width)
    l=np.interp(u,np.linspace(0,1,len(left or [1,1])),left or [1,1])
    r=np.interp(u,np.linspace(0,1,len(right or [1,1])),right or [1,1])
    lateral=(v[None,:]*r[:,None]-(1-v[None,:])*l[:,None])*w[:,None]*.5
    vertices=centers[:,None,:]+lateral[...,None]*wing[:,None,:]+camber*w[:,None,None]*(4*v*(1-v))[None,:,None]*up[:,None,:]
    uu,vv=np.meshgrid(u,v,indexing='ij');vertices+=deformation(layers,uu,vv)
    faces=[];cols=width_segments+1
    for i in range(segments):
        for j in range(width_segments):
            a=i*cols+j;faces.extend(((a,a+1,a+cols),(a+1,a+cols+1,a+cols)))
    return vertices.reshape(-1,3).astype(np.float32),np.stack((vv,1-uu),-1).reshape(-1,2).astype(np.float32),np.asarray(faces,np.int32),centers
