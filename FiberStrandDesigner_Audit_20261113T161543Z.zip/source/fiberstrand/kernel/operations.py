"""Universal, serializable operation contracts and ordered card modifiers."""
from copy import deepcopy
from dataclasses import dataclass
import math
import uuid
import numpy as np


@dataclass(frozen=True)
class OperationSpec:
    inputs:tuple
    output:str


SPECS={
    'create':OperationSpec((),'guide'),'draw':OperationSpec((),'guide'),
    'distribute':OperationSpec(('surface',),'assembly'),'scatter':OperationSpec(('surface',),'assembly'),
    'instance':OperationSpec(('guide',),'card'),'guide':OperationSpec(('guide',),'guide'),
    'groom':OperationSpec(('guide',),'guide'),'clump':OperationSpec(('guide',),'guide'),
    'branch':OperationSpec(('guide',),'guide'),'grow':OperationSpec(('guide',),'guide'),
    'transform':OperationSpec(('card',),'card'),'deform':OperationSpec(('card',),'card'),
    'twist':OperationSpec(('card',),'card'),'profile':OperationSpec(('card',),'card'),
    'attach':OperationSpec(('card','attachment'),'card'),'bind':OperationSpec(('card','attachment'),'card'),
    'sculpt':OperationSpec(('card',),'card'),'override':OperationSpec(('card',),'card'),
    'filter':OperationSpec(('assembly',),'assembly'),'mask':OperationSpec(('assembly',),'assembly'),
    'material':OperationSpec(('structure',),'structure'),'attribute':OperationSpec(('structure',),'structure'),
}
CARD_OPS={'transform','deform','twist','profile','sculpt','override','attach','bind','material','attribute'}


def modifier(op,params=None):
    if op not in CARD_OPS:raise ValueError('Operation does not accept card input: '+op)
    return dict(id=uuid.uuid4().hex,op=op,enabled=True,params=deepcopy(params or {}))


def evaluate_card_modifiers(card):
    if not card.modifiers:return card
    result=card.fast_copy();result.modifiers=[]
    for operation in card.modifiers:
        if not operation.get('enabled',True):continue
        op=operation['op'];p=operation.get('params',{})
        if op not in CARD_OPS:raise ValueError('Unknown card modifier: '+op)
        if op=='transform':
            result.root=(np.asarray(result.root)+np.asarray(p.get('translation',[0,0,0]))).tolist()
            result.yaw+=float(p.get('yaw',0));result.tilt+=float(p.get('tilt',0))
            result.length*=float(p.get('length_scale',1));result.width*=float(p.get('width_scale',1))
        elif op=='deform':
            for key in ('bend','lift','twist','tilt'):setattr(result,key,getattr(result,key)+float(p.get(key,0)))
        elif op=='twist':result.surface={**result.surface,'twist':deepcopy(p.get('profile',[0,0]))}
        elif op=='profile':result.surface={**result.surface,**deepcopy(p)}
        elif op=='sculpt':result.deformation_layers.extend(deepcopy(p.get('layers',[])))
        elif op=='override':
            for key,value in p.items():
                if key not in ('width','length','taper','bend','lift','twist','yaw','tilt','width_profile','offsets'):raise ValueError('Unsupported override: '+key)
                setattr(result,key,deepcopy(value))
        elif op in ('attach','bind'):
            previous=result.attachment;result.attachment=deepcopy(p.get('anchor'))
            if previous and result.attachment and previous.get('id')==result.attachment.get('id'):
                for key in ('_evaluated_matrix','_invalid_reason'):
                    if key in previous:result.attachment[key]=deepcopy(previous[key])
        elif op in ('material','attribute'):
            # Material binding changes source attributes, not card shape.
            if 'tile_id' in p:result.tile_id=p['tile_id']
    result.sanitize()
    return result


def reorder(modifiers,source,target):
    output=deepcopy(modifiers)
    if source==target:return output
    item=output.pop(source)
    if item.get('op') in ('attach','bind') or any(m.get('op') in ('attach','bind') for m in output[min(source,target):max(source,target)]):
        raise ValueError('Moving across attachment space requires explicit freeze/rebind')
    output.insert(target,item)
    return output


def freeze(card):
    """Return evaluated parameters plus exact reversible source; never discard it."""
    source=card.to_dict();evaluated=evaluate_card_modifiers(card)
    evaluated.modifiers=[]
    return evaluated,dict(id=uuid.uuid4().hex,source=source)


def effective_tile_id(card):
    tile_id=card.tile_id
    for item in card.modifiers:
        if item.get('enabled',True) and item.get('op') in ('material','attribute'):
            tile_id=item.get('params',{}).get('tile_id',tile_id)
    return tile_id
