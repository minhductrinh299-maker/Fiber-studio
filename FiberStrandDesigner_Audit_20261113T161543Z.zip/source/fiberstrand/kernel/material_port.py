"""Direct assembly tiles separate optical edits from geometry/bin dependencies."""
from copy import deepcopy
from dataclasses import replace
import numpy as np


def direct_source(graph):
    nodes=(graph or {}).get('nodes',[])
    return nodes[0]['params'] if len(nodes)==1 and nodes[0].get('op')=='kernel_source' else None


def geometry_graph(graph):
    source=direct_source(graph)
    if source is None:return graph
    records={}
    for key,record in source['snapshot']['records'].items():
        payload=record['payload']
        if record['kind']=='structure':payload={k:v for k,v in payload.items() if k!='attributes'}
        records[key]={k:v for k,v in record.items() if k not in ('revision','payload')}
        records[key]['payload']=payload
    return dict(assembly_id=source['assembly_id'],axes=source.get('axes','xy'),records=records)


def colors_key(graph):
    source=direct_source(graph)
    if source is None:return None
    return {key:record['payload'].get('attributes',{}).get('color') for key,record in source['snapshot']['records'].items()
            if record['kind']=='structure'}


def apply_colors(truth,tile):
    source=direct_source(tile.construction_graph)
    if source is None or not truth:return truth
    from ..model import stable_int
    from ..engine_v2.truth import frozen,TruthView
    records=source['snapshot']['records'];profiles={}
    for key,record in records.items():
        if record['kind']!='structure':continue
        value=record['payload'].get('attributes',{}).get('color',[[.3,.2,.1],[.7,.5,.3]])
        profiles[f'{tile.id}:g{stable_int(key):016x}']=np.asarray(value,float)
    items=[]
    for strand in truth:
        profile=profiles.get(strand.sid)
        override=tile.overrides.get(strand.sid.split(':',1)[-1],{})
        if override.get('color'):
            from ..geometry import hex_rgb
            profile=np.stack([hex_rgb(override['color'])]*2)
        if profile is None:items.append(strand);continue
        colors=frozen(np.stack([np.interp(strand.t,np.linspace(0,1,len(profile)),profile[:,axis]) for axis in range(3)],-1))
        items.append(replace(strand,color_root=colors[0],color_mid=colors[len(colors)//2],color_tip=colors[-1],sampled_colors=colors))
    batch=truth.batch
    if batch is not None:
        batch=replace(batch,sampled_colors=frozen(np.concatenate([s.sampled_colors for s in items])),
                      has_sampled=np.ones(len(items),np.uint8),color_root=frozen([s.color_root for s in items]),
                      color_mid=frozen([s.color_mid for s in items]),color_tip=frozen([s.color_tip for s in items]))
        batch.has_sampled.setflags(write=False)
    return TruthView(tuple(items),batch,truth._sid_index)
