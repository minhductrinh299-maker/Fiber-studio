"""Unified source tools. Edits validate on a draft before one undo publication."""
from copy import deepcopy
import json
import uuid
import tkinter as tk
from tkinter import ttk,messagebox,simpledialog
import numpy as np
from .scene import kernel,fork_project
from .assembly import create_assembly,evaluate_guide,interpolate_guides
from .workflows import cards_from_assembly,publish_to_tile,guide_from_edges,operate,assembly_from_tile,assembly_from_cards
from .operations import modifier,reorder,freeze
from ..cards import HairCard,ribbon_mesh
from ..model import Project


class KernelWorkbench(ttk.Frame):
    def __init__(self,editor,parent=None):
        self.editor=editor;self.embedded=parent is not None
        self.window=None if self.embedded else tk.Toplevel(editor)
        super().__init__(parent if self.embedded else self.window)
        self.pack(fill='both',expand=True)
        if self.window:
            self.window.title('Card Editor · Tools');self.window.geometry('800x650')
        self.status=tk.StringVar(value='Select cards in the viewport. Apply creates one undo step.')
        self.page=tk.StringVar(value='Card & Sculpt')
        names=['Create & Workflow','Guides','Card & Sculpt','Surface Profiles','Modifier Stack','Surface Binding']
        self.selector=ttk.Combobox(self,textvariable=self.page,values=names,state='readonly')
        self.selector.pack(fill='x',padx=8,pady=8)
        self.pages={}
        for name,attribute in zip(names,['assemblies','guides','basic_frame','surface','modifiers','attachments']):
            frame=ttk.Frame(self,padding=8);self.pages[name]=frame;setattr(self,attribute,frame)
        self.selector.bind('<<ComboboxSelected>>',lambda e:self.show_page(self.page.get()))
        ttk.Label(self,textvariable=self.status,wraplength=280).pack(side='bottom',fill='x',padx=8,pady=8)
        self.show_page('Card & Sculpt')
        self.guide_id=tk.StringVar();self.parent_id=tk.StringVar();self.assembly_id=tk.StringVar()
        self.target_id=tk.StringVar();self.kind=tk.StringVar(value='surface');self.joint=tk.StringVar()
        self.workflow=tk.StringVar(value='Hair');self.count=tk.StringVar(value='24');self.seed=tk.StringVar(value='42')
        self._guide_tools();self._surface_tools();self._modifier_tools();self._assembly_tools();self._attachment_tools()
        self.refresh()
        from queue import Queue
        from ..engine_v2.scheduler import LatestScheduler
        self.jobs=Queue();self.worker=LatestScheduler(workers=1);self.job_serial=0
        self.poll_job=self.after(50,self.poll_jobs)
        if self.window:self.window.protocol('WM_DELETE_WINDOW',self.close)

    def show_page(self,name):
        for frame in self.pages.values():frame.pack_forget()
        self.page.set(name);self.pages[name].pack(fill='both',expand=True)

    def withdraw(self):
        if self.window:self.window.withdraw()
        self.editor.canvas.focus_set()

    def deiconify(self):
        if self.window:self.window.deiconify()

    def lift(self):
        if self.window:self.window.lift()
        else:self.editor.lift()

    def close(self):
        self.worker.close(wait=True);self.after_cancel(self.poll_job);self.destroy()
        if self.window:self.window.destroy()

    def poll_jobs(self):
        from queue import Empty
        try:
            while True:
                serial,original,baseline,trial,aid,error=self.jobs.get_nowait()
                if serial!=self.job_serial:continue
                if error:self.status.set(error);continue
                current=self.editor.app.project
                stamp=(id(current.cards),id(current.objects),kernel(current).synchronize().revision,tuple((t.id,t.revision) for t in current.tiles))
                if current is not original or stamp!=baseline:
                    self.status.set('Scene changed during conversion; stale result discarded. Run conversion again.');continue
                self.editor._history();current.cards=trial.cards;current.tiles=trial.tiles;current.kernel_data=trial.kernel_data
                current._unified_kernel=None
                if aid:self.assembly_id.set(aid)
                self.editor.app.modified=True
                self.editor.refresh();self.editor.app._schedule_render(0);self.refresh()
                self.status.set(self.job_label+' · completed; Ctrl+Z to undo')
        except Empty:pass
        self.poll_job=self.after(50,self.poll_jobs)

    def run_async(self,label,action):
        project=self.editor.app.project
        baseline=(id(project.cards),id(project.objects),kernel(project).synchronize().revision,tuple((t.id,t.revision) for t in project.tiles))
        trial=fork_project(project);self.job_serial+=1;serial=self.job_serial;self.job_label=label
        self.status.set(label+' · processing in background…')
        publish=self.jobs.put
        def work(token):
            try:
                aid=action(trial,kernel(trial),token)
                kernel(trial).synchronize()
                old={c['id']:c for c in project.cards}
                for card in trial.cards:
                    if token.is_set():return
                    if card is not old.get(card['id']) and card!=old.get(card['id']):ribbon_mesh(HairCard.from_dict(card))
                if not token.is_set():publish((serial,project,baseline,trial,aid,None))
            except Exception as error:
                if not token.is_set():publish((serial,project,baseline,None,None,str(error)))
        self.worker.submit('source-edit',work)

    def import_tile(self):
        tile_id=self.editor.app.current_id
        self.run_async('Converted Graph / Fiber source',lambda p,s,t:assembly_from_tile(p,tile_id,cancel=t.is_set))

    def row(self,frame,*buttons):
        row=ttk.Frame(frame);row.pack(fill='x',pady=5)
        for label,command in buttons:ttk.Button(row,text=label,command=command).pack(side='top' if self.embedded else 'left',fill='x' if self.embedded else 'none',padx=(0,6),pady=2)
        return row

    def combo(self,frame,label,variable,values=()):
        row=ttk.Frame(frame);row.pack(fill='x',pady=5)
        ttk.Label(row,text=label,width=17).pack(side='left')
        box=ttk.Combobox(row,textvariable=variable,values=values);box.pack(side='left',fill='x',expand=True)
        return box

    def edit_json(self,title,value,accept):
        from .visual_editors import visual_dialog
        if isinstance(value,(dict,list)):
            return visual_dialog(self,title,value,accept)
        return self.edit_json_advanced(title,value,accept)

    def edit_json_advanced(self,title,value,accept):
        popup=tk.Toplevel(self);popup.title(title);popup.geometry('650x440')
        text=tk.Text(popup,undo=True,wrap='none');text.pack(fill='both',expand=True,padx=10,pady=10)
        text.insert('1.0',json.dumps(value,indent=2))
        def apply():
            try:accept(json.loads(text.get('1.0','end')))
            except (ValueError,KeyError,TypeError,IndexError) as error:
                messagebox.showerror(title,str(error),parent=popup);return
            popup.destroy()
        ttk.Button(popup,text='Apply',command=apply).pack(pady=(0,10))

    def selected(self,project):
        ids={c.id for c in self.editor._selection()}
        if not ids:raise ValueError('Select unlocked cards in Card Editor first')
        return [HairCard.from_dict(c) for c in project.cards if c['id'] in ids]

    def apply(self,label,action):
        project=self.editor.app.project
        kernel(project).synchronize()
        trial=fork_project(project);service=kernel(trial);service.synchronize()
        action(trial,service)
        # Reject invalid geometry, broken references and cycles before touching UI state.
        service.synchronize()
        changed={c['id']:c for c in project.cards}
        for source in trial.cards:
            if source!=changed.get(source['id']):ribbon_mesh(HairCard.from_dict(source))
        self.editor._history();project.cards=trial.cards;project.kernel_data=trial.kernel_data
        project.tiles=trial.tiles;project._unified_kernel=None
        self.editor.app.modified=True;self.editor.refresh();self.editor.app._schedule_render(0)
        self.status.set(label+' · Ctrl+Z to undo');self.refresh()

    def run(self,label,action):
        try:self.apply(label,action)
        except StopIteration:
            messagebox.showerror(label,'Choose a valid imported target object first',parent=self)
        except (ValueError,KeyError,TypeError,IndexError,np.linalg.LinAlgError) as error:
            messagebox.showerror(label,str(error),parent=self)

    def refresh(self):
        records=kernel(self.editor.app.project).synchronize().records
        guides=[key for key,r in records.items() if r['kind']=='guide']
        assemblies=[key for key,r in records.items() if r['kind']=='assembly']
        self.guide_box.configure(values=guides);self.parent_box.configure(values=['',*guides])
        self.assembly_box.configure(values=assemblies)
        objects=self.editor.app.project.objects;self.target_box.configure(values=[o['id'] for o in objects])
        if assemblies and self.assembly_id.get() not in assemblies:self.assembly_id.set(assemblies[-1])
        if objects and self.target_id.get() not in {o['id'] for o in objects}:self.target_id.set(objects[0]['id'])
        self.objects_text.set(' · '.join(o['name']+' = '+o['id'] for o in objects) or 'Import an OBJ / FBX model through Outliner.')
        selected=self.editor._selection()
        if selected and selected[0].guide_id:self.guide_id.set(selected[0].guide_id)
        self.stack.delete(*self.stack.get_children())
        if selected:
            for i,item in enumerate(selected[0].modifiers):
                self.stack.insert('','end',iid=str(i),text=item['op'],values=('On' if item.get('enabled',True) else 'Off',item['id']))
            from .binding import resolved_card
            owner=self.editor.app.object_workspace
            resolved=resolved_card(selected[0],owner.evaluated_objects(),owner.joint_poses)
            if resolved.attachment and resolved.attachment.get('_invalid_reason'):
                self.status.set(resolved.attachment['_invalid_reason']+' · use Remap / Bind to replace the anchor')

    def _guide_tools(self):
        f=self.guides
        ttk.Label(f,text='Guide source · shared by cards and branch structures').pack(anchor='w')
        self.guide_box=self.combo(f,'Guide ID',self.guide_id)
        self.parent_box=self.combo(f,'Parent guide',self.parent_id)
        self.row(f,('Draw in viewport',self.draw),('Edit control points',self.edit_points),('Make Unique',self.editor._unique_guide))
        self.row(f,('Bind selected to guide',self.bind_guide),('Set parent at u…',self.parent),('Interpolate A → Parent',self.interpolate))
        self.row(f,('Guide from mesh edges…',self.edges),('Groom guide…',lambda:self.guide_op('groom',{'bend':.1,'lift':0})),
                 ('Clump to parent',lambda:self.guide_op('clump',{'guide':self.parent_id.get(),'strength':[0,.8]})))
        ttk.Label(f,text='Draw: click points on the camera target plane; Enter commits, Escape cancels.\n'
                  'Control points are local to the parent. Parent u is the attachment position along its curve.\n'
                  'Mesh edges: enter an ordered chain of connected vertex indices from the imported model.',wraplength=680).pack(anchor='w',pady=15)

    def edit_points(self):
        registry=kernel(self.editor.app.project).synchronize();gid=self.guide_id.get()
        try:p=registry.get(gid)['payload'];points=p.get('points')
        except KeyError:self.status.set('Choose a guide');return
        if points is None:points=evaluate_guide(registry.records,gid).tolist()
        def accept(points):
            def change(project,service):
                from .surface import transport
                transport(points);record=service.registry.get(gid);p=record['payload']
                p.pop('legacy_source',None);p['points']=points
                with service.registry.transaction('Guide controls') as edit:edit.put('guide',p,record['inputs'],gid)
                service.publish_registry(service.registry)
            self.apply('Edited guide controls',change)
        self.edit_json('Guide control points · local XYZ',points,accept)

    def bind_guide(self):
        gid=self.guide_id.get()
        def change(project,service):
            points=evaluate_guide(service.registry.records,gid).tolist();cards=self.selected(project)
            replace={c.id:{**c.to_dict(),'guide_id':gid,'guide_points':points} for c in cards}
            project.cards=[replace.get(c['id'],c) for c in project.cards]
        self.run('Bound selected cards to guide',change)

    def parent(self):
        u=simpledialog.askfloat('Parent','Position along parent (0..1)',initialvalue=.5,minvalue=0,maxvalue=1,parent=self)
        if u is None:return
        def change(project,service):
            gid=self.guide_id.get();parent=self.parent_id.get();record=service.registry.get(gid);p=record['payload']
            if 'points' not in p:p={'points':evaluate_guide(service.registry.records,gid).tolist()}
            p.pop('parent',None);p.pop('parent_u',None)
            if parent:p.update(parent=parent,parent_u=u)
            deps=[parent] if parent else []
            for m in p.get('modifiers',[]):
                if m.get('op')=='clump':deps.append(m['params']['guide'])
            with service.registry.transaction('Guide hierarchy') as edit:edit.put('guide',p,deps,gid)
            service.publish_registry(service.registry)
        self.run('Changed guide parent',change)

    def interpolate(self):
        weight=simpledialog.askfloat('Interpolate','Blend A → Parent',initialvalue=.5,minvalue=0,maxvalue=1,parent=self)
        if weight is None:return
        def change(project,service):
            points=interpolate_guides(service.registry.records,self.guide_id.get(),self.parent_id.get(),weight)
            from .guides import set_guide
            set_guide(project,points,[c.id for c in self.selected(project)])
        self.run('Created interpolated guide',change)

    def guide_op(self,op,params):
        def accept(params):
            def change(project,service):
                gid=self.guide_id.get();record=service.registry.get(gid);p=record['payload']
                if 'points' not in p:p={'points':evaluate_guide(service.registry.records,gid).tolist()}
                p.setdefault('modifiers',[]).append(dict(id=uuid.uuid4().hex,op=op,enabled=True,params=params))
                deps=list(record['inputs'])
                if op=='clump':deps=list(dict.fromkeys([*deps,params['guide']]))
                with service.registry.transaction(op) as edit:edit.put('guide',p,deps,gid)
                service.publish_registry(service.registry)
            self.apply('Applied guide '+op,change)
        self.edit_json('Guide '+op,params,accept)

    def edges(self):
        raw=simpledialog.askstring('Connected edges','Ordered vertex indices, e.g. 0, 1, 2',parent=self)
        if not raw:return
        def change(project,service):
            obj=next(o for o in project.objects if o['id']==self.target_id.get())
            points=guide_from_edges(obj,raw.split(','))
            from .guides import set_guide
            set_guide(project,points,[c.id for c in self.selected(project)])
        self.run('Created guide from edges',change)

    def draw(self):
        self.withdraw()
        def done(points):
            self.deiconify()
            if len(points)<2:return
            def change(project,service):
                from .guides import set_guide
                ids=[c.id for c in self.editor._selection()]
                if not ids:
                    tile=self.editor.app.current_id
                    if not project.find(tile):raise ValueError('Choose a tile first')
                    c=HairCard.create(tile,'Drawn Guide');c.bend=0.;project.cards=[*project.cards,c.to_dict()];ids=[c.id]
                set_guide(project,points,ids)
            self.run('Created drawn guide',change)
        self.editor.begin_guide_draw(done)

    def _surface_tools(self):
        f=self.surface
        ttk.Label(f,text='Chỉnh bề mặt bằng đồ thị: chọn loại profile rồi kéo điểm từ gốc đến ngọn.',wraplength=270).pack(anchor='w')
        self.row(f,('Chỉnh profile bằng đồ thị',self.visual_surface),('Dữ liệu nâng cao…',self.advanced_surface))
        self.surface_text=tk.Text(f,height=12,width=24,undo=True);self.surface_text.pack_forget()
        self.surface_text.insert('1.0',json.dumps(dict(left=[1,1],right=[1,1],twist=[0,0],camber=[0,0],cupping=[0,0],offset=[0,0],edge=[0,0]),indent=2))
        self.row(f,('Load selected profile',self.load_surface),('Apply as modifier',self.apply_surface),('Sculpt layers',self.editor._sculpt_layers))
        ttk.Label(f,text='Twist is in radians; camber/cupping scale with width. Offset/edge use scene units.\n'
                  'Change longitudinal and width segments in Card Properties; the source profiles stay intact.',wraplength=680).pack(anchor='w')

    def visual_surface(self):
        from .operations import evaluate_card_modifiers
        cards=self.editor._selection()
        if not cards:self.status.set('Chọn card trước khi chỉnh profile');return
        params=dict(left=[1,1],right=[1,1],twist=[0,0],camber=[0,0],cupping=[0,0],offset=[0,0],edge=[0,0])
        params.update(evaluate_card_modifiers(cards[0]).surface)
        self.edit_json('Profile bề mặt',params,lambda p:self.add_modifier('profile',p))

    def advanced_surface(self):
        cards=self.editor._selection()
        self.edit_json_advanced('Surface · dữ liệu nâng cao',cards[0].surface if cards else {},lambda p:self.add_modifier('profile',p))

    def load_surface(self):
        selected=self.editor._selection()
        if selected:self.surface_text.delete('1.0','end');self.surface_text.insert('1.0',json.dumps(selected[0].surface,indent=2))

    def apply_surface(self):
        try:params=json.loads(self.surface_text.get('1.0','end'))
        except ValueError as error:messagebox.showerror('Profile',str(error),parent=self);return
        self.add_modifier('profile',params)

    def _modifier_tools(self):
        f=self.modifiers
        self.stack=ttk.Treeview(f,columns=('enabled','id'),height=12)
        self.stack.heading('#0',text='Ordered modifier');self.stack.heading('enabled',text='Enabled');self.stack.heading('id',text='Stable ID')
        self.stack.column('#0',width=150);self.stack.column('enabled',width=65);self.stack.pack(fill='both',expand=True)
        self.row(f,('Toggle',lambda:self.stack_action('toggle')),('Up',lambda:self.stack_action('up')),('Down',lambda:self.stack_action('down')),
                 ('Edit…',lambda:self.stack_action('edit')),('Remove',lambda:self.stack_action('remove')))
        self.row(f,('Transform…',lambda:self.modifier_dialog('transform',{'translation':[0,0,0],'width_scale':1,'length_scale':1})),
                 ('Deform…',lambda:self.modifier_dialog('deform',{'bend':.1,'lift':0,'twist':0})),
                 ('Twist profile…',lambda:self.modifier_dialog('twist',{'profile':[0,.5,0]})))
        self.row(f,('Freeze stack',self.freeze_stack),('Restore last source',self.restore_source),('Refresh selected',self.refresh))

    def add_modifier(self,op,params):
        def change(project,service):
            cards=self.selected(project);replace={}
            for c in cards:c.modifiers.append(modifier(op,params));replace[c.id]=c.to_dict()
            project.cards=[replace.get(c['id'],c) for c in project.cards]
        self.run('Added '+op,change)

    def modifier_dialog(self,op,params):self.edit_json(op,params,lambda p:self.add_modifier(op,p))

    def stack_action(self,action):
        selection=self.stack.selection()
        if not selection:return
        index=int(selection[0]);selected=self.editor._selection()
        if not selected or index>=len(selected[0].modifiers):return
        def change(params=None):
            def edit(project,service):
                c=self.selected(project)[0]
                if action=='toggle':c.modifiers[index]['enabled']=not c.modifiers[index].get('enabled',True)
                elif action in ('up','down'):
                    target=max(0,min(len(c.modifiers)-1,index+(-1 if action=='up' else 1)))
                    c.modifiers=reorder(c.modifiers,index,target)
                elif action=='remove':c.modifiers.pop(index)
                else:c.modifiers[index]['params']=params
                project.cards=[c.to_dict() if source['id']==c.id else source for source in project.cards]
            self.run('Updated modifier stack',edit)
        if action=='edit':self.edit_json('Modifier parameters',selected[0].modifiers[index]['params'],change)
        else:change()

    def freeze_stack(self):
        def change(project,service):
            replace={}
            for card in self.selected(project):
                evaluated,source=freeze(card);source['source']['frozen_sources']=[]
                evaluated.frozen_sources=[*card.frozen_sources,source];replace[card.id]=evaluated.to_dict()
            project.cards=[replace.get(c['id'],c) for c in project.cards]
        self.run('Froze stack · original source retained',change)

    def restore_source(self):
        def change(project,service):
            replace={}
            for c in self.selected(project):
                if not c.frozen_sources:continue
                restored=HairCard.from_dict(c.frozen_sources[-1]['source']);restored.frozen_sources=c.frozen_sources[:-1]
                replace[c.id]=restored.to_dict()
            project.cards=[replace.get(c['id'],c) for c in project.cards]
        self.run('Restored source before Freeze',change)

    def _assembly_tools(self):
        f=self.assemblies
        self.combo(f,'Workflow preset',self.workflow,['Hair','Fur','Free Fiber','Feather'])
        self.combo(f,'Count / barbs',self.count,['12','24','100','1000'])
        self.combo(f,'Random seed',self.seed,['42','1','123'])
        self.assembly_box=self.combo(f,'Assembly ID',self.assembly_id)
        self.row(f,('Create assembly',self.create),('Generate editable cards',self.generate),('Send to texture / graph',self.send_tile))
        self.row(f,('Distribute on target mesh',self.distribute),('Edit structure attributes…',self.attributes))
        self.row(f,('Import current Graph / Fiber tile',self.import_tile),('Selected card guides → strands',self.import_cards))
        ttk.Label(f,text='Feather creates parented rachis, barbs and barbules with independent strand structures.\n'
                  'All presets produce the same source records. Editing a parent updates its descendants.\n'
                  'Sending to a tile projects XY; the tile, atlas and truth baker receive a linked snapshot.',wraplength=680).pack(anchor='w',pady=15)

    def import_cards(self):
        ids=[c.id for c in self.editor._selection()]
        def change(project,service):self.assembly_id.set(assembly_from_cards(project,ids))
        self.run('Converted selected card guides to strand sources',change)

    def create(self):
        workflow=self.workflow.get()
        try:count=int(self.count.get());seed=int(self.seed.get())
        except ValueError:self.status.set('Count and seed must be integers');return
        def change(project,service,token):
            aid=create_assembly(service.registry,workflow,count,seed)
            service.publish_registry(service.registry);return aid
        self.run_async('Created '+workflow,change)

    def generate(self):
        aid=self.assembly_id.get();tile_id=self.editor.app.current_id
        def change(project,service,token):cards_from_assembly(project,aid,tile_id)
        self.run_async('Generated editable cards',change)

    def send_tile(self):
        self.run('Linked assembly to texture tile',lambda p,s:publish_to_tile(p,self.assembly_id.get(),self.editor.app.current_id))

    def distribute(self):
        target=self.target_id.get()
        try:count=int(self.count.get());seed=int(self.seed.get())
        except ValueError:self.status.set('Count and seed must be integers');return
        def change(project,service,token):
            obj=next(o for o in project.objects if o['id']==target)
            vertices=np.asarray(obj['vertices'])*obj.get('scale',1)+np.asarray(obj.get('position',[0,0,0]))
            gid='distribution-surface:'+uuid.uuid4().hex
            with service.registry.transaction('Surface snapshot') as edit:
                edit.put('surface',dict(vertices=vertices.tolist(),triangles=obj['triangles'],asset_id=obj['id']),inputs=[obj['id']],id=gid)
            aid=operate(service.registry,'distribute',[gid],dict(count=count,seed=seed))
            service.publish_registry(service.registry);return aid
        self.run_async('Distributed strands on surface',change)

    def attributes(self):
        def accept(attributes):
            def change(project,service):
                assembly=service.registry.get(self.assembly_id.get())
                with service.registry.transaction('Structure attributes') as edit:
                    for sid in assembly['payload']['structures']:
                        record=service.registry.get(sid);p=record['payload'];p.setdefault('attributes',{}).update(attributes)
                        edit.put('structure',p,record['inputs'],sid)
                service.publish_registry(service.registry)
            self.apply('Edited strand attributes',change)
        self.edit_json('Attributes along strands',{'color':[[.2,.1,.05],[.7,.5,.3]],'roughness':[.5,.7],'opacity':[1,1],
                       'specular':[.5,.5],'anisotropy':[.8,.8],'transmission':[.2,.2],'scatter':[.2,.2],'iridescence':[0,0]},accept)

    def _attachment_tools(self):
        f=self.attachments;self.objects_text=tk.StringVar()
        self.target_box=self.combo(f,'Target object ID',self.target_id)
        ttk.Label(f,textvariable=self.objects_text,wraplength=680).pack(anchor='w',pady=8)
        self.combo(f,'Attachment kind',self.kind,['free','object','surface','skinned','joint'])
        self.combo(f,'Joint path / name',self.joint)
        self.row(f,('Fetch joint pose',self.fetch_joint))
        self.row(f,('Bind / Remap selected',self.attach),('Detach · preserve pose',self.detach),('Open Outliner / Animation',lambda:self.editor.app.object_workspace.show(self.editor)))
        ttk.Label(f,text='Bind preserves current placement. Surface/skinned use a stable triangle and barycentric coordinates.\n'
                  'Skinned cards follow the evaluated FBX skin, including local deformation.\n'
                  'For a joint, enter its FBX path/name and enable the FBX animation source in Outliner.\n'
                  'Topology changes require an explicit Remap; the source is retained until repaired.',wraplength=680).pack(anchor='w',pady=15)

    def fetch_joint(self):
        owner=self.editor.app.object_workspace
        obj=next((o for o in self.editor.app.project.objects if o['id']==self.target_id.get()),None)
        if obj is None or not obj.get('animation_source'):
            self.status.set('Enable the target FBX animation source in Outliner first');return
        try:owner.request_joint(obj['id'],self.joint.get())
        except ValueError as error:self.status.set(str(error));return
        self.status.set('Fetching joint pose in background · Bind when ready; errors appear in Outliner')

    def attach(self):
        if self.kind.get()=='free':self.detach();return
        owner=self.editor.app.object_workspace
        def change(project,service):
            from .binding import bind,resolved_card
            obj=next(o for o in owner.evaluated_objects() if o['id']==self.target_id.get());replace={}
            for card in self.selected(project):
                current=resolved_card(card,owner.evaluated_objects(),owner.joint_poses)
                # A remap resets the reference at this pose; preserve old evaluated placement.
                if current.attachment and current.attachment.get('_evaluated_matrix'):
                    card=self.detached(current)
                root=ribbon_mesh(card)[0][:card.width_segments+1].mean(axis=0)
                card.attachment=bind(card,obj,root,self.kind.get(),joint=self.joint.get(),joints=owner.joint_poses)
                replace[card.id]=card.to_dict()
            project.cards=[replace.get(c['id'],c) for c in project.cards]
        self.run('Bound / remapped selected cards',change)

    @staticmethod
    def detached(card):
        # Preserve evaluated surface through a continuous layer, including rotation.
        from .surface import capture_vertices
        before=ribbon_mesh(card)[0];source=card.fast_copy();source.attachment=None
        source.modifiers=[m for m in source.modifiers if m.get('op') not in ('attach','bind')]
        base=ribbon_mesh(source)[0];delta=(before-base).reshape(card.segments+1,card.width_segments+1,3)
        source.deformation_layers.append(dict(id=uuid.uuid4().hex,enabled=True,space='world',
            u=np.linspace(0,1,card.segments+1).tolist(),v=np.linspace(0,1,card.width_segments+1).tolist(),delta=delta.tolist()))
        return source

    def detach(self):
        owner=self.editor.app.object_workspace
        def change(project,service):
            from .binding import resolved_card
            replace={c.id:self.detached(resolved_card(c,owner.evaluated_objects(),owner.joint_poses)).to_dict() for c in self.selected(project)}
            project.cards=[replace.get(c['id'],c) for c in project.cards]
        self.run('Detached · preserved evaluated surface',change)
