"""Shared source guides projected into immutable legacy worker snapshots."""
from copy import deepcopy
import uuid
import numpy as np
from .registry import Registry
from .surface import transport


def set_guide(project,points,card_ids,guide_id=None):
    points=np.asarray(points,float)
    transport(points)
    if len(points)>256:raise ValueError('Guide exceeds 256 control points')
    from .scene import kernel
    registry=kernel(project).synchronize().fork()
    known=registry.records
    guide_id=guide_id or 'guide:'+uuid.uuid4().hex
    if guide_id in known and known[guide_id]['kind']!='guide':raise ValueError('Not a guide ID')
    affected=set(card_ids)|{c['id'] for c in project.cards if c.get('guide_id')==guide_id}
    cards=[]
    for card in project.cards:
        if card['id'] in affected:
            if card.get('locked'):raise ValueError('Unlock dependent cards before editing their shared guide')
            card={**card,'guide_id':guide_id,'guide_points':points.tolist()}
        cards.append(card)
    # One publication: registry and evaluated-worker source change together.
    with registry.transaction('Edit shared guide') as edit:
        payload=deepcopy(known.get(guide_id,{}).get('payload',{}))
        payload.pop('legacy_source',None);payload.update(points=points.tolist(),space='card-local-normalized')
        edit.put('guide',payload,inputs=known.get(guide_id,{}).get('inputs',[]),id=guide_id)
        for card in cards:
            if card.get('guide_id'):
                edit.put('card',dict(bound_card=True,source=card),inputs=[card['guide_id']],id=card['id'])
    project.cards=cards;project.kernel_data=registry.snapshot()
    from .scene import kernel
    kernel(project).publish_registry(registry)
    return guide_id


def sync_bound_cards(project):
    from .scene import kernel
    registry=kernel(project).synchronize().fork()
    known=registry.records
    with registry.transaction('Synchronize bound card sources') as edit:
        live={c['id'] for c in project.cards}
        for key,record in list(edit.records.items()):
            if record['kind']=='card' and record['payload'].get('bound_card') and key not in live:edit.delete(key)
        for card in project.cards:
            guide=card.get('guide_id')
            if guide:
                if guide not in known:raise ValueError('Missing source guide: '+guide)
                edit.put('card',dict(bound_card=True,source=card),inputs=[guide],id=card['id'])
    project.kernel_data=registry.snapshot()


def make_unique(project,card_id):
    card=next(c for c in project.cards if c['id']==card_id)
    if not card.get('guide_points'):raise ValueError('Card has no explicit guide')
    return set_guide(project,deepcopy(card['guide_points']),[card_id])
