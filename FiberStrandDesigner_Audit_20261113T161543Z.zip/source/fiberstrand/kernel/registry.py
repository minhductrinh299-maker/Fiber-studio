"""ID-addressed immutable records, dependency validation and atomic edits.

Records are JSON source only. Meshes/maps/GPU resources do not belong here.
Callers only receive deep copies, so workers cannot mutate committed state.
"""
from copy import deepcopy
from threading import RLock
import json
import uuid
from dataclasses import dataclass

KINDS={'assembly','guide','structure','card','attachment','modifier','material','surface'}


class StaleRevision(RuntimeError):pass
class InvalidScene(ValueError):pass


@dataclass(frozen=True)
class EvaluationSnapshot:
    revision:int
    versions:tuple
    data:bytes

    def decode(self):return json.loads(self.data)


def validate(records,check_payload=True):
    for key,record in records.items():
        if record.get('id')!=key or record.get('kind') not in KINDS:raise InvalidScene('Invalid identity/kind')
        for dep in record.get('inputs',[]):
            if dep not in records:raise InvalidScene(f'{key}: missing dependency {dep}')
        if record.get('revision',0)<0:raise InvalidScene('Negative record revision')
    active=set();done=set()
    def visit(key):
        if key in active:raise InvalidScene('Dependency cycle: '+key)
        if key in done:return
        active.add(key)
        for dep in records[key].get('inputs',[]):visit(dep)
        active.remove(key);done.add(key)
    for key in records:visit(key)
    # Reject NaN/Inf and non-JSON payloads before committing.
    if check_payload:json.dumps(records,allow_nan=False)


class Registry:
    def __init__(self,source=None):
        source=deepcopy(source or {'schema':1,'revision':0,'records':{}})
        if source.get('schema')!=1:raise InvalidScene('Unsupported kernel schema')
        self._records=source.get('records',{});validate(self._records)
        self.revision=int(source.get('revision',0));self.dirty=set()
        self.lock=RLock();self.undo=[];self.redo=[]

    @property
    def records(self):
        with self.lock:return deepcopy(self._records)

    def snapshot(self):
        with self.lock:return deepcopy(dict(schema=1,revision=self.revision,records=self._records))

    def source_document(self):
        """Internal COW source port. Consumers must replace, never mutate records."""
        with self.lock:return dict(schema=1,revision=self.revision,records=self._records)

    def get(self,key):
        with self.lock:return deepcopy(self._records[key])

    def freeze(self,roots):
        with self.lock:
            closure=set()
            def visit(key):
                if key in closure:return
                closure.add(key)
                for dep in self._records[key].get('inputs',[]):visit(dep)
            for key in roots:visit(key)
            records={key:self._records[key] for key in sorted(closure)}
            return EvaluationSnapshot(self.revision,tuple((key,record['revision']) for key,record in records.items()),
                                      json.dumps(records,allow_nan=False).encode())

    def fork(self):
        """Independent edit branch sharing immutable committed records."""
        with self.lock:
            result=Registry.__new__(Registry);result._records=self._records
            result.revision=self.revision;result.dirty=set();result.lock=RLock();result.undo=[];result.redo=[]
            return result

    def transaction(self,label,expected=None):return Transaction(self,label,expected)

    def accepts(self,revision,versions):
        with self.lock:
            # Unrelated edits may advance the scene: validate actual dependencies.
            return revision<=self.revision and all(k in self._records and self._records[k]['revision']==v for k,v in versions.items())

    def restore(self,redo=False):
        with self.lock:
            source,target=(self.redo,self.undo) if redo else (self.undo,self.redo)
            if not source:return False
            target.append(self._records);records=source.pop().copy()
            self.revision+=1
            records={key:{**record,'revision':self.revision} for key,record in records.items()}
            self._records=records;self.dirty=set(records)
            return True


class Transaction:
    def __init__(self,registry,label,expected):
        self.registry=registry;self.label=label
        with registry.lock:
            self.expected=registry.revision if expected is None else expected
            self._records=registry._records.copy()

    @property
    def records(self):
        return deepcopy(self._records)

    def put(self,kind,payload,inputs=(),id=None):
        key=id or uuid.uuid4().hex
        old=self._records.get(key)
        if old and old['kind']!=kind:raise InvalidScene('Identity belongs to another record kind: '+key)
        if old and old['kind']==kind and old.get('inputs',[])==list(inputs) and old['payload']==payload:return key
        json.dumps(payload,allow_nan=False)
        self._records[key]=dict(id=key,kind=kind,inputs=list(inputs),payload=deepcopy(payload),revision=0)
        return key

    def delete(self,key):self._records.pop(key,None)

    def commit(self):
        registry=self.registry
        with registry.lock:
            if registry.revision!=self.expected:raise StaleRevision('Scene changed before commit')
            validate(self._records,check_payload=False)
            def content(record):return {k:v for k,v in record.items() if k!='revision'}
            changed={k for k in set(registry._records)|set(self._records)
                     if registry._records.get(k) is not self._records.get(k) and content(registry._records.get(k,{}))!=content(self._records.get(k,{}))}
            if not changed:return registry.revision
            affected=set(changed)
            while True:
                extra={key for key,record in self._records.items() if affected.intersection(record.get('inputs',[]))}
                if extra<=affected:break
                affected|=extra
            registry.undo.append(registry._records);registry.undo=registry.undo[-40:];registry.redo.clear()
            registry.revision+=1
            records={key:({**record,'revision':registry.revision} if key in affected else registry._records[key])
                     for key,record in self._records.items()}
            registry._records=records;registry.dirty|=affected
            return registry.revision

    def __enter__(self):return self
    def __exit__(self,kind,value,traceback):
        if kind is None:self.commit()
