"""Rest topology anchors; callers supply current evaluated/deformed vertices.

No animation/skinning is fabricated here. Static scene object transforms and
deformed vertex streams can use the same barycentric anchor evaluation.
"""
import hashlib
import numpy as np


class InvalidAnchor(ValueError):pass


def topology_signature(vertices,faces):
    faces=np.asarray(faces,dtype='<i8')
    return hashlib.sha256(str(len(vertices)).encode()+faces.tobytes()).hexdigest()


def bind_surface(object_id,vertices,faces,face,barycentric,offset=0.):
    faces=np.asarray(faces,np.int64);bary=np.asarray(barycentric,float)
    if not 0<=face<len(faces) or bary.shape!=(3,) or not np.isfinite(bary).all():raise InvalidAnchor('Invalid face/barycentric anchor')
    if np.any(bary<0) or not np.isclose(bary.sum(),1.):raise InvalidAnchor('Barycentric weights must sum to one')
    if not np.isfinite(offset):raise InvalidAnchor('Invalid offset')
    return dict(kind='surface',object_id=object_id,topology=topology_signature(vertices,faces),
                face=int(face),barycentric=bary.tolist(),offset=float(offset))


def evaluate(anchor,vertices,faces):
    if anchor['kind']!='surface':raise NotImplementedError('Attachment backend not implemented: '+anchor['kind'])
    if topology_signature(vertices,faces)!=anchor['topology']:raise InvalidAnchor('Surface topology changed; explicit remap required')
    tri=np.asarray(vertices,float)[np.asarray(faces,np.int64)[anchor['face']]]
    tangent=tri[1]-tri[0];normal=np.cross(tangent,tri[2]-tri[0])
    if np.linalg.norm(normal)<1e-10:raise InvalidAnchor('Attachment triangle is degenerate')
    tangent/=np.linalg.norm(tangent);normal/=np.linalg.norm(normal)
    point=np.asarray(anchor['barycentric'])@tri+normal*anchor['offset']
    matrix=np.eye(4);matrix[:3,:3]=np.column_stack((tangent,normal,np.cross(tangent,normal)));matrix[:3,3]=point
    return matrix
