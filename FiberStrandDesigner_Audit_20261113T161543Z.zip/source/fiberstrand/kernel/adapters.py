"""Explicit legacy source migration. Never invoked in a pointer-motion callback."""
from copy import deepcopy
from .registry import Registry


def migrate_cards(project):
    registry=Registry(project.kernel_data)
    with registry.transaction('Migrate legacy card sources') as edit:
        live={card['id'] for card in project.cards}
        for key,record in list(edit.records.items()):
            if record.get('payload',{}).get('adapter')=='legacy-card' and record['payload']['card_id'] not in live:
                edit.delete(key)
        for source in project.cards:
            guide_id='guide:'+source['id']
            edit.put('guide',dict(adapter='legacy-card',card_id=source['id'],
                source={key:deepcopy(source[key]) for key in ('root','yaw','tilt','length','bend','lift','offsets')}),id=guide_id)
            edit.put('card',dict(adapter='legacy-card',card_id=source['id'],source=source),inputs=[guide_id],id=source['id'])
    project.kernel_data=registry.snapshot()
    return registry.dirty
