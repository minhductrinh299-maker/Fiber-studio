"""Project ports into one canonical registry; source IDs are never regenerated."""
from copy import deepcopy
import hashlib
from .registry import Registry
from .assembly import evaluate_guide
from .attachments import topology_signature


class SceneKernel:
    def __init__(self,project,registry=None):
        self.project=project;self.registry=registry if registry is not None else Registry(project.kernel_data)
        self.source=project.kernel_data;self.stamp=None;self.topologies={};self.tile_revisions={};self.card_sources={}

    def synchronize(self):
        p=self.project
        if self.source is not p.kernel_data:self.registry=Registry(p.kernel_data);self.source=p.kernel_data;self.stamp=None;self.card_sources={}
        stamp=(id(p.cards),id(p.objects),tuple((t.id,t.revision) for t in p.tiles),id(p.kernel_data))
        if stamp==self.stamp:return self.registry
        if self.stamp and stamp[:2]==self.stamp[:2] and {t.id for t in p.tiles}==set(self.tile_revisions):
            with self.registry.transaction('Update tile source ports') as edit:
                for tile in p.tiles:
                    if self.tile_revisions[tile.id]==tile.revision:continue
                    edit.put('material',dict(tile_id=tile.id,tile_revision=tile.revision,project_port=True),id='material:'+tile.id)
                    edit.put('structure',dict(tile=tile.to_dict(),truth_source='FiberEngine',project_port=True),
                             inputs=['material:'+tile.id],id='structure:'+tile.id)
            p.kernel_data=self.registry.source_document();self.source=p.kernel_data
            self.tile_revisions={t.id:t.revision for t in p.tiles}
            self.stamp=(id(p.cards),id(p.objects),tuple((t.id,t.revision) for t in p.tiles),id(p.kernel_data))
            return self.registry
        old=self.registry.source_document()['records'];managed=set()
        with self.registry.transaction('Synchronize project source ports') as edit:
            def put(kind,payload,inputs,id):
                managed.add(id);edit.put(kind,{**payload,'project_port':True},inputs=inputs,id=id)
            for tile in p.tiles:
                material='material:'+tile.id;structure='structure:'+tile.id
                put('material',dict(tile_id=tile.id,tile_revision=tile.revision),[],material)
                put('structure',dict(tile=tile.to_dict(),truth_source='FiberEngine'),[material],structure)
            for obj in p.objects:
                key=(obj['id'],id(obj['triangles']),len(obj['vertices']))
                if key not in self.topologies:self.topologies[key]=topology_signature(obj['vertices'],obj['triangles'])
                put('surface',dict(asset_id=obj['id'],topology=self.topologies[key],position=obj.get('position',[0,0,0]),
                    scale=obj.get('scale',1),visible=obj.get('visible',True),locked=obj.get('locked',False)),[],obj['id'])
            same_objects=self.stamp is not None and self.stamp[1]==id(p.objects)
            for card in p.cards:
                if same_objects and self.card_sources.get(card['id']) is card and 'material:'+card['tile_id'] in managed and card['id'] in old:
                    pending=[card['id']]
                    while pending:
                        key=pending.pop()
                        if key in managed:continue
                        managed.add(key);pending.extend(old[key].get('inputs',[]))
                    continue
                guide=card.get('guide_id') or 'guide:'+card['id']
                if not card.get('guide_id'):
                    put('guide',dict(legacy_source={key:deepcopy(value) for key,value in card.items()
                        if key not in ('deformation_layers','vertex_offsets','modifiers','attachment')}),[],guide)
                elif guide not in old:raise ValueError('Missing source guide: '+guide)
                else:managed.add(guide)
                material='material:'+card['tile_id']
                if material not in managed:put('material',dict(tile_id=card['tile_id'],invalid=True),[],material)
                inputs=[guide,material]
                previous=guide
                for operation in card.get('modifiers',[]):
                    mid='modifier:'+card['id']+':'+operation['id']
                    put('modifier',dict(operation=operation,owner=card['id']),[previous],mid)
                    previous=mid;inputs.append(mid)
                if card.get('attachment'):
                    anchor=card['attachment'];aid=anchor['id'];inputs.append(aid)
                    target=anchor.get('object_id')
                    # Broken anchors are preserved for explicit remap, not rebound silently.
                    put('attachment',dict(anchor=anchor,invalid=target not in managed),[target] if target in managed else [],aid)
                put('card',dict(source=card),inputs,card['id'])
            for key,record in old.items():
                if record['payload'].get('project_port') and key not in managed:edit.delete(key)
        self.card_sources={card['id']:card for card in p.cards}
        p.kernel_data=self.registry.source_document();self.source=p.kernel_data
        self.tile_revisions={t.id:t.revision for t in p.tiles}
        self.stamp=(id(p.cards),id(p.objects),tuple((t.id,t.revision) for t in p.tiles),id(p.kernel_data))
        return self.registry

    def snapshot(self,ids):return self.synchronize().freeze(ids)

    def refresh_links(self):
        registry=self.registry
        from .workflows import update_tile_attributes
        for tile in self.project.tiles:
            for node in (tile.construction_graph or {}).get('nodes',[]):
                if node.get('op')!='kernel_source':continue
                params=node['params'];aid=params.get('assembly_id')
                if aid not in registry._records:continue
                frozen=registry.freeze([aid]);versions=[list(pair) for pair in frozen.versions]
                if params.get('source_versions')==versions:continue
                params['snapshot']={'records':frozen.decode()};params['source_versions']=versions
                update_tile_attributes(tile,params['snapshot'],aid);tile.revision+=1

    def publish_registry(self,registry):
        """Evaluate parent/child guide closure before one project publication."""
        records=registry.records;cache={};cards=[]
        sources=list(self.project.cards);seen={c['id'] for c in sources}
        for key,record in records.items():
            if record['kind']=='card' and not record['payload'].get('project_port') and key not in seen:
                source=record['payload'].get('source')
                if source:sources.append(deepcopy(source));seen.add(key)
        for source in sources:
            guide=source.get('guide_id')
            implicit='guide:'+source['id']
            if not guide and implicit in records and 'points' in records[implicit]['payload']:
                from ..cards import HairCard
                import uuid
                card=HairCard.from_dict(source);version=card.to_dict();version['frozen_sources']=[]
                card.frozen_sources.append(dict(id=uuid.uuid4().hex,source=version))
                card.guide_id=implicit;card.root=[0.,0.,0.];card.length=1.
                card.bend=0.;card.lift=0.;card.tilt=0.;card.offsets=[[0.,0.,0.] for _ in range(5)]
                source=card.to_dict();guide=implicit
            if guide and guide in records and 'points' in records[guide]['payload']:
                points=evaluate_guide(records,guide,cache)
                source={**source,'guide_points':points.tolist()}
            cards.append(source)
        self.project.cards=cards;self.project.kernel_data=registry.snapshot();self.source=None
        self.synchronize();self.refresh_links();self.synchronize()


def kernel(project):
    if getattr(project,'_unified_kernel',None) is None or project._unified_kernel.project is not project:project._unified_kernel=SceneKernel(project)
    return project._unified_kernel


def fork_project(project):
    """Editable draft with shared immutable card/object/registry source ports."""
    from copy import copy
    source=kernel(project);source.synchronize();draft=copy(project)
    draft.cards=list(project.cards);draft.objects=project.objects;draft.tiles=deepcopy(project.tiles)
    draft.kernel_data=source.registry.source_document()
    draft._unified_kernel=SceneKernel(draft,source.registry.fork())
    draft._unified_kernel.topologies=source.topologies.copy()
    draft._unified_kernel.card_sources=source.card_sources.copy()
    draft._unified_kernel.tile_revisions=source.tile_revisions.copy()
    draft._unified_kernel.stamp=(id(draft.cards),id(draft.objects),tuple((t.id,t.revision) for t in draft.tiles),id(draft.kernel_data))
    draft.__dict__.pop('_object_workspace',None)
    return draft
