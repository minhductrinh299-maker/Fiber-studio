"""Pointer-based source curve editors and named numeric controls."""
from ..ui_theme import color as ui_color
from copy import deepcopy
import math
import tkinter as tk
from tkinter import ttk,messagebox
import numpy as np
from ..number_slider import NumberSlider

class CurvePad(ttk.Frame):
    def __init__(self,parent,points,limits,changed):
        super().__init__(parent);self.points=np.asarray(points,float).copy();self.limits=limits;self.changed=changed;self.active=None
        self.canvas=tk.Canvas(self,width=500,height=280,bg=ui_color('viewport'),highlightthickness=0)
        self.canvas.pack(fill='both',expand=True)
        self.canvas.bind('<Configure>',lambda e:self.draw());self.canvas.bind('<Button-1>',self.down)
        self.canvas.bind('<B1-Motion>',self.move);self.canvas.bind('<ButtonRelease-1>',lambda e:setattr(self,'active',None))
    def screen(self):
        lo,hi=self.limits;size=np.array([max(1,self.canvas.winfo_width()-40),max(1,self.canvas.winfo_height()-40)])
        q=(self.points-lo)/np.maximum(np.asarray(hi)-lo,1e-8);q[:,1]=1-q[:,1]
        return q*size+20
    def draw(self):
        c=self.canvas;c.delete('all');w=c.winfo_width();h=c.winfo_height()
        for t in np.linspace(0,1,6):
            c.create_line(20+t*(w-40),20,20+t*(w-40),h-20,fill='#293443')
            c.create_line(20,20+t*(h-40),w-20,20+t*(h-40),fill='#293443')
        xy=self.screen()
        if len(xy)>1:c.create_line(*xy.ravel(),fill='#71d4cc',width=3)
        for i,(x,y) in enumerate(xy):c.create_oval(x-6,y-6,x+6,y+6,fill=ui_color('selection'),outline='');c.create_text(x+10,y-10,text=str(i+1),fill='#d4deeb')
    def down(self,e):
        distances=np.linalg.norm(self.screen()-[e.x,e.y],axis=1);i=int(np.argmin(distances))
        if distances[i]<18:self.active=i
    def move(self,e):
        if self.active is None:return
        lo,hi=map(np.asarray,self.limits);q=np.array([(e.x-20)/max(1,self.canvas.winfo_width()-40),1-(e.y-20)/max(1,self.canvas.winfo_height()-40)])
        self.points[self.active]=lo+np.clip(q,0,1)*(hi-lo);self.changed(self.points.copy());self.draw()

def visual_dialog(owner,title,value,accept):
    popup=tk.Toplevel(owner);popup.title(title);popup.geometry('610x520')
    draft=deepcopy(value)
    ttk.Label(popup,text='Kéo các điểm để chỉnh. Áp dụng để nhận; Hủy giữ nguyên nguồn.',wraplength=560).pack(padx=12,pady=10)
    body=ttk.Frame(popup);body.pack(fill='both',expand=True,padx=12)
    guide=isinstance(value,list) and value and isinstance(value[0],list) and len(value[0])==3
    if guide:
        points=np.asarray(value,float);plane=tk.StringVar(value='XY · nhìn trước');pad=None
        selector=ttk.Combobox(body,textvariable=plane,values=['XY · nhìn trước','XZ · nhìn trên','ZY · nhìn bên'],state='readonly');selector.pack(fill='x')
        def rebuild(event=None):
            nonlocal pad
            if pad:pad.destroy()
            axes={'XY · nhìn trước':(0,1),'XZ · nhìn trên':(0,2),'ZY · nhìn bên':(2,1)}[plane.get()]
            projected=points[:,axes];lo=projected.min(0);hi=projected.max(0);span=max(float(np.max(hi-lo)),.1)
            center=(lo+hi)/2;limits=(center-span*.8,center+span*.8)
            def change(q):points[:,axes]=q
            pad=CurvePad(body,projected,limits,change);pad.pack(fill='both',expand=True)
        selector.bind('<<ComboboxSelected>>',rebuild);rebuild()
        def output():return points.tolist()
    else:
        fields=[];curves=[]
        def visit(obj,path=()):
            if isinstance(obj,dict):
                if set(obj)=={'knots','values'}:curves.append((path,obj));return
                for k,v in obj.items():visit(v,path+(k,))
            elif isinstance(obj,list) and obj and all(isinstance(v,(float,int)) for v in obj):
                if path and path[-1] in ('profile','left','right','twist','camber','cupping','edge','offset'):curves.append((path,obj))
                else:
                    for i,v in enumerate(obj):fields.append((path+(i,),v))
            elif isinstance(obj,(float,int)) and not isinstance(obj,bool):fields.append((path,obj))
        visit(draft)
        def assign(path,value):
            target=draft
            for k in path[:-1]:target=target[k]
            target[path[-1]]=value
        labels={'translation':'Dịch chuyển','width_scale':'Độ rộng','length_scale':'Chiều dài','bend':'Uốn ngang','lift':'Nâng chiều sâu','twist':'Xoắn','yaw':'Xoay','tilt':'Nghiêng','camber':'Độ vồng','cupping':'Độ khum','left':'Bề rộng trái','right':'Bề rộng phải','offset':'Đẩy bề mặt','edge':'Mép','profile':'Dọc từ gốc đến ngọn'}
        for path,v in fields:
            row=ttk.Frame(body);row.pack(fill='x',pady=3)
            text=' / '.join(labels.get(str(k),str(k)) for k in path)
            ttk.Label(row,text=text,width=20).pack(side='left')
            var=tk.DoubleVar(value=v)
            lo,hi=(.05,3.) if path[-1] in ('width_scale','length_scale') else (-max(2.,abs(v)*2),max(2.,abs(v)*2))
            def update(new_v,path=path):
                try:assign(path,float(new_v))
                except (ValueError,TypeError):pass
            NumberSlider(row,variable=var,from_=lo,to=hi,step=0.01,width=155,height=22,command=update).pack(side='right',fill='x',expand=True)
        if curves:
            choice=tk.StringVar();combo=ttk.Combobox(body,textvariable=choice,state='readonly',values=[labels.get(str(p[-1]),str(p[-1])) for p,v in curves]);combo.pack(fill='x',pady=6);combo.current(0)
            holder=ttk.Frame(body);holder.pack(fill='both',expand=True)
            def load(event=None):
                for child in holder.winfo_children():child.destroy()
                path,_=curves[combo.current()];val=draft
                for key in path:val=val[key]
                values=np.asarray(val['values'] if isinstance(val,dict) else val,float)
                knots=np.asarray(val['knots'] if isinstance(val,dict) else np.linspace(0,1,len(values)),float)
                low=min(-1.,float(values.min())-.5);high=max(2.,float(values.max())+.5)
                def change(q):assign(path,dict(knots=knots.tolist(),values=q[:,1].tolist()))
                pad=CurvePad(holder,np.column_stack((knots,values)),([0,low],[1,high]),change)
                # Knots stay ordered; dragging modifies values without corrupting topology.
                original=pad.move
                def move(e):
                    original(e);pad.points[:,0]=knots;change(pad.points);pad.draw()
                pad.canvas.bind('<B1-Motion>',move);pad.pack(fill='both',expand=True)
            combo.bind('<<ComboboxSelected>>',load);load()
        def output():return draft
    bar=ttk.Frame(popup);bar.pack(fill='x',padx=12,pady=10)
    def commit():
        try:accept(output())
        except Exception as error:messagebox.showerror(title,str(error),parent=popup);return
        popup.destroy()
    ttk.Button(bar,text='Nâng cao…',command=lambda:(owner.edit_json_advanced(title,value,accept),popup.destroy())).pack(side='left')
    ttk.Button(bar,text='Áp dụng',command=commit).pack(side='right');ttk.Button(bar,text='Hủy',command=popup.destroy).pack(side='right',padx=8)
    return popup
