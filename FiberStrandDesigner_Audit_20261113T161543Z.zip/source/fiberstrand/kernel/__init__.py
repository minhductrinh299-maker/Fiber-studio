"""Unified Kernel schema/evaluation primitives; legacy adapters are explicit."""
from .registry import Registry,StaleRevision,InvalidScene
