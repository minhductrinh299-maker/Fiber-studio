"""Topology-independent parametric surface over preserved legacy/guide sources."""
import numpy as np
from .surface import deformation


def profile(value,t,default=0.):
    if value is None:return np.full_like(t,default)
    if np.isscalar(value):
        if not np.isfinite(float(value)):raise ValueError('Nonfinite profile')
        return np.full_like(t,float(value))
    if isinstance(value,dict):
        knots=np.asarray(value['knots'],float);values=np.asarray(value['values'],float)
    else:
        values=np.asarray(value,float);knots=np.linspace(0,1,len(values))
    if not len(values) or values.ndim!=1 or len(knots)!=len(values) or np.any(np.diff(knots)<=0):raise ValueError('Invalid profile knots')
    if not np.isfinite(values).all() or not np.isfinite(knots).all():raise ValueError('Nonfinite profile')
    return np.interp(t,knots,values)


def evaluate(card):
    from ..cards import _legacy_ribbon_mesh
    base=card.fast_copy();base.surface={};base.width_segments=1;base.deformation_layers=[];base.vertex_offsets={}
    verts,_,_,center=_legacy_ribbon_mesh(base)
    rows=card.segments+1;cols=card.width_segments+1
    t=np.linspace(0,1,rows);v=np.linspace(0,1,cols)
    edges=verts.reshape(rows,2,3).astype(float)
    center=(edges[:,0]+edges[:,1])*.5
    wing=edges[:,1]-edges[:,0];width=np.linalg.norm(wing,axis=1)
    wing/=np.maximum(width[:,None],1e-10)
    tangent=np.gradient(center,axis=0);tangent/=np.maximum(np.linalg.norm(tangent,axis=1,keepdims=True),1e-10)
    normal=np.cross(wing,tangent);normal/=np.maximum(np.linalg.norm(normal,axis=1,keepdims=True),1e-10)
    p=card.surface
    unknown=set(p)-{'left','right','twist','camber','cupping','offset','edge'}
    if unknown:raise ValueError('Unknown surface profiles: '+', '.join(sorted(unknown)))
    angle=profile(p.get('twist'),t)
    wing2=wing*np.cos(angle[:,None])+normal*np.sin(angle[:,None])
    normal=-wing*np.sin(angle[:,None])+normal*np.cos(angle[:,None]);wing=wing2
    left=profile(p.get('left'),t,1.);right=profile(p.get('right'),t,1.)
    center+=profile(p.get('offset'),t)[:,None]*normal
    side=(v[None,:]*right[:,None]-(1-v[None,:])*left[:,None])*width[:,None]*.5
    arch=(profile(p.get('camber'),t)[:,None]*(4*v*(1-v))[None,:]+
          profile(p.get('cupping'),t)[:,None]*(2*v-1)[None,:]**2)*width[:,None]
    edge=profile(p.get('edge'),t)[:,None]*np.abs(2*v-1)[None,:]**4
    positions=center[:,None,:]+side[...,None]*wing[:,None,:]+(arch+edge)[...,None]*normal[:,None,:]
    u,vv=np.meshgrid(t,v,indexing='ij')
    for layer in card.deformation_layers:
        delta=deformation([layer],u,vv)
        if layer.get('space','world')=='frame':
            delta=delta[...,0,None]*wing[:,None,:]+delta[...,1,None]*tangent[:,None,:]+delta[...,2,None]*normal[:,None,:]
        positions+=delta
    for key,delta in card.vertex_offsets.items():
        row,col=map(int,key.split(':'))
        if 0<=row<rows and 0<=col<cols:positions[row,col]+=delta
    faces=[]
    for row in range(rows-1):
        for col in range(cols-1):
            a=row*cols+col;faces.extend(((a,a+1,a+cols),(a+1,a+cols+1,a+cols)))
    if not np.isfinite(positions).all():raise ValueError('Nonfinite evaluated surface')
    return positions.reshape(-1,3).astype(np.float32),np.stack((vv,1-u),-1).reshape(-1,2).astype(np.float32),np.asarray(faces,np.int32),center.astype(np.float32)
