"""Tk/ttk desktop Fiber Studio.

Card Editor is an integrated optional workspace. Geometry core, individual-strand
inspector, tile edit, atlas visualization, nonblocking previews and exports.
"""
from __future__ import annotations
from .ui_theme import color as ui_color
from .navigation import MayaNavigation, HELP, dolly_factor, rotate_point, rotate_overlays
from .dpi import enable_high_dpi,DpiManager,pixels,font_pixels,window_dpi
from .settings import AppSettings, SettingsDialog
from types import SimpleNamespace
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from pathlib import Path
from queue import Empty,Queue
import math
import threading
import time
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog, colorchooser
from PIL import Image,ImageDraw,ImageTk
import numpy as np
from .model import Project,Tile,FiberSettings,PRESETS,MAP_NAMES,KINDS,VERSION
from .geometry import recommended_detail
from .raster import render_tile,RenderResult
from .atlas import AtlasCache,write_tile_maps
from .projectio import save_project,load_project
from .number_slider import NumberSlider
from .rendercore.lighting import SHIFT_MASK, normalize_azimuth, clamp_elevation

BG=ui_color('background'); SIDEBAR=ui_color('panel'); CARD=ui_color('control'); TEXT=ui_color('text'); MUTED=ui_color('muted')
ACCENT=ui_color('selection'); GREEN=ui_color('success'); LINE=ui_color('border')
LIVE_UNIFORM_ONLY=frozenset({"pattern","band_count","band_strength","speckle","fiber_roundness","antialias"})
BAKE_ONLY_OPTICAL=frozenset({"roughness","specular","anisotropy","transmission","scatter","iridescence"})
FIELDS={
 "Fiber": [
  ("count","Number of fibers",25,50000,1),
  ("length","Length",.05,.94,.01),
  ("length_variation","Length variation",0,1,.01),
  ("root_width","Root width · px @512",.4,14,.1),
  ("width_variation","Width variation",0,1,.01),
  ("taper","Taper exponent",.2,5,.05),
  ("tip_width","Tip width",0,.65,.01),
  ("mid_bulge","Mid bulge",-.6,1.5,.02),
  ("guard_ratio","Guard hair ratio",0,1,.01),
  ("guard_length","Guard length factor",.5,2.6,.05),
  ("guard_width","Guard width factor",.5,2.6,.05),
  ("flyaway","Flyaway ratio",0,.7,.01)],
 "Shape": [
  ("root_angle","Root angle",-1,1,.01),
  ("bend","Bend",-.9,.9,.01),
  ("curl","Curl strength",0,.6,.01),
  ("curl_frequency","Curl frequency",.5,10,.1),
  ("twist","Twist",-1,1,.02),
  ("frizz","Frizz strength",0,.6,.01),
  ("frizz_frequency","Frizz frequency",1,25,1),
  ("sag","Gravity sag",-.4,.4,.01),
  ("fiber_roundness","Normal roundness",0,1,.01),
  ("antialias","Edge filtering",.5,2.5,.05)],
 "Clumps": [
  ("macro_clumps","Macro clump count",1,64,1),
  ("micro_clumps","Micro clump count",1,200,1),
  ("clump_attraction","Root attraction",0,1,.01),
  ("clump_tip","Tip convergence",0,1,.01),
  ("root_spread","Root spread",.05,1,.01)],
 "Color": [
  ("hue_variation","Hue variation",0,.4,.005),
  ("value_variation","Value variation",0,.8,.01),
  ("saturation_variation","Saturation variation",0,.8,.01),
  ("band_count","Color band count",1,18,1),
  ("band_strength","Band contrast",0,1,.01),
  ("speckle","Speckle strength",0,1,.01),
  ("roughness","Roughness",0,1,.01),
  ("specular","Specular",0,1,.01),
  ("anisotropy","Anisotropy",0,1,.01),
  ("transmission","Transmission",0,1,.01),
  ("scatter","Scatter",0,1,.01),
  ("iridescence","Iridescence",0,1,.01),
  ("strand_opacity","Strand opacity",0,1,.01)],
 "Width Curve": [],
 "Feather": [
  ("feather_width","Feather vane width",.12,.90,.01),
  ("feather_asymmetry","Left / right asymmetry",-.7,.7,.01),
  ("feather_barbules","Barbules per barb",0,8,1)]
}


def _checker(w:int,h:int,block:int=15) -> Image.Image:
    try:
        bx = (w + block - 1) // block
        by = (h + block - 1) // block
        grid = ((np.arange(by)[:, None] + np.arange(bx)[None, :]) % 2).astype(np.uint8)
        expanded = np.repeat(np.repeat(grid, block, axis=0), block, axis=1)[:h, :w]
        c0 = np.array([46, 48, 53], dtype=np.uint8)
        c1 = np.array([63, 66, 72], dtype=np.uint8)
        res = np.where(expanded[..., None] == 1, c1, c0)
        return Image.fromarray(res)
    except Exception:
        im=Image.new("RGB",(w,h),(46,48,53))
        d=ImageDraw.Draw(im)
        for y in range(0,h,block):
            for x in range(0,w,block):
                if (x//block+y//block)%2:
                    d.rectangle((x,y,x+block-1,y+block-1), fill=(63,66,72))
        return im


def _composite_display(im:Image.Image) -> Image.Image:
    checker=_checker(im.width,im.height,max(8,min(im.width,im.height)//32))
    if im.mode=="RGBA":
        checker.paste(im,mask=im.getchannel("A"))
        return checker
    return im.convert("RGB")


class ScrollFrame(ttk.Frame):
    def __init__(self,parent):
        super().__init__(parent)
        self.canvas=tk.Canvas(self,bg=SIDEBAR,highlightthickness=0,borderwidth=0)
        scroll=ttk.Scrollbar(self,orient="vertical",command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right",fill="y")
        self.canvas.pack(side="left",fill="both",expand=True)
        self.body=ttk.Frame(self.canvas,style="Panel.TFrame")
        self.window=self.canvas.create_window((0,0),window=self.body,anchor="nw")
        self.body.bind("<Configure>",self._configure)
        self.canvas.bind("<Configure>",self._resize)
        self.canvas.bind("<MouseWheel>",self._wheel)
        self.body.bind("<MouseWheel>",self._wheel)
    def _configure(self,event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
    def _resize(self,event):
        self.canvas.itemconfigure(self.window,width=event.width)
    def _wheel(self,event):
        self.canvas.yview_scroll(-int(event.delta/120),"units")


class App(tk.Tk):
    def __init__(self):
        enable_high_dpi()
        super().__init__()
        self.title(f"Fiber Strand Designer  ·  {VERSION}")
        self.geometry("1500x900")
        self.minsize(1150,650)
        self.configure(bg=BG)
        self._install_style()
        from .ui_theme import install
        install(self)
        self.app_settings=AppSettings.load()
        self.project=Project.sample()
        self._settings_window=None
        self.active_workspace='fiber'
        self.card_window=None
        self.construction_window=None
        self.render_window=None
        self.file_path:Path|None=None
        self.modified=False
        self.current_id=self.project.tiles[0].id
        self.selected_sid:str|None=None
        self.selected_sids:set[str]=set()
        self.selected_tile_ids:set[str]={self.project.tiles[0].id}
        self._box_select_start=None
        self._box_select_current=None
        self._box_modifier=None  # 'add', 'sub', or None
        self._current_truth=None
        self.mode=tk.StringVar(value="Tile")
        self.channel=tk.StringVar(value="color")
        self.page_var=tk.StringVar(value="0")
        self.preset=tk.StringVar(value="Soft Cat Undercoat")
        self.size_var=tk.StringVar(value="384 x 512")
        self.kind_var=tk.StringVar(value="fur")
        self.pattern_var=tk.StringVar(value="solid")
        self._results:dict[str,RenderResult]={}
        self._atlas=AtlasCache(self.project)
        self._undo:list[dict]=[]
        self._redo:list[dict]=[]
        self._worker=ThreadPoolExecutor(max_workers=2,thread_name_prefix="fiber-raster")
        from .engine_v2.scheduler import LatestScheduler
        self._preview_scheduler=LatestScheduler(workers=2)
        self._truth_scheduler=LatestScheduler(workers=1)
        self._fiber_preview=None
        self._live_gpu_viewport=None
        self._slider_drag=None
        self._number_vars={}
        self._settle_render=None
        self._queue:Queue=Queue()
        from .engine_v2.atlas_pipeline import AtlasPipeline
        self._atlas_pipeline=AtlasPipeline(self._atlas,self._queue.put)
        self._jobs:dict[str,threading.Event]={}
        self._after_render=None
        self._preview_image=None
        self._image_rect=(0,0,1,1)
        self._frame_revision=0
        self._exporting=False
        self.zoom=1.0
        self.pan_x=0
        self.pan_y=0
        self.view_angle=0.
        self._pan_start=None
        self._drag_index=None
        self._drag_start=None
        self.atlas_tool_var=tk.StringVar(value="Move")
        self._atlas_scale_handles=[]
        self._atlas_rotate_handle=None
        self._atlas_drag_state=None
        self._atlas_scene_info=None
        self._nav_active=False
        self._nav_hq_after=None
        self._pending_single_select=None
        self._syncing_tree=False
        self._drag_offset=(0.,0.)
        self._loading_settings=False
        self._closing=False
        self._poll_after=None
        self._build()
        self.dpi_manager=DpiManager(self)
        self.bind('<<DpiChanged>>',lambda e:self.after_idle(self._redraw))
        self.bind('<Tab>',self._toggle_mode_shortcut)
        self.bind('<KeyPress>',lambda e:self._dispatch_global_key(e,release=False),add='+')
        self.bind('<KeyRelease>',lambda e:self._dispatch_global_key(e,release=True),add='+')
        self._fill_tree()
        self._sync_from_tile()
        self._schedule_render(0)
        self._poll_after=self.after(75,self._poll_workers)
        self.protocol("WM_DELETE_WINDOW",self._close)
        self.update_idletasks()

    def _install_style(self):
        s=ttk.Style(self)
        s.theme_use("clam")
        s.configure(".",background=BG,foreground=TEXT,font=("Segoe UI",10),bordercolor=LINE)
        s.configure("TFrame",background=BG)
        s.configure("Panel.TFrame",background=SIDEBAR)
        s.configure("TLabel",background=BG,foreground=TEXT)
        s.configure("Panel.TLabel",background=SIDEBAR,foreground=TEXT)
        s.configure("Muted.TLabel",background=SIDEBAR,foreground=MUTED)
        s.configure("Hero.TLabel",background=BG,foreground=TEXT,font=("Segoe UI Semibold",17))
        s.configure("TButton",background=CARD,foreground=TEXT,borderwidth=0,padding=(12,7))
        s.map("TButton",background=[("active",ui_color('hover'))])
        s.configure("Accent.TButton",background=ACCENT,foreground="#181818",padding=(13,8),font=("Segoe UI Semibold",10))
        s.map("Accent.TButton",background=[("active",ui_color('cyan'))])
        s.configure("TCombobox",fieldbackground=CARD,background=CARD,foreground=TEXT,
                    selectbackground=ACCENT,selectforeground="#161616",padding=4)
        s.map("TCombobox",fieldbackground=[("readonly",CARD)],foreground=[("readonly",TEXT)])
        s.configure("TEntry",fieldbackground=CARD,foreground=TEXT,insertcolor=TEXT,padding=6)
        s.configure("Treeview",background=SIDEBAR,fieldbackground=SIDEBAR,foreground=TEXT,
                    rowheight=34,borderwidth=0)
        s.configure("Treeview.Heading",background=CARD,foreground=TEXT)
        s.map("Treeview",background=[("selected",ui_color('accent'))],foreground=[("selected",ui_color('text'))])
        s.configure("TNotebook",background=SIDEBAR,borderwidth=0)
        s.configure("TNotebook.Tab",background=CARD,foreground=MUTED,padding=(8,8))
        s.map("TNotebook.Tab",background=[("selected",SIDEBAR)],foreground=[("selected",TEXT)])
        s.configure("Horizontal.TScale",background=SIDEBAR,troughcolor=ui_color('border'),sliderlength=14)
        s.configure("TProgressbar",background=ACCENT,troughcolor=CARD)
        s.configure("TScrollbar",background=CARD,troughcolor=BG)
        # Fix slider jump on click: Jump directly to clicked position on trough instead of incremental stepped crawl
        self.tk.call('bind', 'TScale', '<Button-1>', 'ttk::scale::Jump %W %x %y')

    def _build(self):
        toolbar=ttk.Frame(self,padding=(14,8))
        toolbar.pack(side="top",fill="x")

        # 1. Left Zone: Brand identity with dropdown menu trigger
        self.brand_box=ttk.Frame(toolbar,cursor="hand2")
        self.brand_box.pack(side="left")
        self.ui_registry.brand_header(self.brand_box)
        ttk.Label(self.brand_box,text="FSD",style="Hero.TLabel",font=("Segoe UI Semibold",12),cursor="hand2").pack(side="left")
        tk.Label(self.brand_box,text="Fiber Strand Designer ▾",font=("Segoe UI",9),bg=ui_color('background'),fg=ui_color('muted'),cursor="hand2").pack(side="left",padx=(4,14))

        # Build dropdown project management menu
        self.project_menu=tk.Menu(self,tearoff=0,bg=ui_color('control'),fg=ui_color('text'),
                                  activebackground=ui_color('accent'),activeforeground='#ffffff',
                                  font=('Segoe UI',9),relief='flat',bd=0)
        self.project_menu.add_command(label="✦  New Project",command=self._new_project,accelerator="Ctrl+N")
        self.project_menu.add_command(label="📂  Open Project...",command=self._open,accelerator="Ctrl+O")
        self.project_menu.add_separator()
        self.project_menu.add_command(label="💾  Save",command=self._save,accelerator="Ctrl+S")
        self.project_menu.add_command(label="💾  Save As...",command=self._save_as,accelerator="Ctrl+Shift+S")
        self.project_menu.add_separator()
        self.project_menu.add_command(label="⎌  Undo",command=self._undo_action,accelerator="Ctrl+Z")
        self.project_menu.add_command(label="↷  Redo",command=self._redo_action,accelerator="Ctrl+Y")
        self.project_menu.add_separator()
        self.project_menu.add_command(label="⚙  Settings...",command=self._open_settings)
        from .ui_theme import manage
        self.project_menu.add_command(label="🎨  Theme Manager...",command=lambda:manage(self))
        self.project_menu.add_separator()
        # Window submenu for switching workspaces
        window_menu=tk.Menu(self.project_menu,tearoff=0,bg=ui_color('control'),fg=ui_color('text'),
                            activebackground=ui_color('accent'),activeforeground='#ffffff',
                            font=('Segoe UI',9),relief='flat',bd=0)
        window_menu.add_command(label="✦ Fiber Studio",command=lambda:self._switch_workspace("fiber"))
        window_menu.add_command(label="☊ Construction Graph",command=lambda:self._switch_workspace("graph"))
        window_menu.add_command(label="◫ Card Editor 3D",command=lambda:self._switch_workspace("cards"))
        window_menu.add_command(label="◈ GPU Render Studio",command=lambda:self._switch_workspace("render"))
        self.project_menu.add_cascade(label="🗔  Window",menu=window_menu)
        self.project_menu.add_separator()
        self.project_menu.add_command(label="❌  Exit",command=self._close)

        def _show_project_menu(event):
            try:
                x = self.brand_box.winfo_rootx()
                y = self.brand_box.winfo_rooty() + self.brand_box.winfo_height() + 2
                self.project_menu.post(x, y)
            except Exception:
                pass

        self.brand_box.bind("<Button-1>", _show_project_menu)
        for child in self.brand_box.winfo_children():
            child.bind("<Button-1>", _show_project_menu)

        # 2. Right Zone: Contextual Actions & Settings
        right_box=ttk.Frame(toolbar)
        right_box.pack(side="right")
        self.btn_top_export=ttk.Button(right_box,text="Export Atlas",style="TButton",command=self._export_dialog)
        self.btn_top_export.pack(side="right",padx=(6,2))
        self.btn_top_bake=ttk.Button(right_box,text="⚡ Bake Tile",style="Primary.TButton",command=lambda:self._schedule_render(0))
        self.btn_top_bake.pack(side="right",padx=2)

        # 3. Center Zone: Modern Segmented Workspace Pill Navigation placed at exact center
        ws_container=ttk.Frame(toolbar,style="PillContainer.TFrame",padding=(2,2))
        ws_container.place(relx=0.5,rely=0.5,anchor='center')
        self.btn_ws_fiber=ttk.Button(ws_container,text="✦  Fiber Studio",style="PillActive.TButton",command=lambda:self._switch_workspace("fiber"))
        self.btn_ws_fiber.pack(side="left",padx=1)
        self.btn_ws_graph=ttk.Button(ws_container,text="☊  Construction Graph",style="Pill.TButton",command=lambda:self._switch_workspace("graph"))
        self.btn_ws_graph.pack(side="left",padx=1)
        self.btn_ws_cards=ttk.Button(ws_container,text="◫  Card Editor 3D",style="Pill.TButton",command=lambda:self._switch_workspace("cards"))
        self.btn_ws_cards.pack(side="left",padx=1)
        self.btn_ws_render=ttk.Button(ws_container,text="◈  GPU Render Studio",style="Pill.TButton",command=lambda:self._switch_workspace("render"))
        self.btn_ws_render.pack(side="left",padx=1)

        self.main_content=ttk.Frame(self)
        self.main_content.pack(fill="both",expand=True,padx=10,pady=(0,8))
        body=ttk.PanedWindow(self.main_content,orient="horizontal")
        self.bodypane=body
        body.pack(fill="both",expand=True)
        sidebar=ttk.Frame(body,style="Panel.TFrame",width=235)
        workspace=ttk.Frame(body)
        controls=ttk.Frame(body,style="Panel.TFrame",width=365)
        body.add(sidebar,weight=1);body.add(workspace,weight=5);body.add(controls,weight=2)
        self._build_sidebar(sidebar)
        self._build_workspace(workspace)
        self._build_controls(controls)
        self.after(250,self._set_sashes)
        foot=ttk.Frame(self,padding=(12,6));foot.pack(side="bottom",fill="x")
        self.status=tk.StringVar(value="Ready · render queue empty")
        ttk.Label(foot,textvariable=self.status).pack(side="left")
        self.progress=ttk.Progressbar(foot,mode="indeterminate",length=135)
        self.progress.pack(side="right",padx=8)

    def _set_sashes(self):
        try:
            width=self.bodypane.winfo_width()
            if width>=970:
                self.bodypane.sashpos(0,pixels(self,235))
                self.bodypane.sashpos(1,width-pixels(self,375))
        except tk.TclError: pass

    def _build_sidebar(self,parent):
        ttk.Label(parent,text="TILE LIBRARY",style="Panel.TLabel",
                  font=("Segoe UI Semibold",11)).pack(anchor="w",padx=12,pady=(17,8))
        ttk.Label(parent,text="Each tile is independently generated.",style="Muted.TLabel",wraplength=195).pack(anchor="w",padx=12,pady=(0,8))
        self.tree=ttk.Treeview(parent,show="tree",selectmode="extended",height=15)
        self.tree.pack(fill="both",expand=True,padx=8,pady=6)
        self.tree.bind("<<TreeviewSelect>>",self._select_tree)
        row=ttk.Frame(parent,style="Panel.TFrame");row.pack(fill="x",padx=8,pady=3)
        ttk.Button(row,text="+ New Tile",command=self._new_tile).pack(fill="x",padx=2)
        edit_row=ttk.Frame(parent,style="Panel.TFrame");edit_row.pack(fill="x",padx=8,pady=3)
        ttk.Button(edit_row,text="Duplicate",command=self._duplicate_tile).pack(side="left",expand=True,fill="x",padx=2)
        ttk.Button(edit_row,text="Delete",command=self._delete_tile).pack(side="left",expand=True,fill="x",padx=2)
        ttk.Label(parent,text="TILE PRESETS",style="Panel.TLabel").pack(anchor="w",padx=12,pady=(20,6))
        self.preset_combo=ttk.Combobox(parent,textvariable=self.preset,values=list(PRESETS),state="readonly")
        self.preset_combo.pack(fill="x",padx=11)
        ttk.Button(parent,text="Apply preset to selected tile",command=self._apply_preset).pack(fill="x",padx=11,pady=(7,9))
        ttk.Label(parent,text="KIND",style="Panel.TLabel").pack(anchor="w",padx=12,pady=(8,4))
        kind=ttk.Combobox(parent,textvariable=self.kind_var,values=KINDS,state="readonly")
        kind.pack(fill="x",padx=11)
        kind.bind("<<ComboboxSelected>>",self._set_kind)
        ttk.Label(parent,text="TILE RESOLUTION",style="Panel.TLabel").pack(anchor="w",padx=12,pady=(12,4))
        size=ttk.Combobox(parent,textvariable=self.size_var,values=["256 x 256","256 x 512","384 x 512","512 x 512","512 x 1024","1024 x 1024"],state="readonly")
        size.pack(fill="x",padx=11)
        size.bind("<<ComboboxSelected>>",self._set_size)
        ttk.Button(parent,text="Rename tile",command=self._rename_tile).pack(fill="x",padx=11,pady=(12,15))

    def _update_workspace_buttons(self):
        ws = getattr(self, 'active_workspace', 'fiber')
        if hasattr(self, 'btn_ws_fiber'):
            self.btn_ws_fiber.configure(style="PillActive.TButton" if ws == "fiber" else "Pill.TButton")
        if hasattr(self, 'btn_ws_graph'):
            self.btn_ws_graph.configure(style="PillActive.TButton" if ws == "graph" else "Pill.TButton")
        if hasattr(self, 'btn_ws_cards'):
            self.btn_ws_cards.configure(style="PillActive.TButton" if ws == "cards" else "Pill.TButton")
        if hasattr(self, 'btn_ws_render'):
            self.btn_ws_render.configure(style="PillActive.TButton" if ws == "render" else "Pill.TButton")

        if hasattr(self, 'btn_top_bake') and hasattr(self, 'btn_top_export'):
            if ws in ('fiber', 'graph'):
                self.btn_top_bake.pack(side="right", padx=2)
                self.btn_top_export.configure(text="Export Atlas", command=self._export_dialog)
            elif ws == 'cards':
                self.btn_top_bake.pack_forget()
                self.btn_top_export.configure(text="Export OBJ", command=lambda: self.card_window.export() if getattr(self, 'card_window', None) else None)
            elif ws == 'render':
                self.btn_top_bake.pack_forget()
                self.btn_top_export.configure(text="Capture PNG", command=lambda: self.render_window.capture() if getattr(self, 'render_window', None) else None)

    def _switch_workspace(self, name):
        if not hasattr(self, 'active_workspace'):
            self.active_workspace = 'fiber'
        if self.active_workspace == name:
            return

        prev = self.active_workspace
        if prev == 'fiber':
            self.bodypane.pack_forget()
        elif prev == 'graph':
            if self.construction_window and self.construction_window.winfo_exists():
                self.construction_window.pack_forget()
                if hasattr(self.construction_window, 'pause'):
                    self.construction_window.pause()
        elif prev == 'render':
            if self.render_window and self.render_window.winfo_exists():
                self.render_window.pack_forget()
                if hasattr(self.render_window, 'pause'):
                    self.render_window.pause()
        elif prev == 'cards':
            if self.card_window and self.card_window.winfo_exists():
                self.card_window.pack_forget()
                if hasattr(self.card_window, 'pause'):
                    self.card_window.pause()

        self.active_workspace = name
        container = getattr(self, 'main_content', self)
        if name == 'fiber':
            self.bodypane.pack(fill="both", expand=True)
            self.after(50, self._set_sashes)
            self._redraw()
            surf = getattr(self, '_live_gpu_viewport', None)
            if surf and hasattr(surf, 'surface') and surf.surface:
                surf.surface.focus_set()
            elif hasattr(self, 'canvas') and self.canvas:
                self.canvas.focus_set()
        elif name == 'graph':
            if self.construction_window is None or not self.construction_window.winfo_exists():
                from .construction.studio import ConstructionStudio
                self.construction_window = ConstructionStudio(container, self)
            else:
                if hasattr(self.construction_window, 'resume'):
                    self.construction_window.resume()
                elif hasattr(self.construction_window, 'receive_tile'):
                    self.construction_window.receive_tile(self.current_id)
            self.construction_window.pack(fill="both", expand=True)
            if hasattr(self.construction_window, 'canvas') and self.construction_window.canvas:
                self.construction_window.canvas.focus_set()
            else:
                self.construction_window.focus_set()
        elif name == 'render':
            if self.render_window is None or not self.render_window.winfo_exists():
                from .rendercore.studio import RenderStudio
                self.render_window = RenderStudio(container, self)
            else:
                if hasattr(self.render_window, 'resume'):
                    self.render_window.resume()
            self.render_window.pack(fill="both", expand=True)
            if self.render_window.renderer:
                self.render_window.sync_project()
                self.render_window._frame_later(0)
            if hasattr(self.render_window, 'stage') and self.render_window.stage:
                self.render_window.stage.focus_set()
            else:
                self.render_window.focus_set()
        elif name == 'cards':
            if self.card_window is None or not self.card_window.winfo_exists():
                from .card_editor import CardEditor
                self.card_window = CardEditor(container, self)
            else:
                if hasattr(self.card_window, 'resume'):
                    self.card_window.resume()
                elif hasattr(self.card_window, 'refresh'):
                    self.card_window.refresh()
            self.card_window.pack(fill="both", expand=True)
            if hasattr(self.card_window, 'canvas') and self.card_window.canvas:
                self.card_window.canvas.focus_set()
            else:
                self.card_window.focus_set()

        self._update_workspace_buttons()

    def _dispatch_global_key(self, event, release=False):
        w = getattr(event, 'widget', None)
        if isinstance(w, (ttk.Entry, ttk.Combobox, tk.Entry, tk.Spinbox, tk.Text)):
            return None
        ws = getattr(self, 'active_workspace', 'fiber')
        if ws == 'cards':
            win = getattr(self, 'card_window', None)
            if win and win.winfo_exists() and hasattr(win, '_handle_global_key'):
                if w in (win, getattr(win, 'canvas', None)):
                    return None
                return win._handle_global_key(event, release=release)
        elif ws == 'render':
            win = getattr(self, 'render_window', None)
            if win and win.winfo_exists() and hasattr(win, '_handle_global_key'):
                if w in (win, getattr(win, 'stage', None), getattr(win, 'preview_label', None)):
                    return None
                return win._handle_global_key(event)
        elif ws == 'graph':
            win = getattr(self, 'construction_window', None)
            if win and win.winfo_exists() and hasattr(win, '_handle_global_key'):
                if w in (win, getattr(win, 'canvas', None)):
                    return None
                return win._handle_global_key(event)
        return None

    def _open_construction_studio(self):
        self._switch_workspace("graph")

    def _open_render_studio(self):
        self._switch_workspace("render")

    def _open_card_editor(self):
        self._switch_workspace("cards")

    def _continue_workflow(self,destination,tile_id=None,card_ids=None):
        tile=self.project.find(tile_id or self.current_id)
        if tile is None:
            self.status.set('Source tile no longer exists; select a project tile.')
            return
        self.current_id=tile.id
        if not self.tree.exists(tile.id):self._fill_tree()
        self.tree.selection_set(tile.id)
        self._sync_from_tile()
        if destination in ('cards','render'):
            matching=[c['id'] for c in self.project.cards if c.get('tile_id')==tile.id]
            if not matching:
                from .cards import HairCard
                self._history()
                card=HairCard.create(tile.id,tile.name+' Card')
                self.project.cards.append(card.to_dict());matching=[card.id]
                self._notify_card_editor()
            result=self._results.get(tile.id)
            if result is None or result.revision!=tile.revision:self._submit_preview(tile,show_status=False)
        if destination=='graph':self._switch_workspace('graph')
        elif destination=='cards':
            self._switch_workspace('cards')
            if self.card_window:
                self.card_window.selected=set(card_ids or matching)&{c.id for c in self.card_window.cards}
                self.card_window._sync_tree();self.card_window._sync_inspector();self.card_window._render_soon(0)
        elif destination=='render':
            self._switch_workspace('render')
            if self.render_window and self.render_window.renderer:self.render_window.sync_project()
        elif destination in ('fiber','atlas'):
            self._switch_workspace('fiber')
            self.mode.set('Atlas' if destination=='atlas' else 'Tile')
            self._mode_changed();self._schedule_render(0)

    def _toggle_inline_render(self):
        from .rendercore.inline_preview import toggle
        live=self._live_gpu_viewport
        host=live.surface if live is not None and live.winfo_viewable() else self.canvas
        toggle(self,host,self,'workspace')

    def _build_workspace(self,parent):
        hdr=ttk.Frame(parent,padding=(12,8));hdr.pack(fill="x")
        self.lit_angle=tk.DoubleVar(value=40.)
        ttk.Label(hdr,text='Góc sáng').pack(side='right')
        NumberSlider(hdr,variable=self.lit_angle,from_=180,to=-180,step=1.0,width=140,height=22,
                     command=lambda v:self._redraw()).pack(side='right',padx=6)
        mode_pill=ttk.Frame(hdr,style="PillContainer.TFrame",padding=(2,2))
        mode_pill.pack(side="left",padx=(0,8))
        self.btn_mode_tile=ttk.Button(mode_pill,text="Tile",style="PillActive.TButton" if self.mode.get()=="Tile" else "Pill.TButton",
                                      command=lambda:(self.mode.set("Tile"),self._mode_changed()))
        self.btn_mode_tile.pack(side="left",padx=1)
        self.btn_mode_atlas=ttk.Button(mode_pill,text="Atlas",style="PillActive.TButton" if self.mode.get()=="Atlas" else "Pill.TButton",
                                       command=lambda:(self.mode.set("Atlas"),self._mode_changed()))
        self.btn_mode_atlas.pack(side="left",padx=1)
        ttk.Label(hdr,text="[Tab]",foreground=MUTED,font=("Segoe UI",8)).pack(side="left",padx=(0,8))
        ttk.Label(hdr,text="Map").pack(side="left",padx=(8,4))
        channels=ttk.Combobox(hdr,textvariable=self.channel,values=("lit",)+MAP_NAMES,state="readonly",width=10)
        channels.pack(side="left",padx=(0,8));channels.bind("<<ComboboxSelected>>",self._mode_changed)
        ttk.Button(hdr,text="Fit [F]",style="TButton",command=self._fit_view).pack(side="left",padx=(0,6))
        ttk.Label(hdr,text="Page").pack(side="left",padx=(6,4))
        self.page_combo=ttk.Combobox(hdr,textvariable=self.page_var,values=["0"],state="readonly",width=3)
        self.page_combo.pack(side="left",padx=(0,6))
        self.page_combo.bind("<<ComboboxSelected>>",lambda e:self._redraw())
        self.atlas_tools_frame=ttk.Frame(hdr)
        ttk.Label(self.atlas_tools_frame,text="Tool:").pack(side="left",padx=(8,4))
        for label,mode in (("Select [Q]","Select"),("Move [W]","Move"),("Rotate [E]","Rotate"),("Scale [R]","Scale")):
            ttk.Radiobutton(self.atlas_tools_frame,text=label,value=mode,variable=self.atlas_tool_var,
                            style="Toolbutton",command=self._redraw).pack(side="left",padx=1)
        ttk.Button(self.atlas_tools_frame,text="↻ 90°",style="TButton",command=self._atlas_rotate_90).pack(side="left",padx=(4,2))
        ttk.Button(self.atlas_tools_frame,text="Auto Pack",style="TButton",command=self._atlas_auto_pack).pack(side="left",padx=2)
        ttk.Button(self.atlas_tools_frame,text="Align Top",style="TButton",command=self._atlas_align_top).pack(side="left",padx=2)
        ttk.Button(self.atlas_tools_frame,text="Align Left",style="TButton",command=self._atlas_align_left).pack(side="left",padx=2)
        ttk.Button(self.atlas_tools_frame,text="Reset",style="TButton",command=self._atlas_reset_layout).pack(side="left",padx=2)
        for key,mode in (("q","Select"),("w","Move"),("e","Rotate"),("r","Scale")):
            self.bind(f"<KeyPress-{key}>",lambda e,m=mode:self._set_atlas_tool_key(e,m))
            self.bind(f"<KeyPress-{key.upper()}>",lambda e,m=mode:self._set_atlas_tool_key(e,m))
        stage=ttk.Frame(parent)
        self.workspace_stage=stage
        stage.pack(fill="both",expand=True,padx=10,pady=(0,7))
        self.canvas=tk.Canvas(stage,bg="#121316",highlightthickness=0,borderwidth=0)
        self.canvas.pack(fill="both",expand=True)
        try:
            from .engine_v2.preview import FiberPreviewViewport
            self._live_gpu_viewport=FiberPreviewViewport(stage,show_header=False)
            self._live_gpu_viewport.pack(fill="both",expand=True)
            self.canvas.pack_forget()
            self._live_gpu_viewport.surface.bind("<Button-1>",self._pick_live_gpu)
            self._live_gpu_viewport.surface.bind("<Double-Button-1>",self._pick_live_gpu)
            self._live_gpu_viewport.surface.bind("<B1-Motion>",self._sculpt_drag_live_gpu)
            self._live_gpu_viewport.surface.bind("<ButtonRelease-1>",self._sculpt_finish_live_gpu)
        except Exception:
            self._live_gpu_viewport=None
        self.canvas.bind("<Enter>",lambda e:self.canvas.focus_set(),add='+')
        self.canvas.bind("<Configure>",lambda e:self.after(80,self._redraw))
        self.canvas.bind("<Button-1>",self._pick)
        self.canvas.bind("<B1-Motion>",self._canvas_drag)
        self.canvas.bind("<ButtonRelease-1>",self._canvas_release)
        self.canvas.bind("<Double-Button-1>",self._double_click_canvas)
        self.canvas.bind("<Double-1>",self._double_click_canvas)
        self.canvas.bind("<MouseWheel>",self._zoom_view)
        self.canvas.bind("<Button-4>",lambda e:self._zoom_by(1.2))
        self.canvas.bind("<Button-5>",lambda e:self._zoom_by(1/1.2))
        self.canvas.bind("<ButtonPress-3>",self._light_down)
        self.canvas.bind("<B3-Motion>",self._light_move)
        self.canvas.bind("<ButtonRelease-3>",self._light_up)
        if self._live_gpu_viewport is not None:
            self._live_gpu_viewport.surface.bind("<Enter>",lambda e:self._live_gpu_viewport.surface.focus_set(),add='+')
            self._live_gpu_viewport.surface.bind("<ButtonPress-3>",self._light_down)
            self._live_gpu_viewport.surface.bind("<B3-Motion>",self._light_move)
            self._live_gpu_viewport.surface.bind("<ButtonRelease-3>",self._light_up)
        self.navigation=MayaNavigation(self.canvas,self._nav_orbit,self._nav_pan,self._nav_dolly,
                                       on_start=self._on_nav_start,on_end=self._on_nav_end)
        sub=ttk.Frame(parent,padding=(13,9));sub.pack(fill="x")
        self.tile_info=tk.StringVar(value="Waiting for tile")
        ttk.Label(sub,textvariable=self.tile_info).pack(side="left")
        ttk.Label(sub,text=HELP,foreground=MUTED).pack(side="right")

    def _build_controls(self,parent):
        ttk.Label(parent,text="FIBER STUDIO",style="Panel.TLabel",font=("Segoe UI Semibold",12)).pack(anchor="w",padx=12,pady=(17,3))
        ttk.Label(parent,text="Procedural shape, clusters & pigment",style="Muted.TLabel").pack(anchor="w",padx=12,pady=(0,8))
        self.notebook=ttk.Notebook(parent)
        self.notebook.pack(fill="both",expand=True,padx=6,pady=(4,10))
        self.slider_vars:dict[str,tk.DoubleVar]={}
        self.value_labels:dict[str,ttk.Label]={}
        for tab_name in ("Fiber","Shape","Clumps","Color"):
            fields=FIELDS[tab_name]
            frame=ScrollFrame(self.notebook)
            self.notebook.add(frame,text=tab_name)
            self._make_sliders(frame.body,fields)
            if tab_name=="Color": self._color_controls(frame.body)
        extras=ScrollFrame(self.notebook)
        self.notebook.add(extras,text="Extra")
        self._width_controls(extras.body)
        ttk.Label(extras.body,text="FEATHER STRUCTURE",style="Panel.TLabel",
                  font=("Segoe UI Semibold",11)).pack(anchor="w",padx=10,pady=(12,5))
        self._make_sliders(extras.body,FIELDS["Feather"])
        self.inspector=ScrollFrame(self.notebook)
        self.notebook.add(self.inspector,text="Strand")
        self._build_inspector(self.inspector.body)

    def _make_sliders(self,parent,fields):
        for key,label,lo,hi,step in fields:
            group=ttk.Frame(parent,style="Panel.TFrame",padding=(8,3));group.pack(fill="x",pady=2)
            line=ttk.Frame(group,style="Panel.TFrame");line.pack(fill="x")
            ttk.Label(line,text=label,style="Panel.TLabel").pack(side="left")
            value=tk.DoubleVar(value=float(getattr(FiberSettings(),key)))
            self.slider_vars[key]=value
            info=ttk.Label(line,text="0",style="Muted.TLabel")
            self.value_labels[key]=info
            number=tk.StringVar()
            self._number_vars[key]=number
            is_int = step >= 1.0 and isinstance(getattr(FiberSettings(), key), int)
            def on_slider_change(v, key=key, step=step):
                self._format_value(key, step)
                self._commit_slider(key, step, live=True)
                self._schedule_render(0)
            slider=NumberSlider(line,variable=value,from_=lo,to=hi,step=step,is_integer=is_int,
                                width=155,height=22,command=on_slider_change)
            slider.pack(side="right",fill="x",expand=True)
            self._format_value(key,step)

    def _format_value(self,key,step):
        v=self.slider_vars[key].get()
        decimals=3 if step<.01 else (2 if step<.1 else (1 if step<1 else 0))
        self.value_labels[key].configure(text=f"{v:.{decimals}f}")
        if key in self._number_vars:
            self._number_vars[key].set(f'{v:.{decimals}f}')

    def _number_commit(self,key,step,lo,hi):
        try:
            value=float(self._number_vars[key].get().replace(',','.'))
            if not math.isfinite(value):raise ValueError('finite value required')
        except (ValueError,tk.TclError):
            self._format_value(key,step)
            return
        self.slider_vars[key].set(min(hi,max(lo,value)))
        self._commit_slider(key,step)

    def _begin_slider(self,key):
        self._slider_drag=[key,False]

    def _end_slider(self,key,step):
        self._commit_slider(key,step)
        self._slider_drag=None
        self._schedule_render(0)

    def _width_controls(self,parent):
        ttk.Label(parent,text="PROFILE ROOT → TIP",style="Panel.TLabel",
                  font=("Segoe UI Semibold",11)).pack(anchor="w",padx=10,pady=(18,8))
        ttk.Label(parent,text="Multiply the analytical taper at five positions.",
                  style="Muted.TLabel",wraplength=270).pack(anchor="w",padx=10,pady=5)
        self.width_vars=[]
        for idx,name in enumerate(["Root (0%)","Low (25%)","Middle (50%)","Upper (75%)","Tip (100%)"]):
            outer=ttk.Frame(parent,style="Panel.TFrame",padding=(8,3));outer.pack(fill="x",pady=2)
            ttk.Label(outer,text=name,style="Panel.TLabel",width=13).pack(side="left")
            var=tk.DoubleVar(value=1.0);self.width_vars.append(var)
            scale=NumberSlider(outer,variable=var,from_=.05,to=3.0,step=0.01,width=155,height=22,
                               command=lambda v,i=idx:self._commit_width_curve(i))
            scale.pack(side="right",fill="x",expand=True)
        ttk.Button(parent,text="Reset width profile",command=self._reset_width_curve).pack(fill="x",padx=10,pady=14)

    def _commit_width_curve(self,idx):
        if self._loading_settings:return
        tile=self._current()
        if not tile:return
        if tile.construction_graph:
            self.status.set('Graph tile: use Construction Graph V4 to edit fibers')
            return
        new=[round(var.get(),3) for var in self.width_vars]
        if new==tile.settings.width_profile:return
        self._history();tile.settings.width_profile=new;tile.revision+=1
        self._schedule_render(0)

    def _reset_width_curve(self):
        tile=self._current()
        if not tile:return
        if tile.construction_graph:
            self.status.set('Graph tile: use Construction Graph V4 to edit fibers')
            return
        if tile.settings.width_profile==[1.0]*5:return
        self._history();tile.settings.width_profile=[1.0]*5
        tile.revision+=1
        for v in self.width_vars:v.set(1.0)
        self._schedule_render(0)

    def _color_controls(self,parent):
        ttk.Label(parent,text="STRAND GRADIENT",style="Panel.TLabel",font=("Segoe UI Semibold",11)).pack(anchor="w",padx=10,pady=(18,8))
        self.color_buttons={}
        for key,label in (("color_root","Root color"),("color_mid","Mid color"),("color_tip","Tip color")):
            frame=ttk.Frame(parent,style="Panel.TFrame");frame.pack(fill="x",padx=10,pady=3)
            ttk.Label(frame,text=label,style="Panel.TLabel").pack(side="left")
            btn=tk.Button(frame,text="       ",relief="flat",bg="#777777",activebackground="#a2a2a2",
                          bd=0,highlightthickness=0,command=lambda k=key:self._pick_color(k))
            btn.pack(side="right")
            self.color_buttons[key]=btn
        ttk.Label(parent,text="PIGMENT PATTERN",style="Panel.TLabel").pack(anchor="w",padx=10,pady=(15,5))
        pattern=ttk.Combobox(parent,textvariable=self.pattern_var,values=["solid","banded","agouti","speckle","ombre"],state="readonly")
        pattern.pack(fill="x",padx=9,pady=(0,15))
        pattern.bind("<<ComboboxSelected>>",self._set_pattern)

    def _build_inspector(self,parent):
        self.sculpt_var=tk.BooleanVar(value=False)
        tk.Checkbutton(parent,text="Sculpt curve: drag the 5 nodes",variable=self.sculpt_var,
                       bg=SIDEBAR,fg=ACCENT,selectcolor=CARD,activebackground=SIDEBAR,
                       activeforeground=TEXT,command=self._redraw).pack(anchor="w",padx=10,pady=(12,4))
        self.selection_label=tk.StringVar(value="Click an individual strand in the tile preview.")
        ttk.Label(parent,textvariable=self.selection_label,style="Panel.TLabel",wraplength=310).pack(anchor="w",padx=10,pady=12)
        self.ov_vars={}
        for key,label,default,lo,hi in [
            ("width_scale","Width multiplier",1.,.1,4),
            ("length_scale","Length multiplier",1.,.2,2.5),
            ("bend_add","Add bend",0.,-.6,.6),
            ("offset_x","Horizontal offset",0.,-.2,.2),
            ("offset_y","Vertical offset",0.,-.2,.2),
            ("opacity","Opacity multiplier",1.,0,1)]:
            wrapper=ttk.Frame(parent,style="Panel.TFrame",padding=(8,3));wrapper.pack(fill="x",pady=2)
            ttk.Label(wrapper,text=label,style="Panel.TLabel",width=15).pack(side="left")
            var=tk.DoubleVar(value=default);self.ov_vars[key]=var
            scale=NumberSlider(wrapper,from_=lo,to=hi,step=0.01,variable=var,width=155,height=22,
                               command=lambda v:self._commit_override())
            scale.pack(side="right",fill="x",expand=True)
        hidden=tk.BooleanVar(value=False);self.ov_vars["hidden"]=hidden
        tk.Checkbutton(parent,text="Hide individual fiber",variable=hidden,command=self._commit_override,
                       bg=SIDEBAR,fg=TEXT,selectcolor=CARD,activebackground=SIDEBAR,
                       activeforeground=TEXT).pack(anchor="w",padx=10,pady=10)
        ttk.Button(parent,text="Dye selected strand",command=self._dye_strand).pack(fill="x",padx=10,pady=3)
        ttk.Button(parent,text="Reset strand overrides",command=self._reset_strand).pack(fill="x",padx=10,pady=(3,14))

    def _current(self) -> Tile|None:
        return self.project.find(self.current_id)

    def _fill_tree(self):
        self.tree.delete(*self.tree.get_children())
        for tile in self.project.tiles:
            self.tree.insert("", "end",iid=tile.id,text=f"{tile.name}")
        sel = [tid for tid in self.selected_tile_ids if self.tree.exists(tid)]
        if not sel and self.current_id and self.tree.exists(self.current_id):
            sel = [self.current_id]
        if sel:
            self.tree.selection_set(sel)

    def _select_tree(self,event=None):
        if getattr(self,'_syncing_tree',False):return
        ids=self.tree.selection()
        if not ids: return
        self.selected_tile_ids=set(ids)
        if ids[0]==self.current_id:
            self._redraw()
            return
        self.current_id=ids[0]
        self.selected_sid=None
        self.selected_sids.clear()
        self._sync_from_tile()
        self._redraw()
        if self.mode.get()!="Atlas" or self.current_id not in self._results:
            self._schedule_render(0)

    def _sync_from_tile(self):
        tile=self._current()
        if not tile:return
        self._loading_settings=True
        for key,var in self.slider_vars.items():
            var.set(float(getattr(tile.settings,key)))
            step=next((v[4] for rows in FIELDS.values() for v in rows if v[0]==key),.01)
            self._format_value(key,step)
        self.pattern_var.set(tile.settings.pattern)
        for idx,v in enumerate(self.width_vars):v.set(tile.settings.width_profile[idx])
        self.kind_var.set(tile.kind)
        self.size_var.set(f"{tile.width} x {tile.height}")
        for key,btn in self.color_buttons.items():btn.configure(bg=getattr(tile.settings,key))
        self._sync_override()
        self._loading_settings=False

    def _sync_override(self):
        tile=self._current()
        if not tile:return
        if not self.selected_sids and not self.selected_sid:
            self.selection_label.set("Click or box drag strands in Tile view to select/edit.")
            ov={}
        elif len(self.selected_sids) > 1:
            self.selection_label.set(f"{len(self.selected_sids)} strands selected · Tile {tile.name}\n(Shift: add, Ctrl: subtract)")
            ov={}
        else:
            sid = self.selected_sid or next(iter(self.selected_sids))
            idx=sid.split(":")[1]
            ov=tile.overrides.get(idx,{})
            self.selection_label.set(f"Strand {idx} · Tile {tile.name}\nIndependent overrides (stable ID)")
        for key,var in self.ov_vars.items():
            var.set(ov.get(key,False if key=="hidden" else (1.0 if key in ("width_scale","length_scale","opacity") else 0.0)))
        self._sync_live_gpu_selection()

    def _sync_live_gpu_selection(self):
        if self._live_gpu_viewport is None:
            return
        vp = self._live_gpu_viewport
        s = getattr(self, 'app_settings', None)
        if s is not None:
            vp.show_hud = s.show_hud
            vp.show_axis_gizmo = s.show_axis_gizmo
            vp.up_axis = s.up_axis
        try:
            vp.hud_dpr = window_dpi(vp.surface) / 96.0
        except Exception:
            vp.hud_dpr = 1.0
        tile = self._current()
        if tile:
            sel_cnt = len(self.selected_sids) if self.selected_sids else (1 if self.selected_sid else 0)
            vp.hud_lines = (
                f"TILE VIEWPORT · {vp.up_axis} · {tile.name}",
                f"Size: {tile.width}×{tile.height} · Strands: {tile.settings.count} · Sel: {sel_cnt}",
                f"Zoom: {vp.zoom:.2f}x · Rev: {tile.revision}",
            )
        if not self.selected_sid and not self.selected_sids:
            self._live_gpu_viewport.set_selection(None, None, [], getattr(self, '_box_rect_screen', None))
            if self._fiber_preview is not None and self._fiber_preview.winfo_exists():
                self._fiber_preview.set_selection(None, None)
            return
        strands = None
        if self._current_truth is not None:
            strands = self._current_truth
        elif self.current_id in self._results:
            strands = self._results[self.current_id].strands
        if not strands:
            self._live_gpu_viewport.set_selection(None, None, [], getattr(self, '_box_rect_screen', None))
            return
        primary_pts = None
        nodes = None
        multi_pts = []
        for strand in strands:
            if strand.sid == self.selected_sid:
                primary_pts = strand.points
                if getattr(self, 'sculpt_var', None) and self.sculpt_var.get():
                    n_list = []
                    for i in range(5):
                        n_idx = round(i * (len(primary_pts) - 1) / 4)
                        n_list.append(primary_pts[n_idx])
                    nodes = np.array(n_list, dtype=np.float32)
            elif strand.sid in self.selected_sids:
                multi_pts.append(strand.points)
        box = getattr(self, '_box_rect_screen', None)
        self._live_gpu_viewport.set_selection(primary_pts, nodes, multi_pts, box)
        if self._fiber_preview is not None and self._fiber_preview.winfo_exists():
            self._fiber_preview.set_selection(primary_pts, nodes)

    def _history(self):
        self._undo.append(self.project.to_dict())
        if len(self._undo)>80:self._undo.pop(0)
        self._redo.clear()
        self.modified=True

    def _commit_slider(self,key,step,live=False):
        if self._loading_settings:return
        tile=self._current()
        if tile is None:return
        if tile.construction_graph:
            self.status.set('Graph tile: edit its properties in Construction Graph V4')
            self._sync_from_tile()
            return
        val=self.slider_vars[key].get()
        if step>=1:val=int(round(val))
        else:val=round(val/step)*step
        self.slider_vars[key].set(val)
        self._format_value(key,step)
        if getattr(tile.settings,key)==val:return
        drag=self._slider_drag
        if not drag or drag[0]!=key or not drag[1]:
            self._history()
            if drag and drag[0]==key:drag[1]=True
        setattr(tile.settings,key,val)
        tile.settings.sanitize()
        tile.revision+=1
        if self.mode.get()=="Tile" and self._live_gpu_viewport is not None:
            if key in LIVE_UNIFORM_ONLY:
                self._live_gpu_viewport.set_material(tile.settings)
                if self._fiber_preview is not None and self._fiber_preview.winfo_exists():
                    self._fiber_preview.set_material(tile.settings)
                return
            if key=="strand_opacity" and live and self._live_gpu_viewport._published_opacity>1e-4:
                self._live_gpu_viewport.set_material(tile.settings,update_opacity=True)
                if self._fiber_preview is not None and self._fiber_preview.winfo_exists():
                    self._fiber_preview.set_material(tile.settings,update_opacity=True)
                return
            if key in BAKE_ONLY_OPTICAL and live:
                return
        self._schedule_render(33 if live else 0)

    def _pick_color(self,key):
        tile=self._current()
        if not tile:return
        if tile.construction_graph:
            self.status.set('Graph tile: use Construction Graph V4 to edit fibers')
            return
        selected=colorchooser.askcolor(getattr(tile.settings,key),title=f"Choose {key}",parent=self)
        if not selected or not selected[1]:return
        self._history();setattr(tile.settings,key,selected[1]);tile.revision+=1
        self.color_buttons[key].configure(bg=selected[1]);self._schedule_render(0)

    def _set_pattern(self,event=None):
        tile=self._current()
        if not tile:return
        if tile.construction_graph:
            self.status.set('Graph tile: use Construction Graph V4 to edit fibers')
            return
        val=self.pattern_var.get()
        if val==tile.settings.pattern:return
        self._history();tile.settings.pattern=val;tile.revision+=1
        if self.mode.get()=="Tile" and self._live_gpu_viewport is not None:
            self._live_gpu_viewport.set_material(tile.settings)
            if self._fiber_preview is not None and self._fiber_preview.winfo_exists():
                self._fiber_preview.set_material(tile.settings)
            return
        self._schedule_render(0)

    def _set_kind(self,event=None):
        tile=self._current()
        if not tile:return
        kind=self.kind_var.get()
        if kind==tile.kind:return
        self._history();tile.kind=kind;tile.revision+=1;self._schedule_render(0)

    def _set_size(self,event=None):
        tile=self._current()
        if not tile:return
        try:w,h=(int(s.strip()) for s in self.size_var.get().split("x"))
        except ValueError:return
        if tile.width==w and tile.height==h:return
        self._history();tile.width, tile.height=w,h;tile.revision+=1
        self._invalidate_atlas();self._schedule_render(0)

    def _apply_preset(self):
        tile=self._current()
        if not tile:return
        if tile.construction_graph and not messagebox.askyesno(
                'Switch to legacy engine',
                'This tile uses Construction Graph V4. Replace it with a legacy preset?\nThe graph will be removed from this tile.', parent=self):
            return
        self._history();tile.construction_graph=None;tile.apply_preset(self.preset.get())
        tile.overrides.clear();self.selected_sid=None
        self._sync_from_tile();self._schedule_render(0)

    def _new_tile(self):
        name=simpledialog.askstring("New Fiber Tile","Tile name:",parent=self)
        if not name:return
        self._history()
        tile=Tile.create(name,self.preset.get())
        self.project.tiles.append(tile)
        self.current_id=tile.id
        self._invalidate_atlas();self._fill_tree();self._sync_from_tile();self._schedule_render(0)

    def _duplicate_tile(self):
        tile=self._current()
        if not tile:return
        self._history();new=tile.clone()
        self.project.tiles.append(new);self.current_id=new.id
        self._invalidate_atlas();self._fill_tree();self._sync_from_tile();self._schedule_render(0)

    def _delete_tile(self):
        tile=self._current()
        if not tile or len(self.project.tiles)<=1:return
        if not messagebox.askyesno("Delete Tile",f"Delete '{tile.name}'?",parent=self):return
        self._history();self.project.tiles=[t for t in self.project.tiles if t.id!=tile.id]
        self._results.pop(tile.id,None)
        self.current_id=self.project.tiles[0].id
        self._invalidate_atlas();self._fill_tree();self._sync_from_tile();self._schedule_render(0)

    def _rename_tile(self):
        tile=self._current()
        if not tile:return
        name=simpledialog.askstring("Rename Tile","Tile name:",initialvalue=tile.name,parent=self)
        if not name or name==tile.name:return
        self._history();tile.name=name;self._fill_tree()

    def _commit_override(self):
        tile=self._current()
        if not tile or (not self.selected_sid and not self.selected_sids):return
        if tile.construction_graph:
            self.status.set('Graph tile: use Construction Graph V4 to edit fibers')
            return
        target_sids = set(self.selected_sids) if self.selected_sids else {self.selected_sid}
        new={key:(bool(var.get()) if key=="hidden" else float(var.get())) for key,var in self.ov_vars.items()}
        self._history()
        for sid in target_sids:
            idx=sid.split(":")[1]
            old=tile.overrides.get(idx,{})
            tile.overrides[idx]={**old,**new}
        tile.revision+=1;self._schedule_render(0)

    def _dye_strand(self):
        tile=self._current()
        if not tile or (not self.selected_sid and not self.selected_sids):return
        if tile.construction_graph:
            self.status.set('Graph tile: use Construction Graph V4 to edit fibers')
            return
        chosen=colorchooser.askcolor(title="Fiber color override",parent=self)
        if not chosen or not chosen[1]:return
        target_sids = set(self.selected_sids) if self.selected_sids else {self.selected_sid}
        self._history()
        for sid in target_sids:
            idx=sid.split(":")[1]
            tile.overrides.setdefault(idx,{})["color"]=chosen[1]
        tile.revision+=1;self._schedule_render(0)

    def _reset_strand(self):
        tile=self._current()
        if not tile or (not self.selected_sid and not self.selected_sids):return
        if tile.construction_graph:
            self.status.set('Graph tile: use Construction Graph V4 to edit fibers')
            return
        target_sids = set(self.selected_sids) if self.selected_sids else {self.selected_sid}
        self._history()
        for sid in target_sids:
            idx=sid.split(":")[1]
            tile.overrides.pop(idx,None)
        tile.revision+=1
        self._sync_override();self._schedule_render(0)

    def _clear_atlas_ui_caches(self):
        if hasattr(self,'_atlas_comp_cache'):self._atlas_comp_cache.clear()
        if hasattr(self,'_atlas_tf_cache'):self._atlas_tf_cache.clear()
        self._atlas_scene_info=None

    def _invalidate_atlas(self):
        self._frame_revision+=1
        self._atlas=AtlasCache(self.project)
        self._clear_atlas_ui_caches()
        if hasattr(self,'_atlas_pipeline'):
            from .engine_v2.atlas_pipeline import AtlasPipeline
            self._atlas_pipeline.close()
            self._atlas_pipeline=AtlasPipeline(self._atlas,self._queue.put)
        self.page_var.set("0")
        self.page_combo.configure(values=[str(i) for i in range(self._atlas.layout.pages)] or ["0"])
        self._results.clear()

    def _repack_atlas_from_results(self):
        """Rebuild atlas pages cleanly from cached RenderResults without rebaking fibers."""
        self._frame_revision+=1
        self._atlas=AtlasCache(self.project)
        self._clear_atlas_ui_caches()
        if hasattr(self,'_atlas_pipeline'):
            from .engine_v2.atlas_pipeline import AtlasPipeline
            self._atlas_pipeline.close()
            self._atlas_pipeline=AtlasPipeline(self._atlas,self._queue.put)
        pages=max(1,self._atlas.layout.pages)
        cur_p=min(pages-1,max(0,int(self.page_var.get() or 0)))
        self.page_combo.configure(values=[str(i) for i in range(pages)])
        self.page_var.set(str(cur_p))
        for tile in self.project.tiles:
            res=self._results.get(tile.id)
            if res is not None and res.revision==tile.revision:
                self._atlas.update_tile(res)
            elif self.mode.get()=="Atlas":
                self._submit_preview(tile,show_status=False)

    def _set_atlas_tool_key(self,event,tool_mode):
        if getattr(self, 'active_workspace', 'fiber') != 'fiber':
            return
        if self.mode.get()!="Atlas":return
        if event and isinstance(event.widget,(ttk.Entry,ttk.Combobox,tk.Entry,tk.Spinbox,tk.Text)):
            return
        self.atlas_tool_var.set(tool_mode)
        self._redraw()

    def _schedule_render(self,delay=160):
        from .kernel.scene import kernel
        kernel(self.project).synchronize()
        # Throttle without postponing an already scheduled frame on each motion.
        if self._after_render is None:
            self._after_render=self.after(min(33,delay),self._start_preview)

    def _open_fiber_preview(self):
        if self._fiber_preview is None or not self._fiber_preview.winfo_exists():
            from .engine_v2.preview import FiberPreview
            self._fiber_preview=FiberPreview(self)
        else:self._fiber_preview.lift()
        self._schedule_render(0)

    def _toggle_mode_shortcut(self,event=None):
        if event and isinstance(event.widget,(ttk.Entry,ttk.Combobox,tk.Entry,tk.Spinbox,tk.Text)):
            return
        ws = getattr(self, 'active_workspace', 'fiber')
        if ws == 'cards':
            if hasattr(self, 'card_window') and self.card_window and self.card_window.winfo_exists():
                return self.card_window._toggle_inspector()
            return
        elif ws == 'render':
            if hasattr(self, 'render_window') and self.render_window and self.render_window.winfo_exists():
                return self.render_window._toggle_controls_key(event)
            return
        elif ws != 'fiber':
            return
        current=self.mode.get()
        new_mode="Atlas" if current=="Tile" else "Tile"
        self.mode.set(new_mode)
        self._mode_changed()
        return "break"

    def _mode_changed(self,event=None):
        if hasattr(self, 'btn_mode_tile') and hasattr(self, 'btn_mode_atlas'):
            is_tile = (self.mode.get() == "Tile")
            self.btn_mode_tile.configure(style="PillActive.TButton" if is_tile else "Pill.TButton")
            self.btn_mode_atlas.configure(style="PillActive.TButton" if not is_tile else "Pill.TButton")
        if self.channel.get()=='lit':
            for tile in self.project.tiles:
                if self.mode.get()=='Atlas' or tile.id==self.current_id:
                    self._submit_preview(tile,show_status=False,force_atlas=True)
        panel=getattr(self,'_inline_render',None)
        if panel and panel.winfo_exists():panel.destroy();self._inline_render=None
        if getattr(self,'atlas_tools_frame',None) is not None:
            if self.mode.get()=="Atlas":
                self.atlas_tools_frame.pack(side="left",padx=(10,0))
            else:
                self.atlas_tools_frame.pack_forget()
        if self._live_gpu_viewport is not None:
            if self.mode.get()=="Tile" and self.channel.get()!="lit":
                self.canvas.pack_forget()
                self._live_gpu_viewport.pack(fill="both",expand=True)
                self._live_gpu_viewport.request_frame()
            else:
                self._live_gpu_viewport.pack_forget()
                self.canvas.pack(fill="both",expand=True)
        self._fit_view()
        if self.mode.get()=="Atlas":
            for tile in self.project.tiles:
                if tile.id not in self._results:
                    self._submit_preview(tile,show_status=False)

    def _start_preview(self):
        self._after_render=None
        tile=self._current()
        if not tile:return
        self._submit_preview(tile)

    def _submit_preview(self,tile:Tile,show_status=True,force_atlas=False):
        force_atlas=force_atlas or self.channel.get()=='lit'
        publish=self._queue.put
        old=self._jobs.get(tile.id)
        if old:old.set()
        cancel=threading.Event();self._jobs[tile.id]=cancel
        snapshot=deepcopy(tile)
        generation=self._frame_revision
        dragging=bool(self._slider_drag)
        detail=recommended_detail(snapshot,base=22 if dragging else 36)
        # Real-time GPU viewport updates immediately for active tile
        if tile.id==self.current_id:
            from .engine_v2.engine import ENGINE
            from .engine_v2.preview import pack_instances
            def truth_work(token):
                try:
                    truth,_=ENGINE.truth(snapshot,detail=detail,cancel=token.is_set)
                    data=pack_instances(truth,snapshot.settings,token.is_set)
                    if not token.is_set():
                        publish(('truth',generation,(snapshot.id,snapshot.revision,
                                         (snapshot.width,snapshot.height),data,snapshot.settings,truth),None))
                except Exception as ex:
                    if not token.is_set():publish(('truth',generation,None,str(ex)))
            self._truth_scheduler.submit('active-truth',truth_work,priority=-1,cancel_running=not dragging)
        # Software tile bake runs in Atlas mode or when explicitly requested (e.g. entering Card Editor)
        if self.mode.get()=="Atlas" or force_atlas:
            max_edge=640 if self._slider_drag else max(snapshot.width,snapshot.height)
            scale=min(1,max_edge/max(snapshot.width,snapshot.height))
            size=(max(64,int(snapshot.width*scale)),max(64,int(snapshot.height*scale)))
            if show_status:
                self.status.set(f"Baking atlas tile {snapshot.name} ...")
                self.progress.start(12)
            def work(token):
                try:
                    r=render_tile(snapshot,size=size,detail=detail,
                                  should_cancel=lambda:cancel.is_set() or token.is_set())
                    if not cancel.is_set() and not token.is_set():
                        publish(("render",generation,r,None))
                except Exception as ex:
                    if not cancel.is_set() and not token.is_set():
                        publish(("render",generation,None,(snapshot.id,str(ex))))
            self._preview_scheduler.submit(tile.id,work,priority=0 if show_status else 10)
        else:
            if show_status:
                self.status.set(f"Live Fiber GPU · {snapshot.name} · " + ("Construction Graph V4" if snapshot.construction_graph else f"{snapshot.settings.count} fibers"))
                self.progress.stop()

    def _poll_workers(self):
        try:
            while True:
                kind,version,data,error=self._queue.get_nowait()
                if kind=='atlas':
                    if version!=self._frame_revision:continue
                    if error:
                        self.status.set(f'Atlas staging failed: {error}')
                        continue
                    self._atlas=data
                    if self.card_window is not None and self.card_window.winfo_exists():
                        self.card_window.refresh_texture()
                    self._redraw()
                    continue
                if kind=='truth':
                    if version!=self._frame_revision:continue
                    if error:
                        self.status.set(f'Live truth error: {error}')
                        continue
                    tile_id,revision,size,instances,settings_snap,truth_snap=data
                    tile=self.project.find(tile_id)
                    if tile is None or tile.id!=self.current_id:continue
                    if not self._slider_drag and tile.revision!=revision:continue
                    self._current_truth=truth_snap
                    if self._live_gpu_viewport is not None and self.mode.get()=="Tile":
                        self._live_gpu_viewport.publish(tile_id,revision,size,instances,settings_snap)
                        self._sync_live_gpu_selection()
                    if self._fiber_preview is not None and self._fiber_preview.winfo_exists():
                        self._fiber_preview.publish(tile_id,revision,size,instances,settings_snap)
                        self._fiber_preview.set_selection(getattr(self._live_gpu_viewport,'selected_points',None),
                                                          getattr(self._live_gpu_viewport,'selected_nodes',None))
                    continue
                if kind=="render":
                    if version!=self._frame_revision:continue
                    if error:
                        tile_id,msg=error
                        if "cancelled" not in msg.lower():self.status.set(f"Render error: {msg}")
                        continue
                    result=data
                    tile=self.project.find(result.tile_id)
                    if tile is None or tile.revision!=result.revision:continue
                    self._results[tile.id]=result
                    self._atlas_pipeline.submit(result,self._frame_revision)
                    if self.card_window is not None and self.card_window.winfo_exists():
                        self.card_window.refresh_texture()
                    self.status.set(f"Ready · {tile.name} · {len(result.strands)} fibers · {result.width}x{result.height}")
                    self.progress.stop()
                    self._redraw()
                if kind=="export":
                    self._exporting=False;self.progress.stop()
                    if error:
                        self.status.set("Export failed")
                        messagebox.showerror("Export failed",str(error),parent=self)
                    else:
                        self.status.set(f"Export complete · {len(data)} files")
                        messagebox.showinfo("Atlas exported",f"Exported {len(data)} files.\n\nFolder: {Path(data[0]).parent}",parent=self)
                if kind=="export_progress":
                    self.status.set(str(data))
        except Empty:pass
        if not getattr(self,'_closing',False):
            self._poll_after=self.after(16,self._poll_workers)

    def _fit_view(self):
        self.zoom=1.0;self.pan_x=0;self.pan_y=0;self.view_angle=0.;self._raw_view_angle=0.
        if self._live_gpu_viewport is not None:
            self._live_gpu_viewport.reset_view()
        self._redraw()

    def _on_nav_start(self):
        self._nav_active=True
        if getattr(self,'_nav_hq_after',None) is not None:
            try:self.after_cancel(self._nav_hq_after)
            except Exception:pass
            self._nav_hq_after=None

    def _on_nav_end(self):
        self._nav_active=False
        info=getattr(self,'_atlas_scene_info',None)
        if info and info.get('fast'):
            self._redraw()

    def _schedule_hq_atlas_redraw(self,delay=90):
        if getattr(self,'_nav_hq_after',None) is not None:
            try:self.after_cancel(self._nav_hq_after)
            except Exception:pass
        self._nav_hq_after=self.after(delay,self._run_hq_atlas_redraw)

    def _run_hq_atlas_redraw(self):
        self._nav_hq_after=None
        info=getattr(self,'_atlas_scene_info',None)
        if info and info.get('fast') and not getattr(self,'_closing',False):
            self._redraw()

    def _nav_orbit(self,dx,dy,snap=False):
        raw=getattr(self,'_raw_view_angle',self.view_angle)
        raw=(raw-dx*.4)%360
        self._raw_view_angle=raw
        if snap:
            self.view_angle=float(round(raw/90.0)*90.0%360)
        else:
            self.view_angle=float(raw)
        self._redraw()

    def _nav_pan(self,dx,dy):
        old_ix,old_iy=int(self.pan_x),int(self.pan_y)
        self.pan_x+=dx;self.pan_y+=dy
        new_ix,new_iy=int(self.pan_x),int(self.pan_y)
        mdx,mdy=new_ix-old_ix,new_iy-old_iy
        if not mdx and not mdy:return
        info=getattr(self,'_atlas_scene_info',None)
        if self.mode.get()=="Atlas" and info is not None and self.canvas.winfo_exists():
            cx0,cy0,cx1,cy1=info["cov_rect"]
            cw,ch=info["cw"],info["ch"]
            x,y,w,h=self._image_rect
            nx,ny=x+mdx,y+mdy
            ncx0,ncy0,ncx1,ncy1=cx0+mdx,cy0+mdy,cx1+mdx,cy1+mdy
            covers_ok=(
                (ncx0<=0 or ncx0<=nx+1) and
                (ncy0<=0 or ncy0<=ny+1) and
                (ncx1>=cw or ncx1>=nx+w-1) and
                (ncy1>=ch or ncy1>=ny+h-1)
            )
            if covers_ok:
                self.canvas.move("atlas_world",mdx,mdy)
                self._image_rect=(nx,ny,w,h)
                info["cov_rect"]=(ncx0,ncy0,ncx1,ncy1)
                self._atlas_scale_handles=[(n,hx+mdx,hy+mdy) for n,hx,hy in self._atlas_scale_handles]
                if self._atlas_rotate_handle is not None:
                    rhx,rhy,rcx,rcy=self._atlas_rotate_handle
                    self._atlas_rotate_handle=(rhx+mdx,rhy+mdy,rcx+mdx,rcy+mdy)
                self.canvas.tag_raise("atlas_hud")
                return
        self._redraw()

    def _nav_dolly(self,dx,dy):self._zoom_by(1/dolly_factor(dx))

    def _unrotate_event(self,event):
        x,y,w,h=self._image_rect
        px,py=rotate_point(event.x,event.y,x+w/2,y+h/2,-self.view_angle)
        return SimpleNamespace(x=px,y=py,state=getattr(event,"state",0))

    def _light_down(self,event):
        if not (event.state & SHIFT_MASK):return
        self._light_drag = (event.x, event.y, float(self.lit_angle.get()))
        return "break"

    def _light_move(self,event):
        drag = getattr(self, "_light_drag", None)
        if not drag:return
        start_x, start_y, start_ang = drag
        dx = event.x - start_x
        # 0.42 deg per pixel: horizontal drag changes azimuth
        new_ang = normalize_azimuth(start_ang - dx * 0.42)
        self.lit_angle.set(round(new_ang, 1))
        self._redraw()
        return "break"

    def _light_up(self,event):
        if getattr(self, "_light_drag", None) is not None:
            self._light_drag = None
            self._redraw()
            return "break"

    def _zoom_view(self,event):
        self._zoom_by(1.2 if event.delta>0 else (1/1.2),schedule_hq=True)

    def _zoom_by(self,factor,schedule_hq=False):
        self.zoom=float(np.clip(self.zoom*factor,.35,8.0))
        self._redraw(fast_preview=schedule_hq)
        if schedule_hq:
            self._schedule_hq_atlas_redraw(90)

    def _redraw(self,fast_preview=False):
        if not self.canvas.winfo_exists():return
        if self.mode.get()=="Tile" and self.channel.get()!="lit":
            self._sync_live_gpu_selection()
            tile=self._current()
            if tile:
                self.tile_info.set(f"{tile.name}  |  Live Fiber GPU Viewport  |  {tile.width}×{tile.height}  |  revision {tile.revision}" + ("  |  CONSTRUCTION GRAPH V4" if tile.construction_graph else ""))
            return
        self.canvas.delete("all")
        page_id=max(0,min(self._atlas.layout.pages-1,int(self.page_var.get())))
        ch_name=self.channel.get()
        if ch_name=='lit':
            from .rendercore.lit_map import image_for
            if self.mode.get()=='Tile':
                tile=self._current();result=self._results.get(tile.id) if tile else None
                if result is None:
                    if tile and tile.id not in self._jobs:self._submit_preview(tile,show_status=False,force_atlas=True)
                    return
                maps=result.maps;identity=('tile',tile.id,result.revision,id(result))
            else:
                maps={name:self._atlas.get_page(name,page_id) for name in ('color','alpha','normal','flow','roughness')}
                identity=('atlas',id(self._atlas),page_id)
            image=image_for(self,self,maps,identity,self._redraw,lambda:self.channel.get()=='lit')
        else:image=self._atlas.get_page(ch_name,page_id)

        # Cache composite display + mip pyramid per raw page instance
        comp_cache=getattr(self,'_atlas_comp_cache',None)
        if comp_cache is None:
            comp_cache={};self._atlas_comp_cache=comp_cache
        comp_key=(ch_name,page_id,id(image))
        if comp_key not in comp_cache:
            if len(comp_cache)>16:comp_cache.clear()
            shown=_composite_display(image)
            mips=[shown]
            if shown.width>=1024 and shown.height>=1024:
                m2=shown.reduce(2)
                mips.append(m2)
                if m2.width>=1024 and m2.height>=1024:
                    mips.append(m2.reduce(2))
            comp_cache[comp_key]=(shown,mips)
        shown,mips=comp_cache[comp_key]

        cw=max(1,self.canvas.winfo_width());ch=max(1,self.canvas.winfo_height())
        scale=min((cw-52)/shown.width,(ch-52)/shown.height)
        scale=max(.01,scale*self.zoom)
        w=max(1,int(shown.width*scale));h=max(1,int(shown.height*scale))
        x=(cw-w)//2+int(self.pan_x);y=(ch-h)//2+int(self.pan_y)
        self._image_rect=(x,y,w,h)

        # Pick smallest mip >= target (w, h) to cut resize cost by 4x-16x
        src_img=shown
        for m in reversed(mips):
            if m.width>=w and m.height>=h:
                src_img=m
                break

        ang=self.view_angle%360.0
        fast_nav=bool(fast_preview or getattr(self,'_nav_active',False))
        resamp=Image.Resampling.NEAREST if (fast_nav or scale>=1) else Image.Resampling.BILINEAR
        rot_resamp=Image.Resampling.NEAREST if fast_nav else Image.Resampling.BILINEAR

        # Crop to visible viewport (+256px margin) when zoomed larger than canvas
        sx0,sy0,sx1,sy1=0,0,src_img.width,src_img.height
        img_cx,img_cy=x+w*0.5,y+h*0.5
        cov_rect=(x,y,x+w,y+h)
        tw,th=w,h
        if abs(ang)<1e-4 and (w>cw+64 or h>ch+64):
            pad=256
            vx0=max(x,-pad);vy0=max(y,-pad)
            vx1=min(x+w,cw+pad);vy1=min(y+h,ch+pad)
            if vx1>vx0 and vy1>vy0:
                sx0=max(0,int(math.floor((vx0-x)/w*src_img.width)))
                sy0=max(0,int(math.floor((vy0-y)/h*src_img.height)))
                sx1=min(src_img.width,int(math.ceil((vx1-x)/w*src_img.width)))
                sy1=min(src_img.height,int(math.ceil((vy1-y)/h*src_img.height)))
                if sx1>sx0 and sy1>sy0:
                    ix0=x+sx0/src_img.width*w;iy0=y+sy0/src_img.height*h
                    ix1=x+sx1/src_img.width*w;iy1=y+sy1/src_img.height*h
                    tw=max(1,int(round(ix1-ix0)));th=max(1,int(round(iy1-iy0)))
                    img_cx=0.5*(ix0+ix1);img_cy=0.5*(iy0+iy1)
                    cov_rect=(ix0,iy0,ix1,iy1)
        elif abs(ang)>=1e-4 and (w>cw*1.5 or h>ch*1.5):
            rad=math.radians(-ang)
            dcx,dcy=cw*0.5-(x+w*0.5),ch*0.5-(y+h*0.5)
            udx=dcx*math.cos(rad)+dcy*math.sin(rad)
            udy=-dcx*math.sin(rad)+dcy*math.cos(rad)
            half_r=0.5*math.hypot(cw,ch)+256.0
            sx0=max(0,int(math.floor((w*0.5+udx-half_r)/w*src_img.width)))
            sy0=max(0,int(math.floor((h*0.5+udy-half_r)/h*src_img.height)))
            sx1=min(src_img.width,int(math.ceil((w*0.5+udx+half_r)/w*src_img.width)))
            sy1=min(src_img.height,int(math.ceil((h*0.5+udy+half_r)/h*src_img.height)))
            if sx1>sx0 and sy1>sy0:
                ix0=sx0/src_img.width*w;iy0=sy0/src_img.height*h
                ix1=sx1/src_img.width*w;iy1=sy1/src_img.height*h
                tw=max(1,int(round(ix1-ix0)));th=max(1,int(round(iy1-iy0)))
                img_cx,img_cy=rotate_point(x+0.5*(ix0+ix1),y+0.5*(iy0+iy1),x+w*0.5,y+h*0.5,self.view_angle)
                cov_rect=(cw,ch,0,0)

        tf_cache=getattr(self,'_atlas_tf_cache',None)
        if tf_cache is None:
            tf_cache={};self._atlas_tf_cache=tf_cache
        tf_key=(comp_key,id(src_img),sx0,sy0,sx1,sy1,tw,th,round(self.view_angle,4),fast_nav)
        if tf_key not in tf_cache:
            if len(tf_cache)>16:tf_cache.clear()
            sub=src_img.crop((sx0,sy0,sx1,sy1)) if (sx0>0 or sy0>0 or sx1<src_img.width or sy1<src_img.height) else src_img
            resized=sub.resize((tw,th),resamp) if (sub.width!=tw or sub.height!=th) else sub
            if abs(ang)<1e-4:
                rotated=resized
            elif abs(ang-90.0)<1e-4:
                rotated=resized.transpose(Image.Transpose.ROTATE_90)
            elif abs(ang-180.0)<1e-4:
                rotated=resized.transpose(Image.Transpose.ROTATE_180)
            elif abs(ang-270.0)<1e-4:
                rotated=resized.transpose(Image.Transpose.ROTATE_270)
            else:
                rotated=resized.rotate(self.view_angle,expand=True,resample=rot_resamp)
            tf_cache[tf_key]=ImageTk.PhotoImage(rotated)
        self._preview_image=tf_cache[tf_key]
        self.canvas.create_image(img_cx,img_cy,image=self._preview_image,anchor="center",tags=("atlas_world","atlas_bg"))
        self.canvas.create_rectangle(x,y,x+w,y+h,outline="#686d75",width=1,tags=("atlas_world","atlas_bg"))
        if abs(ang)>=1e-4:
            rotate_overlays(self.canvas,x+w/2,y+h/2,self.view_angle,tag="atlas_bg")

        self._atlas_scene_info={"cw":cw,"ch":ch,"cov_rect":cov_rect,"fast":fast_nav}
        self._redraw_atlas_overlays(update_info=True)
        self._draw_atlas_hud_and_gizmo(cw, ch)

    def _redraw_atlas_overlays(self, update_info: bool = False):
        if not self.canvas.winfo_exists() or self.mode.get()!="Atlas":return
        self.canvas.delete("atlas_ov")
        self.canvas.delete("atlas_box")
        x,y,w,h=self._image_rect
        drag_state=getattr(self,'_atlas_drag_state',None)
        drag_cur=(drag_state or {}).get('current',{})
        page_idx=int(self.page_var.get())
        atlas_sz=self._atlas.layout.size
        sel_boxes=[]
        for t in self.project.tiles:
            placement=self._atlas.layout.placements.get(t.id)
            if not placement or placement.page!=page_idx:continue
            if t.id in drag_cur:
                cur_x,cur_y,cur_w,cur_h,cur_rot=drag_cur[t.id]
            else:
                cur_x,cur_y,cur_w,cur_h,cur_rot=placement.x,placement.y,placement.width,placement.height,getattr(placement,'rotation',0.0)
            px=x+(cur_x/atlas_sz)*w
            py=y+(cur_y/atlas_sz)*h
            pw=(cur_w/atlas_sz)*w
            ph=(cur_h/atlas_sz)*h
            is_sel=(t.id in self.selected_tile_ids)
            if is_sel:
                sel_boxes.append((px,py,px+pw,py+ph,cur_rot))
            self.canvas.create_rectangle(px,py,px+pw,py+ph,outline="#ffba42" if is_sel else "#9398a0",width=3 if is_sel else 1,tags=("atlas_world","atlas_ov"))
            if pw>36:
                lbl=t.name[:14]+(f" ({int(round(cur_rot))%360}°)" if abs(cur_rot%360.0)>0.5 else "")
                self.canvas.create_text(px+3,py+3,text=lbl,anchor="nw",fill="#ffe6b8" if is_sel else "#c8ccd4",font=("Segoe UI",font_pixels(self,9 if is_sel else 8)),tags=("atlas_world","atlas_ov"))

        self._atlas_scale_handles=[]
        self._atlas_rotate_handle=None
        tool_mode=self.atlas_tool_var.get()
        if sel_boxes:
            gx0=min(b[0] for b in sel_boxes)
            gy0=min(b[1] for b in sel_boxes)
            gx1=max(b[2] for b in sel_boxes)
            gy1=max(b[3] for b in sel_boxes)
            if len(sel_boxes)>1:
                self.canvas.create_rectangle(gx0,gy0,gx1,gy1,outline="#ffd27d",width=1,dash=(3,3),tags=("atlas_world","atlas_ov"))
            if tool_mode=="Scale":
                hs=4.5
                gm_x,gm_y=0.5*(gx0+gx1),0.5*(gy0+gy1)
                handle_pts=(
                    ("nw",gx0,gy0),("n",gm_x,gy0),("ne",gx1,gy0),
                    ("e",gx1,gm_y),("se",gx1,gy1),("s",gm_x,gy1),
                    ("sw",gx0,gy1),("w",gx0,gm_y),
                )
                for hname,hx,hy in handle_pts:
                    self.canvas.create_rectangle(hx-hs,hy-hs,hx+hs,hy+hs,fill="#ffba42",outline="#121316",width=1,tags=("atlas_world","atlas_ov"))
                    self._atlas_scale_handles.append((hname,hx,hy))
            elif tool_mode=="Rotate":
                rcx,rcy=0.5*(gx0+gx1),0.5*(gy0+gy1)
                rr=max(24.0,min(0.45*max(gx1-gx0,gy1-gy0),90.0))
                self.canvas.create_oval(rcx-rr,rcy-rr,rcx+rr,rcy+rr,outline="#64d2ff",width=1.5,dash=(4,3),tags=("atlas_world","atlas_ov"))
                rhx,rhy=rcx,rcy-rr
                self.canvas.create_line(rcx,rcy,rhx,rhy,fill="#64d2ff",width=1.5,tags=("atlas_world","atlas_ov"))
                self.canvas.create_oval(rhx-5,rhy-5,rhx+5,rhy+5,fill="#64d2ff",outline="#121316",width=1,tags=("atlas_world","atlas_ov"))
                self._atlas_rotate_handle=(rhx,rhy,rcx,rcy)
                if drag_state and drag_state.get('mode')=='rotate':
                    d_ang=drag_state.get('delta_deg',0.0)
                    self.canvas.create_text(rcx,rcy-rr-14,text=f"{d_ang:+.1f}°",fill="#8be0ff",font=("Segoe UI Semibold",font_pixels(self,9)),tags=("atlas_world","atlas_ov"))

        if update_info:
            self.tile_info.set(f"Atlas  |  {atlas_sz}²  |  {self._atlas.layout.pages} page(s)  |  Tool: {tool_mode}")
        if abs(self.view_angle%360.0)>=1e-4:
            rotate_overlays(self.canvas,x+w/2,y+h/2,self.view_angle,tag="atlas_ov")
        box=getattr(self,'_atlas_box_drag',None)
        if box:
            bx0,by0=box['start_x'],box['start_y']
            bx1,by1=box['cur_x'],box['cur_y']
            rx0,rx1=min(bx0,bx1),max(bx0,bx1)
            ry0,ry1=min(by0,by1),max(by0,by1)
            self.canvas.create_rectangle(rx0,ry0,rx1,ry1,outline="#ffba42",width=1,dash=(4,3),tags=("atlas_box",))
        self.canvas.tag_raise("atlas_hud")

    def _draw_atlas_hud_and_gizmo(self, cw: int, ch: int):
        s = getattr(self, 'app_settings', None)
        if s is None or s.show_hud:
            up_axis = s.up_axis if s else "Y-Up"
            pad_x, pad_y = pixels(self, 12), pixels(self, 12)
            # Maya-style transparent HUD: crisp overlaid text with drop-shadow, no background box
            lines = (
                (f"ATLAS VIEWPORT · {up_axis} · Page {self.page_var.get()} · Tool: {self.atlas_tool_var.get()}", "#e8b87a", ("Segoe UI Semibold", font_pixels(self, 9))),
                (f"Size: {self._atlas.layout.size}² · Selected: {len(self.selected_tile_ids)} · Zoom: {self.zoom:.2f}x", "#e6eaf0", ("Segoe UI", font_pixels(self, 8))),
                (f"Map: {self.channel.get()} · Tiles: {len(self.project.tiles)}", "#cfd5df", ("Segoe UI", font_pixels(self, 8))),
            )
            y_cur = pad_y
            for text, color, fnt in lines:
                self.canvas.create_text(pad_x + 1, y_cur + 1, anchor="nw", fill="#080a0e", text=text, font=fnt, tags=("atlas_hud",))
                self.canvas.create_text(pad_x, y_cur, anchor="nw", fill=color, text=text, font=fnt, tags=("atlas_hud",))
                y_cur += pixels(self, 16)
        if s is None or s.show_axis_gizmo:
            cx, cy = pixels(self, 44), ch - pixels(self, 44)
            r = pixels(self, 26)
            self.canvas.create_oval(cx - r - 8, cy - r - 8, cx + r + 8, cy + r + 8, fill="#12151b", outline="#383e4a", width=1, tags=("atlas_hud",))
            ang = math.radians(self.view_angle)
            ux, uy = math.cos(ang), -math.sin(ang)
            vx, vy = -math.sin(ang), -math.cos(ang)
            self.canvas.create_line(cx, cy, cx + ux * r, cy + uy * r, fill="#f25555", width=2, tags=("atlas_hud",))
            self.canvas.create_text(cx + ux * (r + 9), cy + uy * (r + 9), text="X", fill="#f25555", font=("Segoe UI Semibold", font_pixels(self, 8)), tags=("atlas_hud",))
            self.canvas.create_line(cx, cy, cx + vx * r, cy + vy * r, fill="#52d669", width=2, tags=("atlas_hud",))
            self.canvas.create_text(cx + vx * (r + 9), cy + vy * (r + 9), text="Y", fill="#52d669", font=("Segoe UI Semibold", font_pixels(self, 8)), tags=("atlas_hud",))

    def _atlas_auto_pack(self):
        """Recompute optimal shelf packing without manual overrides and commit."""
        self._history()
        self.project.metadata.pop("tile_placements", None)
        self._repack_atlas_from_results()
        self._redraw()
        self.status.set("Atlas tiles packed automatically.")

    def _atlas_align_top(self):
        """Align selected (or all on page) tiles to the top margin."""
        page=int(self.page_var.get())
        placements=self.project.metadata.setdefault("tile_placements", {})
        top_y=self._atlas.layout.gutter
        targets=self.selected_tile_ids or {t.id for t in self.project.tiles}
        self._history()
        for tid in targets:
            p=self._atlas.layout.placements.get(tid)
            if p and p.page==page:
                placements[tid]={"page":page,"x":p.x,"y":top_y,"width":p.width,"height":p.height,"rotation":getattr(p,"rotation",0.0)}
        self._repack_atlas_from_results()
        self._redraw()
        self.status.set(f"Atlas tiles on page {page} aligned to top.")

    def _atlas_align_left(self):
        """Align selected (or all on page) tiles to the left margin."""
        page=int(self.page_var.get())
        placements=self.project.metadata.setdefault("tile_placements", {})
        left_x=self._atlas.layout.gutter
        targets=self.selected_tile_ids or {t.id for t in self.project.tiles}
        self._history()
        for tid in targets:
            p=self._atlas.layout.placements.get(tid)
            if p and p.page==page:
                placements[tid]={"page":page,"x":left_x,"y":p.y,"width":p.width,"height":p.height,"rotation":getattr(p,"rotation",0.0)}
        self._repack_atlas_from_results()
        self._redraw()
        self.status.set(f"Atlas tiles on page {page} aligned to left.")

    def _atlas_rotate_90(self):
        """Rotate selected tile(s) on the atlas by 90 degrees around their center."""
        page=int(self.page_var.get())
        targets=self.selected_tile_ids or ({self.current_id} if self.current_id else set())
        if not targets:return
        placements=self.project.metadata.setdefault("tile_placements", {})
        gutter=self._atlas.layout.gutter
        atlas_size=self._atlas.layout.size
        self._history()
        for tid in targets:
            p=self._atlas.layout.placements.get(tid)
            if not p or p.page!=page:continue
            new_rot=(getattr(p,"rotation",0.0)+90.0)%360.0
            nw,nh=p.height,p.width
            cx,cy=p.x+p.width*0.5,p.y+p.height*0.5
            nx=max(gutter,min(atlas_size-nw-gutter,int(round(cx-nw*0.5))))
            ny=max(gutter,min(atlas_size-nh-gutter,int(round(cy-nh*0.5))))
            placements[tid]={"page":page,"x":nx,"y":ny,"width":nw,"height":nh,"rotation":new_rot}
        self._repack_atlas_from_results()
        self._redraw()
        self.status.set("Rotated selected atlas tile(s) 90°.")

    def _atlas_reset_layout(self):
        """Reset atlas tile placements to clean automatic shelf packing."""
        self._atlas_auto_pack()

    def _canvas_drag(self,event):
        if self.mode.get()=="Atlas":
            self._atlas_tile_drag(event)
        else:
            self._sculpt_drag(event)

    def _canvas_release(self,event):
        if self.mode.get()=="Atlas":
            self._atlas_tile_release(event)
        else:
            self._sculpt_finish(event)

    def _double_click_canvas(self,event):
        """Double click opens tile view when clicking an atlas tile rect."""
        event=self._unrotate_event(event)
        x,y,w,h=self._image_rect
        if not (x<=event.x<=x+w and y<=event.y<=y+h):return
        if self.mode.get()=="Atlas":
            ax=(event.x-x)/w*self._atlas.layout.size
            ay=(event.y-y)/h*self._atlas.layout.size
            for tid,p in self._atlas.layout.placements.items():
                if p.page==int(self.page_var.get()) and p.x<=ax<=p.x+p.width and p.y<=ay<=p.y+p.height:
                    self.tree.selection_set(tid)
                    self.current_id=tid
                    self.selected_tile_ids={tid}
                    self._sync_from_tile()
                    self.mode.set("Tile")
                    self._mode_changed()
                    self._select_tree()
                    return

    def _start_atlas_transform(self, mode, drag_group, ax, ay, handle="center"):
        orig = {}
        for tid in drag_group:
            pl = self._atlas.layout.placements.get(tid)
            if pl:
                orig[tid] = (pl.x, pl.y, pl.width, pl.height, getattr(pl, "rotation", 0.0))
        if not orig:
            return
        gx0 = min(v[0] for v in orig.values())
        gy0 = min(v[1] for v in orig.values())
        gx1 = max(v[0] + v[2] for v in orig.values())
        gy1 = max(v[1] + v[3] for v in orig.values())
        cx, cy = 0.5 * (gx0 + gx1), 0.5 * (gy0 + gy1)
        if mode == "scale":
            px = gx1 if "w" in handle else (gx0 if "e" in handle else cx)
            py = gy1 if "n" in handle else (gy0 if "s" in handle else cy)
        else:
            px, py = cx, cy
        self._atlas_drag_state = {
            "mode": mode,
            "tiles": set(orig.keys()),
            "handle": handle,
            "start_ax": ax,
            "start_ay": ay,
            "pivot_x": px,
            "pivot_y": py,
            "group_box": (gx0, gy0, gx1, gy1),
            "start_angle": math.degrees(math.atan2(ay - py, ax - px)),
            "delta_deg": 0.0,
            "orig": orig,
            "current": dict(orig),
        }

    def _sync_tree_selection(self):
        sel_list = [tid for tid in self.selected_tile_ids if self.tree.exists(tid)]
        self._syncing_tree = True
        try:
            self.tree.selection_set(sel_list if sel_list else ())
        finally:
            self._syncing_tree = False

    def _atlas_tile_drag(self,event):
        if getattr(self, '_atlas_box_drag', None):
            box = self._atlas_box_drag
            box['cur_x'] = event.x
            box['cur_y'] = event.y
            self.canvas.delete("atlas_box")
            rx0, rx1 = min(box['start_x'], box['cur_x']), max(box['start_x'], box['cur_x'])
            ry0, ry1 = min(box['start_y'], box['cur_y']), max(box['start_y'], box['cur_y'])
            self.canvas.create_rectangle(rx0, ry0, rx1, ry1, outline="#ffba42", width=1, dash=(4, 3), tags=("atlas_box",))
            return
        state = getattr(self, '_atlas_drag_state', None)
        if not state:return
        self._pending_single_select = None
        shift = bool(getattr(event, "state", 0) & 0x0001)
        unrot=self._unrotate_event(event)
        x,y,w,h=self._image_rect
        if w<=0 or h<=0:return
        atlas_size=self._atlas.layout.size
        gutter=self._atlas.layout.gutter
        ax=(unrot.x-x)/w*atlas_size
        ay=(unrot.y-y)/h*atlas_size
        mode=state["mode"]
        new_tf={}
        if mode=="move":
            dx_atlas=ax-state["start_ax"]
            dy_atlas=ay-state["start_ay"]
            if shift:
                if abs(dx_atlas)>=abs(dy_atlas):
                    dy_atlas=0.0
                else:
                    dx_atlas=0.0
            for tid,(ox,oy,ow,oh,orot) in state["orig"].items():
                nx=max(gutter,min(atlas_size-ow-gutter,int(round(ox+dx_atlas))))
                ny=max(gutter,min(atlas_size-oh-gutter,int(round(oy+dy_atlas))))
                new_tf[tid]=(nx,ny,ow,oh,orot)
        elif mode=="scale":
            handle=state["handle"]
            px,py=state["pivot_x"],state["pivot_y"]
            gx0,gy0,gx1,gy1=state["group_box"]
            gw,gh=max(16.0,gx1-gx0),max(16.0,gy1-gy0)
            sx=sy=1.0
            if handle=="center":
                s=max(0.1,1.0+(ax-state["start_ax"])/max(64.0,gw))
                sx=sy=s
            else:
                if "e" in handle:
                    sx=max(0.1,(ax-px)/max(16.0,gx1-px))
                elif "w" in handle:
                    sx=max(0.1,(px-ax)/max(16.0,px-gx0))
                if "s" in handle:
                    sy=max(0.1,(ay-py)/max(16.0,gy1-py))
                elif "n" in handle:
                    sy=max(0.1,(py-ay)/max(16.0,py-gy0))
                if shift and len(handle)==2:
                    s=max(sx,sy);sx=sy=s
            for tid,(ox,oy,ow,oh,orot) in state["orig"].items():
                nw=max(16,min(atlas_size-2*gutter,int(round(ow*sx))))
                nh=max(16,min(atlas_size-2*gutter,int(round(oh*sy))))
                nx=int(round(px+(ox-px)*sx))
                ny=int(round(py+(oy-py)*sy))
                nx=max(gutter,min(atlas_size-nw-gutter,nx))
                ny=max(gutter,min(atlas_size-nh-gutter,ny))
                new_tf[tid]=(nx,ny,nw,nh,orot)
        elif mode=="rotate":
            px,py=state["pivot_x"],state["pivot_y"]
            cur_ang=math.degrees(math.atan2(ay-py,ax-px))
            delta=((cur_ang-state["start_angle"]+180.0)%360.0)-180.0
            if shift:
                delta=round(delta/15.0)*15.0
            state["delta_deg"]=-delta
            rad=math.radians(delta)
            ca,sa=math.cos(rad),math.sin(rad)
            for tid,(ox,oy,ow,oh,orot) in state["orig"].items():
                nrot=(orot-delta)%360.0
                swap=(abs((nrot%180.0)-90.0)<45.0)!=(abs((orot%180.0)-90.0)<45.0)
                nw,nh=(oh,ow) if swap else (ow,oh)
                ocx,ocy=ox+ow*0.5,oy+oh*0.5
                dx,dy=ocx-px,ocy-py
                ncx=px+dx*ca-dy*sa
                ncy=py+dx*sa+dy*ca
                nx=max(gutter,min(atlas_size-nw-gutter,int(round(ncx-nw*0.5))))
                ny=max(gutter,min(atlas_size-nh-gutter,int(round(ncy-nh*0.5))))
                new_tf[tid]=(nx,ny,nw,nh,nrot)
        state["current"]=new_tf
        self._redraw_atlas_overlays()

    def _atlas_tile_release(self,event):
        pending_single = getattr(self, '_pending_single_select', None)
        self._pending_single_select = None
        box_drag = getattr(self, '_atlas_box_drag', None)
        if box_drag:
            x,y,w,h=self._image_rect
            if w > 0 and h > 0:
                p0 = self._unrotate_event(SimpleNamespace(x=box_drag['start_x'], y=box_drag['start_y']))
                p1 = self._unrotate_event(SimpleNamespace(x=event.x, y=event.y))
                bx0, bx1 = min(p0.x, p1.x), max(p0.x, p1.x)
                by0, by1 = min(p0.y, p1.y), max(p0.y, p1.y)
                al0 = (bx0 - x) / w * self._atlas.layout.size
                al1 = (bx1 - x) / w * self._atlas.layout.size
                at0 = (by0 - y) / h * self._atlas.layout.size
                at1 = (by1 - y) / h * self._atlas.layout.size
                page = int(self.page_var.get())
                hit_tiles = set()
                for tid, p in self._atlas.layout.placements.items():
                    if p.page == page:
                        if not (p.x + p.width < al0 or p.x > al1 or p.y + p.height < at0 or p.y > at1):
                            hit_tiles.add(tid)
                orig = box_drag['original']
                if box_drag['ctrl']:
                    self.selected_tile_ids = orig - hit_tiles
                elif box_drag['shift']:
                    self.selected_tile_ids = orig | hit_tiles
                else:
                    self.selected_tile_ids = hit_tiles
                if self.selected_tile_ids and self.current_id not in self.selected_tile_ids:
                    self.current_id = next(iter(self.selected_tile_ids))
                    self._sync_from_tile()
                self._sync_tree_selection()
            self._atlas_box_drag = None
            self._redraw_atlas_overlays(update_info=True)
            return

        state=getattr(self,'_atlas_drag_state',None)
        self._atlas_drag_state=None
        if state:
            cur=state["current"]
            orig=state["orig"]
            tiles=state["tiles"]
            changed = any(cur.get(t) != orig.get(t) for t in tiles)
            if changed:
                self._history()
                placements=self.project.metadata.setdefault("tile_placements",{})
                page=int(self.page_var.get())
                for tid in tiles:
                    if tid in cur:
                        nx,ny,nw,nh,nrot=cur[tid]
                        placements[tid]={"page":page,"x":nx,"y":ny,"width":nw,"height":nh,"rotation":float(nrot%360.0)}
                self._repack_atlas_from_results()
                self._redraw()
                self.status.set(f"Atlas tile(s) {state['mode']} applied.")
                return
        if pending_single and pending_single in self.selected_tile_ids:
            self.selected_tile_ids = {pending_single}
            self.current_id = pending_single
            self._sync_from_tile()
            self._sync_tree_selection()
        if state or pending_single:
            self._redraw_atlas_overlays(update_info=True)

    def _sculpt_drag(self,event):
        if self._drag_index is None or self._drag_start is None:return
        event=self._unrotate_event(event)
        x,y,w,h=self._image_rect
        self._drag_offset=((event.x-self._drag_start[0])/max(1,w),
                           (event.y-self._drag_start[1])/max(1,h))
        self._redraw()

    def _sculpt_finish(self,event):
        if self._drag_index is None:return
        tile=self._current()
        if tile and self.selected_sid:
            dx,dy=self._drag_offset
            if abs(dx)+abs(dy)>1e-5:
                idx=self.selected_sid.split(":")[1]
                old=tile.overrides.get(idx,{})
                nodes=deepcopy(old.get("curve_nodes",[[0.0,0.0] for _ in range(5)]))
                nodes[self._drag_index][0]+=dx
                nodes[self._drag_index][1]+=dy
                self._history()
                tile.overrides[idx]={**old,"curve_nodes":nodes}
                tile.revision+=1
                self._schedule_render(0)
        self._drag_index=None;self._drag_start=None;self._drag_offset=(0.,0.)
        self._redraw()

    def _pick(self,event):
        raw_x, raw_y = event.x, event.y
        ev_state = getattr(event, "state", 0)
        shift = bool(ev_state & 0x0001)
        ctrl = bool(ev_state & 0x0004)
        event=self._unrotate_event(event)
        x,y,w,h=self._image_rect
        if self.mode.get()=="Atlas":
            if w<=0 or h<=0:return
            self._pending_single_select = None
            ax=(event.x-x)/w*self._atlas.layout.size
            ay=(event.y-y)/h*self._atlas.layout.size
            tool_mode=self.atlas_tool_var.get()
            if tool_mode=="Scale" and self.selected_tile_ids:
                for hname,hx,hy in getattr(self,'_atlas_scale_handles',[]):
                    if abs(event.x-hx)<=9 and abs(event.y-hy)<=9:
                        self._start_atlas_transform("scale",self.selected_tile_ids,ax,ay,handle=hname)
                        self._redraw_atlas_overlays()
                        return
            if tool_mode=="Rotate" and self.selected_tile_ids and getattr(self,'_atlas_rotate_handle',None):
                rhx,rhy,_,_=self._atlas_rotate_handle
                if math.hypot(event.x-rhx,event.y-rhy)<=12:
                    self._start_atlas_transform("rotate",self.selected_tile_ids,ax,ay)
                    self._redraw_atlas_overlays()
                    return
            clicked_tid = None
            if x<=event.x<=x+w and y<=event.y<=y+h:
                page_idx = int(self.page_var.get())
                for t in reversed(self.project.tiles):
                    p = self._atlas.layout.placements.get(t.id)
                    if p and p.page==page_idx and p.x<=ax<=p.x+p.width and p.y<=ay<=p.y+p.height:
                        clicked_tid = t.id
                        break
            if clicked_tid:
                if ctrl:
                    if clicked_tid in self.selected_tile_ids:
                        self.selected_tile_ids.discard(clicked_tid)
                    else:
                        self.selected_tile_ids.add(clicked_tid)
                elif shift:
                    self.selected_tile_ids.add(clicked_tid)
                else:
                    if clicked_tid not in self.selected_tile_ids:
                        self.selected_tile_ids = {clicked_tid}
                    elif len(self.selected_tile_ids) > 1:
                        self._pending_single_select = clicked_tid
                if self.selected_tile_ids:
                    if clicked_tid in self.selected_tile_ids:
                        self.current_id = clicked_tid
                    elif self.current_id not in self.selected_tile_ids:
                        self.current_id = next(iter(self.selected_tile_ids))
                    self._sync_from_tile()
                self._sync_tree_selection()
                if tool_mode!="Select" and self.selected_tile_ids:
                    drag_group = set(self.selected_tile_ids) if clicked_tid in self.selected_tile_ids else {clicked_tid}
                    self._start_atlas_transform(tool_mode.lower(),drag_group,ax,ay,handle="center")
                self._redraw_atlas_overlays(update_info=True)
                return
            else:
                # Clicked empty space on atlas: initiate box drag selection
                if not shift and not ctrl:
                    self.selected_tile_ids.clear()
                    self._sync_tree_selection()
                self._atlas_box_drag = {
                    'start_x': raw_x, 'start_y': raw_y,
                    'cur_x': raw_x, 'cur_y': raw_y,
                    'shift': shift, 'ctrl': ctrl,
                    'original': set(self.selected_tile_ids)
                }
                self._redraw_atlas_overlays(update_info=True)
                return
        if not (x<=event.x<=x+w and y<=event.y<=y+h):return
        tile=self._current()
        if not tile:return
        r=self._results.get(tile.id)
        if not r:return
        if self.sculpt_var.get() and self.selected_sid:
            for strand in r.strands:
                if strand.sid!=self.selected_sid:continue
                for i in range(5):
                    node_idx=round(i*(len(strand.points)-1)/4)
                    px,py=strand.points[node_idx]
                    if math.hypot(event.x-(x+float(px)*w),event.y-(y+float(py)*h))<pixels(self,12):
                        self._drag_index=i;self._drag_start=(event.x,event.y)
                        self._drag_offset=(0.,0.)
                        return
                break
        nx=(event.x-x)/w
        ny=(event.y-y)/h
        best_sid=None;best_d=float("inf")
        # Vectorized polyline proximity over each 2D strand; only on click.
        for strand in r.strands:
            p=strand.points
            a=p[:-1];b=p[1:];v=b-a
            z=np.array([nx,ny],dtype=np.float32)-a
            denom=np.maximum(np.sum(v*v,axis=-1),1e-10)
            t=np.clip(np.sum(z*v,axis=-1)/denom,0,1)
            nearest=a+t[:,None]*v
            d=((nearest[:,0]-nx)*w)**2+((nearest[:,1]-ny)*h)**2
            dist=float(np.min(d))
            if dist<best_d: best_d=dist;best_sid=strand.sid
        if best_d<=pixels(self,14)**2:
            if ctrl:
                self.selected_sids.discard(best_sid)
                if self.selected_sid == best_sid:
                    self.selected_sid = next(iter(self.selected_sids), None)
            elif shift:
                self.selected_sids.add(best_sid)
                self.selected_sid = best_sid
            else:
                self.selected_sid=best_sid
                self.selected_sids={best_sid}
            self._sync_override()
            self.notebook.select(self.inspector)
            self._redraw()
        else:
            if not shift and not ctrl:
                self.selected_sid = None
                self.selected_sids.clear()
                self._sync_override()
                self._redraw()

    def _pick_live_gpu(self,event):
        if not self._live_gpu_viewport:return
        tile=self._current()
        if not tile:return
        strands=self._current_truth
        if strands is None and tile.id in self._results:
            strands=self._results[tile.id].strands
        if not strands:return

        # Check if clicking on sculpt node of already selected strand
        if getattr(self,'sculpt_var',None) and self.sculpt_var.get() and self.selected_sid:
            for s in strands:
                if s.sid!=self.selected_sid:continue
                pts=s.points
                for i in range(5):
                    node_idx=round(i*(len(pts)-1)/4)
                    norm_pt=pts[node_idx]
                    tw, th = self._live_gpu_viewport.tile_size
                    w = max(1, self._live_gpu_viewport.surface.winfo_width())
                    h = max(1, self._live_gpu_viewport.surface.winfo_height())
                    fit = min(w / tw, h / th) * 0.9 * self._live_gpu_viewport.zoom
                    c = math.cos(self._live_gpu_viewport.angle)
                    s_ang = math.sin(self._live_gpu_viewport.angle)
                    p_tile = norm_pt * np.array([tw, th], dtype=np.float32)
                    centered = p_tile - 0.5 * np.array([tw, th], dtype=np.float32)
                    rot_x = c * centered[0] - s_ang * centered[1]
                    rot_y = s_ang * centered[0] + c * centered[1]
                    screen_x = rot_x * fit + self._live_gpu_viewport.pan[0] + 0.5 * w
                    screen_y = 0.5 * h - (rot_y * fit + self._live_gpu_viewport.pan[1])
                    if math.hypot(event.x - screen_x, event.y - screen_y) < pixels(self, 14):
                        self._drag_index = i
                        self._drag_start = (event.x, event.y)
                        self._drag_offset = (0., 0.)
                        return
                break

        # Check modifier keys: Shift to add, Ctrl to subtract
        shift = bool(event.state & 0x0001)
        ctrl = bool(event.state & 0x0004)

        # Map screen click to normalized tile coords
        norm_x, norm_y = self._live_gpu_viewport.screen_to_tile(event.x, event.y)
        p_norm = np.array([norm_x, norm_y], dtype=np.float32)
        tw, th = self._live_gpu_viewport.tile_size
        w = max(1, self._live_gpu_viewport.surface.winfo_width())
        h = max(1, self._live_gpu_viewport.surface.winfo_height())
        fit = min(w / tw, h / th) * 0.9 * self._live_gpu_viewport.zoom

        best_sid = None
        best_dist = float('inf')

        batch = getattr(strands, 'batch', None)
        if batch is not None and batch.uniform_detail >= 2 and batch.count == len(strands):
            n = batch.count
            d = batch.uniform_detail
            pts = batch.points.reshape(n, d, 2)
            a = pts[:, :-1, :]
            b = pts[:, 1:, :]
            v = b - a
            z = p_norm[None, None, :] - a
            denom = np.maximum(np.sum(v * v, axis=-1), 1e-10)
            t = np.clip(np.sum(z * v, axis=-1) / denom, 0.0, 1.0)
            nearest = a + t[..., None] * v
            diff_norm = nearest - p_norm[None, None, :]
            diff_tile = diff_norm * np.array([tw, th], dtype=np.float32)
            d2_tile = np.sum(diff_tile * diff_tile, axis=-1)
            min_d2 = np.min(d2_tile, axis=-1)
            best_idx = int(np.argmin(min_d2))
            dist_screen = math.sqrt(float(min_d2[best_idx])) * fit
            if dist_screen <= pixels(self, 16):
                best_sid = strands[best_idx].sid
        else:
            for strand in strands:
                pts = strand.points
                a = pts[:-1]
                b = pts[1:]
                v = b - a
                z = p_norm - a
                denom = np.maximum(np.sum(v * v, axis=-1), 1e-10)
                t = np.clip(np.sum(z * v, axis=-1) / denom, 0.0, 1.0)
                nearest = a + t[:, None] * v
                diff_norm = nearest - p_norm
                diff_tile = diff_norm * np.array([tw, th], dtype=np.float32)
                d2_tile = np.sum(diff_tile * diff_tile, axis=-1)
                dist_screen = math.sqrt(float(np.min(d2_tile))) * fit
                if dist_screen < best_dist:
                    best_dist = dist_screen
                    best_sid = strand.sid
            if best_dist > pixels(self, 16):
                best_sid = None

        if best_sid is not None:
            if ctrl:
                self.selected_sids.discard(best_sid)
                if self.selected_sid == best_sid:
                    self.selected_sid = next(iter(self.selected_sids), None)
            elif shift:
                self.selected_sids.add(best_sid)
                self.selected_sid = best_sid
            else:
                self.selected_sid = best_sid
                self.selected_sids = {best_sid}
            self._sync_override()
            self.notebook.select(self.inspector)
            self._redraw()
        else:
            # Clicked empty space on live GPU viewport -> start rectangle box drag
            if not shift and not ctrl:
                self.selected_sid = None
                self.selected_sids.clear()
                self._sync_override()
            self._box_select_start = (event.x, event.y)
            self._box_select_current = (event.x, event.y)
            self._box_modifier = 'sub' if ctrl else ('add' if shift else 'replace')
            self._box_orig_sids = set(self.selected_sids)
            self._box_rect_screen = None
            self._redraw()

    def _sculpt_drag_live_gpu(self,event):
        if getattr(self, '_box_select_start', None) is not None:
            self._box_select_current = (event.x, event.y)
            bx0, by0 = self._box_select_start
            bx1, by1 = self._box_select_current
            self._box_rect_screen = (bx0, by0, bx1, by1)
            self._sync_live_gpu_selection()
            return

        if self._drag_index is None or self._drag_start is None or not self._live_gpu_viewport:return
        tw, th = self._live_gpu_viewport.tile_size
        w = max(1, self._live_gpu_viewport.surface.winfo_width())
        h = max(1, self._live_gpu_viewport.surface.winfo_height())
        fit = min(w / tw, h / th) * 0.9 * self._live_gpu_viewport.zoom
        if fit <= 1e-5: return
        dx_screen = event.x - self._drag_start[0]
        dy_screen = event.y - self._drag_start[1]
        c = math.cos(self._live_gpu_viewport.angle)
        s = math.sin(self._live_gpu_viewport.angle)
        # unrotate delta to tile space
        dx_rot = dx_screen / fit
        dy_rot = -dy_screen / fit
        dx_tile = c * dx_rot + s * dy_rot
        dy_tile = -s * dx_rot + c * dy_rot
        self._drag_offset = (dx_tile / tw, dy_tile / th)

    def _sculpt_finish_live_gpu(self,event):
        if getattr(self, '_box_select_start', None) is not None:
            bx0, by0 = self._box_select_start
            bx1, by1 = event.x, event.y
            self._box_select_start = None
            self._box_select_current = None
            self._box_rect_screen = None
            if abs(bx1 - bx0) >= 3 or abs(by1 - by0) >= 3:
                # Find all strands intersecting the screen rectangle
                tile = self._current()
                strands = self._current_truth
                if strands is None and tile and tile.id in self._results:
                    strands = self._results[tile.id].strands
                if strands and self._live_gpu_viewport:
                    tw, th = self._live_gpu_viewport.tile_size
                    w = max(1, self._live_gpu_viewport.surface.winfo_width())
                    h = max(1, self._live_gpu_viewport.surface.winfo_height())
                    fit = min(w / tw, h / th) * 0.9 * self._live_gpu_viewport.zoom
                    c = math.cos(self._live_gpu_viewport.angle)
                    s_ang = math.sin(self._live_gpu_viewport.angle)
                    rx0, rx1 = min(bx0, bx1), max(bx0, bx1)
                    ry0, ry1 = min(by0, by1), max(by0, by1)
                    hit_sids = set()
                    for strand in strands:
                        pts = strand.points
                        p_tile = pts * np.array([tw, th], dtype=np.float32)
                        centered = p_tile - 0.5 * np.array([tw, th], dtype=np.float32)
                        rot_x = c * centered[:, 0] - s_ang * centered[:, 1]
                        rot_y = s_ang * centered[:, 0] + c * centered[:, 1]
                        sx = rot_x * fit + self._live_gpu_viewport.pan[0] + 0.5 * w
                        sy = 0.5 * h - (rot_y * fit + self._live_gpu_viewport.pan[1])
                        # If any vertex falls inside or bounding box overlaps
                        if np.any((sx >= rx0) & (sx <= rx1) & (sy >= ry0) & (sy <= ry1)):
                            hit_sids.add(strand.sid)
                    orig = getattr(self, '_box_orig_sids', set())
                    mod = getattr(self, '_box_modifier', 'replace')
                    if mod == 'sub':
                        self.selected_sids = orig - hit_sids
                    elif mod == 'add':
                        self.selected_sids = orig | hit_sids
                    else:
                        self.selected_sids = hit_sids
                    if self.selected_sids:
                        self.selected_sid = next(iter(self.selected_sids))
                    else:
                        self.selected_sid = None
                    self._sync_override()
                    self._redraw()
            return

        if self._drag_index is None:return
        tile=self._current()
        if tile and self.selected_sid:
            dx,dy=self._drag_offset
            if abs(dx)+abs(dy)>1e-5:
                idx=self.selected_sid.split(":")[1]
                old=tile.overrides.get(idx,{})
                nodes=deepcopy(old.get("curve_nodes",[[0.0,0.0] for _ in range(5)]))
                nodes[self._drag_index][0]+=dx
                nodes[self._drag_index][1]+=dy
                self._history()
                tile.overrides[idx]={**old,"curve_nodes":nodes}
                tile.revision+=1
                self._schedule_render(0)
        self._drag_index=None;self._drag_start=None;self._drag_offset=(0.,0.)

    def _open_settings(self):
        if self._settings_window is not None and self._settings_window.winfo_exists():
            self._settings_window.lift();self._settings_window.focus_set();return
        self._settings_window=SettingsDialog(self, on_apply=self._apply_settings)

    def _apply_settings(self):
        self._redraw()
        if self._live_gpu_viewport is not None:
            self._live_gpu_viewport.request_frame()
        if self.card_window is not None and self.card_window.winfo_exists():
            self.card_window._sync_inspector()
            self.card_window._render_soon(0)
        if self.render_window is not None and self.render_window.winfo_exists():
            self.render_window.topmost_var.set(self.app_settings.render_studio_topmost)
            self.render_window.attributes('-topmost', self.app_settings.render_studio_topmost)
            self.render_window._frame_later(0)

    def _open_render_studio(self):
        self._switch_workspace("render")

    def _open_card_editor(self):
        self._switch_workspace("cards")

    def _notify_card_editor(self):
        if self.card_window is not None and self.card_window.winfo_exists():
            self.card_window.refresh()

    def _new_project(self):
        if not self._confirm_discard():return
        self.project=Project.sample()
        self.file_path=None;self.modified=False;self._undo.clear();self._redo.clear()
        self.current_id=self.project.tiles[0].id;self.selected_sid=None
        self._invalidate_atlas();self._fill_tree();self._sync_from_tile();self._schedule_render(0)
        self._notify_card_editor()

    def _confirm_discard(self):
        if not self.modified:return True
        response=messagebox.askyesnocancel("Unsaved changes","Save changes to your project?",parent=self)
        if response is None:return False
        if response and not self._save():return False
        return True

    def _open(self):
        if not self._confirm_discard():return
        path=filedialog.askopenfilename(parent=self,filetypes=[("Fiber Strand Project","*.fsd"),("All files","*.*")])
        if not path:return
        try: project=load_project(path)
        except Exception as ex:
            messagebox.showerror("Open failed",str(ex),parent=self);return
        self.project=project;self.file_path=Path(path)
        self.modified=False;self._undo.clear();self._redo.clear()
        self.current_id=project.tiles[0].id if project.tiles else None
        self.selected_sid=None;self._invalidate_atlas();self._fill_tree();self._sync_from_tile();self._schedule_render(0)
        self._notify_card_editor()

    def _save(self):
        if self.file_path is None:
            return self._save_as()
        try:save_project(self.project,self.file_path)
        except Exception as ex:
            messagebox.showerror("Save failed",str(ex),parent=self);return False
        self.modified=False
        self.status.set(f"Saved {self.file_path.name}")
        return True

    def _save_as(self):
        path=filedialog.asksaveasfilename(defaultextension=".fsd",filetypes=[("Fiber Strand Project","*.fsd")],parent=self)
        if not path:return False
        self.file_path=Path(path)
        return self._save()

    def _history_restore(self, snapshot:dict):
        old_tiles=[t.to_dict() for t in self.project.tiles]
        new_project=Project.from_dict(snapshot)
        tiles_changed=old_tiles != [t.to_dict() for t in new_project.tiles]
        self.project=new_project
        self.current_id=self.current_id if self.project.find(self.current_id) else (self.project.tiles[0].id if self.project.tiles else None)
        self.selected_sid=None
        self.modified=True
        if tiles_changed:
            self._invalidate_atlas();self._fill_tree();self._sync_from_tile();self._schedule_render(0)
        # Card-only history never invalidates or re-bakes any fiber tile.
        self._notify_card_editor()
        if not tiles_changed:self.status.set("Card edit restored · fiber cache preserved")

    def _undo_action(self):
        if not self._undo:return
        self._redo.append(self.project.to_dict())
        self._history_restore(self._undo.pop())

    def _redo_action(self):
        if not self._redo:return
        self._undo.append(self.project.to_dict())
        self._history_restore(self._redo.pop())

    def _export_dialog(self):
        if self._exporting:return
        if not self.project.tiles:
            messagebox.showwarning("Empty project","There are no tiles to export",parent=self);return
        folder=filedialog.askdirectory(title="Export all tile maps / atlas",parent=self)
        if not folder:return
        project=deepcopy(self.project)
        from .model import EXTRA_MAP_NAMES
        channels=MAP_NAMES+EXTRA_MAP_NAMES if messagebox.askyesno('Export channels',
            'Include V2 optical/material channels?\nNo exports the original 9 channels.',parent=self) else MAP_NAMES
        try:layout=AtlasCache(project)
        except Exception as ex:
            messagebox.showerror("Atlas packing error",str(ex),parent=self);return
        self._exporting=True
        self.progress.start(12)
        self.status.set(f"Exporting {len(project.tiles)} tiles · full resolution ...")
        publish=self._queue.put
        def worker():
            try:
                tile_files=[]
                for i,tile in enumerate(project.tiles):
                    publish(("export_progress",0,f"Exporting tile {i+1}/{len(project.tiles)}: {tile.name}",None))
                    result=render_tile(tile,detail=recommended_detail(tile,base=32),channels=channels)
                    layout.update_tile(result)
                    tile_files.extend(write_tile_maps(folder,tile,result))
                files=layout.write(folder,project,names=channels)+tile_files
                publish(("export",0,files,None))
            except Exception as ex:
                publish(("export",0,None,str(ex)))
        self._worker.submit(worker)

    def _close(self):
        if not self._confirm_discard():return
        self._closing=True
        if getattr(self,'_lit_map',None):self._lit_map.close()
        panel=getattr(self,'_inline_render',None)
        if panel and panel.winfo_exists():panel.destroy();self._inline_render=None
        if self._poll_after is not None:
            try:self.after_cancel(self._poll_after)
            except tk.TclError:pass
            self._poll_after=None
        for ev in self._jobs.values():ev.set()
        self._preview_scheduler.close(wait=True)
        self._truth_scheduler.close(wait=True)
        self._atlas_pipeline.close()
        self._atlas_pipeline.scheduler.close(wait=True)
        if self._live_gpu_viewport is not None:
            try:self._live_gpu_viewport.close()
            except Exception:pass
            self._live_gpu_viewport=None
        if self._fiber_preview is not None and self._fiber_preview.winfo_exists():self._fiber_preview.close()
        self._worker.shutdown(wait=False,cancel_futures=True)
        if self.card_window is not None and self.card_window.winfo_exists():self.card_window._close()
        if self.render_window is not None and self.render_window.winfo_exists():self.render_window._close()
        if self.construction_window is not None and self.construction_window.winfo_exists():self.construction_window._close()
        if self._after_render is not None:
            try:self.after_cancel(self._after_render)
            except tk.TclError:pass
            self._after_render=None
        try:self.progress.stop()
        except tk.TclError:pass
        if hasattr(self,'dpi_manager') and hasattr(self.dpi_manager,'_timer') and self.dpi_manager._timer is not None:
            try:self.after_cancel(self.dpi_manager._timer)
            except tk.TclError:pass
            self.dpi_manager._timer=None
        if getattr(self,'object_workspace',None) is not None:self.object_workspace.close()
        self.destroy()


def run():
    app=App()
    app.mainloop()
