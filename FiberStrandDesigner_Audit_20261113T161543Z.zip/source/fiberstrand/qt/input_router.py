"""Workspace key routing with text-entry isolation, matching legacy root binds."""
from PySide6 import QtCore,QtWidgets

class WorkspaceInputRouter(QtCore.QObject):
    def __init__(self,window):
        super().__init__(window);self.window=window;self.forwarding=False
        QtWidgets.QApplication.instance().installEventFilter(self)
        self._sync_inspector_widths()

    def _sync_inspector_widths(self):
        if getattr(self.window,"two_studio_layout",False):return
        stack=getattr(self.window,"workspace_stack",None)
        if stack is None:return
        width=max(1,self.window.width()//5)
        for i in range(stack.count()):
            inspector=getattr(stack.widget(i),"inspector_scroll",None)
            if inspector is not None:inspector.setFixedWidth(width)

    def eventFilter(self,receiver,event):
        if receiver is self.window and event.type()==QtCore.QEvent.Type.Resize:self._sync_inspector_widths()
        if self.forwarding or not isinstance(receiver,QtWidgets.QWidget):return False
        if event.type() not in (QtCore.QEvent.Type.KeyPress,QtCore.QEvent.Type.KeyRelease,QtCore.QEvent.Type.ShortcutOverride):return False
        if receiver.window() is not self.window:return False
        focus=QtWidgets.QApplication.focusWidget()
        editable=(QtWidgets.QLineEdit,QtWidgets.QTextEdit,QtWidgets.QPlainTextEdit,QtWidgets.QAbstractSpinBox,QtWidgets.QComboBox)
        node=focus or receiver
        while node is not None:
            if isinstance(node,editable):return False
            node=node.parentWidget()
        stack=getattr(self.window,'workspace_stack',None);workspace=stack.currentWidget() if stack else None
        viewport=workspace.input_target(focus) if hasattr(workspace,'input_target') else getattr(workspace,'viewport',None)
        if viewport is None or receiver is viewport:return False
        K=QtCore.Qt.Key;k=event.key();mods=event.modifiers();ctrl=bool(mods & QtCore.Qt.KeyboardModifier.ControlModifier)
        plain={K.Key_F,K.Key_Q,K.Key_W,K.Key_E,K.Key_R,K.Key_B,K.Key_G,K.Key_S,K.Key_Space,K.Key_Tab,K.Key_Escape,K.Key_Delete,K.Key_Backspace,K.Key_Return,K.Key_Enter,K.Key_1,K.Key_2,K.Key_3,K.Key_4,K.Key_5,K.Key_6}
        recognized=(ctrl and k in (K.Key_Z,K.Key_Y,K.Key_A,K.Key_D)) or (not ctrl and (k in plain or (k==K.Key_D and mods & QtCore.Qt.KeyboardModifier.ShiftModifier)))
        if not recognized:return False
        event.accept()
        if event.type()==QtCore.QEvent.Type.ShortcutOverride:return True
        self.forwarding=True
        try:
            if event.type()==QtCore.QEvent.Type.KeyRelease:viewport.keyReleaseEvent(event)
            else:viewport.keyPressEvent(event)
        finally:self.forwarding=False
        return True
