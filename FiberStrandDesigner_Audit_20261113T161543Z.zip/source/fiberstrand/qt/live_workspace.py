"""Live fiber viewport, source-space strand picking and five-point sculpting."""
from copy import deepcopy
import math
import numpy as np
from PySide6 import QtCore,QtGui
from .theme import TOKENS

class LiveWorkspaceMixin:
    def _setup_live_workspace(self,graph=False):
        from ..settings import AppSettings
        self._live_settings=AppSettings.load()
        self._live_graph=graph;self._live_core=None;self._live_packet=None;self._preview_strands=[];self._strand_ids=set();self._primary_sid=None;self._strand_drag=None
        if not graph:
            self.viewport.pointerPressed.connect(self._strand_press);self.viewport.pointerMoved.connect(self._strand_move);self.viewport.pointerReleased.connect(self._strand_release)
        self.viewport.interactionFinished.connect(lambda mode,cancelled:self._cancel_strand_drag() if cancelled else None)
        self.viewport.cancelRequested.connect(self._cancel_strand_drag)
        self.viewport._map_overlay=self._paint_strand_overlay
        if not graph:
            self.map_combo.insertItem(0,'Live Fiber GPU','live');self.map_combo.setCurrentIndex(0)
        else:self.viewport.lightOrbitChanged.connect(self._graph_light)

    def _use_live(self):
        return self._live_graph or (self.mode_combo.currentText()=='Tile Mode' and (self.map_combo.currentData() or self.map_combo.currentText())=='live')

    def _request_live_preview(self):
        if self.current_tile is None:return
        tile=self.current_tile
        key=(id(self.controller.project),id(tile),tile.id,tile.revision)
        if self._live_graph:
            import json
            key+=(json.dumps(self.graph,sort_keys=True),)
        cached=getattr(self,'_live_cached',None)
        if cached and cached[0]==key:
            self._preview_strands=cached[2][0]
            if getattr(self,'_live_display_key',None)!=key:
                self._live_packet=(cached[1],cached[2][1]);self._live_packet_key=key
            else:self._live_packet=None
            self.viewport.set_renderer_callback(self._paint_live_frame);self.viewport.update();return
        if getattr(self,'_live_display_key',None)==key and self._live_core is not None:
            self._preview_strands=self._live_display_strands;self._live_packet=None
            self.viewport.set_renderer_callback(self._paint_live_frame);self.viewport.update();return
        snapshot=deepcopy(self.current_tile)
        if self._live_graph:snapshot.construction_graph=deepcopy(self.graph)
        def worker(cancel):
            from ..engine_v2.engine import ENGINE
            from ..engine_v2.preview import pack_instances
            truth,_=ENGINE.truth(snapshot,cancel=cancel)
            return truth,pack_instances(truth,snapshot.settings,cancel)
        def publish(result,revision):
            if self.current_tile is None or self.current_tile.id!=snapshot.id or not self._use_live():return
            if result[1].nbytes<=32*1024*1024:self._live_cached=(key,snapshot,result)
            else:self._live_cached=None
            self._preview_strands=result[0];self._live_packet=(snapshot,result[1]);self._live_packet_key=key;self.viewport.set_renderer_callback(self._paint_live_frame);self.viewport.update()
        self.controller.submit_job('graph_live_preview' if self._live_graph else 'fiber_studio_preview',worker,publish)

    def _paint_live_frame(self):
        if not self.isVisible() or not self._use_live():return
        if self._live_core is None:
            try:
                from .live_preview import QtLiveFiberCore
                self._live_core=QtLiveFiberCore(self.viewport,lambda e:self.controller.jobFailed.emit('live viewport',e))
            except Exception as e:
                self.controller.jobFailed.emit('live viewport', str(e))
                self.viewport.set_renderer_callback(None)
                if hasattr(self, '_set_map_channel'):
                    self._set_map_channel('color')
                return
        core=self._live_core;core.sync_transform()
        core.show_hud=self._live_settings.show_hud;core.show_axis_gizmo=self._live_settings.show_axis_gizmo;core.up_axis=self._live_settings.up_axis
        az=math.radians(getattr(self,"_graph_light_azimuth",self.light_slider.value() if not self._live_graph else 40.))
        el=math.radians(getattr(self,"_light_elevation",40.))
        core.light_direction=(math.sin(az)*math.cos(el),-math.sin(el),math.cos(az)*math.cos(el))
        if self._live_packet:
            tile,data=self._live_packet;self._live_packet=None;self._live_display_key=self._live_packet_key;self._live_display_strands=self._preview_strands;core.publish(tile.id,tile.revision,(tile.width,tile.height),data,tile.settings)
        core.hud_lines=(str(core.device),f'Live Fiber GPU | {core.revision} | selected {len(self._strand_ids)}')
        if getattr(self, 'current_tile', None):
            self.viewport.set_hud_text(f'TILE: {self.current_tile.name} · LIVE FIBER GPU')
        self._sync_live_selection();core.frame()

    def _sync_live_selection(self):
        if self._live_core is None:return
        primary=next((s for s in self._preview_strands if s.sid==self._primary_sid),None)
        points=None if primary is None else np.asarray(primary.points).copy()
        if points is not None and self._strand_drag and 'node' in self._strand_drag:
            i=round(self._strand_drag['node']*(len(points)-1)/4);points[i]+=self._strand_drag.get('delta',0.)
        self._live_core.selected_points=points
        self._live_core.selected_nodes=None if points is None else points[np.rint(np.linspace(0,len(points)-1,5)).astype(int)]
        self._live_core.selected_multi_points=[s.points for s in self._preview_strands if s.sid in self._strand_ids and s.sid!=self._primary_sid]

    def _strand_uv(self,pos):
        if self._use_live() and self._live_core:
            self._live_core.sync_transform();ratio=self.viewport.devicePixelRatioF();return np.array(self._live_core.screen_to_tile(pos.x()*ratio,pos.y()*ratio))
        return np.array(self.viewport.image_uv(pos))

    def _strand_scale(self):
        tile=self.current_tile
        if tile is None:return 1.
        fit=min(self.viewport.width()/tile.width,self.viewport.height()/tile.height)*(.9 if self._use_live() else 1.)*self.viewport._view_zoom
        return max(1.,fit*min(tile.width,tile.height))

    def _strand_press(self,pos,button,mods):
        if button!=QtCore.Qt.MouseButton.LeftButton.value or (not self._live_graph and self.mode_combo.currentText()=='Atlas Mode'):return
        point=self._strand_uv(pos);scale=self._strand_scale()
        current=next((s for s in self._preview_strands if s.sid==self._primary_sid),None)
        if current is not None:
            nodes=np.asarray(current.points)[np.rint(np.linspace(0,len(current.points)-1,5)).astype(int)]
            closest=int(np.argmin(np.linalg.norm(nodes-point,axis=1)))
            if np.linalg.norm(nodes[closest]-point)*scale<12:
                self._strand_drag={'node':closest,'start':point,'delta':np.zeros(2),'tile':self.current_tile};return
        best=None;distance=16/scale
        for strand in self._preview_strands:
            points=np.asarray(strand.points);a=points[:-1];v=points[1:]-a
            t=np.clip(np.sum((point-a)*v,axis=1)/np.maximum(np.sum(v*v,axis=1),1e-12),0,1)
            d=float(np.min(np.linalg.norm(a+t[:,None]*v-point,axis=1)))
            if d<distance:distance=d;best=strand.sid
        shift=bool(mods & QtCore.Qt.KeyboardModifier.ShiftModifier.value);ctrl=bool(mods & QtCore.Qt.KeyboardModifier.ControlModifier.value)
        if best:
            if ctrl:self._strand_ids.discard(best)
            elif shift:self._strand_ids.add(best)
            else:self._strand_ids={best}
            self._primary_sid=best if not ctrl else next(iter(self._strand_ids),None)
        else:
            if not shift and not ctrl:self._strand_ids=set();self._primary_sid=None
            self._strand_drag={'box':True,'start':point,'end':point,'orig':set(self._strand_ids),'shift':shift,'ctrl':ctrl}
        self.viewport.update()

    def _strand_move(self,pos,mods):
        d=self._strand_drag
        if d is None:return
        point=self._strand_uv(pos)
        if d.get('box'):d['end']=point
        else:d['delta']=point-d['start']
        self.viewport.update()

    def _strand_release(self,pos,button,mods):
        d=self._strand_drag;self._strand_drag=None
        if not d:return
        if d.get('box'):
            lo=np.minimum(d['start'],d['end']);hi=np.maximum(d['start'],d['end'])
            hits={s.sid for s in self._preview_strands if np.any(np.all((s.points>=lo)&(s.points<=hi),axis=1))}
            self._strand_ids=d['orig']-hits if d['ctrl'] else d['orig']|hits if d['shift'] else hits;self._primary_sid=next(iter(self._strand_ids),None)
        elif d['tile'] is self.current_tile and np.linalg.norm(d['delta'])>1e-6 and self._primary_sid:
            tile=self.current_tile;index=self._primary_sid.split(':')[1];old=tile.overrides.get(index,{})
            nodes=deepcopy(old.get('curve_nodes',[[0.,0.] for _ in range(5)]));nodes[d['node']]=(np.asarray(nodes[d['node']])+d['delta']).tolist()
            self.controller.snapshot();tile.overrides={**tile.overrides,index:{**old,'curve_nodes':nodes}};tile.revision+=1;self.controller.tileUpdated.emit(tile.id);self._request_preview()
        self.viewport.update()

    def _cancel_strand_drag(self):self._strand_drag=None;self.viewport.update()

    def _paint_strand_overlay(self,painter):
        if not self._live_graph and self._is_atlas():
            self._paint_atlas_overlay(painter);return
        if self._use_live():return
        strand=next((s for s in self._preview_strands if s.sid==self._primary_sid),None)
        if strand is None:return
        path=QtGui.QPainterPath();points=[self.viewport.image_point(float(p[0]),float(p[1])) for p in strand.points]
        if not points:return
        path.moveTo(points[0])
        for point in points[1:]:path.lineTo(point)
        painter.setPen(QtGui.QPen(QtGui.QColor(TOKENS['gold']),2));painter.drawPath(path)
        for i in np.rint(np.linspace(0,len(points)-1,5)).astype(int):painter.drawEllipse(points[i],5,5)

    def _live_light_changed(self,*args):
        self.viewport.update()

    def _graph_light(self,dx,dy):
        self._graph_light_azimuth=(getattr(self,'_graph_light_azimuth',40.)+dx+180)%360-180
        self._light_elevation=max(-85.,min(85.,getattr(self,"_light_elevation",40.)+dy))
        self.viewport.update()

    def close_live_viewport(self):
        atlas_presenter=getattr(self,"_gpu_atlas_presenter",None)
        if atlas_presenter:atlas_presenter.close();self._gpu_atlas_presenter=None
        presenter=getattr(self,"_texture_presenter",None)
        if presenter:presenter.close();self._texture_presenter=None
        self._live_display_key=None
        if self._live_core:self.viewport.set_renderer_callback(None);self._live_core.close_gpu();self._live_core=None
