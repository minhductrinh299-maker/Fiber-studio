"""Modern Parameter Slider & Numeric Entry Component for Qt 6 / PySide6.

Designs match professional 3D DCC tools (Maya, Houdini, Substance Painter)
with a thin track background, filled vibrant cyan bar with circular knob,
and a clean digital readout on the right.
"""
from __future__ import annotations
from PySide6 import QtCore, QtGui, QtWidgets
from .theme import TOKENS


class QtNumberSlider(QtWidgets.QWidget):
    valueChanged = QtCore.Signal(float)

    def __init__(
        self,
        from_: float = 0.0,
        to: float = 1.0,
        step: float = 0.01,
        value: float | None = None,
        is_integer: bool = False,
        format_str: str | None = None,
        parent: QtWidgets.QWidget | None = None,
        label: str | None = None,
        min_val: float | None = None,
        max_val: float | None = None,
    ):
        super().__init__(parent)
        self.label = label
        if min_val is not None:
            from_ = min_val
        if max_val is not None:
            to = max_val
        self.from_ = float(from_)
        self.to = float(to)
        self.step = float(step)
        self.is_integer = is_integer
        self.format_str = format_str
        self._value = float(value if value is not None else from_)

        self._dragging = False
        self._drag_start_x = 0
        self._drag_start_val = 0.0

        self.setFocusPolicy(QtCore.Qt.FocusPolicy.StrongFocus)
        self.setMinimumHeight(24)
        self.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Expanding,
            QtWidgets.QSizePolicy.Policy.Fixed,
        )

        # Inline editor (hidden by default)
        self._line_edit = QtWidgets.QLineEdit(self)
        self._line_edit.setAlignment(QtCore.Qt.AlignmentFlag.AlignRight)
        self._line_edit.setStyleSheet(
            f"background-color: {TOKENS['bg_control']}; color: {TOKENS['cyan']}; "
            f"border: 1px solid {TOKENS['cyan']}; border-radius: 4px; padding: 2px 4px; font-weight: 600;"
        )
        self._line_edit.hide()
        self._line_edit.textChanged.connect(self._on_inline_text_changed)
        self._line_edit.editingFinished.connect(self._commit_inline_edit)

    def value(self) -> float:
        return self._value

    def setValue(self, val: float, notify: bool = True):
        lo, hi = min(self.from_, self.to), max(self.from_, self.to)
        clamped = max(lo, min(hi, float(val)))
        if self.is_integer:
            clamped = float(round(clamped))
        elif self.step > 0:
            clamped = round(clamped / self.step) * self.step

        if abs(self._value - clamped) > 1e-9:
            self._value = clamped
            self.update()
            if notify:
                self.valueChanged.emit(self._value)

    def _get_display_text(self) -> str:
        if self.format_str:
            return self.format_str.format(self._value)
        if self.is_integer:
            return f"{int(self._value)}"
        if self.step >= 0.1:
            return f"{self._value:.1f}"
        if self.step >= 0.01:
            return f"{self._value:.3f}"
        return f"{self._value:.3f}"

    def _on_inline_text_changed(self, text: str):
        if not self._line_edit.isVisible():
            return
        try:
            val = float(text.strip())
            # Clamped and updated realtime without hiding the editor
            lo, hi = min(self.from_, self.to), max(self.from_, self.to)
            clamped = max(lo, min(hi, float(val)))
            if self.is_integer:
                clamped = float(round(clamped))
            elif self.step > 0:
                clamped = round(clamped / self.step) * self.step
            if abs(self._value - clamped) > 1e-9:
                self._value = clamped
                self.update()
                self.valueChanged.emit(self._value)
        except ValueError:
            pass

    def _commit_inline_edit(self):
        text = self._line_edit.text().strip()
        try:
            val = float(text)
            self.setValue(val)
        except ValueError:
            pass
        self._line_edit.hide()
        self.update()

    def mouseDoubleClickEvent(self, event: QtGui.QMouseEvent):
        # Open inline edit box on right side
        w = self.width()
        box_w = 64
        self._line_edit.setGeometry(w - box_w - 4, 1, box_w, self.height() - 2)
        self._line_edit.setText(self._get_display_text())
        self._line_edit.show()
        self._line_edit.selectAll()
        self._line_edit.setFocus()

    def _fraction(self) -> float:
        rng = self.to - self.from_
        if abs(rng) < 1e-9:
            return 0.0
        return max(0.0, min(1.0, (self._value - self.from_) / rng))

    def _apply_mouse_fraction(self, x: float):
        w = max(10, self.width() - 76) # Slider track width (leaving 70px for readout)
        frac = max(0.0, min(1.0, x / w))
        val = self.from_ + frac * (self.to - self.from_)
        self.setValue(val)

    def paintEvent(self, event: QtGui.QPaintEvent):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)

        w = self.width()
        h = self.height()
        readout_w = 66
        track_w = max(20, w - readout_w - 10)
        style=self.property("fsdStyle") or {}
        track_h = 4.0
        track_y = (h - track_h) / 2.0

        # 1. Slider Track Background (Dark Slate)
        painter.setPen(QtCore.Qt.PenStyle.NoPen)
        painter.setBrush(QtGui.QColor(style.get("background",TOKENS["bg_control"]))) # #10283E
        painter.drawRoundedRect(QtCore.QRectF(0, track_y, track_w, track_h), 2.0, 2.0)

        # 2. Cyan Filled Track
        frac = self._fraction()
        fill_w = track_w * frac
        if fill_w > 0:
            painter.setBrush(QtGui.QColor(style.get("active",TOKENS["cyan"])))
            painter.drawRoundedRect(QtCore.QRectF(0, track_y, fill_w, track_h), 2.0, 2.0)

        # 3. Knob / Handle (White-Cyan Circle)
        knob_r = 4.0
        knob_x = fill_w
        knob_y = h / 2.0
        painter.setBrush(QtGui.QColor(style.get("active",TOKENS["cyan"]) if self.hasFocus() or self._dragging else style.get("active",TOKENS["cyan"])))
        painter.drawEllipse(QtCore.QPointF(knob_x, knob_y), knob_r, knob_r)

        # 4. Right-side Numeric Display Box
        if not self._line_edit.isVisible():
            box_x = w - readout_w
            box_rect = QtCore.QRectF(box_x, (h - 20) / 2.0, readout_w, 20)
            painter.setBrush(QtGui.QColor(style.get("background",TOKENS["bg_control"])))
            painter.setPen(QtGui.QColor(style.get("border",TOKENS["border"])))
            painter.drawRoundedRect(box_rect, float(style.get("radius",4)), float(style.get("radius",4)))

            painter.setPen(QtGui.QColor(style.get("foreground",TOKENS["text"])))
            font = self.font()
            font.setFamily("Consolas")
            font.setPixelSize(style.get("font_size",11))
            font.setWeight(QtGui.QFont.Weight(style.get("font_weight",600)))
            painter.setFont(font)
            painter.drawText(
                box_rect.adjusted(2, 0, -4, 0),
                QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter,
                self._get_display_text(),
            )

    def mousePressEvent(self, event: QtGui.QMouseEvent):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self._dragging = True
            self.setFocus()
            self._apply_mouse_fraction(event.position().x())

    def mouseMoveEvent(self, event: QtGui.QMouseEvent):
        if self._dragging:
            self._apply_mouse_fraction(event.position().x())

    def mouseReleaseEvent(self, event: QtGui.QMouseEvent):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self._dragging = False

    def keyPressEvent(self, event: QtGui.QKeyEvent):
        key = event.key()
        step = self.step
        if event.modifiers() & QtCore.Qt.KeyboardModifier.ShiftModifier:
            step *= 0.1
        elif event.modifiers() & QtCore.Qt.KeyboardModifier.ControlModifier:
            step *= 10.0

        if key in (QtCore.Qt.Key.Key_Left, QtCore.Qt.Key.Key_Down):
            self.setValue(self._value - step)
            event.accept()
        elif key in (QtCore.Qt.Key.Key_Right, QtCore.Qt.Key.Key_Up):
            self.setValue(self._value + step)
            event.accept()
        else:
            super().keyPressEvent(event)
