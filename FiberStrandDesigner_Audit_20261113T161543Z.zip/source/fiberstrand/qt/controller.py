"""Central Application Controller and Unified Scene State for Fiber Strand Designer.

Acts as the Single Source of Truth (SSOT) between:
- Project data persistence (Save, Load, Export, Dirty tracking)
- Live AtlasCache synchronization across workspaces
- Asynchronous Job Scheduler for heavy fiber baking & tile rendering
- Change notification signals (tiles, cards, objects, selection, graph)
- Transactional Undo / Redo for robust state recovery
"""
from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any, Callable, Optional
from concurrent.futures import ThreadPoolExecutor, Future
import threading

from PySide6 import QtCore

from ..model import Project, Tile
from ..cards import HairCard
from ..atlas import AtlasCache
from ..projectio import save_project, load_project



class AsyncJobWorker(QtCore.QObject):
    """Worker object to dispatch background results safely to Qt UI thread."""
    taskFinished = QtCore.Signal(str, object, int) # (task_id, result, revision)
    taskFailed = QtCore.Signal(str, str, int)      # (task_id, error_msg, revision)


from .atlas_management import AtlasManagement

class AppController(AtlasManagement,QtCore.QObject):
    """Central Controller managing Project lifecycle, Shared Atlas, and Async Jobs."""

    # Project lifecycle signals
    projectLoaded = QtCore.Signal()
    projectSaved = QtCore.Signal(str) # file path
    projectModified = QtCore.Signal(bool) # is_dirty
    
    # Granular domain signals
    tilesChanged = QtCore.Signal()
    tileUpdated = QtCore.Signal(str)
    activeTileChanged = QtCore.Signal(str)
    renderMaterialChanged = QtCore.Signal() # tile_id
    cardsChanged = QtCore.Signal()
    cardSelected = QtCore.Signal(list) # list of selected card ids
    graphApplied = QtCore.Signal(str) # tile_id
    atlasRebuilt = QtCore.Signal()
    jobFailed = QtCore.Signal(str, str)
    jobStarted = QtCore.Signal(str)
    jobCompleted = QtCore.Signal(str)
    bakeProgress = QtCore.Signal(int, int)

    def __init__(self, project: Project | None = None, parent: QtCore.QObject | None = None):
        super().__init__(parent)
        self._project: Project = project if project is not None else Project.sample()
        self.active_tile_id=self._project.tiles[0].id if self._project.tiles else None
        self._project_path: Optional[Path] = None
        self._dirty: bool = False
        self._revision: int = 1
        self._job_serial = 0
        self._closed = False
        self._interaction_owners=set()
        self._opening_project=False
        self._job_futures = {}
        self._cancel_events = {}
        
        # Undo / Redo history stacks (deep copies of project dictionary)
        self._undo_stack: list[dict[str, Any]] = []
        self._redo_stack: list[dict[str, Any]] = []
        self._max_history: int = 30

        # Shared Atlas Cache
        self._atlas_generation=0
        self._atlas_channels=("color","alpha","normal","flow","roughness","ao","depth","id")
        self._baked_tokens={}
        self._atlas_stage_queue={}
        self._atlas_stage_busy=False
        self._atlas: AtlasCache = AtlasCache(self._project)
        self._rebuild_atlas_cache()

        # Heavy Async Task ThreadPool (Background execution without UI freezes)
        self._executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="fsd_worker")
        from ..fiberbake_x.scheduler import LatestScheduler
        self._preview_executor=LatestScheduler(workers=1,max_pending=8,name="fsd-preview")
        self._active_jobs: dict[str, int] = {} # task_name -> latest_job_revision
        self._job_worker = AsyncJobWorker()
        self._job_worker.taskFinished.connect(self._on_job_finished)
        self._job_worker.taskFailed.connect(self._on_job_failed)
        
        # Callbacks registered by views for job results
        self._result_handlers: dict[str, Callable[[Any, int], None]] = {}
        self.tileUpdated.connect(lambda tid:getattr(self,'_atlas_token_cache',{}).pop(tid,None))
        self.graphApplied.connect(lambda tid:getattr(self,'_atlas_token_cache',{}).pop(tid,None))
        self.tilesChanged.connect(self.ensure_atlas)
        self.tileUpdated.connect(lambda _tid: self.ensure_atlas(), QtCore.Qt.ConnectionType.QueuedConnection)
        self.graphApplied.connect(lambda _tid: self.ensure_atlas(), QtCore.Qt.ConnectionType.QueuedConnection)
        QtCore.QTimer.singleShot(0,self.ensure_atlas)

    # -------------------------------------------------------------------------
    # Project & State Properties
    # -------------------------------------------------------------------------
    @property
    def project(self) -> Project:
        return self._project

    @property
    def project_path(self) -> Optional[Path]:
        return self._project_path

    @property
    def is_dirty(self) -> bool:
        return self._dirty

    @property
    def revision(self) -> int:
        return self._revision

    @property
    def atlas(self) -> AtlasCache:
        return self._atlas

    def set_active_tile(self,tile_id):
        if self.project.find(tile_id) is None:raise ValueError('Unknown tile: '+str(tile_id))
        if self.active_tile_id!=tile_id:
            self.active_tile_id=tile_id;self.activeTileChanged.emit(tile_id)

    def current_tile(self):
        tile=self.project.find(self.active_tile_id)
        if tile is None and self.project.tiles:
            tile=self.project.tiles[0];self.active_tile_id=tile.id
        return tile

    def set_render_material(self,material):
        from ..rendercore.settings import store_material
        self.snapshot();store_material(self.project,material);self.renderMaterialChanged.emit()

    # -------------------------------------------------------------------------
    # Undo / Redo Transactions
    # -------------------------------------------------------------------------
    def snapshot(self):
        """Record an atomic state snapshot for Undo before modifying data."""
        self._undo_stack.append(deepcopy(self._project.to_dict()))
        if len(self._undo_stack) > self._max_history:
            self._undo_stack.pop(0)
        self._redo_stack.clear()
        self._revision += 1
        self.cancel_job("open_project")
        self.mark_dirty()

    def snapshot_interactive(self,key):
        """Coalesce one parameter burst while advancing every source revision."""
        import time
        now=time.monotonic();last=getattr(self,'_interactive_snapshot',None)
        if last and last[0]==key and last[1]==id(self._project) and last[2]==self._revision and now-last[3]<.3:
            self._revision+=1;self.mark_dirty()
        else:self.snapshot()
        self._interactive_snapshot=(key,id(self._project),self._revision,now)

    def undo(self) -> bool:
        if not self._undo_stack:
            return False
        if self._undo_stack[-1].get('__atlas_layout_undo__'):
            record=self._undo_stack.pop();self._redo_stack.append(self._layout_history_record());self._restore_layout_record(record);return True
        self._redo_stack.append(deepcopy(self._project.to_dict()))
        prev_data = self._undo_stack.pop()
        self._invalidate_jobs()
        self._project = Project.from_dict(deepcopy(prev_data))
        self._rebuild_atlas_cache()
        self._revision += 1
        self.mark_dirty()
        self.projectLoaded.emit()
        self.tilesChanged.emit()
        self.cardsChanged.emit()
        return True

    def redo(self) -> bool:
        if not self._redo_stack:
            return False
        if self._redo_stack[-1].get('__atlas_layout_undo__'):
            record=self._redo_stack.pop();self._undo_stack.append(self._layout_history_record());self._restore_layout_record(record);return True
        self._undo_stack.append(deepcopy(self._project.to_dict()))
        next_data = self._redo_stack.pop()
        self._invalidate_jobs()
        self._project = Project.from_dict(deepcopy(next_data))
        self._rebuild_atlas_cache()
        self._revision += 1
        self.mark_dirty()
        self.projectLoaded.emit()
        self.tilesChanged.emit()
        self.cardsChanged.emit()
        return True


    def mark_dirty(self, dirty: bool = True):
        if self._dirty != dirty:
            self._dirty = dirty
            self.projectModified.emit(self._dirty)

    # -------------------------------------------------------------------------
    # Project File I/O
    # -------------------------------------------------------------------------
    def new_project(self) -> Project:
        """Create a fresh starter project."""
        self._invalidate_jobs()
        self._undo_stack.clear(); self._redo_stack.clear()
        self._project = Project.sample()
        self._project_path = None
        self._rebuild_atlas_cache()
        self._revision += 1
        self._dirty = False
        self.projectLoaded.emit()
        self.tilesChanged.emit()
        self.cardsChanged.emit()
        self.projectModified.emit(False)
        return self._project

    def open_project_async(self, filename, on_success=None):
        """Read, validate and unpack source assets without blocking Qt input."""
        path=Path(filename)
        self._invalidate_jobs()
        self._opening_project=True
        def read(cancel):
            loaded=load_project(path)
            return loaded,AtlasCache(loaded)
        def publish(result,revision):
            loaded,cache=result
            self._install_project(loaded,path)
            if on_success:on_success(loaded)
        self.submit_job('open_project',read,publish)

    def open_project(self, filename: str | Path) -> Project:
        """Atomically load an .fsd project file and update all shared caches."""
        path = Path(filename)
        loaded = load_project(path)
        AtlasCache(loaded)  # validate before replacing the current document
        return self._install_project(loaded,path)

    def _install_project(self,loaded,path):
        self._invalidate_jobs()
        self._project = loaded
        self._project_path = path
        self._rebuild_atlas_cache()
        self._revision += 1
        self._dirty = False
        self._undo_stack.clear()
        self._redo_stack.clear()
        self.projectLoaded.emit()
        self.tilesChanged.emit()
        self.cardsChanged.emit()
        self.projectModified.emit(False)
        return self._project

    def save_project(self, filename: str | Path | None = None) -> Path:
        """Persist current project to disk safely with atomic temp file swap."""
        target_path = Path(filename) if filename is not None else self._project_path
        if target_path is None:
            raise ValueError("No file path specified for saving project.")
        
        Project.from_dict(deepcopy(self._project.to_dict()))  # Validate IDs before writing
        saved = save_project(self._project, target_path)
        self._project_path = saved
        self._dirty = False
        self.projectSaved.emit(str(saved))
        self.projectModified.emit(False)
        return saved

    # -------------------------------------------------------------------------
    # Shared Atlas Management
    # -------------------------------------------------------------------------
    def _rebuild_atlas_cache(self):
        """Regenerate layout and page allocations for all tiles in project."""
        try:
            self._atlas_pending_layout=None
            if hasattr(self,"_active_jobs"):
                self.cancel_job("atlas_relayout")
            if hasattr(self,"_active_jobs"):
                self.cancel_job("atlas_stage")
            self._atlas_stage_queue.clear()
            if hasattr(self,"_pending_atlas"):self._pending_atlas.clear()
            self._atlas_stage_busy=False
            self._atlas = AtlasCache(self._project)
            self._atlas_generation+=1
            self._baked_tokens.clear()
            self.atlasRebuilt.emit()
        except Exception as error:
            raise RuntimeError("Atlas layout invalid: "+str(error)) from error

    def update_tile_atlas(self, tile_result, token=None):
        """Queue immutable results; compose full-resolution pages off the GUI thread."""
        self._atlas_stage_queue[tile_result.tile_id]=(tile_result,token)
        self._start_atlas_stage()

    def _start_atlas_stage(self):
        if self._closed or getattr(self,"_atlas_pending_layout",None) is not None or self._atlas_stage_busy or not self._atlas_stage_queue:return
        tid=next(iter(self._atlas_stage_queue))
        result,token=self._atlas_stage_queue.pop(tid)
        base=self._atlas;generation=self._atlas_generation
        self._atlas_stage_busy=True
        self._atlas_stage_current=(tid,token)
        def stage(cancel):
            if cancel():return None
            staged=base.staged_tile(result)
            staged.changed_regions=base.changed_regions+staged.changed_regions
            return staged
        def publish(staged,revision):
            self._atlas_stage_busy=False
            current=self.project.find(tid)
            valid_source=token is None or (current is not None and self._atlas_token(current)==token)
            if staged is not None and self._atlas is base and self._atlas_generation==generation and valid_source:
                self._atlas=staged
                if token is not None:
                    self._baked_tokens[tid]=token
                    if getattr(self,"_pending_atlas",{}).get("atlas_bake:"+tid)==token:
                        self._pending_atlas.pop("atlas_bake:"+tid,None)
                self._atlas_generation+=1
                self.atlasRebuilt.emit()
                self.bakeProgress.emit(len(self._baked_tokens),len(self.project.tiles))
                QtCore.QTimer.singleShot(0,self.ensure_atlas)
            if token is not None and not valid_source:
                self._pending_atlas.pop("atlas_bake:"+tid,None)
                QtCore.QTimer.singleShot(0,self.ensure_atlas)
            self._start_atlas_stage()
        self.submit_job('atlas_stage',stage,publish)

    def set_interacting(self,owner,active):
        """Give viewport gestures priority over background source baking."""
        if active:
            self._interaction_owners.add(owner)
            for name in list(self._active_jobs):
                if name.startswith('atlas_bake:'):
                    self.cancel_job(name)
                    getattr(self,'_pending_atlas',{}).pop(name,None)
        else:
            self._interaction_owners.discard(owner)
            if not self._interaction_owners:QtCore.QTimer.singleShot(120,self.ensure_atlas)

    def _atlas_token(self,tile):
        import hashlib
        if getattr(self,'_atlas_token_project',None) is not self.project:
            self._atlas_token_project=self.project;self._atlas_token_cache={}
        stamp=(id(tile),tile.revision,tile.width,tile.height,tile.seed,tile.kind,tuple(vars(tile.settings).values()),id(tile.construction_graph),id(tile.overrides),self._atlas_channels)
        cached=self._atlas_token_cache.get(tile.id)
        if cached is not None and cached[0]==stamp:return cached[1]
        token=hashlib.sha256(json.dumps((tile.to_dict(),self._atlas_channels),sort_keys=True).encode()).hexdigest()
        self._atlas_token_cache[tile.id]=(stamp,token);return token

    def request_atlas_channel(self,channel):
        if channel not in self._atlas_channels:
            self._atlas_channels=(*self._atlas_channels,channel)
            self.ensure_atlas()

    def ensure_atlas(self):
        """Schedule missing source maps; workers only return immutable bake results."""
        if self._closed or self._opening_project or self._interaction_owners or getattr(self,"_atlas_pending_layout",None) is not None:return
        if set(self.atlas.layout.placements)!={t.id for t in self.project.tiles}:self._rebuild_atlas_cache()
        if self._atlas_stage_busy or self._atlas_stage_queue or any(n.startswith("atlas_bake:") for n in self._active_jobs):return
        from ..raster import render_tile
        channels=self._atlas_channels
        for tile in self.project.tiles:
            token=self._atlas_token(tile)
            if self._baked_tokens.get(tile.id)==token:continue
            name='atlas_bake:'+tile.id
            if getattr(self,'_pending_atlas',{}).get(name)==token:continue
            if not hasattr(self,'_pending_atlas'):self._pending_atlas={}
            self._pending_atlas[name]=token
            snapshot=deepcopy(tile)
            def bake(cancel,snapshot=snapshot):
                import os,sys
                if sys.platform=='win32' and os.environ.get('FSD_FIBERBAKE_BACKEND','auto') not in ('cpu','legacy-gpu'):
                    try:
                        from ..fiberbake_x.atlas import prepare_production
                        return prepare_production(snapshot,channels,cancel)
                    except Exception:
                        if cancel() or os.environ.get('FSD_FIBERBAKE_BACKEND')=='gpu':raise
                return render_tile(snapshot,channels=channels,should_cancel=cancel)
            def publish(result,revision,tid=tile.id,token=token,name=name):
                current=self.project.find(tid)
                if current is None or self._atlas_token(current)!=token:
                    self._pending_atlas.pop(name,None)
                    QtCore.QTimer.singleShot(0,self.ensure_atlas)
                    return
                self.update_tile_atlas(result,token)
            self.submit_job(name,bake,publish)
            break # Backpressure: one result through bake/stage/publication at a time.

    # -------------------------------------------------------------------------
    # UDIM & Atlas Capacity Operations
    # -------------------------------------------------------------------------
    def get_active_udims(self) -> list[int]:
        """Return list of sorted active UDIM IDs for project."""
        udims = getattr(self.atlas.layout, "udims", None)
        if udims:
            return list(udims)
        return [1001 + p for p in range(max(1, self.atlas.layout.pages))]

    def add_udim(self, udim: int | None = None) -> int:
        """Create a new UDIM page to expand atlas capacity for additional fiber clusters."""
        active = list(self.project.metadata.get("active_udims", []))
        if not active:
            active = list(self.get_active_udims())
        if udim is None:
            udim = max(active) + 1 if active else 1001
        if udim not in active:
            self.snapshot()
            active.append(udim)
            self.project.metadata["active_udims"] = sorted(active)
            self._rebuild_atlas_cache()
            self.ensure_atlas()
            self.mark_dirty(True)
        return udim

    def remove_udim(self, udim: int) -> bool:
        """Remove an empty UDIM page if no tiles reside on it."""
        active = list(self.project.metadata.get("active_udims", []))
        tiles_on_udim = [tid for tid, p in self.atlas.layout.placements.items() if getattr(p, "udim", 1001 + p.page) == udim]
        if tiles_on_udim:
            return False
        if udim in active and len(active) > 1:
            self.snapshot()
            active.remove(udim)
            self.project.metadata["active_udims"] = sorted(active)
            self._rebuild_atlas_cache()
            self.ensure_atlas()
            self.mark_dirty(True)
            return True
        return False

    def assign_tile_udim(self, tile_id: str, udim: int, x: int | None = None, y: int | None = None):
        """Move a tile / fiber cluster to a target UDIM page."""
        self.snapshot_layout()
        meta = dict(self.project.metadata)
        placements = dict(meta.get("tile_placements", {}))
        current = dict(placements.get(tile_id, {}))
        current["udim"] = int(udim)
        current["page"] = max(0, int(udim) - 1001)
        if x is not None and y is not None:
            current["x"] = int(x)
            current["y"] = int(y)
        placements[tile_id] = current
        meta["tile_placements"] = placements
        active = set(meta.get("active_udims", []))
        active.add(int(udim))
        meta["active_udims"] = sorted(active)
        self.project.metadata = meta
        self.relayout_atlas()
        self.ensure_atlas()
        self.mark_dirty(True)

    def auto_pack_udim(self, udim: int | None = None):
        """Auto-pack tiles within a designated UDIM or across all UDIMs."""
        self.snapshot_layout()
        meta = dict(self.project.metadata)
        placements = dict(meta.get("tile_placements", {}))
        if udim is not None:
            for tid, p in list(placements.items()):
                p_udim = p.get("udim", 1001 + p.get("page", 0))
                if p_udim == udim:
                    placements[tid] = {"udim": udim, "page": udim - 1001}
        else:
            placements.clear()
        meta["tile_placements"] = placements
        self.project.metadata = meta
        self.relayout_atlas()
        self.ensure_atlas()
        self.mark_dirty(True)

    # -------------------------------------------------------------------------
    # Card Operations (Uniqueness and Reference Integrity)
    # -------------------------------------------------------------------------
    def add_card(self, tile_id: str | None = None) -> HairCard:
        self.snapshot()
        if tile_id is None and self._project.tiles:
            tile_id = self._project.tiles[0].id
        root_x = (len(self._project.cards) - 3) * 0.28
        new_card = HairCard.create(tile_id, f"Card {len(self._project.cards)+1:03d}", [root_x, 0, 0])
        self._project.cards.append(new_card.to_dict())
        self._revision += 1
        self.cardsChanged.emit()
        return new_card

    def duplicate_cards(self, indices: list[int]) -> list[str]:
        """Duplicate cards guaranteeing new stable unique IDs."""
        self.snapshot()
        new_ids = []
        for idx in sorted(set(indices)):
            if 0 <= idx < len(self._project.cards):
                source_dict = self._project.cards[idx]
                card = HairCard.from_dict(source_dict)
                dup = card.duplicate(dx=0.15)
                # Ensure guaranteed unique ID in project
                existing_ids = {c['id'] for c in self._project.cards}
                while dup.id in existing_ids:
                    import uuid
                    dup.id = uuid.uuid4().hex[:12]
                self._project.cards.append(dup.to_dict())
                new_ids.append(dup.id)
        self._revision += 1
        self.cardsChanged.emit()
        return new_ids

    def delete_cards(self, indices: list[int]):
        self.snapshot()
        for idx in sorted(set(indices), reverse=True):
            if 0 <= idx < len(self._project.cards):
                del self._project.cards[idx]
        self._revision += 1
        self.cardsChanged.emit()

    def assign_tile_to_cards(self, card_indices: list[int], tile_id: str):
        if self.project.find(tile_id) is None:raise ValueError("Tile does not exist: "+str(tile_id))
        self.snapshot()
        for idx in card_indices:
            if 0 <= idx < len(self._project.cards):
                self._project.cards[idx]['tile_id'] = tile_id
        self._revision += 1
        self.cardsChanged.emit()

    # -------------------------------------------------------------------------
    # Asynchronous Heavy Job Dispatcher (Latest-Request-Wins)
    # -------------------------------------------------------------------------
    def cancel_job(self,task_name):
        if task_name=="open_project" and self._opening_project:
            self._opening_project=False
            QtCore.QTimer.singleShot(0,self.ensure_atlas)
        event=self._cancel_events.pop(task_name,None)
        if event:event.set()
        future=self._job_futures.pop(task_name,None)
        if future:future.cancel()
        self._active_jobs.pop(task_name,None);self._result_handlers.pop(task_name,None)

    def submit_job(self, task_name: str, worker_fn: Callable[[], Any], on_success: Callable[[Any, int], None]):
        """Submits heavy computation without freezing Qt main UI thread."""
        if self._closed:return
        old_event=self._cancel_events.get(task_name)
        if old_event:old_event.set()
        cancel=threading.Event();self._cancel_events[task_name]=cancel
        previous=self._job_futures.get(task_name)
        if previous:previous.cancel()
        self._job_serial += 1
        current_rev = self._job_serial
        self._active_jobs[task_name] = current_rev
        self._result_handlers[task_name] = on_success

        self.jobStarted.emit(task_name)
        def run():
            try:
                import inspect
                res = worker_fn(cancel.is_set) if inspect.signature(worker_fn).parameters else worker_fn()
                if cancel.is_set():return
                self._job_worker.taskFinished.emit(task_name, res, current_rev)
            except Exception as e:
                self._job_worker.taskFailed.emit(task_name, str(e), current_rev)

        executor=self._preview_executor if task_name in ("fiber_studio_preview","graph_live_preview","atlas_canvas_preview") else self._executor
        self._job_futures[task_name]=executor.submit(task_name,lambda token:run(),priority=0) if executor is self._preview_executor else executor.submit(run)

    def _on_job_finished(self, task_name: str, result: Any, rev: int):
        # Ignore stale out-of-order job completions
        if self._closed or self._active_jobs.get(task_name) != rev:
            return
        handler = self._result_handlers.get(task_name)
        if handler:
            try:
                handler(result, rev)
                self.jobCompleted.emit(task_name)
            except Exception as error:self.jobFailed.emit(task_name,str(error))
            finally:
                if self._active_jobs.get(task_name)==rev:
                    self._active_jobs.pop(task_name,None);self._result_handlers.pop(task_name,None);self._job_futures.pop(task_name,None);self._cancel_events.pop(task_name,None)

    def _on_job_failed(self, task_name: str, error_msg: str, rev: int):
        if self._closed or self._active_jobs.get(task_name) != rev:
            return
        self._active_jobs.pop(task_name,None);self._result_handlers.pop(task_name,None)
        self._job_futures.pop(task_name,None);self._cancel_events.pop(task_name,None)
        if task_name=="open_project":
            self._opening_project=False
            self.tilesChanged.emit()
        if task_name=="atlas_relayout":
            self._rebuild_atlas_cache();QtCore.QTimer.singleShot(0,self.ensure_atlas)
        if task_name=="atlas_stage":
            tid,token=self._atlas_stage_current
            name="atlas_bake:"+tid
            if getattr(self,"_pending_atlas",{}).get(name)==token:
                self._pending_atlas.pop(name,None)
            self._atlas_stage_busy=False
            self._start_atlas_stage()
        if hasattr(self,"_pending_atlas"):self._pending_atlas.pop(task_name,None)
        self.jobFailed.emit(task_name,error_msg)

    def _invalidate_jobs(self):
        self._opening_project=False
        self._atlas_pending_layout=None
        self._atlas_stage_busy=False
        self._atlas_stage_queue.clear()
        if hasattr(self,"_pending_atlas"):self._pending_atlas.clear()
        for event in self._cancel_events.values():event.set()
        self._cancel_events.clear()
        self._active_jobs.clear();self._result_handlers.clear()
        for future in self._job_futures.values():future.cancel()
        self._job_futures.clear()

    def shutdown(self):
        """Clean shutdown of worker threads."""
        self._closed=True
        self._invalidate_jobs()
        self._executor.shutdown(wait=False, cancel_futures=True)
        self._preview_executor.close(wait=False)

    def close(self):
        self.shutdown()
