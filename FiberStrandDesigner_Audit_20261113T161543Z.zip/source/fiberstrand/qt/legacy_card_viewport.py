"""Qt adapter for the persistent legacy card GPU viewport and drag operators.
Qt owns HWND/input/lifetime. EditorScene, picking and GPU buffers remain shared
with Tk; this module never creates a Tk window or replaces the project model.
"""
import math
from copy import deepcopy
from types import SimpleNamespace
import numpy as np
from PySide6 import QtCore,QtGui,QtWidgets
from ..cards import HairCard,change_segments
from ..card_edit_ops import apply_card_drag
from .theme import TOKENS

PIES={'Select':['Move','Rotate','Scale','Duplicate','Delete','Make Unique'],
      'Groom':['Comb','Relax','Spread','Smooth','Lift','Noise'],
      'Shape':['Bend','Twist','Taper','Width','Length','Lift'],
      'Mesh':['Vertex','Insert Row','Remove Row','Relax','Root','Width']}

class _Value:
    def __init__(self,fn):self.fn=fn
    def get(self):return self.fn()

class _QtNativeMetrics:
    native_owner='qt'
    def __init__(self,widget):self.widget=widget
    def winfo_id(self):return int(self.widget.winId())
    def winfo_width(self):return self.widget.width()
    def winfo_height(self):return self.widget.height()
    def winfo_fpixels(self,value):return 96*self.widget.devicePixelRatioF()

class _Pie(QtWidgets.QWidget):
    def __init__(self,names,origin):
        super().__init__(None,QtCore.Qt.WindowType.ToolTip|QtCore.Qt.WindowType.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_TransparentForMouseEvents);self.setFocusPolicy(QtCore.Qt.FocusPolicy.NoFocus)
        self.names=names;self.setAttribute(QtCore.Qt.WidgetAttribute.WA_ShowWithoutActivating);self.resize(290,290);self.move(origin-QtCore.QPoint(145,145))
    def paintEvent(self,event):
        p=QtGui.QPainter(self);p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing);p.fillRect(self.rect(),QtGui.QColor(TOKENS['bg_dark']))
        p.setPen(QtGui.QColor(TOKENS['cyan']));p.drawText(self.rect(),QtCore.Qt.AlignmentFlag.AlignCenter,'Space')
        for i,name in enumerate(self.names):
            a=math.radians(-90+i*60);q=QtCore.QRectF(145+100*math.cos(a)-42,145+100*math.sin(a)-22,84,44)
            p.setBrush(QtGui.QColor(TOKENS['bg_panel']));p.drawEllipse(q);p.drawText(q,QtCore.Qt.AlignmentFlag.AlignCenter,name)

class LegacyCardViewportMixin:
    def _setup_legacy_card_viewport(self):
        from ..settings import AppSettings
        self._legacy_settings=AppSettings.load()
        self._gpu_view=None;self._gpu_failed=False;self._card_drag=None;self._edit_epoch=0;self._components={};self._selected_ids=set()
        self._card_tool='Select';self._card_mode='Select';self._brush_enabled=False;self._brush_radius=80.;self._last_drag=None;self._pie_origin=None;self._pie=None;self._card_frame_pending=False;self._guide_draw=None;self._show_wire=False
        self.camera_yaw=-.18;self.camera_pitch=.1;self._card_distance=4.8;self._card_target=np.array([0.,.7,0.])
        v=self.viewport;v.set_view_kind('cards')
        v.pointerPressed.connect(self._card_press);v.pointerMoved.connect(self._card_move);v.pointerReleased.connect(self._card_release);v.hoverMoved.connect(self._card_hover)
        v.interactionStarted.connect(self._card_gesture_start);v.interactionFinished.connect(self._card_gesture_end)
        v.repeatRequested.connect(self._card_repeat);v.piePressed.connect(self._card_pie_start);v.pieReleased.connect(self._card_pie_end);v.contextRequested.connect(self._card_context)
        v.acceptRequested.connect(lambda:self.finish_guide_draw(True) if self._guide_draw is not None else None)
        self.cardsModified.connect(self.controller.cardsChanged.emit)
        self.controller.atlasRebuilt.connect(self._schedule_card_frame)
        self.controller.projectLoaded.connect(self._card_project_replaced)
        for mode,button in (('Select',self.btn_select),('Groom',self.btn_groom),('Shape',self.btn_shape),('Mesh',self.btn_mesh)):
            button.clicked.connect(lambda checked=False,m=mode:self._card_set_mode(m))
        self.comp_combo.currentTextChanged.connect(lambda _:self._schedule_card_frame())
        self._card_set_mode('Select')
        self._sync_card_selection_from_list();self._schedule_card_frame()

    def _ensure_card_gpu(self):
        if self._gpu_view is not None or self._gpu_failed:return
        try:
            from ..editor_viewport import GPUCardViewport
            self._gpu_view=GPUCardViewport(_QtNativeMetrics(self.viewport))
            self.viewport.set_renderer_callback(self._paint_card_gpu)
        except Exception as error:
            self._gpu_failed=True;self.controller.jobFailed.emit('card viewport',str(error))

    def _schedule_card_frame(self):
        if not hasattr(self,'_gpu_view'):return
        if self.isVisible():self.viewport.update()

    def _paint_card_gpu(self):
        if not self.isVisible() or self._gpu_view is None:return
        view=self._gpu_view;r=view.renderer;dpr=self.viewport.devicePixelRatioF()
        scene_owner=getattr(getattr(self,'scene_service',None),'backend',None)
        if scene_owner is not None:r.object_workspace=scene_owner
        key=(id(self.controller.project),self.controller.revision,self._edit_epoch,getattr(scene_owner,'pose_revision',0))
        if getattr(self,'_card_source_key',None)!=key:
            from ..rendercore.settings import material_from_project
            r.material=material_from_project(self.controller.project)
            if not hasattr(self,'studio_display'):r.material.shadow_strength=0.;r.material.scatter_strength=0.
            cards=[HairCard.from_dict(c) for c in self.controller.project.cards]
            if self._guide_draw and len(self._guide_draw['points'])>=2:
                preview=HairCard.create(self.tile_combo.currentData(),'Guide preview');preview.id='__guide_preview__';preview.root=[0.,0.,0.];preview.length=1.;preview.guide_points=deepcopy(self._guide_draw['points']);preview.width=.012;preview.segments=32;preview.bend=0.;cards.append(preview)
            view.reconcile(cards);self._card_source_key=key
        atlas_key=(id(self.controller.atlas),len(self.controller.atlas.changed_regions))
        if getattr(self,'_card_atlas_key',None)!=atlas_key:view.bind_atlas(self.controller.atlas);self._card_atlas_key=atlas_key
        if hasattr(self,'_studio_material'):
            r.material=self._studio_material
            from .render_studio import DEBUG_MODE_MAP
            r.material.debug={'Textured':17,'Coverage':1,'Normals':2,'Wireframe':0}.get(self.studio_display,DEBUG_MODE_MAP.get(self.studio_display,0))
            if r.quality_mode!=self.quality_combo.currentText():r.set_quality(self.quality_combo.currentText(),1.,'Spatial')
        r.resize(max(32,round(self.viewport.width()*dpr)),max(32,round(self.viewport.height()*dpr)))
        r.yaw=self.camera_yaw;r.pitch=self.camera_pitch;r.distance=self._card_distance;r.target[:]=self._card_target
        r.show_wire=self._show_wire
        r.selection_mode=self.comp_combo.currentText();r.show_grid=self._legacy_settings.show_grid;r.show_axis_gizmo=self._legacy_settings.show_axis_gizmo;r.show_hud=self._legacy_settings.show_hud;r.up_axis=self._legacy_settings.up_axis;r.hud_dpr=dpr
        r.hud_lines=(r.info.gpu_renderer,f'{self._card_mode} | {self._card_tool} | {r.selection_mode} | S: brush size | Space: marking menu')
        r.editing=self.viewport._gesture is not None;r.set_interaction(r.editing)
        view.scene.select(self._selected_ids,self._components);view.scene.active=next(iter(self._selected_ids),None)
        pending=r.render_editor()
        if pending and not self._card_frame_pending:
            self._card_frame_pending=True;QtCore.QTimer.singleShot(16,self._next_card_frame)

    def _next_card_frame(self):self._card_frame_pending=False;self._schedule_card_frame()

    def showEvent(self,event):
        super().showEvent(event)
        if hasattr(self,'_gpu_view'):
            self._ensure_card_gpu()
            if self._gpu_failed:self._draw_cards_wireframe_fallback()
            else:self._schedule_card_frame()

    def close_card_viewport(self):
        if getattr(self,'_gpu_view',None):
            self.viewport.set_renderer_callback(None);self._gpu_view.close();self._gpu_view=None
        self._card_pie_close()

    def _card_project_replaced(self):
        self._card_drag=None;self._selected_ids=set();self._components={};self._edit_epoch+=1;self._schedule_card_frame()

    def _sync_card_selection_from_list(self):
        self._selected_ids={self.controller.project.cards[i]['id'] for i in self.selected_indices if 0<=i<len(self.controller.project.cards)}
        self._schedule_card_frame()

    def _card_select_ids(self,ids):
        self._selected_ids=set(ids);self.selected_indices={i for i,c in enumerate(self.controller.project.cards) if c['id'] in ids}
        self.card_list.blockSignals(True)
        for i in range(self.card_list.count()):self.card_list.item(i).setSelected(i in self.selected_indices)
        self.card_list.blockSignals(False);self.controller.cardSelected.emit(list(ids));self._schedule_card_frame()

    def _legacy_orbit(self,dx,dy):
        self.camera_yaw-=dx*.008;self.camera_pitch=max(-1.2,min(1.2,self.camera_pitch+dy*.006));self._schedule_card_frame()

    def _legacy_pan(self,dx,dy):
        from ..navigation import pan_target
        h=max(100,self.viewport.height());w=max(100,self.viewport.width());fov=2*math.atan(h/(2*max(100,min(w,h)*1.45)))
        self._card_target[:]=pan_target(self._card_target,self.camera_yaw,self.camera_pitch,self._card_distance,h,dx,dy,fov);self._schedule_card_frame()

    def _legacy_dolly(self,factor):
        value=self._card_distance*factor
        if math.isfinite(value) and value>0:self._card_distance=max(1e-5,value)
        self._schedule_card_frame()

    def _legacy_frame(self):
        scene_owner=getattr(getattr(self,'scene_service',None),'backend',None)
        if scene_owner is not None:r.object_workspace=scene_owner
        key=(id(self.controller.project),self.controller.revision,self._edit_epoch,getattr(scene_owner,'pose_revision',0))
        if self._gpu_view and getattr(self,"_card_source_key",None)==key:
            target,distance=self._gpu_view.focus_bounds(self._selected_ids or None);self._card_target[:]=target;self._card_distance=distance
        else:
            roots=[c.get('root',[0,0,0]) for c in self.controller.project.cards if c.get('visible',True)]
            if roots:
                pts=np.asarray(roots,float)
                self._card_target[:]=pts.mean(axis=0)+[0,.5,0]
                self._card_distance=float(max(np.ptp(pts,axis=0).max(),1.)*1.8)
            else:
                self._card_target[:]=[0,.7,0];self._card_distance=4.8
        self._schedule_card_frame()

    def _card_gesture_start(self,mode,pos):
        if self._gpu_view:self._gpu_view.renderer.set_interaction(True)

    def _card_gesture_end(self,mode,cancelled):
        if cancelled and mode=='edit':self._legacy_cancel()
        if self._gpu_view:self._gpu_view.renderer.set_interaction(False)
        self._schedule_card_frame()

    def _card_press(self,pos,button,mods):
        if button!=QtCore.Qt.MouseButton.LeftButton.value or self.viewport._space_down:return
        if self._guide_draw is not None:
            if self._gpu_view:
                anchor=np.asarray(self._card_target,float);point=anchor+self._gpu_view.world_delta(pos.x()-self.viewport.width()/2,pos.y()-self.viewport.height()/2,anchor)
                self._guide_draw['points'].append(point.tolist());self._edit_epoch+=1;self._schedule_card_frame()
            return
        if self.viewport._s_down:self._card_drag={'size':True,'x':pos.x(),'radius':self._brush_radius};return
        if self._gpu_view is None:return
        dpr=self.viewport.devicePixelRatioF();x,y=pos.x()*dpr,pos.y()*dpr
        mode=self.comp_combo.currentText();cid,part=self._gpu_view.pick(x,y,mode)
        shift=bool(mods & QtCore.Qt.KeyboardModifier.ShiftModifier.value);ctrl=bool(mods & QtCore.Qt.KeyboardModifier.ControlModifier.value)
        ids=set(self._selected_ids)
        if cid:
            if ctrl and mode=='Card':ids.discard(cid)
            elif shift:ids.add(cid)
            elif cid not in ids:ids={cid}
        elif not shift and not ctrl and not self._brush_enabled:ids.clear()
        if mode!='Card' and cid and part is not None:
            if not shift and not ctrl:self._components={}
            parts=self._components.setdefault(cid,set())
            if ctrl:parts.discard((mode,part))
            else:parts.add((mode,part))
        elif not shift and not ctrl:self._components={}
        if self._brush_enabled:
            hits=self._gpu_view.brush_hits(x,y,self._brush_radius*dpr)
            if hits:ids=ids-hits if ctrl else ids|hits if shift else set(hits)
        self._card_select_ids(ids)
        if cid is None and not self._brush_enabled:
            self._card_drag={'box':True,'start':(x,y),'last':(x,y),'original':set(ids),'shift':shift,'ctrl':ctrl};self._gpu_view.scene.selection_box=(x,y,x,y);return
        sources={c['id']:HairCard.from_dict(c) for c in self.controller.project.cards if c['id'] in ids and not c.get('locked',False)}
        if not sources or self._card_tool=='Select':return
        self._card_drag={'orig':sources,'x':pos.x(),'y':pos.y(),'tool':self._card_tool,'components':deepcopy(self._components),'card_id':cid,'part':part,'changed':False,'project':self.controller.project}

    def _card_move(self,pos,mods):
        d=self._card_drag
        if not d:return
        if d.get('size'):self._brush_radius=max(25.,min(320.,d['radius']+pos.x()-d['x']));return
        if d.get('box'):
            p=(pos.x()*self.viewport.devicePixelRatioF(),pos.y()*self.viewport.devicePixelRatioF());d['last']=p;self._gpu_view.scene.selection_box=(*d['start'],*p);self._schedule_card_frame();return
        dx,dy=pos.x()-d['x'],pos.y()-d['y']
        if abs(dx)+abs(dy)<2:return
        if not d['changed']:
            d['previous_redo']=list(self.controller._redo_stack);d['previous_dirty']=self.controller.is_dirty
            self.controller.snapshot();d['undo_length']=len(self.controller._undo_stack)
        fine=.18 if mods & QtCore.Qt.KeyboardModifier.ShiftModifier.value else 1.
        self._card_apply(d,dx*fine*(self.viewport._pen_pressure if self._brush_enabled else 1.),dy*fine*(self.viewport._pen_pressure if self._brush_enabled else 1.),pos);d['changed']=True;d['last_delta']=(dx*fine,dy*fine);self._schedule_card_frame()

    def _card_apply(self,drag,dx,dy,pos):
        cards=[HairCard.from_dict(c) for c in self.controller.project.cards if c['id'] in drag['orig']]
        context=SimpleNamespace(distance=self._card_distance,view=self._gpu_view,brush=_Value(lambda:self._brush_enabled),radius=self._brush_radius,dpi_factor=self.viewport.devicePixelRatioF(),selection_mode=_Value(self.comp_combo.currentText),mode=_Value(lambda:self._card_mode),snap_mesh_id=None)
        apply_card_drag(context,drag,dx,dy,pos.x()*context.dpi_factor,pos.y()*context.dpi_factor,targets=cards)
        replacements={c.id:c.to_dict() for c in cards};self.controller.project.cards=[replacements.get(c['id'],c) for c in self.controller.project.cards];self._edit_epoch+=1

    def _card_release(self,pos,button,mods):
        d=self._card_drag;self._card_drag=None
        if not d:return
        if d.get('box'):
            a=d['start'];b=d['last'];hits=self._gpu_view.select_box((*a,*b)) if abs(a[0]-b[0])+abs(a[1]-b[1])>3 else set()
            self._card_select_ids(d['original']-hits if d['ctrl'] else d['original']|hits if d['shift'] else hits);self._gpu_view.scene.selection_box=None
        elif d.get('changed'):
            from ..kernel.surface import capture_vertices
            records=[]
            for raw in self.controller.project.cards:
                if raw['id'] in d['orig']:
                    card=HairCard.from_dict(raw);capture_vertices(card);raw=card.to_dict()
                records.append(raw)
            self.controller.project.cards=records
            self._last_drag=(d['tool'],*d['last_delta']);self.controller.cardsChanged.emit()
        self._schedule_card_frame()

    def _legacy_cancel(self):
        if self._guide_draw is not None:self.finish_guide_draw(False)
        d=self._card_drag;self._card_drag=None;self._card_pie_close()
        if self._gpu_view:self._gpu_view.scene.selection_box=None
        if d and d.get('changed') and d.get('project') is self.controller.project:
            originals={k:v.to_dict() for k,v in d['orig'].items()};self.controller.project.cards=[originals.get(c['id'],c) for c in self.controller.project.cards]
            if len(self.controller._undo_stack)==d.get('undo_length'):
                self.controller._undo_stack.pop();self.controller._redo_stack=d.get('previous_redo',[]);self.controller.mark_dirty(d.get('previous_dirty',True))
            self._edit_epoch+=1
        self._schedule_card_frame()

    def _card_hover(self,pos):
        if self._gpu_view and self._pie_origin is None:self._gpu_view.hover(pos.x()*self.viewport.devicePixelRatioF(),pos.y()*self.viewport.devicePixelRatioF());self._schedule_card_frame()

    def _card_repeat(self):
        if not self._last_drag or self._last_drag[0]=='Vertex':return
        sources={c['id']:HairCard.from_dict(c) for c in self.controller.project.cards if c['id'] in self._selected_ids and not c.get('locked',False)}
        if not sources:return
        self.controller.snapshot();tool,dx,dy=self._last_drag
        self._card_apply({'tool':tool,'orig':sources,'components':deepcopy(self._components)},dx,dy,self.viewport._last_mouse_pos);self.controller.cardsChanged.emit()

    def _card_set_mode(self,mode):
        self._card_mode=mode
        for name,button in (('Select',self.btn_select),('Groom',self.btn_groom),('Shape',self.btn_shape),('Mesh',self.btn_mesh)):
            button.setProperty('class','workspace_pill_active' if name==mode else 'workspace_pill');button.style().unpolish(button);button.style().polish(button)
        self._card_choose_tool({'Select':'Select','Groom':'Comb','Shape':'Bend','Mesh':'Vertex'}[mode])

    def _card_choose_tool(self,tool):
        if tool=='Brush':self._brush_enabled=not self._brush_enabled;self._schedule_card_frame();return
        if tool=='Duplicate':self._duplicate_card();return
        if tool=='Delete':self._delete_card();return
        if tool in ('Insert Row','Remove Row','Make Unique','Reset Overrides'):self._card_context_action(tool);return
        self._card_tool=tool
        if tool=='Vertex':self.comp_combo.setCurrentText('Vertex')
        self._schedule_card_frame()

    def _card_pie_start(self,pos):
        self._pie_origin=QtCore.QPointF(pos);QtCore.QTimer.singleShot(150,self._card_show_pie)

    def _card_show_pie(self):
        if self._pie_origin is None:return
        self._card_pie_close(False);self._pie=_Pie(PIES[self._card_mode],self.viewport.mapToGlobal(self._pie_origin.toPoint()));self._pie.show()

    def _card_pie_close(self,clear=True):
        if getattr(self,'_pie',None):self._pie.close();self._pie.deleteLater();self._pie=None
        if clear:self._pie_origin=None

    def _card_pie_end(self,pos):
        origin=self._pie_origin
        if origin is not None:
            dx,dy=pos.x()-origin.x(),pos.y()-origin.y()
            if math.hypot(dx,dy)>34:self._card_choose_tool(PIES[self._card_mode][round((math.degrees(math.atan2(dy,dx))+90)/60)%6])
        self._card_pie_close()

    def _card_context(self,pos):
        menu=QtWidgets.QMenu(self)
        for label,callback in (('Add Card',self._add_card),('Duplicate',self._duplicate_card),('Delete',self._delete_card)):
            menu.addAction(label,callback)
        for label in ('Make Unique','Insert Row','Remove Row','Reset Overrides'):menu.addAction(label,lambda checked=False,v=label:self._card_context_action(v))
        menu.addAction('Draw Guide Card',self._draw_guide_card)
        wire=menu.addAction('Wireframe');wire.setCheckable(True);wire.setChecked(self._show_wire);wire.toggled.connect(self._set_card_wire)
        menu.exec(pos)

    def _card_context_action(self,action):
        cards=[HairCard.from_dict(c) for c in self.controller.project.cards if c['id'] in self._selected_ids and not c.get('locked',False)]
        if not cards:return
        self.controller.snapshot()
        for card in cards:
            if action=='Make Unique':
                tile=self.controller.project.find(card.tile_id)
                if tile:
                    clone=tile.clone();clone.name=tile.name+' / '+card.name;self.controller.project.tiles=[*self.controller.project.tiles,clone];card.tile_id=clone.id
            elif action in ('Insert Row','Remove Row'):change_segments(card,card.segments+(1 if action=='Insert Row' else -1))
            elif action=='Reset Overrides':card.vertex_offsets={};card.deformation_layers=[];card.offsets=[[0.,0.,0.] for _ in range(5)]
        mapping={c.id:c.to_dict() for c in cards};self.controller.project.cards=[mapping.get(c['id'],c) for c in self.controller.project.cards]
        if action=='Make Unique':self.controller._rebuild_atlas_cache();self.controller.tilesChanged.emit()
        self._edit_epoch+=1;self.controller.cardsChanged.emit();self._schedule_card_frame()

    def _set_card_wire(self,value):self._show_wire=value;self._schedule_card_frame()

    def begin_guide_draw(self,callback):
        self._guide_draw={'points':[],'callback':callback};self.viewport.setFocus()
        self.viewport.set_hud_text('Draw Guide: click points · Enter commit · Escape cancel')

    def finish_guide_draw(self,accept):
        d=self._guide_draw
        if d is None:return
        self._guide_draw=None;self._edit_epoch+=1;self._schedule_card_frame()
        d['callback'](d['points'] if accept else [])

    def _draw_guide_card(self):
        tile_id=self.tile_combo.currentData()
        if not tile_id:return
        def commit(points):
            if len(points)<2:return
            card=HairCard.create(tile_id,'Drawn Guide Card');card.root=[0.,0.,0.];card.length=1.;card.guide_points=points;card.bend=0.
            self.controller.snapshot();self.controller.project.cards=[*self.controller.project.cards,card.to_dict()]
            self.controller.cardsChanged.emit();self._card_select_ids({card.id})
        self.begin_guide_draw(commit)
