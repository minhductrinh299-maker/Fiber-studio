"""Qt host for the same analytic SDF live-fiber core used by the legacy UI."""
import math
from ..engine_v2.live_core import LiveFiberGPUCore

class _Surface:
    def __init__(self,widget):self.widget=widget
    def winfo_id(self):return int(self.widget.winId())
    def winfo_width(self):return max(1,round(self.widget.width()*self.widget.devicePixelRatioF()))
    def winfo_height(self):return max(1,round(self.widget.height()*self.widget.devicePixelRatioF()))

class _Status:
    def __init__(self,report):self.report=report;self.text=''
    def set(self,text):
        self.text=text
        if text.startswith(('GPU preview unavailable','GPU frame failed')):self.report(text)

class QtLiveFiberCore(LiveFiberGPUCore):
    def __init__(self,viewport,report):
        self.viewport=viewport
        self.native_surface=viewport.live_surface()
        super().__init__(_Surface(self.native_surface),_Status(report),native_owner='qt')
        self.initialize()
        if self.gl is None:
            self.close_gpu();raise RuntimeError(self.message.text)
    def frame(self):
        if callable(getattr(self.viewport,'_map_canvas',None)) or self.viewport._renderer_callback is None:
            self.viewport.hide_live_surface();return
        if self.native_surface.geometry()!=self.viewport.rect():self.native_surface.setGeometry(self.viewport.rect())
        if not self.native_surface.isVisible():self.native_surface.show();self.native_surface.raise_()
        super().frame()
    def request_frame(self):self.viewport.update()
    def sync_transform(self):
        self.zoom=self.viewport._view_zoom;self.angle=math.radians(self.viewport._view_angle)
        ratio=self.viewport.devicePixelRatioF();self.pan=[self.viewport._view_pan.x()*ratio,self.viewport._view_pan.y()*ratio];self.hud_dpr=ratio
