"""Two real Studio workspaces; panel docking and shared project/action lifetime."""
from copy import deepcopy
from pathlib import Path
import json
from PySide6 import QtCore,QtGui,QtWidgets
from .main_window_legacy import FSDMainWindow as FileCommands
from .controller import AppController
from .action_registry import ActionRegistry,ActionDef
from .fiber_workspace import FiberWorkspace
from .scene_studio import SceneStudio
from .bake_panel import BakePanel
from .theme import TOKENS,get_stylesheet
from ..resources import branding_asset

LAYOUT_PATH=Path(__file__).resolve().parents[2]/'assets/branding/studio_layout.json'

class TwoStudioMainWindow(FileCommands):
    two_studio_layout=True
    def __init__(self,controller=None,project=None):
        QtWidgets.QMainWindow.__init__(self);self.controller=controller or AppController(project);self.resize(1440,900);self.setMinimumSize(1000,650)
        self.setDockNestingEnabled(True);self._studio_states={};self._active_studio=None;self._style_studio=None;self._layout_restoring=False
        icon=branding_asset('icon')
        if icon.exists():self.setWindowIcon(QtGui.QIcon(str(icon)))
        self.workspace_stack=QtWidgets.QStackedWidget();self.setCentralWidget(self.workspace_stack)
        self.fiber_workspace=FiberWorkspace(self.controller,self.workspace_stack);self.scene_studio=SceneStudio(self.controller,self.workspace_stack)
        self.workspace_stack.addWidget(self.fiber_workspace);self.workspace_stack.addWidget(self.scene_studio)
        # Stable component aliases keep file/project tools and saved element IDs compatible.
        self.fiber_studio=self.fiber_workspace.fiber;self.construction_studio=self.fiber_workspace.graph;self.card_editor=self.scene_studio;self.render_studio=self.scene_studio
        self.console=QtWidgets.QPlainTextEdit();self.console.setReadOnly(True);self.console.setMaximumBlockCount(500)
        self.jobs=QtWidgets.QListWidget();self._job_items={};self.bake_panel=BakePanel(self.controller)
        self.bottom=QtWidgets.QTabWidget();self.bottom.addTab(self.bake_panel,'Bake / Export');self.bottom.addTab(self.jobs,'Jobs');self.bottom.addTab(self.console,'Console');self.bottom.addTab(self.scene_studio.bottom_panel,'3D Assets / Animation')
        self._docks={}
        self._dock('fiber.library','Fiber Library',self.fiber_workspace.library_panel,QtCore.Qt.DockWidgetArea.LeftDockWidgetArea)
        self._dock('fiber.inspector','Fiber Inspector',self.fiber_workspace.inspector_panel,QtCore.Qt.DockWidgetArea.RightDockWidgetArea)
        self._dock('scene.outliner','Scene Outliner',self.scene_studio.library_panel,QtCore.Qt.DockWidgetArea.LeftDockWidgetArea)
        self._dock('scene.inspector','Context Inspector',self.scene_studio.inspector_panel,QtCore.Qt.DockWidgetArea.RightDockWidgetArea)
        self._dock('context.bottom','Context / Jobs / Assets',self.bottom,QtCore.Qt.DockWidgetArea.BottomDockWidgetArea)
        self.fiber_workspace.inspectorToggle.connect(lambda:self._toggle_dock('fiber.inspector'))
        self.scene_studio.inspectorToggle.connect(lambda:self._toggle_dock('scene.inspector'))
        self.action_registry=ActionRegistry(self);self._register_actions();self._header();self._menus();self._status_bar()
        self.action_registry.actionResult.connect(self._action_result)
        self.controller.jobStarted.connect(self._job_started);self.controller.jobCompleted.connect(self._job_completed);self.controller.jobFailed.connect(self._on_background_error)
        self.controller.projectModified.connect(self._update_window_title);self.controller.projectLoaded.connect(self._project_loaded);self.controller.projectSaved.connect(self._on_project_saved)
        self.controller.cardSelected.connect(lambda *a:self.action_registry.refresh())
        for viewport in (self.fiber_studio.viewport,self.construction_studio.viewport,self.scene_studio.viewport):
            viewport.interactionStarted.connect(lambda mode,pos,v=viewport:self.controller.set_interacting(v,True));viewport.interactionFinished.connect(lambda mode,cancelled,v=viewport:self.controller.set_interacting(v,False))
        self.scene_studio.scene_service.message.connect(lambda text:self.console.appendPlainText(text))
        from .input_router import WorkspaceInputRouter
        self._input_router=WorkspaceInputRouter(self)
        from .style_registry import UIStyleRegistry
        self.ui_registry=UIStyleRegistry(self)
        from .style_manager import LiveDevModeFilter
        self.dev_filter=LiveDevModeFilter(self);QtWidgets.QApplication.instance().installEventFilter(self.dev_filter)
        self._switch_workspace('fiber');self._update_window_title(self.controller.is_dirty)
        self._load_layouts();self._audit_controls()
        self.ui_registry.inventoryChanged.connect(self._audit_controls)
    @property
    def project(self):return self.controller.project
    def _dock(self,key,title,widget,area):
        dock=QtWidgets.QDockWidget(title,self);dock.setObjectName(key);dock.setWidget(widget);dock.setAllowedAreas(QtCore.Qt.DockWidgetArea.AllDockWidgetAreas);widget.setMinimumWidth(180 if area!=QtCore.Qt.DockWidgetArea.BottomDockWidgetArea else 0)
        self.addDockWidget(area,dock);self._docks[key]=dock
    def _toggle_dock(self,key):self._docks[key].setVisible(not self._docks[key].isVisible())
    def _header(self):
        toolbar=QtWidgets.QToolBar('Studio Navigation',self);toolbar.setObjectName('studio.navigation');toolbar.setMovable(False);self.addToolBar(toolbar)
        logo=QtWidgets.QLabel();path=branding_asset('logo')
        if path.exists():logo.setPixmap(QtGui.QPixmap(str(path)).scaled(25,25,QtCore.Qt.AspectRatioMode.KeepAspectRatio,QtCore.Qt.TransformationMode.SmoothTransformation))
        toolbar.addWidget(logo);toolbar.addWidget(QtWidgets.QLabel('  FIBER STRAND DESIGNER  '))
        self.btn_fiber=QtWidgets.QPushButton('Fiber Studio');self.btn_cards=QtWidgets.QPushButton('3D Studio')
        for button,key in ((self.btn_fiber,'workspace.fiber'),(self.btn_cards,'workspace.scene')):button.clicked.connect(lambda checked=False,k=key:self.action_registry.trigger(k));toolbar.addWidget(button)
        toolbar.addSeparator()
        for key in ('edit.undo','edit.redo','view.frame_selected','view.fit_view','window.bottom'):toolbar.addAction(self.action_registry.create_qaction(key,self))
    def _status_bar(self):
        bar=self.statusBar();self.lbl_ready=QtWidgets.QLabel('Ready');self.lbl_status=self.lbl_ready;self.lbl_ws_info=QtWidgets.QLabel();self.lbl_stats=QtWidgets.QLabel();bar.addWidget(self.lbl_ready,1);bar.addPermanentWidget(self.lbl_ws_info);bar.addPermanentWidget(self.lbl_stats)
    def _register(self,key,label,handler,context='global',shortcut=None,description=''):
        self.action_registry.register(ActionDef(key,label,'Studio',description or label,shortcut=shortcut,context=context),handler)
    def _register_actions(self):
        r=self.action_registry;r.context_provider=lambda context:(self.workspace_stack.currentIndex()==0 and self.fiber_workspace.views.currentIndex()==1 if context=='graph' else self.workspace_stack.currentIndex()==0 if context=='fiber' else self.workspace_stack.currentIndex()==1 if context in ('scene','cards','render') else True)
        entries=[('file.new','New Project',self._action_new,'global','Ctrl+N'),('file.sample_300','Open 300 Advanced Samples',self._open_advanced_samples,'global',None),('file.open','Open Project…',self._action_open,'global','Ctrl+O'),('file.save','Save',self._action_save,'global','Ctrl+S'),('file.save_as','Save As…',self._action_save_as,'global','Ctrl+Shift+S'),('file.export_obj','Export Scene / Atlas…',self._action_export_obj,'global','Ctrl+E'),('file.exit','Exit',self.close,'global','Alt+F4'),('workspace.fiber','Fiber Studio',lambda:self._switch_workspace('fiber'),'global','F1'),('workspace.scene','3D Studio',lambda:self._switch_workspace('scene'),'global','F2'),('edit.undo','Undo',self._action_undo,'global','Ctrl+Z'),('edit.redo','Redo',self._action_redo,'global','Ctrl+Y'),('edit.duplicate','Duplicate',self._action_duplicate,'global','Ctrl+D'),('edit.delete','Delete',self._action_delete,'global','Del'),('view.frame_selected','Frame Selected',self._frame_selected,'global','F'),('view.fit_view','Frame / Fit All',self._fit_view,'global',None),('scene.import','Import OBJ / FBX…',self.scene_studio.import_model,'scene',None),('scene.add','Create Card',self.scene_studio._add_card,'scene',None),('scene.guide','Draw Guide',self.scene_studio._draw_guide_card,'scene',None),('scene.group','Group Selected Cards',self.scene_studio.create_group,'scene',None),('scene.capture','Capture PNG',self.scene_studio.capture,'scene',None),('scene.scatter','Scatter on Surface',self.scene_studio.scatter,'scene',None),('fiber.tile','Tile View',lambda:self.fiber_workspace.views.setCurrentIndex(0),'fiber',None),('fiber.graph','Graph View',lambda:self.fiber_workspace.views.setCurrentIndex(1),'fiber',None),('fiber.atlas','Atlas View',lambda:self.fiber_workspace.views.setCurrentIndex(2),'fiber',None),('fiber.add','Add Tile',self.fiber_studio._new_tile,'fiber',None),('fiber.bake','Bake Selected Tile',lambda:self.show_bake('selected'),'fiber',None),('fiber.bake_all','Bake Atlas',lambda:self.show_bake('all'),'fiber',None),('fiber.export','Export Maps…',self.bake_panel.export_maps,'fiber',None),('window.bottom','Context Panel',lambda:self._toggle_dock('context.bottom'),'global',None),('layout.save','Save Workspace Layout',self.save_layouts,'global',None),('layout.reset','Reset Workspace Layout',self.reset_layout,'global',None),('develop.toggle','Develop Picking',self._toggle_dev_mode,'global','F11'),('develop.studio','Develop Studio…',self._open_developer_style_manager,'global','F12')]
        for key,label,call,context,shortcut in entries:self._register(key,label,call,context,shortcut)
        self.fiber_workspace.views.currentChanged.connect(lambda:self.action_registry.refresh())
        for key,tool in [('scene.select','Select'),('scene.move','Move'),('scene.rotate','Rotate'),('scene.scale','Scale'),('scene.brush','Brush')]:self._register(key,tool,lambda t=tool:self.scene_studio._card_choose_tool(t),'scene')
    def _menus(self):
        bar=self.menuBar()
        sections={'File':['file.new','file.open','file.sample_300','file.save','file.save_as','file.export_obj','file.exit'],'Edit':['edit.undo','edit.redo','edit.duplicate','edit.delete'],'Fiber':['fiber.tile','fiber.graph','fiber.atlas','fiber.add','fiber.bake','fiber.bake_all','fiber.export'],'3D':['scene.import','scene.add','scene.guide','scene.group','scene.scatter','scene.select','scene.move','scene.rotate','scene.scale','scene.brush','scene.capture'],'View':['view.frame_selected','view.fit_view','window.bottom'],'Layout':['layout.save','layout.reset'],'Develop':['develop.toggle','develop.studio']}
        for title,keys in sections.items():
            menu=bar.addMenu(title)
            for key in keys:menu.addAction(self.action_registry.create_qaction(key,self))
        panels=bar.addMenu('Panels')
        for dock in self._docks.values():panels.addAction(dock.toggleViewAction())
        self.action_dev_mode=self.action_registry._qactions['develop.toggle'];self.action_dev_mode.setCheckable(True)
    def _switch_workspace(self,name):
        target='fiber' if name in ('fiber','graph','atlas') else 'scene'
        if self._active_studio==target:
            if name in ('graph','atlas'):self.fiber_workspace.views.setCurrentIndex(1 if name=='graph' else 2)
            return
        if self._active_studio is not None:self._studio_states[self._active_studio]=bytes(self.saveState().toBase64()).decode()
        self._active_studio=target;self.workspace_stack.setCurrentIndex(0 if target=='fiber' else 1)
        for key,dock in self._docks.items():dock.setVisible(key.startswith(target+'.'))
        self.btn_fiber.setProperty('class','workspace_pill_active' if target=='fiber' else 'workspace_pill');self.btn_cards.setProperty('class','workspace_pill_active' if target=='scene' else 'workspace_pill')
        state=self._studio_states.get(target)
        if state:self.restoreState(QtCore.QByteArray.fromBase64(state.encode()))
        else:self.resizeDocks([self._docks[target+('.library' if target=='fiber' else '.outliner')],self._docks[target+'.inspector']],[260,300],QtCore.Qt.Orientation.Horizontal)
        self.lbl_ws_info.setText('Fiber Studio' if target=='fiber' else '3D Studio');self.lbl_stats.setText(f'{len(self.project.tiles)} tiles · {len(self.project.cards)} cards');self.action_registry.refresh()
        if name in ('graph','atlas'):self.fiber_workspace.views.setCurrentIndex(1 if name=='graph' else 2)
    def _action_duplicate(self):
        if self.workspace_stack.currentIndex()==0:self.fiber_studio._dup_tile()
        else:self.scene_studio._duplicate_card()
    def _action_delete(self):
        if self.workspace_stack.currentIndex()==0:
            if self.fiber_workspace.views.currentIndex()==1:self.fiber_workspace.canvas.delete_selection()
            else:self.fiber_studio._del_tile()
        else:self.scene_studio.delete_context()
    def _frame_selected(self):self.fiber_workspace.fit() if self.workspace_stack.currentIndex()==0 else self.scene_studio.frame_context()
    def _fit_view(self):self.fiber_workspace.fit() if self.workspace_stack.currentIndex()==0 else self.scene_studio.frame_all()
    def _action_undo(self):
        if self.workspace_stack.currentIndex()==0 and self.fiber_workspace.views.currentIndex()==1:self.construction_studio._undo_graph()
        else:self.controller.undo()
    def _action_redo(self):
        if self.workspace_stack.currentIndex()==0 and self.fiber_workspace.views.currentIndex()==1:self.construction_studio._redo_graph()
        else:self.controller.redo()
    def show_bake(self,mode):self._docks['context.bottom'].show();self.bottom.setCurrentWidget(self.bake_panel);self.bake_panel.bake(mode)
    def _job_started(self,name):
        item=self._job_items.get(name)
        if item is None:item=QtWidgets.QListWidgetItem();self.jobs.addItem(item);self._job_items[name]=item
        item.setText('Running · '+name);self.lbl_ready.setText(name)
    def _job_completed(self,name):
        if name in self._job_items:self._job_items[name].setText('Complete · '+name)
        self.lbl_ready.setText('Ready')
    def _on_background_error(self,name,error):
        if hasattr(self,'console'):self.console.appendPlainText(name+': '+error)
        if hasattr(self,'lbl_ready'):self.lbl_ready.setText('Error · '+name+' (Console)')
    def _action_result(self,key,success,message):
        if not success:self._on_background_error(key,message);self._docks['context.bottom'].show();self.bottom.setCurrentWidget(self.console)
    def _project_loaded(self):self._update_window_title(self.controller.is_dirty);self.action_registry.refresh();self.ui_registry.refresh()
    def _audit_controls(self):
        # Existing component controls enter the registry only when a real slot exists.
        from PySide6.QtCore import SIGNAL
        import weakref
        from shiboken6 import isValid
        for widget in self.findChildren(QtWidgets.QAbstractButton):
            if widget.window() is not self or widget.objectName().startswith('qt_') or widget.property('action_id'):continue
            if isinstance(widget,(QtWidgets.QCheckBox,QtWidgets.QRadioButton)):continue
            if widget.receivers(SIGNAL('clicked(bool)')):
                key='control.'+str(widget.property('fsdId') or widget.objectName() or id(widget));widget.setProperty('action_id',key);ref=weakref.ref(widget)
                def invoke(ref=ref):
                    control=ref()
                    if control is None or not isValid(control):raise RuntimeError('Control is no longer in the active inspector')
                    control.click()
                self._register(key,widget.text(),invoke)
            elif not widget.isCheckable():widget.hide();widget.setToolTip('Hidden: no implemented action')
    def save_layouts(self):
        self._studio_states[self._active_studio]=bytes(self.saveState().toBase64()).decode();data={'version':1,'studios':self._studio_states};temporary=LAYOUT_PATH.with_suffix('.tmp');temporary.write_text(json.dumps(data,indent=2),encoding='utf-8');temporary.replace(LAYOUT_PATH)
    def _load_layouts(self):
        if not LAYOUT_PATH.exists():return
        try:
            data=json.loads(LAYOUT_PATH.read_text(encoding='utf-8'));self._studio_states=data.get('studios',{});state=self._studio_states.get(self._active_studio)
            if state:self.restoreState(QtCore.QByteArray.fromBase64(state.encode()))
        except (OSError,ValueError) as error:self._on_background_error('Layout',str(error))
    def reset_layout(self):
        self._studio_states.clear()
        for key,dock in self._docks.items():dock.setFloating(False);self.addDockWidget(QtCore.Qt.DockWidgetArea.BottomDockWidgetArea if key=='context.bottom' else QtCore.Qt.DockWidgetArea.LeftDockWidgetArea if key.endswith(('library','outliner')) else QtCore.Qt.DockWidgetArea.RightDockWidgetArea,dock)
        active=self._active_studio;self._active_studio=None;self._switch_workspace(active)
    def closeEvent(self,event):
        if not self._confirm_ui_design() or not self._check_unsaved_changes():event.ignore();return
        self.fiber_workspace.close_fiber();self.scene_studio.close_scene();self.controller.shutdown();event.accept()

    def _open_advanced_samples(self):
        if not self._check_unsaved_changes():return
        path=Path(__file__).resolve().parents[2]/'projects/FSD_300_Advanced_Unique.fsd'
        if not path.exists():raise FileNotFoundError(path)
        self.controller.open_project_async(path,lambda project:self._switch_workspace('scene'))

FSDMainWindow=TwoStudioMainWindow

