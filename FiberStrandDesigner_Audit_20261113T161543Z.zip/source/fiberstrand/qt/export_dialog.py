"""Interactive export dialog for UDIM and Texture Set atlas generation."""
from __future__ import annotations
from pathlib import Path
from PySide6 import QtCore, QtGui, QtWidgets
from .theme import TOKENS


class QtAtlasExportDialog(QtWidgets.QDialog):
    """Dialog for configuring and executing multi-UDIM / Texture Set export."""

    def __init__(self, controller, parent: QtWidgets.QWidget | None = None):
        super().__init__(parent)
        self.controller = controller
        self.setWindowTitle("Export Hair Cards & Atlas (UDIM / Texture Sets)")
        self.resize(520, 480)
        self.setStyleSheet(f"""
            QDialog {{
                background-color: {TOKENS['bg_dark']};
                color: {TOKENS['text']};
            }}
            QGroupBox {{
                font-weight: bold;
                border: 1px solid {TOKENS['border']};
                border-radius: 6px;
                margin-top: 12px;
                padding-top: 14px;
                background-color: {TOKENS['bg_panel']};
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 4px;
                color: {TOKENS['cyan']};
            }}
            QRadioButton, QCheckBox {{
                color: {TOKENS['text']};
                spacing: 6px;
            }}
            QLineEdit {{
                background-color: {TOKENS['bg_control']};
                color: {TOKENS['text']};
                border: 1px solid {TOKENS['border']};
                border-radius: 4px;
                padding: 5px 8px;
            }}
            QPushButton {{
                background-color: {TOKENS['bg_control']};
                color: {TOKENS['text']};
                border: 1px solid {TOKENS['border']};
                border-radius: 4px;
                padding: 6px 14px;
                font-weight: 500;
            }}
            QPushButton:hover {{
                background-color: {TOKENS['bg_hover']};
                border-color: {TOKENS['cyan']};
            }}
            QPushButton#btn_primary {{
                background-color: {TOKENS['gold']};
                color: #050E17;
                font-weight: bold;
                border: none;
            }}
            QPushButton#btn_primary:hover {{
                background-color: {TOKENS['gold_hover']};
            }}
        """)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setSpacing(12)

        # 1. Output Directory Group
        grp_dir = QtWidgets.QGroupBox("Destination Folder", self)
        dir_layout = QtWidgets.QHBoxLayout(grp_dir)
        default_dir = str(Path.cwd() / "exported_atlas")
        self.edit_dir = QtWidgets.QLineEdit(default_dir, grp_dir)
        btn_browse = QtWidgets.QPushButton("Browse...", grp_dir)
        btn_browse.clicked.connect(self._browse_dir)
        dir_layout.addWidget(self.edit_dir, 1)
        dir_layout.addWidget(btn_browse)
        layout.addWidget(grp_dir)

        # 2. Export Mode Group
        grp_mode = QtWidgets.QGroupBox("Export Architecture / Format", self)
        mode_layout = QtWidgets.QVBoxLayout(grp_mode)

        self.radio_udim = QtWidgets.QRadioButton("UDIM Format (Standard continuous UVs, <channel>.<UDIM>.png)", grp_mode)
        self.radio_udim.setToolTip("Export single OBJ with continuous UDIM coordinates [0..N, 0..M] and UDIM texture maps. Ideal for Maya, Arnold, Houdini, Blender, and Unreal Engine UDIM virtual textures.")
        self.radio_udim.setChecked(True)

        self.radio_texture_set = QtWidgets.QRadioButton("Separate Texture Sets (Distinct TextureSet_<UDIM>/ folders, [0..1] UVs)", grp_mode)
        self.radio_texture_set.setToolTip("Export separate texture sets per UDIM into distinct subdirectories, with per-UDIM materials and normalized [0..1] UVs. Ideal for game engines and multi-material workflows.")

        self.radio_legacy = QtWidgets.QRadioButton("Legacy Multi-Page Format (FSD_Atlas_{page:02d}_{channel}.png)", grp_mode)
        self.radio_legacy.setToolTip("Legacy compatibility export mode.")

        mode_layout.addWidget(self.radio_udim)
        mode_layout.addWidget(self.radio_texture_set)
        mode_layout.addWidget(self.radio_legacy)
        layout.addWidget(grp_mode)

        # 3. Channels to Export Group
        grp_channels = QtWidgets.QGroupBox("Texture Channels", self)
        ch_grid = QtWidgets.QGridLayout(grp_channels)
        self.channel_boxes = {}
        available_channels = [
            ("color", "Color (Diffuse)", True),
            ("alpha", "Alpha (Opacity)", True),
            ("normal", "Normal (Tangent)", True),
            ("flow", "Flow (Direction)", True),
            ("roughness", "Roughness", True),
            ("ao", "Ambient Occlusion", True),
            ("depth", "Depth", False),
            ("id", "Strand ID Table", False),
            ("cluster_id", "Cluster ID", False),
            ("material_id", "Material ID", False),
            ("material_mask", "Material RGB Mask", False),
            ("rgb_mask", "Root / Mid / Tip Mask", False),
            ("specular", "Specular", False),
            ("anisotropy", "Anisotropy", False),
            ("transmission", "Transmission", False),
            ("scatter", "Scatter", False),
            ("iridescence", "Iridescence", False),
        ]
        for idx, (ch_key, ch_name, default_checked) in enumerate(available_channels):
            cb = QtWidgets.QCheckBox(ch_name, grp_channels)
            cb.setChecked(default_checked)
            self.channel_boxes[ch_key] = cb
            ch_grid.addWidget(cb, idx // 2, idx % 2)
        layout.addWidget(grp_channels)

        # 4. UDIM Capacity Summary Card
        grp_summary = QtWidgets.QGroupBox("Atlas UDIM Summary", self)
        sum_layout = QtWidgets.QVBoxLayout(grp_summary)
        active_udims = self.controller.get_active_udims()
        cards_count = len(self.controller.project.cards)
        placements = self.controller.atlas.layout.placements

        udim_tile_counts = {}
        for u in active_udims:
            tiles_in_u = [tid for tid, p in placements.items() if getattr(p, "udim", 1001 + p.page) == u]
            udim_tile_counts[u] = len(tiles_in_u)

        summary_lines = [
            f"• Active UDIMs ({len(active_udims)}): " + ", ".join(f"UDIM {u} ({udim_tile_counts.get(u,0)} tiles)" for u in active_udims),
            f"• Atlas Resolution: {self.controller.atlas.layout.size}×{self.controller.atlas.layout.size} px per UDIM",
            f"• Hair Cards in Project: {cards_count} visible card meshes",
        ]
        lbl_sum = QtWidgets.QLabel("\n".join(summary_lines), grp_summary)
        lbl_sum.setStyleSheet(f"color: {TOKENS['cyan']}; font-size: 11px;")
        sum_layout.addWidget(lbl_sum)
        layout.addWidget(grp_summary)

        # 5. Buttons (Export & Cancel)
        btn_layout = QtWidgets.QHBoxLayout()
        btn_layout.addStretch(1)

        self.btn_cancel = QtWidgets.QPushButton("Cancel", self)
        self.btn_cancel.clicked.connect(self.reject)
        btn_layout.addWidget(self.btn_cancel)

        self.btn_export = QtWidgets.QPushButton("Export Now", self)
        self.btn_export.setObjectName("btn_primary")
        self.btn_export.clicked.connect(self.accept)
        btn_layout.addWidget(self.btn_export)

        layout.addLayout(btn_layout)

    def _browse_dir(self):
        f = QtWidgets.QFileDialog.getExistingDirectory(self, "Select Export Directory", self.edit_dir.text())
        if f:
            self.edit_dir.setText(f)

    def get_export_config(self) -> dict:
        """Return configured options for export worker."""
        if self.radio_texture_set.isChecked():
            mode = "texture_set"
        elif self.radio_legacy.isChecked():
            mode = "legacy"
        else:
            mode = "udim"

        selected_channels = [k for k, cb in self.channel_boxes.items() if cb.isChecked()]
        if not selected_channels:
            selected_channels = ["color", "alpha", "normal"]

        return {
            "folder": Path(self.edit_dir.text().strip() or "exported_atlas"),
            "mode": mode,
            "channels": tuple(selected_channels),
        }
