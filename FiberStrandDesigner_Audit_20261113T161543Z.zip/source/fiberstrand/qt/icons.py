"""Local Lucide presentation assets. Never changes text, slots or command state."""
from functools import lru_cache
from pathlib import Path
from PySide6 import QtCore, QtGui, QtWidgets

ICON_ROOT = Path(__file__).resolve().parents[2] / 'assets/icons/lucide'
# Exact captions keep model/tool values and all existing command wiring intact.
CAPTIONS = {
    'Fiber Studio':'feather', '3D Studio':'box', 'New Project':'file-plus-2',
    'Open Project':'folder-open', 'Save':'save', 'Save As':'save',
    'Undo':'undo-2', 'Redo':'redo-2', 'Duplicate':'copy', 'Delete':'trash-2',
    'New':'plus', 'Add':'plus', 'Add Tile':'plus', 'Create Card':'plus',
    'Add Node':'plus', 'Delete Node':'trash-2', 'Rename':'pencil',
    'Group':'layers', 'Group Selected Cards':'layers', 'Presets':'sliders-horizontal',
    'Select':'mouse-pointer-2', 'Move':'move', 'Rotate':'rotate-3d',
    'Scale':'scaling', 'Brush':'brush', 'Groom':'brush', 'Shape':'spline',
    'Mesh':'box', 'Draw Guide':'spline', 'Frame Selected':'focus',
    'Frame All':'maximize', 'Frame / Fit All':'maximize', 'Fit Â· F':'maximize',
    'Import OBJ / FBX':'folder-open', 'Capture PNG':'camera',
    'Import Graph':'upload', 'Export Graph':'download',
    'Export Maps':'download', 'Export Scene / Atlas':'download',
    'Context Panel':'panel-bottom', 'Play / Pause':'play',
    'Bake Selected Tile':'sparkles', 'Bake Atlas':'sparkles',
    'Save Workspace Layout':'save', 'Reset Workspace Layout':'settings-2',
    'Develop Studio':'sliders-horizontal', 'Exit':'log-out',
    'Bind to joint':'link', 'Assign tile to selection':'link',
    'Apply source payload':'check', 'Use as Graph Output':'check',
    'Use Graph for Tile':'check', 'From Current Tile':'copy',
    'Scatter on Surface':'layers',
}

@lru_cache(maxsize=256)
def lucide_icon(name, foreground, accent, muted):
    path = ICON_ROOT / (name + '.svg')
    if not path.is_file():
        return QtGui.QIcon()
    svg = path.read_text(encoding='utf-8')
    icon = QtGui.QIcon()
    for mode, color in ((QtGui.QIcon.Mode.Normal, foreground),
                        (QtGui.QIcon.Mode.Active, accent),
                        (QtGui.QIcon.Mode.Selected, accent),
                        (QtGui.QIcon.Mode.Disabled, muted)):
        # 3x source raster retains crisp strokes on high-density displays.
        data = svg.replace('currentColor', color).replace('width="24"', 'width="72"').replace('height="24"', 'height="72"')
        pixmap = QtGui.QPixmap()
        if pixmap.loadFromData(data.encode('utf-8'), 'SVG'):
            icon.addPixmap(pixmap, mode, QtGui.QIcon.State.Off)
            icon.addPixmap(pixmap, mode, QtGui.QIcon.State.On)
    return icon

def decorate_controls(window, colors):
    for toolbar in window.findChildren(QtWidgets.QToolBar):
        toolbar.setIconSize(QtCore.QSize(16,16))
    for control in window.findChildren(QtWidgets.QAbstractButton) + window.findChildren(QtGui.QAction):
        if isinstance(control, (QtWidgets.QCheckBox, QtWidgets.QRadioButton)):
            continue
        caption = control.text().replace('&', '').strip().rstrip('.â€¦')
        name = CAPTIONS.get(caption)
        if not name:
            continue
        style = control.property('fsdStyle') or {}
        icon = lucide_icon(name, style.get('foreground', colors['text']), colors['cyan'], colors['text_muted'])
        if not icon.isNull():
            control.setIcon(icon)
            if isinstance(control, QtWidgets.QAbstractButton):
                control.setIconSize(QtCore.QSize(15, 15))
