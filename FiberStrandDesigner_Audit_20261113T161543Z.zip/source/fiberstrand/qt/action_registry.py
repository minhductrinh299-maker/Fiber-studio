"""Unified Action Registry for Fiber Strand Designer (Qt 6).

Centralizes every user-executable action, keyboard shortcut, tooltip, menu path,
and category across the application:
- P1: Comprehensive tool accessibility mapping
- P2: Information Architecture & contextual availability
- P3: Standardized action triggers, keyboard shortcuts, and UX feedback
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Any
from PySide6 import QtCore, QtGui, QtWidgets


@dataclass
class ActionDef:
    id: str
    title: str
    category: str              # "File", "Edit", "Card", "Fiber", "Graph", "Render", "View", "Window"
    description: str
    shortcut: str | None = None
    icon: str | None = None
    undo_policy: str = "handler transaction"
    context: str = "global"     # "global", "cards", "fiber", "graph", "render"


class ActionRegistry(QtCore.QObject):
    """Central registry of all DCC commands and user actions."""

    actionResult = QtCore.Signal(str,bool,str)
    actionTriggered = QtCore.Signal(str) # action_id

    def __init__(self, parent: QtCore.QObject | None = None):
        super().__init__(parent)
        self._actions: dict[str, ActionDef] = {}
        self._handlers: dict[str, Callable[[], Any]] = {}
        self._qactions: dict[str, QtGui.QAction] = {}
        self._register_default_actions()

    def register(self, action_def: ActionDef, handler: Callable[[], Any] | None = None) -> None:
        self._actions[action_def.id] = action_def
        if handler:
            self._handlers[action_def.id] = handler

    def bind_handler(self,action_id,handler):
        if action_id not in self._actions:raise KeyError(action_id)
        self._handlers[action_id]=handler;self.refresh()

    def available(self,action_id):
        definition=self._actions.get(action_id)
        if definition is None or action_id not in self._handlers:return False
        provider=getattr(self,'context_provider',None)
        if provider and definition.context!='global' and not provider(definition.context):return False
        predicate=getattr(self,'predicates',{}).get(action_id)
        return bool(predicate()) if predicate else True

    def refresh(self):
        for key,action in self._qactions.items():action.setEnabled(self.available(key))

    def trigger(self,action_id):
        if not self.available(action_id):return False
        try:
            result=self._handlers[action_id]();self.actionTriggered.emit(action_id)
            self.actionResult.emit(action_id,True,str(result) if result is not None else '')
            return True
        except Exception as error:
            self.actionResult.emit(action_id,False,str(error));return False

    def create_qaction(self,action_id,parent):
        if action_id in self._qactions:return self._qactions[action_id]
        definition=self._actions.get(action_id)
        if definition is None:return None
        action=QtGui.QAction(definition.title,parent)
        if definition.shortcut:action.setShortcut(QtGui.QKeySequence(definition.shortcut))
        action.setToolTip(definition.description);action.setStatusTip(definition.description)
        action.triggered.connect(lambda checked=False,key=action_id:self.trigger(key))
        self._qactions[action_id]=action;action.setEnabled(self.available(action_id));return action

    def get_action_def(self, action_id: str) -> ActionDef | None:
        return self._actions.get(action_id)

    def all_actions(self) -> list[ActionDef]:
        return list(self._actions.values())

    def actions_by_category(self, category: str) -> list[ActionDef]:
        return [a for a in self._actions.values() if a.category == category]

    def _register_default_actions(self):
        # 1. File Actions
        self.register(ActionDef("file.new", "New Project", "File", "Create a fresh starter grooming project", "Ctrl+N", "✦"))
        self.register(ActionDef("file.open", "Open Project...", "File", "Open an existing .fsd project file", "Ctrl+O", "📂"))
        self.register(ActionDef("file.sample_300", "Open Sample (300 Diverse Clusters)...", "File", "Load 300 diverse hair/fur/feather clusters in a 20x15 grid layout", None, "🌟"))
        self.register(ActionDef("file.save", "Save Project", "File", "Save changes to current .fsd project file", "Ctrl+S", "💾"))
        self.register(ActionDef("file.save_as", "Save Project As...", "File", "Save project to a new file location", "Ctrl+Shift+S", "💾"))
        self.register(ActionDef("file.export_obj", "Export OBJ & Atlas...", "File", "Export card mesh geometry (.obj), material (.mtl) and baked texture maps", "Ctrl+E", "📦"))
        self.register(ActionDef("file.exit", "Exit", "File", "Exit Fiber Strand Designer", "Alt+F4", "❌"))

        # 2. Edit Actions
        self.register(ActionDef("edit.undo", "Undo", "Edit", "Revert last editing operation", "Ctrl+Z", "⎌"))
        self.register(ActionDef("edit.redo", "Redo", "Edit", "Restore previously undone operation", "Ctrl+Y", "↷"))
        self.register(ActionDef("edit.duplicate", "Duplicate Selection", "Edit", "Duplicate selected card(s) or tile", "Ctrl+D", "⧉"))
        self.register(ActionDef("edit.delete", "Delete Selection", "Edit", "Delete selected card(s), tile, or graph node", "Del", "🗑"))
        self.register(ActionDef("edit.select_all", "Select All", "Edit", "Select all cards in current scene", "Ctrl+A", "✓"))

        # 3. View Actions
        self.register(ActionDef("view.frame_selected", "Frame Selected", "View", "Focus and frame selected cards or view center", "F", "⊡"))
        self.register(ActionDef("view.fit_view", "Fit View", "View", "Fit complete scene bounds into active viewport", "A", "⛶"))
        self.register(ActionDef("view.toggle_wireframe", "Toggle Wireframe", "View", "Switch wireframe overlay on cards or tiles", "W", "▦"))
        self.register(ActionDef("view.toggle_grid", "Toggle Ground Grid", "View", "Show or hide 3D world ground grid", "G", "⊞"))
        self.register(ActionDef("view.toggle_cube", "Toggle Orientation Cube", "View", "Show or hide viewport 3D orientation cube", None, "🧊"))

        # 4. Workspaces Actions
        self.register(ActionDef("workspace.fiber", "Fiber Studio", "Window", "Switch to 2D Procedural Strand Generation Workspace", "F1", "🌿"))
        self.register(ActionDef("workspace.graph", "Construction Graph", "Window", "Switch to Node Operator Flow Workspace", "F2", "☁"))
        self.register(ActionDef("workspace.cards", "Card Editor 3D", "Window", "Switch to 3D Card Grooming & Placement Workspace", "F3", "🪶"))
        self.register(ActionDef("workspace.render", "GPU Render Studio", "Window", "Switch to High-Fidelity Lookdev & Capture Workspace", "F4", "✨"))

        # 5. Card Editor Specific Actions
        self.register(ActionDef("cards.add", "Add Hair Card", "Card", "Create and place a new hair card ribbon into scene", None, "+"))
        self.register(ActionDef("cards.draw_guide", "Draw Guide Curve", "Card", "Draw interactive curve points on viewport to spawn guide card", None, "✎"))
        self.register(ActionDef("cards.reset_overrides", "Reset Card Overrides", "Card", "Clear custom offsets, deformation layers and restore base geometry", None, "↺"))
        self.register(ActionDef("cards.make_unique", "Make Unique Tile", "Card", "Clone card's tile into a dedicated unique tile variant", None, "🔗"))
        self.register(ActionDef("cards.insert_row", "Insert Subdivision Row", "Card", "Increase card longitudinal mesh resolution (+1 row)", None, "⬆"))
        self.register(ActionDef("cards.remove_row", "Remove Subdivision Row", "Card", "Decrease card longitudinal mesh resolution (-1 row)", None, "⬇"))
        self.register(ActionDef("cards.assign_tile", "Assign Atlas Tile", "Card", "Assign selected tile from library to selected cards", None, "🔗"))

        # 6. Fiber Studio Specific Actions
        self.register(ActionDef("fiber.new_tile", "New Atlas Tile", "Fiber", "Create a new procedural fiber tile", None, "+"))
        self.register(ActionDef("fiber.duplicate_tile", "Duplicate Tile", "Fiber", "Duplicate current fiber tile with independent settings", None, "⧉"))
        self.register(ActionDef("fiber.delete_tile", "Delete Tile", "Fiber", "Remove current tile from library", None, "🗑"))
        self.register(ActionDef("fiber.bake_tile", "Bake Tile / Refresh", "Fiber", "Trigger asynchronous fiber generation and rasterization", "B", "▶"))

        # 7. Construction Graph Actions
        self.register(ActionDef("graph.add_node", "Add Graph Node", "Graph", "Add new procedural operator node to graph", None, "+"))
        self.register(ActionDef("graph.delete_node", "Delete Graph Node", "Graph", "Remove active operator node from construction graph", None, "🗑"))
        self.register(ActionDef("graph.load_preset", "Load Graph Preset", "Graph", "Load pre-configured node graph recipe", None, "📋"))
        self.register(ActionDef("graph.import_json", "Import Graph JSON", "Graph", "Load construction graph from external JSON file", None, "📥"))
        self.register(ActionDef("graph.export_json", "Export Graph JSON", "Graph", "Export active graph definition to JSON file", None, "📤"))
        self.register(ActionDef("graph.apply_tile", "Apply Graph to Tile", "Graph", "Evaluate graph and commit procedural curves to active tile", "Ctrl+Return", "⚡"))

        # 8. Render Studio Actions
        self.register(ActionDef("render.capture", "Capture Render Frame", "Render", "Capture clean high-res transparent PNG snapshot", "F10", "📷"))
        self.register(ActionDef("render.export_exr", "Export Linear EXR", "Render", "Export 32-bit linear floating point radiance EXR", None, "💾"))
