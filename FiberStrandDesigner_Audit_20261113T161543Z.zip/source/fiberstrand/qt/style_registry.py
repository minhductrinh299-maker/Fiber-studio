"""Semantic UI families, persistent design overrides and reversible live editing."""
from copy import deepcopy
from pathlib import Path
import json,re,os,weakref
from PySide6 import QtCore,QtGui,QtWidgets
from .theme import TOKENS,BRAND_TOKENS,QSS_TEMPLATE

SPEC_PATH=Path(__file__).resolve().parents[2]/'assets/branding/ui_design_spec.json'
FAMILY_LABELS={
 'button.action':'Nút thao tác', 'button.command':'Lệnh chính toàn workspace',
 'navigation.workspace':'Chuyển workspace','navigation.mode':'Chế độ công cụ',
 'button.icon':'Nút biểu tượng','group.disclosure':'Tiêu đề nhóm thu gọn',
 'field.input':'Ô nhập giá trị','field.select':'Danh sách chọn','field.toggle':'Checkbox / Radio',
 'value.slider':'Slider số','list.outliner':'Danh sách / Outliner',
 'label.body':'Nhãn thông số','label.heading':'Tiêu đề','label.muted':'Chú thích',
 'panel.surface':'Panel','panel.row':'Hàng / vùng trong suốt',
 'navigation.menu':'Menu','navigation.tabs':'Tab chức năng',
 'feedback.progress':'Thanh tiến trình','feedback.status':'Thanh trạng thái',
 'layout.scrollbar':'Thanh cuộn','layout.splitter':'Vạch chia panel'}
def default_spec():
    base=dict(height=30,radius=6,padding_x=10,padding_y=3,font_size=12,font_weight=400,
              background='$bg_control',foreground='$text',border='$border',hover='$bg_hover',active='$cyan')
    families={name:dict(base) for name in FAMILY_LABELS}
    for name in ('navigation.workspace','navigation.mode'):
        families[name].update(height=32,radius=7,font_weight=600)
    families['button.command'].update(background='$cyan',foreground='$bg_dark',border='transparent',hover='$teal',font_weight=600)
    families['button.icon'].update(height=28,padding_x=2,padding_y=2)
    families['group.disclosure'].update(height=27,background='transparent',border='transparent',font_weight=600)
    families['value.slider'].update(height=28,foreground='$text',active='$cyan',border='$border_subtle',font_size=11)
    for name in ('label.body','label.heading','label.muted','panel.row'):
        families[name].update(height=0,background='transparent',border='transparent',padding_x=0,padding_y=0)
    families['label.heading'].update(font_weight=600,font_size=12,foreground='$text')
    families['label.muted'].update(foreground='$text_muted',font_size=11)
    families['panel.surface'].update(height=0,background='$bg_panel',border='transparent',padding_x=0,padding_y=0)
    families['list.outliner'].update(height=0)
    families['field.toggle'].update(height=24,background='transparent',border='transparent')
    families['navigation.menu'].update(height=24,background='$bg_dark',padding_x=8,padding_y=2)
    families['navigation.tabs'].update(height=30)
    families['feedback.progress'].update(height=8,padding_x=0,padding_y=0,radius=3)
    families['feedback.status'].update(height=28,background='$bg_dark',foreground='$text_muted',padding_y=0)
    families['layout.scrollbar'].update(height=10,padding_x=0,padding_y=0,radius=4,background='$bg_dark')
    families['layout.splitter'].update(height=0,padding_x=0,padding_y=0,radius=0,background='$border',border='transparent')
    families['button.action'].update(font_size=11,padding_x=6)
    for name in ('button.action','button.icon','field.input','field.select'):
        families[name]['border']='$border_subtle'
    for name in ('navigation.workspace','navigation.mode','navigation.menu','navigation.tabs'):
        families[name].update(background='$bg_panel',border='transparent',font_weight=600)
    return dict(version=2,name='Quiet Graphite',colors=dict(BRAND_TOKENS),
                typography=dict(font_family='Segoe UI'),geometry=dict(radius_button=5),
                families=families,elements={},layouts={})

def validate_spec(data):
    if not isinstance(data,dict):raise ValueError('Design phải là JSON object')
    if data.get('version',1) not in (1,2):raise ValueError('Phiên bản design chưa được hỗ trợ')
    spec=default_spec()
    for key in ('name','colors','typography','geometry','families','elements','layouts'):
        if key in data:
            if isinstance(spec[key],dict):spec[key].update(deepcopy(data[key]))
            else:spec[key]=data[key]
    # Migrate the old palette/geometry, never its arbitrary QSS snippets.
    if data.get('version',1)<2:
        spec['elements']={};spec['layouts']={}
        spec['families']['button.action']['radius']=int(data.get('geometry',{}).get('radius_button',5))
    color_re=r'#[0-9a-fA-F]{3,8}|[a-zA-Z]+|rgba?\(.*\)|transparent'
    for key,value in spec['colors'].items():
        if key not in TOKENS or not isinstance(value,str):
            raise ValueError('Palette không hợp lệ: '+str(key))
    if not isinstance(spec['typography'].get('font_family'), str):
        spec['typography']['font_family'] = 'Segoe UI'
    fields=set(default_spec()['families']['button.action'])
    for family,patch in list(spec['families'].items()):
        if family not in FAMILY_LABELS or not isinstance(patch,dict):raise ValueError('Họ style không hợp lệ: '+str(family))
        merged={**default_spec()['families'][family],**patch};spec['families'][family]=merged
        if set(merged)-fields:raise ValueError('Thuộc tính style không được hỗ trợ')
        for key,value in merged.items():
            if key in ('background','foreground','border','hover','active'):
                if not isinstance(value,str) or not (value.startswith('$') or value in ('transparent', 'none') or QtGui.QColor(value).isValid() or re.fullmatch(color_re, value)):
                    raise ValueError('Màu style không hợp lệ: '+str(value))
            else:
                if not isinstance(value,(int,float)) or isinstance(value,bool):
                    raise ValueError('Giá trị style phải là số: '+key)
                val = int(value)
                if val < 0: val = 0
                merged[key] = val
    for ident,patch in spec['elements'].items():
        if not isinstance(ident,str) or not isinstance(patch,dict) or set(patch)-{'family','text','tooltip','min_width','hidden'}:raise ValueError('Element override không hợp lệ')
        if 'family' in patch and patch['family'] not in FAMILY_LABELS:raise ValueError('Họ element không tồn tại')
        for key in ('text','tooltip'):
            if key in patch and (not isinstance(patch[key],str) or len(patch[key])>500):raise ValueError('Nhãn element không hợp lệ')
        if 'min_width' in patch:
            if not isinstance(patch['min_width'],(int,float)) or isinstance(patch['min_width'],bool):raise ValueError('Chiều rộng không hợp lệ')
            patch['min_width'] = max(0, int(patch['min_width']))
        if 'hidden' in patch and not isinstance(patch['hidden'],bool):raise ValueError('hidden phải là boolean')
    for ident,patch in spec['layouts'].items():
        if not isinstance(patch,dict) or set(patch)-{'spacing','margins','order'}:raise ValueError('Layout override không hợp lệ')
        if 'spacing' in patch:
            if not isinstance(patch['spacing'],(int,float)) or isinstance(patch['spacing'],bool):raise ValueError('Spacing ngoài giới hạn')
            patch['spacing'] = max(0, int(patch['spacing']))
        if 'margins' in patch:
            if not isinstance(patch['margins'],list) or len(patch['margins'])!=4 or any(not isinstance(x,(int,float)) or isinstance(x,bool) for x in patch['margins']):raise ValueError('Margins không hợp lệ')
            patch['margins'] = [max(0, int(x)) for x in patch['margins']]
        if 'order' in patch and (not isinstance(patch['order'],list) or len(set(patch['order']))!=len(patch['order']) or any(not isinstance(x,str) for x in patch['order'])):raise ValueError('Thứ tự layout không hợp lệ')
    spec["geometry"]={"radius_button":spec["families"]["button.action"]["radius"]}
    spec["typography"]={"font_family":spec["typography"]["font_family"]}
    return spec

def load_style_spec(path=SPEC_PATH):
    if not Path(path).exists():return default_spec()
    return validate_spec(json.loads(Path(path).read_text(encoding='utf-8-sig')))
def save_style_spec(spec,path=SPEC_PATH):
    data=validate_spec(spec);path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix(path.suffix+'.tmp');temporary.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(temporary,path)

def resolved_style(spec,family):
    return {key:spec['colors'][value[1:]] if isinstance(value,str) and value.startswith('$') else value for key,value in spec['families'][family].items()}

def generate_qss_from_spec(spec):
    spec=validate_spec(spec);rules=[QSS_TEMPLATE.format(**spec['colors']),f'QWidget {{ font-family: "{spec["typography"]["font_family"]}"; }}']
    # Explicit class selectors also override the historical class="primary" rules.
    classes=('QPushButton','QToolButton','QLabel','QLineEdit','QComboBox','QSpinBox','QDoubleSpinBox','QListWidget','QTreeWidget','QCheckBox','QRadioButton','QMenuBar','QTabBar','QProgressBar','QStatusBar','QScrollBar','QSplitterHandle','QWidget')
    for family in FAMILY_LABELS:
        s=resolved_style(spec,family);selector=','.join(f'{cls}[fsdFamily="{family}"]' for cls in classes)
        geometry=''
        if s['height']>0 and family not in ('layout.scrollbar','navigation.menu'):
            inner=max(0,s['height']-2*s['padding_y']-2)
            geometry=f'min-height:{inner}px;max-height:{inner}px;'
        rules.append(f'{selector} {{ {geometry} background-color:{s["background"]}; color:{s["foreground"]}; border:1px solid {s["border"]}; border-radius:{s["radius"]}px; padding:{s["padding_y"]}px {s["padding_x"]}px; font-size:{s["font_size"]}px; font-weight:{s["font_weight"]}; }}')
        if family.startswith(('button.','navigation.','field.','group.')):
            for state,bg,fg in [('hover',s['hover'],s['foreground']),('pressed',s['active'],spec['colors']['bg_dark']),('checked',s['background'],s['active'])]:
                selectors=','.join(f'{cls}[fsdFamily="{family}"]:{state}' for cls in classes if cls in ('QPushButton','QToolButton','QCheckBox','QRadioButton'))
                rules.append(f'{selectors} {{background-color:{bg};color:{fg};border-color:{s["active"]};}}')
            if family in ('field.input','field.select'):
                focus=','.join(f'{cls}[fsdFamily="{family}"]:focus' for cls in ('QLineEdit','QComboBox','QSpinBox','QDoubleSpinBox'))
                rules.append(f'{focus} {{border-color:{s["active"]};}}')
            active=','.join(f'{cls}[fsdFamily="{family}"][fsdActive="true"]' for cls in ('QPushButton','QToolButton'))
            rules.append(f'{active} {{color:{s["active"]};border-color:{s["active"]};background-color:{s["background"]};}}')
            disabled=','.join(f'{cls}[fsdFamily="{family}"]:disabled' for cls in classes)
            rules.append(f'{disabled} {{color:{spec["colors"]["text_muted"]};background-color:{spec["colors"]["bg_dark"]};border-color:{spec["colors"]["border"]};}}')
    menu=resolved_style(spec,'navigation.menu');tabs=resolved_style(spec,'navigation.tabs');bar=resolved_style(spec,'layout.scrollbar');progress=resolved_style(spec,'feedback.progress')
    rules.append(f"QMenuBar {{background:{menu['background']};color:{menu['foreground']};border:none;border-bottom:1px solid {menu['border']};font-size:{menu['font_size']}px;}} QMenu {{background:{menu['background']};color:{menu['foreground']};border:1px solid {menu['border']};border-radius:{menu['radius']}px;padding:4px;font-size:{menu['font_size']}px;}} QMenu::item,QMenuBar::item {{padding:{menu['padding_y']}px {menu['padding_x']}px;color:{menu['foreground']};background:transparent;border-radius:{menu['radius']}px;}} QMenu::item:selected,QMenuBar::item:selected {{background:{menu['hover']};color:{menu['active']};}} QMenu::separator {{height:1px;background:{menu['border']};margin:4px 6px;}}")
    rules.append(f"QTabBar::tab {{background:{tabs['background']};color:{tabs['foreground']};padding:{tabs['padding_y']}px {tabs['padding_x']}px;border:1px solid {tabs['border']};border-top-left-radius:{tabs['radius']}px;border-top-right-radius:{tabs['radius']}px;}} QTabBar::tab:selected {{color:{tabs['active']};background:{tabs['hover']};}}")
    rules.append(f"QScrollBar:vertical {{width:{bar['height']}px;}} QScrollBar:horizontal {{height:{bar['height']}px;}} QScrollBar::handle {{background:{bar['hover']};border-radius:{bar['radius']}px;}} QScrollBar::handle:vertical {{min-height:20px;}} QScrollBar::handle:horizontal {{min-width:20px;}} QScrollBar::handle:hover {{background:{bar['active']};}} QProgressBar::chunk {{background:{progress['active']};border-radius:{progress['radius']}px;}}")
    rules.append(f"QCheckBox::indicator:checked,QRadioButton::indicator:checked {{background:{spec['colors']['cyan']};border:1px solid {spec['colors']['cyan']};}}")
    colors=spec['colors']
    rules.append(f"QPushButton:focus,QToolButton:focus {{border-color:{colors['cyan']};}} QPushButton:checked,QToolButton:checked,QPushButton[fsdActive=\"true\"],QToolButton[fsdActive=\"true\"] {{background:{colors['selection']};color:{colors['cyan']};border-color:{colors['teal']};}} QTabBar::tab:selected {{background:{colors['selection']};color:{colors['cyan']};border-bottom:2px solid {colors['cyan']};}}")
    rules.append(f'QToolButton[fsdFamily="group.disclosure"] {{background:transparent;color:{colors["text"]};border:none;text-align:left;padding:3px 2px;}} QToolButton[fsdFamily="group.disclosure"]:hover {{background:{colors["bg_hover"]};color:{colors["cyan"]};}}')
    from .popups import popup_qss
    rules.append(popup_qss(spec['colors'],resolved_style(spec,'field.select'),menu))
    return '\n'.join(rules)

def slug(value):return re.sub(r'[^a-zA-Z0-9_]+','_',value).strip('_')[:64] or 'element'
def widget_text(widget):
    if isinstance(widget,(QtWidgets.QAbstractButton,QtWidgets.QLabel)):return widget.text()
    return ''

class UIStyleRegistry(QtCore.QObject):
    changed=QtCore.Signal()
    inventoryChanged=QtCore.Signal()
    def __init__(self,window,path=SPEC_PATH):
        from .popups import install_popup_policy
        install_popup_policy(QtWidgets.QApplication.instance())
        super().__init__(window);self.window=window;self.path=Path(path);self.entries={};self.layout_entries={};self.undo_stack=[];self.redo_stack=[];self._applying=False
        try:self.spec=load_style_spec(path);self.load_error=''
        except (ValueError,TypeError,KeyError,OSError) as error:self.spec=default_spec();self.load_error=str(error)
        self.saved=deepcopy(self.spec)
        self._timer=QtCore.QTimer(self);self._timer.setSingleShot(True);self._timer.timeout.connect(self.refresh)
        QtWidgets.QApplication.instance().installEventFilter(self)
        try:self.refresh()
        except ValueError as error:
            self.load_error=str(error);self.spec=default_spec();self.saved=deepcopy(self.spec);self.refresh()
    @property
    def dirty(self):return self.spec!=self.saved
    def family_for(self,w):
        from .slider import QtNumberSlider
        from .inspector import QtPropertyGroup,QtPropertyRow,QtColorPicker
        if isinstance(w,(QtNumberSlider,QtColorPicker)):return 'value.slider'
        if isinstance(w,QtWidgets.QMenuBar):return 'navigation.menu'
        if isinstance(w,QtWidgets.QTabBar):return 'navigation.tabs'
        if isinstance(w,QtWidgets.QProgressBar):return 'feedback.progress'
        if isinstance(w,QtWidgets.QStatusBar):return 'feedback.status'
        if isinstance(w,QtWidgets.QScrollBar):return 'layout.scrollbar'
        if isinstance(w,QtWidgets.QSplitterHandle):return 'layout.splitter'
        if isinstance(w,QtWidgets.QScrollArea):return 'panel.surface'
        if isinstance(w,QtWidgets.QAbstractButton):
            if isinstance(w,(QtWidgets.QCheckBox,QtWidgets.QRadioButton)):return 'field.toggle'
            if isinstance(w,QtWidgets.QToolButton):
                return 'group.disclosure' if isinstance(w.parentWidget(),QtPropertyGroup) else 'button.icon'
            if w in [getattr(self.window,n,None) for n in ('btn_fiber','btn_graph','btn_cards','btn_render')]:return 'navigation.workspace'
            if w is getattr(self.window,'btn_bake_tile',None):return 'button.command'
            parent=w.parentWidget()
            if parent is getattr(getattr(self.window,'card_editor',None),'mode_group',None):return 'navigation.mode'
            if w.maximumWidth()<=40 or (len(widget_text(w))<=2 and not widget_text(w).isalnum()):return 'button.icon'
            return 'button.action'
        if isinstance(w,QtWidgets.QComboBox):return 'field.select'
        if isinstance(w,(QtWidgets.QLineEdit,QtWidgets.QAbstractSpinBox)):return 'field.input'
        if isinstance(w,QtWidgets.QAbstractItemView):return 'list.outliner'
        if isinstance(w,QtWidgets.QLabel):
            text=w.text()
            if text and (text.isupper() or text.startswith('▤')):return 'label.heading'
            if any(color.lower() in w.styleSheet().lower() for color in (TOKENS['text_muted'],'#8EA6B8','#A1ABB5')):return 'label.muted'
            return 'label.body'
        if isinstance(w,QtPropertyGroup):return 'panel.surface'
        for name in ('fiber_studio','construction_studio','card_editor','render_studio'):
            owner=getattr(self.window,name,None)
            if owner and w in [getattr(owner,'sidebar',None),getattr(owner,'inspector_content',None)]:return 'panel.surface'
        if isinstance(w,QtPropertyRow):return 'panel.row'
        return 'panel.row'
    def _eligible(self,w):
        import shiboken6
        if not shiboken6.isValid(w):return False
        from .viewport import QtViewportHost
        if w is self.window or isinstance(w,(QtViewportHost,QtWidgets.QMainWindow,QtWidgets.QMenu,QtWidgets.QStackedWidget)):return False
        if w.objectName().startswith('qt_') and not isinstance(w,(QtWidgets.QMenuBar,QtWidgets.QScrollBar,QtWidgets.QTabBar)):return False
        p=w.parentWidget()
        if isinstance(p,(QtWidgets.QAbstractItemView,QtWidgets.QAbstractSpinBox,QtWidgets.QComboBox,QtWidgets.QScrollArea)):return False
        return w.window() is self.window
    def peer_layout(self,w):
        parent=w.parentWidget();root=QtWidgets.QWidget.layout(parent) if parent else None
        def find(layout):
            if layout is None:return None
            for i in range(layout.count()):
                item=layout.itemAt(i)
                if item.widget() is w:return layout
                nested=find(item.layout())
                if nested is not None:return nested
            return None
        return find(root)

    def refresh(self):
        if self._applying:return
        before={(i,id(w)) for i,e,w in self.widgets()}
        before_layouts={(i,id(e['ref']())) for i,e in self.layout_entries.items()}
        self._applying=True
        try:
            # Attribute IDs do not depend on captions, order or the active workspace.
            owners=[('app',self.window)]+[(f'app.{name}',getattr(self.window,name,None)) for name in ('fiber_studio','construction_studio','card_editor','render_studio')]
            for prefix,owner in owners:
                if owner is None:continue
                for name,value in vars(owner).items():
                    if isinstance(value,QtWidgets.QWidget) and self._eligible(value) and not value.property('fsdId'):value.setProperty('fsdId',prefix+'.'+name)
            def walk(parent,prefix):
                seen={}
                for w in parent.findChildren(QtWidgets.QWidget,options=QtCore.Qt.FindChildOption.FindDirectChildrenOnly):
                    base=w.objectName() or slug(widget_text(w) or w.__class__.__name__);index=seen.get(base,0);seen[base]=index+1
                    ident=w.property('fsdId') or f'{prefix}.{base}.{index}'
                    if self._eligible(w):
                        w.setProperty('fsdId',ident)
                        if ident not in self.entries or self.entries[ident]['ref']() is not w:
                            layout=QtWidgets.QWidget.layout(w)
                            margins=layout.contentsMargins() if layout else None
                            self.entries[ident]=dict(ref=weakref.ref(w),family=self.family_for(w),text=widget_text(w),tooltip=w.toolTip(),min_width=w.minimumWidth(),hidden=w.isHidden(),
                                spacing=layout.spacing() if layout else 0,margins=[margins.left(),margins.top(),margins.right(),margins.bottom()] if margins else [],
                                order=[layout.itemAt(i).widget() for i in range(layout.count())] if isinstance(layout,QtWidgets.QBoxLayout) else [])
                            # Remove per-widget QSS; one family now owns visual appearance.
                            w.setStyleSheet('')
                    walk(w,ident)
            walk(self.window,'app')
            def layouts(layout,key):
                layout.setProperty('fsdLayoutId',key)
                record=self.layout_entries.get(key)
                if record is None or record['ref']() is not layout:
                    m=layout.contentsMargins()
                    self.layout_entries[key]=dict(ref=weakref.ref(layout),spacing=layout.spacing(),margins=[m.left(),m.top(),m.right(),m.bottom()],order=[layout.itemAt(i).widget() for i in range(layout.count())] if isinstance(layout,QtWidgets.QBoxLayout) else [])
                for i in range(layout.count()):
                    nested=layout.itemAt(i).layout()
                    if nested is not None:layouts(nested,key+'/layout/'+str(i))
            for ident,e,w in self.widgets():
                layout=QtWidgets.QWidget.layout(w)
                if layout is not None:layouts(layout,ident)
            # Anonymous icon utility controls in the same command row use its family.
            peers={}
            for ident,e,w in self.widgets():
                if isinstance(w,QtWidgets.QPushButton):
                    layout=self.peer_layout(w)
                    if layout is not None:peers.setdefault(id(layout),[]).append(e)
            for entries in peers.values():
                families={e['family'] for e in entries}
                if families=={'button.action','button.icon'}:
                    for e in entries:e['family']='button.action'
            changed=before!={(i,id(w)) for i,e,w in self.widgets()} or before_layouts!={(i,id(e['ref']())) for i,e in self.layout_entries.items()}
            if changed:self.apply()
        finally:self._applying=False
        if changed:self.inventoryChanged.emit()
    def widgets(self):
        import shiboken6
        return [(ident,e,e['ref']()) for ident,e in self.entries.items() if e['ref']() is not None and shiboken6.isValid(e['ref']())]
    def family_assignments(self,spec):
        assignments={ident:spec['elements'].get(ident,{}).get('family',e['family']) for ident,e,w in self.widgets()}
        groups={}
        for ident,e,w in self.widgets():
            if not isinstance(w,(QtWidgets.QPushButton,QtWidgets.QToolButton)) or e['family'] in ('button.command','group.disclosure'):continue
            layout=self.peer_layout(w)
            if layout is not None:groups.setdefault((id(layout),type(w)),[]).append(ident)
        for peers in groups.values():
            explicit={spec['elements'][ident]['family'] for ident in peers if 'family' in spec['elements'].get(ident,{})}
            if len(explicit)>1:raise ValueError('Các nút đồng cấp phải dùng cùng họ style: '+', '.join(peers))
            if explicit:
                family=next(iter(explicit))
                for ident in peers:assignments[ident]=family
        return assignments

    def apply(self):
        assignments=self.family_assignments(self.spec)
        TOKENS.update(self.spec['colors'])
        qss=generate_qss_from_spec(self.spec)
        if getattr(self,'_applied_qss',None)!=qss:
            self.window.setStyleSheet(qss);self._applied_qss=qss
        for ident,e,w in self.widgets():
            patch=self.spec['elements'].get(ident,{})
            family=assignments[ident];family_changed=w.property('fsdFamily')!=family
            w.setProperty('fsdFamily',family)
            cls=w.property('class') or '';w.setProperty('fsdActive',str(cls).endswith('_active'))
            values=resolved_style(self.spec,family);w.setProperty('fsdStyle',values)
            if isinstance(w,QtWidgets.QAbstractButton):
                h=values['height'];w.setMinimumHeight(h);w.setMaximumHeight(h)
                if family=='button.icon':w.setFixedWidth(h)
                elif w.minimumWidth()==w.maximumWidth():w.setMaximumWidth(16777215)
            elif family in ('field.input','field.select','value.slider'):w.setMinimumHeight(values['height']);w.setMaximumHeight(values['height'])
            if isinstance(w,(QtWidgets.QLabel,QtWidgets.QAbstractButton)):
                if 'text' in patch:w.setText(patch['text'])
                elif w.property('fsdTextOverride') is not None:w.setText(e['text'])
                w.setProperty('fsdTextOverride',patch.get('text'))
            w.setToolTip(patch.get('tooltip',e['tooltip']))
            w.setMinimumWidth(patch.get('min_width',e['min_width']) if family!='button.icon' else values['height'])
            if 'hidden' in patch:w.setVisible(not patch['hidden'])
            elif w.property('fsdHiddenOverride') is not None:w.setVisible(not e['hidden'])
            w.setProperty('fsdHiddenOverride',patch.get('hidden'))
            if family_changed:w.style().unpolish(w);w.style().polish(w)
            if isinstance(w,QtWidgets.QAbstractButton) or family in ('field.input','field.select','value.slider'):w.setFixedHeight(values['height'])
            w.update()
        from .icons import decorate_controls
        decorate_controls(self.window,self.spec['colors'])
        self._apply_layouts()

    def _apply_layouts(self):
        import shiboken6
        previous=getattr(self,'_applied_layout_keys',set())
        current=set(self.spec['layouts'])
        for key,e in self.layout_entries.items():
            # Never mutate Qt's private layouts during a palette-only refresh.
            # Keep prior keys so Undo still restores the original layout values.
            if key not in current and key not in previous:continue
            layout=e['ref']()
            if layout is None or not shiboken6.isValid(layout):continue
            patch=self.spec['layouts'].get(key,{})
            layout.setSpacing(patch.get('spacing',e['spacing']));layout.setContentsMargins(*patch.get('margins',e['margins']))
            if not isinstance(layout,QtWidgets.QBoxLayout):continue
            order=patch.get('order')
            desired=[self.entries[i]['ref']() for i in order if i in self.entries] if order else e['order']
            actual=[w for w in desired if w is not None and shiboken6.isValid(w) and layout.indexOf(w)>=0]
            slots=[i for i in range(layout.count()) if layout.itemAt(i).widget() in actual]
            if len(slots)!=len(actual) or [layout.itemAt(i).widget() for i in slots]==actual:continue
            settings={w:(layout.stretch(layout.indexOf(w)),layout.itemAt(layout.indexOf(w)).alignment()) for w in actual}
            hidden={w:w.isHidden() for w in actual}
            for w in actual:layout.removeWidget(w)
            for slot,w in zip(slots,actual):
                layout.insertWidget(slot,w,*settings[w])
                if hidden[w]:w.hide()

        self._applied_layout_keys=current

    def edit(self,section,key,value):
        trial=deepcopy(self.spec)
        if value is None:trial[section].pop(key,None)
        else:trial[section][key]=deepcopy(value)
        self.replace(trial)
    def replace(self,spec):
        validated=validate_spec(spec)
        self.family_assignments(validated)
        if validated==self.spec:return
        self.undo_stack.append(deepcopy(self.spec));self.undo_stack=self.undo_stack[-50:];self.redo_stack.clear();self.spec=validated;self.apply();self.changed.emit()
    def undo(self):
        if self.undo_stack:self.redo_stack.append(self.spec);self.spec=self.undo_stack.pop();self.apply();self.changed.emit()
    def redo(self):
        if self.redo_stack:self.undo_stack.append(self.spec);self.spec=self.redo_stack.pop();self.apply();self.changed.emit()
    def save(self):save_style_spec(self.spec,self.path);self.saved=deepcopy(self.spec);self.changed.emit()
    def discard(self):self.replace(self.saved)
    def audit(self):
        groups={};issues=[]
        for ident,e,w in self.widgets():
            if not isinstance(w,(QtWidgets.QPushButton,QtWidgets.QToolButton)):continue
            parent=w.parentWidget();layout=QtWidgets.QWidget.layout(parent) if parent else None
            # Same parent and control type form a peer group. Main command and disclosure have distinct hierarchy.
            family=w.property('fsdFamily')
            if family in ('button.command','group.disclosure'):continue
            peer=self.peer_layout(w)
            groups.setdefault((id(peer) if peer is not None else id(parent),type(w)),[]).append((ident,family,w.height()))
        for peers in groups.values():
            if len({p[1] for p in peers})>1:issues.append(dict(type='peer_family',elements=[p[0] for p in peers],families=[p[1] for p in peers]))
        return dict(element_count=len(self.widgets()),family_count=len(FAMILY_LABELS),issues=issues,layout_ids=list(self.layout_entries),families={family:sum(w.property('fsdFamily')==family for ident,e,w in self.widgets()) for family in FAMILY_LABELS},elements=[dict(id=i,type=w.__class__.__name__,family=w.property('fsdFamily'),text=widget_text(w)) for i,e,w in self.widgets()])
    def eventFilter(self,receiver,event):
        if self._applying:return False
        if event.type()==QtCore.QEvent.Type.DynamicPropertyChange and isinstance(receiver,QtWidgets.QWidget) and receiver.window() is self.window and event.propertyName().data()==b'class':
            receiver.setProperty('fsdActive',str(receiver.property('class') or '').endswith('_active'))
            receiver.style().unpolish(receiver);receiver.style().polish(receiver);receiver.update()
        if event.type()==QtCore.QEvent.Type.ChildAdded and isinstance(receiver,QtWidgets.QWidget) and receiver.window() is self.window:
            self._timer.start(50)
        return False
