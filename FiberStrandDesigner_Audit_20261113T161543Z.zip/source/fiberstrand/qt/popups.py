"""Shared Qt popup chrome and logical-pixel placement, independent of scene state."""
from PySide6 import QtCore,QtGui,QtWidgets


def anchored_rect(anchor,size,available,gap=4):
    """Prefer below the control, flip above when needed, clamp to this screen."""
    area=available.adjusted(6,6,-6,-6)
    width=max(1,min(max(anchor.width(),size.width()),area.width()))
    below=area.bottom()-anchor.bottom()-gap
    above=anchor.top()-area.top()-gap
    use_below=size.height()<=below or below>=above
    height=max(1,min(size.height(),max(below if use_below else above,1),area.height()))
    x=anchor.left()
    y=anchor.bottom()+gap+1 if use_below else anchor.top()-gap-height
    x=max(area.left(),min(x,area.right()-width+1));y=max(area.top(),min(y,area.bottom()-height+1))
    return QtCore.QRect(x,y,width,height)


def point_popup_geometry(popup,point,preferred=None):
    popup.ensurePolished()
    if popup.layout():popup.layout().activate()
    screen=QtGui.QGuiApplication.screenAt(point) or popup.screen()
    if screen is None:return
    area=screen.availableGeometry().adjusted(6,6,-6,-6)
    wanted=(preferred or popup.size()).expandedTo(popup.minimumSizeHint())
    size=QtCore.QSize(min(wanted.width(),area.width()),min(wanted.height(),area.height()))
    popup.resize(size)
    popup.move(max(area.left(),min(point.x(),area.right()-size.width()+1)),max(area.top(),min(point.y(),area.bottom()-size.height()+1)))


class ComboPopupStyle(QtWidgets.QProxyStyle):
    def __init__(self,parent):
        # Own a separate base style. Never transfer ownership of QApplication.style().
        super().__init__(QtWidgets.QStyleFactory.create('Fusion'));self.setParent(parent)
    def styleHint(self,hint,option=None,widget=None,returnData=None):
        if hint==QtWidgets.QStyle.StyleHint.SH_ComboBox_Popup:return 0
        return super().styleHint(hint,option,widget,returnData)
    def drawPrimitive(self,element,option,painter,widget=None):
        if element==QtWidgets.QStyle.PrimitiveElement.PE_IndicatorArrowDown and isinstance(widget,QtWidgets.QComboBox):
            from .theme import TOKENS
            values=widget.property('fsdStyle') or {}
            color=values.get('foreground',TOKENS['text']) if widget.isEnabled() else TOKENS['text_muted']
            center=option.rect.center();painter.save();painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
            pen=QtGui.QPen(QtGui.QColor(color),1.5);pen.setCapStyle(QtCore.Qt.PenCapStyle.RoundCap);pen.setJoinStyle(QtCore.Qt.PenJoinStyle.RoundJoin)
            painter.setPen(pen);painter.setBrush(QtCore.Qt.BrushStyle.NoBrush)
            painter.drawPolyline(QtGui.QPolygonF([QtCore.QPointF(center.x()-3.5,center.y()-1.5),QtCore.QPointF(center.x(),center.y()+2),QtCore.QPointF(center.x()+3.5,center.y()-1.5)]));painter.restore();return
        super().drawPrimitive(element,option,painter,widget)


class PopupPolicy(QtCore.QObject):
    def configure(self,combo):
        if getattr(combo,'_fsd_popup_style',None) is not None:return
        style=ComboPopupStyle(combo);combo._fsd_popup_style=style
        combo.setStyle(style)
        combo.setMaxVisibleItems(10)
        # Keep arbitrary custom item delegates/models; only standardise scrolling.
        view=combo.view();view.setVerticalScrollMode(QtWidgets.QAbstractItemView.ScrollMode.ScrollPerPixel)
        view.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        view.setTextElideMode(QtCore.Qt.TextElideMode.ElideRight)
    def _combo_owner(self,widget):
        parent=widget.parentWidget()
        return parent if isinstance(parent,QtWidgets.QComboBox) and widget.isWindow() else None
    def _anchor(self,combo,popup):
        import shiboken6
        if not shiboken6.isValid(combo) or not shiboken6.isValid(popup) or not popup.isVisible():return
        anchor=QtCore.QRect(combo.mapToGlobal(QtCore.QPoint()),combo.size())
        screen=QtGui.QGuiApplication.screenAt(anchor.center()) or combo.screen()
        if screen:
            view=combo.view()
            rows=[view.sizeHintForRow(i) for i in range(min(10,combo.count()))]
            row=max([24,combo.fontMetrics().height()+10,*rows])
            height=min(10,max(1,combo.count()))*row+8
            width=max(combo.width(),popup.width())
            rect=anchored_rect(anchor,QtCore.QSize(width,height),screen.availableGeometry())
            if popup.geometry()!=rect:popup.setGeometry(rect)
            view.setCurrentIndex(combo.model().index(combo.currentIndex(),combo.modelColumn(),combo.rootModelIndex()))
            view.scrollTo(view.currentIndex(),QtWidgets.QAbstractItemView.ScrollHint.EnsureVisible)
    def eventFilter(self,widget,event):
        if isinstance(widget,QtWidgets.QComboBox) and event.type()==QtCore.QEvent.Type.Polish:
            self.configure(widget)
        if isinstance(widget,QtWidgets.QWidget) and event.type()==QtCore.QEvent.Type.Show:
            combo=self._combo_owner(widget)
            if combo is not None:
                self._anchor(combo,widget)
                # Qt can finish its selected-row layout after Show. Anchor once
                # more on the next turn, not continuously on Move/Resize.
                QtCore.QTimer.singleShot(0,lambda:self._anchor(combo,widget))
        return False


def install_popup_policy(app):
    policy=getattr(app,'_fsd_popup_policy',None)
    if policy is None:
        policy=PopupPolicy(app);app._fsd_popup_policy=policy;app.installEventFilter(policy)
        for effect in (QtCore.Qt.UIEffect.UI_AnimateCombo,QtCore.Qt.UIEffect.UI_AnimateMenu,QtCore.Qt.UIEffect.UI_FadeMenu):app.setEffectEnabled(effect,False)
        for widget in app.allWidgets():
            if isinstance(widget,QtWidgets.QComboBox):policy.configure(widget)
    return policy


def popup_qss(colors,select=None,menu=None):
    select=select or {};menu=menu or {}
    background=menu.get('background',colors['bg_panel']);foreground=select.get('foreground',colors['text'])
    border=menu.get('border',colors['border']);hover=select.get('hover',colors['bg_hover']);active=select.get('active',colors['cyan'])
    font=select.get('font_size',12)
    menu_foreground=menu.get('foreground',colors['text'])
    menu_y=menu.get('padding_y',5);menu_x=menu.get('padding_x',12)
    return f"""
QComboBox,QComboBox[fsdFamily="field.select"] {{padding-right:28px;}}
QComboBox::drop-down {{subcontrol-origin:padding;subcontrol-position:top right;width:24px;border:none;background:transparent;}}
QComboBox::down-arrow {{width:12px;height:8px;}}
QComboBoxPrivateContainer {{background:{background};color:{foreground};border:1px solid {border};border-radius:6px;padding:3px;}}
QComboBox QAbstractItemView {{background:{background};color:{foreground};border:1px solid {border};border-radius:6px;padding:3px;outline:none;font-size:{font}px;selection-background-color:{hover};selection-color:{active};}}
QComboBox QAbstractItemView::item {{min-height:24px;padding:4px 10px;margin:1px 0;border:none;border-radius:4px;background:transparent;color:{foreground};}}
QComboBox QAbstractItemView::item:hover,QComboBox QAbstractItemView::item:selected {{background:{hover};color:{active};}}
QComboBox QAbstractItemView::item:disabled {{color:{colors['text_muted']};}}
QFrame[fsdPopup="true"] {{background:{background};color:{foreground};border:1px solid {border};border-radius:8px;padding:4px;}}
QMenu {{color:{menu_foreground};}}
QMenu::item {{min-height:22px;padding:{menu_y}px {max(24,menu_x)}px {menu_y}px {menu_x}px;}}
QMenu::item:disabled {{color:{colors['text_muted']};}}
QMenu::indicator {{width:12px;height:12px;}}
"""
