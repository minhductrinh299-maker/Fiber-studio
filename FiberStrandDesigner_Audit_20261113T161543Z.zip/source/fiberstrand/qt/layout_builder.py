"""Visual Menu & Custom Toolbar Layout Builder for Fiber Strand Designer.

Allows users to:
1. Browse a complete warehouse ("Kho Nút") of every DCC action available in the app
2. Organize buttons into custom Menu groups, Toolbars, and Quick Action Panels
3. Add / Remove / Reorder buttons interactively
4. Export and Import the customized layout to/from JSON for Antigravity AI to apply
"""
from __future__ import annotations

import json
from pathlib import Path
from PySide6 import QtCore, QtGui, QtWidgets
from .theme import TOKENS
from .action_registry import ActionRegistry, ActionDef


class ActionItemWidget(QtWidgets.QListWidgetItem):
    """Custom ListWidgetItem representing a DCC action."""
    def __init__(self, action_def: ActionDef):
        shortcut_str = f" [{action_def.shortcut}]" if action_def.shortcut else ""
        icon_str = f"{action_def.icon} " if action_def.icon else "• "
        super().__init__(f"{icon_str}{action_def.title}{shortcut_str}  ·  ({action_def.category})")
        self.action_def = action_def
        self.setData(QtCore.Qt.ItemDataRole.UserRole, action_def.id)
        self.setToolTip(f"ID: {action_def.id}\n{action_def.description}")


class LayoutBuilderDialog(QtWidgets.QDialog):
    """Studio UI for visual layout organization and JSON export."""

    layoutApplied = QtCore.Signal(dict)

    def __init__(self, registry: ActionRegistry, parent: QtWidgets.QWidget | None = None):
        super().__init__(parent)
        self.registry = registry
        self.setWindowTitle("Fiber Strand Designer · Bộ Tùy Biến Menu & Sắp Xếp Nút Chức Năng (Layout Studio)")
        self.resize(1120, 720)
        self.setStyleSheet(f"""
            QDialog {{ background-color: {TOKENS['bg_dark']}; color: {TOKENS['text']}; font-family: 'Segoe UI', sans-serif; }}
            QListWidget {{ background-color: {TOKENS['bg_panel']}; border: 1px solid {TOKENS['border']}; border-radius: 6px; padding: 4px; }}
            QListWidget::item {{ padding: 6px 10px; margin: 2px 0; border-radius: 4px; color: {TOKENS['text']}; }}
            QListWidget::item:hover {{ background-color: {TOKENS['bg_hover']}; }}
            QListWidget::item:selected {{ background-color: {TOKENS['cyan']}; color: #000000; font-weight: 700; }}
            QLineEdit {{ background-color: {TOKENS['bg_control']}; border: 1px solid {TOKENS['border']}; border-radius: 4px; padding: 6px 10px; color: {TOKENS['text']}; }}
            QComboBox {{ background-color: {TOKENS['bg_control']}; border: 1px solid {TOKENS['border']}; border-radius: 4px; padding: 4px 8px; color: {TOKENS['text']}; }}
            QGroupBox {{ border: 1px solid {TOKENS['border']}; border-radius: 6px; margin-top: 18px; font-weight: 700; color: {TOKENS['cyan']}; font-size: 11px; }}
            QGroupBox::title {{ subcontrol-origin: margin; subcontrol-position: top left; padding: 0 6px; }}
            QTreeWidget {{ background-color: {TOKENS['bg_panel']}; border: 1px solid {TOKENS['border']}; border-radius: 6px; }}
            QTreeWidget::item {{ padding: 6px; border-bottom: 1px solid {TOKENS['border_subtle']}; }}
            QTreeWidget::item:selected {{ background-color: {TOKENS['cyan']}; color: #000000; }}
        """)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(14, 14, 14, 14)
        main_layout.setSpacing(12)

        # 1. Header with instructions and action buttons
        header_bar = QtWidgets.QHBoxLayout()
        lbl_title = QtWidgets.QLabel("🎨 BẢNG SẮP XẾP BỐ CỤC UI & KHO NÚT CHỨC NĂNG", self)
        lbl_title.setStyleSheet(f"font-size: 14px; font-weight: 700; color: {TOKENS['cyan']};")
        header_bar.addWidget(lbl_title)
        header_bar.addStretch(1)

        btn_load_default = QtWidgets.QPushButton("↺ Nạp Mẫu Mặc Định", self)
        btn_load_default.setProperty("class", "workspace_pill")
        btn_load_default.clicked.connect(self._load_default_template)
        header_bar.addWidget(btn_load_default)

        btn_import_json = QtWidgets.QPushButton("📥 Nhập File JSON...", self)
        btn_import_json.setProperty("class", "workspace_pill")
        btn_import_json.clicked.connect(self._import_json)
        header_bar.addWidget(btn_import_json)

        btn_export_json = QtWidgets.QPushButton("📤 Xuất File JSON Cho AI", self)
        btn_export_json.setProperty("class", "gold_action")
        btn_export_json.setStyleSheet("background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #F5C344, stop:1 #FF9A3C); color: #000; font-weight: 700; padding: 6px 14px; border-radius: 4px;")
        btn_export_json.clicked.connect(self._export_json)
        header_bar.addWidget(btn_export_json)

        main_layout.addLayout(header_bar)

        # 2. Main Two-Column Splitter: Left = Warehouse ("Kho Nút"), Right = Layout Canvas ("Bảng Sắp Xếp")
        content_splitter = QtWidgets.QSplitter(QtCore.Qt.Orientation.Horizontal, self)
        content_splitter.setStyleSheet(f"QSplitter::handle {{ background-color: {TOKENS['border']}; width: 2px; }}")

        # === CỘT TRÁI: KHO TẤT CẢ NÚT CHỨC NĂNG ===
        left_box = QtWidgets.QGroupBox("KHO TẤT CẢ NÚT CHỨC NĂNG (WAREHOUSE)")
        left_layout = QtWidgets.QVBoxLayout(left_box)
        left_layout.setContentsMargins(10, 16, 10, 10)
        left_layout.setSpacing(8)

        # Search & Filter
        filter_row = QtWidgets.QHBoxLayout()
        self.search_input = QtWidgets.QLineEdit(left_box)
        self.search_input.setPlaceholderText("🔍 Tìm nút chức năng theo tên, ID, phím tắt...")
        self.search_input.textChanged.connect(self._filter_warehouse)
        filter_row.addWidget(self.search_input, 1)

        self.category_combo = QtWidgets.QComboBox(left_box)
        self.category_combo.addItem("Tất cả danh mục (All)")
        for cat in sorted({a.category for a in self.registry.all_actions()}):
            self.category_combo.addItem(cat)
        self.category_combo.currentTextChanged.connect(self._filter_warehouse)
        filter_row.addWidget(self.category_combo)
        left_layout.addLayout(filter_row)

        self.warehouse_list = QtWidgets.QListWidget(left_box)
        self.warehouse_list.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.ExtendedSelection)
        left_layout.addWidget(self.warehouse_list, 1)

        lbl_hint = QtWidgets.QLabel("💡 Chọn nút bên trái rồi bấm [Thêm vào ➔] hoặc kéo thả sang bảng bên phải.", left_box)
        lbl_hint.setStyleSheet(f"color: {TOKENS['text_muted']}; font-size: 11px;")
        left_layout.addWidget(lbl_hint)

        content_splitter.addWidget(left_box)

        # === CỘT GIỮA: NÚT ĐIỀU HƯỚNG CHUYỂN QUA LẠI ===
        center_nav = QtWidgets.QWidget(self)
        center_nav_layout = QtWidgets.QVBoxLayout(center_nav)
        center_nav_layout.setContentsMargins(4, 0, 4, 0)
        center_nav_layout.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)

        self.btn_add_to_canvas = QtWidgets.QPushButton("Thêm vào ➔", center_nav)
        self.btn_add_to_canvas.setProperty("class", "primary")
        self.btn_add_to_canvas.setStyleSheet(f"background-color: {TOKENS['cyan']}; color: #000; font-weight: 700; padding: 8px 12px; border-radius: 4px;")
        self.btn_add_to_canvas.clicked.connect(self._add_selected_to_layout)
        center_nav_layout.addWidget(self.btn_add_to_canvas)

        self.btn_remove_from_canvas = QtWidgets.QPushButton("⌫ Xóa khỏi bảng", center_nav)
        self.btn_remove_from_canvas.setProperty("class", "workspace_pill")
        self.btn_remove_from_canvas.clicked.connect(self._remove_selected_from_layout)
        center_nav_layout.addWidget(self.btn_remove_from_canvas)

        content_splitter.addWidget(center_nav)

        # === CỘT PHẢI: BẢNG SẮP XẾP BỐ CỤC (LAYOUT CANVAS) ===
        right_box = QtWidgets.QGroupBox("BẢNG SẮP XẾP MENU & TOOLBAR (TÙY BIẾN CHO ĐẠI CA)")
        right_layout = QtWidgets.QVBoxLayout(right_box)
        right_layout.setContentsMargins(10, 16, 10, 10)
        right_layout.setSpacing(8)

        # Section manager row
        sec_row = QtWidgets.QHBoxLayout()
        self.sec_name_input = QtWidgets.QLineEdit(right_box)
        self.sec_name_input.setPlaceholderText("Tên nhóm mới (ví dụ: 'Thao Tác Nhanh', 'Grooming Tools')...")
        btn_create_sec = QtWidgets.QPushButton("+ Tạo Nhóm Mới", right_box)
        btn_create_sec.setProperty("class", "primary")
        btn_create_sec.clicked.connect(self._create_custom_section)
        sec_row.addWidget(self.sec_name_input, 1)
        sec_row.addWidget(btn_create_sec)
        right_layout.addLayout(sec_row)

        self.layout_tree = QtWidgets.QTreeWidget(right_box)
        self.layout_tree.setHeaderLabels(["Bố Cục UI / Nhóm Chức Năng", "Action ID", "Phím Tắt"])
        self.layout_tree.header().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeMode.Stretch)
        self.layout_tree.header().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        self.layout_tree.header().setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        right_layout.addWidget(self.layout_tree, 1)

        # Reorder buttons row
        reorder_row = QtWidgets.QHBoxLayout()
        btn_move_up = QtWidgets.QPushButton("⬆ Di chuyển lên", right_box)
        btn_move_up.clicked.connect(self._move_item_up)
        btn_move_down = QtWidgets.QPushButton("⬇ Di chuyển xuống", right_box)
        btn_move_down.clicked.connect(self._move_item_down)
        btn_clear_canvas = QtWidgets.QPushButton("🗑 Xóa sạch bảng (Làm lại)", right_box)
        btn_clear_canvas.clicked.connect(self._clear_layout)
        reorder_row.addWidget(btn_move_up)
        reorder_row.addWidget(btn_move_down)
        reorder_row.addStretch(1)
        reorder_row.addWidget(btn_clear_canvas)
        right_layout.addLayout(reorder_row)

        content_splitter.addWidget(right_box)
        content_splitter.setSizes([380, 120, 620])
        main_layout.addWidget(content_splitter, 1)

        # Populate warehouse list
        self._populate_warehouse()
        self._load_default_template()

    def _populate_warehouse(self):
        self.warehouse_list.clear()
        for adef in self.registry.all_actions():
            item = ActionItemWidget(adef)
            self.warehouse_list.addItem(item)

    def _filter_warehouse(self):
        query = self.search_input.text().strip().lower()
        selected_cat = self.category_combo.currentText()
        for i in range(self.warehouse_list.count()):
            item = self.warehouse_list.item(i)
            adef = getattr(item, "action_def", None)
            if not adef:
                continue
            cat_match = (selected_cat.startswith("Tất cả") or adef.category == selected_cat)
            text_match = (
                not query
                or query in adef.title.lower()
                or query in adef.id.lower()
                or (adef.shortcut and query in adef.shortcut.lower())
                or query in adef.description.lower()
            )
            item.setHidden(not (cat_match and text_match))

    def _create_custom_section(self):
        name = self.sec_name_input.text().strip()
        if not name:
            QtWidgets.QMessageBox.information(self, "Tạo nhóm", "Vui lòng nhập tên nhóm chức năng.")
            return
        section_item = QtWidgets.QTreeWidgetItem(self.layout_tree, [f"📂 {name}", "", ""])
        section_item.setFlags(section_item.flags() | QtCore.Qt.ItemFlag.ItemIsEditable)
        section_item.setExpanded(True)
        self.layout_tree.setCurrentItem(section_item)
        self.sec_name_input.clear()

    def _add_selected_to_layout(self):
        selected_items = self.warehouse_list.selectedItems()
        if not selected_items:
            QtWidgets.QMessageBox.information(self, "Chưa chọn nút", "Vui lòng chọn một hoặc nhiều nút từ kho bên trái.")
            return

        target_parent = self.layout_tree.currentItem()
        if target_parent is None:
            # If no group selected, put into first group or create one
            if self.layout_tree.topLevelItemCount() == 0:
                target_parent = QtWidgets.QTreeWidgetItem(self.layout_tree, ["📂 Toolbar Tùy Biến Của Đại Ca", "", ""])
                target_parent.setExpanded(True)
            else:
                target_parent = self.layout_tree.topLevelItem(0)
        elif target_parent.parent() is not None:
            # If a child action was selected, add sibling to its parent group
            target_parent = target_parent.parent()

        for item in selected_items:
            adef = getattr(item, "action_def", None)
            if adef:
                child = QtWidgets.QTreeWidgetItem(target_parent, [
                    f"{adef.icon or '•'} {adef.title}",
                    adef.id,
                    adef.shortcut or ""
                ])
                child.setData(0, QtCore.Qt.ItemDataRole.UserRole, adef.id)

        target_parent.setExpanded(True)

    def _remove_selected_from_layout(self):
        item = self.layout_tree.currentItem()
        if item is None:
            return
        parent = item.parent()
        if parent is not None:
            parent.removeChild(item)
        else:
            idx = self.layout_tree.indexOfTopLevelItem(item)
            self.layout_tree.takeTopLevelItem(idx)

    def _move_item_up(self):
        item = self.layout_tree.currentItem()
        if not item: return
        parent = item.parent()
        if parent:
            idx = parent.indexOfChild(item)
            if idx > 0:
                parent.takeChild(idx)
                parent.insertChild(idx - 1, item)
                self.layout_tree.setCurrentItem(item)
        else:
            idx = self.layout_tree.indexOfTopLevelItem(item)
            if idx > 0:
                self.layout_tree.takeTopLevelItem(idx)
                self.layout_tree.insertTopLevelItem(idx - 1, item)
                self.layout_tree.setCurrentItem(item)

    def _move_item_down(self):
        item = self.layout_tree.currentItem()
        if not item: return
        parent = item.parent()
        if parent:
            idx = parent.indexOfChild(item)
            if idx < parent.childCount() - 1:
                parent.takeChild(idx)
                parent.insertChild(idx + 1, item)
                self.layout_tree.setCurrentItem(item)
        else:
            idx = self.layout_tree.indexOfTopLevelItem(item)
            if idx < self.layout_tree.topLevelItemCount() - 1:
                self.layout_tree.takeTopLevelItem(idx)
                self.layout_tree.insertTopLevelItem(idx + 1, item)
                self.layout_tree.setCurrentItem(item)

    def _clear_layout(self):
        reply = QtWidgets.QMessageBox.question(self, "Xóa bảng sắp xếp", "Đại ca có muốn xóa toàn bộ bảng và tạo lại từ đầu?")
        if reply == QtWidgets.QMessageBox.StandardButton.Yes:
            self.layout_tree.clear()

    def _load_default_template(self):
        """Loads a clean starter DCC layout template."""
        self.layout_tree.clear()
        defaults = {
            "🚀 Main Ribbon Toolbar (Thanh Công Cụ Chính)": [
                "cards.add", "cards.draw_guide", "cards.reset_overrides", "cards.make_unique",
                "view.frame_selected", "view.toggle_wireframe", "view.toggle_grid"
            ],
            "🌿 Fiber & Tile Tools (Thao Tác Sợi & Atlas)": [
                "fiber.new_tile", "fiber.duplicate_tile", "fiber.bake_tile"
            ],
            "☁ Construction Graph Operations (Tác Vụ Đồ Thị)": [
                "graph.add_node", "graph.load_preset", "graph.apply_tile"
            ],
            "✨ GPU Render Studio Actions (Lookdev & Xuất Ảnh)": [
                "render.capture", "render.export_exr", "file.export_obj"
            ]
        }
        for sec_name, action_ids in defaults.items():
            sec_item = QtWidgets.QTreeWidgetItem(self.layout_tree, [sec_name, "", ""])
            sec_item.setExpanded(True)
            for aid in action_ids:
                adef = self.registry.get_action_def(aid)
                if adef:
                    child = QtWidgets.QTreeWidgetItem(sec_item, [
                        f"{adef.icon or '•'} {adef.title}",
                        adef.id,
                        adef.shortcut or ""
                    ])
                    child.setData(0, QtCore.Qt.ItemDataRole.UserRole, adef.id)

    def to_layout_dict(self) -> dict:
        """Serializes current layout tree into structured JSON dict."""
        layout = {"sections": []}
        for i in range(self.layout_tree.topLevelItemCount()):
            top = self.layout_tree.topLevelItem(i)
            sec_name = top.text(0).replace("📂 ", "").strip()
            actions = []
            for j in range(top.childCount()):
                child = top.child(j)
                aid = child.data(0, QtCore.Qt.ItemDataRole.UserRole) or child.text(1)
                actions.append(aid)
            layout["sections"].append({
                "name": sec_name,
                "actions": actions
            })
        return layout

    def from_layout_dict(self, data: dict):
        self.layout_tree.clear()
        for sec in data.get("sections", []):
            sec_name = sec.get("name", "Custom Section")
            sec_item = QtWidgets.QTreeWidgetItem(self.layout_tree, [f"📂 {sec_name}", "", ""])
            sec_item.setExpanded(True)
            for aid in sec.get("actions", []):
                adef = self.registry.get_action_def(aid)
                if adef:
                    child = QtWidgets.QTreeWidgetItem(sec_item, [
                        f"{adef.icon or '•'} {adef.title}",
                        adef.id,
                        adef.shortcut or ""
                    ])
                    child.setData(0, QtCore.Qt.ItemDataRole.UserRole, adef.id)
                else:
                    child = QtWidgets.QTreeWidgetItem(sec_item, [f"• {aid}", aid, ""])
                    child.setData(0, QtCore.Qt.ItemDataRole.UserRole, aid)

    def _export_json(self):
        data = self.to_layout_dict()
        default_path = str(Path(__file__).resolve().parents[2] / "custom_ui_layout.json")
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Xuất cấu hình bố cục JSON cho AI", default_path, "JSON File (*.json)"
        )
        if path:
            try:
                Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
                self.layoutApplied.emit(data)
                QtWidgets.QMessageBox.information(
                    self,
                    "Xuất JSON Thành Công!",
                    f"Đã lưu bố cục của đại ca vào:\n{path}\n\nĐại ca có thể gửi file này cho AI để áp dụng trực tiếp!"
                )
            except Exception as e:
                QtWidgets.QMessageBox.critical(self, "Lỗi Xuất File", f"Không thể lưu file JSON:\n{e}")

    def _import_json(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Nhập cấu hình bố cục JSON", "", "JSON File (*.json)"
        )
        if path:
            try:
                data = json.loads(Path(path).read_text(encoding="utf-8"))
                self.from_layout_dict(data)
                QtWidgets.QMessageBox.information(self, "Nạp Thành Công", f"Đã nạp bố cục từ file:\n{path}")
            except Exception as e:
                QtWidgets.QMessageBox.critical(self, "Lỗi Nạp File", f"Không thể đọc file JSON:\n{e}")
