"""Construction Graph V4 Node Workspace for Qt 6 / PySide6.

Features:
- Parametric curve graph node list, operators and typed connections
- Robust Preset loading using make_preset (no AttributeError, no callable confusion)
- Node add, delete, parameter modification, import/export JSON
- Asynchronous Preview and atomic Apply to active tile
"""
from __future__ import annotations
import json
from pathlib import Path
from copy import deepcopy
from typing import Any
from PySide6 import QtCore, QtGui, QtWidgets
from PIL.ImageQt import ImageQt
from .viewport import QtViewportHost
from .live_workspace import LiveWorkspaceMixin
from .inspector import QtPropertyGroup
from .slider import QtNumberSlider
from .theme import TOKENS

from fiberstrand.construction.presets import PRESETS, make_preset
from fiberstrand.construction.core import OPS, normalize_graph, GraphEvaluator, GraphError
from fiberstrand.raster import render_tile



class QtConstructionGraph(LiveWorkspaceMixin, QtWidgets.QWidget):
    graphApplied = QtCore.Signal(str) # tile_id

    def __init__(self, controller, parent: QtWidgets.QWidget | None = None):
        super().__init__(parent)
        self.controller = controller
        self.current_tile = controller.current_tile()
        
        # Load or create active graph
        if self.current_tile and getattr(self.current_tile, 'construction_graph', None):
            self.graph = deepcopy(self.current_tile.construction_graph)
        else:
            self.graph = make_preset(list(PRESETS.keys())[0])

        self.selected_node_id: str | None = None
        self._graph_undo=[];self._graph_redo=[]
        self._interactive_burst: tuple[str, float] | None = None

        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.splitter = QtWidgets.QSplitter(QtCore.Qt.Orientation.Horizontal, self)
        self.splitter.setStyleSheet(f"QSplitter::handle {{ background-color: {TOKENS['border']}; width: 2px; }}")

        # 1. Left Sidebar: Node Operators
        sidebar = QtWidgets.QWidget(self.splitter)
        sidebar.setMinimumWidth(180)
        sidebar.setStyleSheet(f"background-color: {TOKENS['bg_panel']};")
        sb_layout = QtWidgets.QVBoxLayout(sidebar)
        sb_layout.setContentsMargins(10, 12, 10, 10)
        sb_layout.setSpacing(8)

        lbl_hdr = QtWidgets.QHBoxLayout()
        lbl = QtWidgets.QLabel("▤ NODE OPERATORS", sidebar)
        lbl.setStyleSheet(f"color: {TOKENS['cyan']}; font-weight: 700; font-size: 11px;")
        lbl_hdr.addWidget(lbl)
        lbl_hdr.addStretch(1)
        btn_filter = QtWidgets.QPushButton("☰", sidebar)
        btn_filter.setFixedSize(22, 22)
        lbl_hdr.addWidget(btn_filter)
        sb_layout.addLayout(lbl_hdr)

        op_row = QtWidgets.QHBoxLayout()
        self.op_combo = QtWidgets.QComboBox(sidebar)
        self.op_combo.addItems(list(OPS.keys()))
        btn_add = QtWidgets.QPushButton("+ Add", sidebar)
        btn_add.clicked.connect(self._add_node)
        btn_del = QtWidgets.QPushButton("Delete", sidebar)
        btn_del.clicked.connect(self._delete_node)
        op_row.addWidget(self.op_combo, 1)
        op_row.addWidget(btn_add)
        op_row.addWidget(btn_del)
        sb_layout.addLayout(op_row)

        self.node_list = QtWidgets.QListWidget(sidebar)
        self.node_list.setStyleSheet(f"background-color: {TOKENS['bg_control']}; border: 1px solid {TOKENS['border']}; border-radius: 4px;")
        self.node_list.currentRowChanged.connect(self._on_node_selected)
        sb_layout.addWidget(self.node_list)

        sb_layout.addStretch(1)
        self.splitter.addWidget(sidebar)

        # 2. Center: Live Preview & Graph Control Bar
        center_widget = QtWidgets.QWidget(self)
        center_layout = QtWidgets.QVBoxLayout(center_widget)
        center_layout.setContentsMargins(8, 8, 8, 8)
        center_layout.setSpacing(6)

        header = QtWidgets.QHBoxLayout()
        lbl_p = QtWidgets.QLabel("Preset:", center_widget)
        lbl_p.setStyleSheet(f"color: {TOKENS['text_muted']};")
        header.addWidget(lbl_p)

        self.preset_combo = QtWidgets.QComboBox(center_widget)
        self.preset_combo.addItems(list(PRESETS.keys()))
        header.addWidget(self.preset_combo)

        btn_load = QtWidgets.QPushButton("Load Preset", center_widget)
        btn_load.clicked.connect(self._load_preset)
        header.addWidget(btn_load)

        btn_import = QtWidgets.QPushButton("Import JSON", center_widget)
        btn_import.clicked.connect(self._import_json)
        btn_export = QtWidgets.QPushButton("Export JSON", center_widget)
        btn_export.clicked.connect(self._export_json)
        header.addWidget(btn_import)
        header.addWidget(btn_export)

        for label,callback in (("Undo",self._undo_graph),("Redo",self._redo_graph)):
            button=QtWidgets.QPushButton(label,center_widget);button.clicked.connect(callback);header.addWidget(button)
        btn_back_fiber = QtWidgets.QPushButton("◀ Fiber Studio", center_widget)
        btn_back_fiber.setToolTip("Quay lại màn hình chính Fiber & Atlas Studio")
        btn_back_fiber.setMaximumWidth(110)
        btn_back_fiber.clicked.connect(lambda: getattr(self.window(), "_switch_workspace", lambda _: None)("fiber"))
        header.addWidget(btn_back_fiber)

        header.addStretch(1)

        btn_apply = QtWidgets.QPushButton("⚡ Apply to Tile", center_widget)
        btn_apply.setProperty("class", "primary")
        btn_apply.clicked.connect(self._apply_graph)
        header.addWidget(btn_apply)

        center_layout.addLayout(header)

        # Sub-tabs: Construction Graph & Graph Settings
        tabs_bar = QtWidgets.QHBoxLayout()
        btn_tab_graph = QtWidgets.QPushButton("☁ Construction Graph", center_widget)
        btn_tab_graph.setProperty("class", "workspace_pill_active")
        btn_tab_settings = QtWidgets.QPushButton("⚙ Graph Settings", center_widget)
        btn_tab_settings.setProperty("class", "workspace_pill")
        tabs_bar.addWidget(btn_tab_graph)
        tabs_bar.addWidget(btn_tab_settings)
        tabs_bar.addStretch(1)
        center_layout.addLayout(tabs_bar)

        self.viewport = QtViewportHost(center_widget)
        self.viewport.set_empty_label("Evaluating Construction Graph...")
        self.viewport.frameRequested.connect(self.viewport.fit_view)
        self.viewport.undoRequested.connect(self._undo_graph)
        self.viewport.redoRequested.connect(self._redo_graph)
        self.viewport.tabToggleRequested.connect(self._toggle_inspector)
        self.viewport.deleteRequested.connect(self._delete_node)
        center_layout.addWidget(self.viewport, 1)

        # Bottom Bar: Zoom & Canvas Grid Tools
        bottom_bar = QtWidgets.QHBoxLayout()
        for icon_s, tip, action_cb in [
            ("⛶", "Fit View [F]", self.viewport.fit_view),
            ("＋", "Zoom In (+25%)", lambda: self._zoom_step(1.25)),
            ("－", "Zoom Out (-25%)", lambda: self._zoom_step(0.8)),
            ("1:1", "Reset Zoom (100%)", lambda: self._set_zoom_factor(1.0)),
            ("⊡", "Focus Center", self.viewport.fit_view),
            ("▦", "Toggle Orientation Cube", lambda: self.viewport.set_orientation_cube(not getattr(self.viewport, '_show_cube', False)))
        ]:
            tb = QtWidgets.QToolButton(center_widget)
            tb.setText(icon_s)
            tb.setToolTip(tip)
            tb.setFixedSize(24, 22)
            tb.clicked.connect(action_cb)
            bottom_bar.addWidget(tb)

        bottom_bar.addStretch(1)
        lbl_zoom = QtWidgets.QLabel("Zoom:", center_widget)
        lbl_zoom.setStyleSheet(f"color: {TOKENS['text_muted']};")
        bottom_bar.addWidget(lbl_zoom)

        self.combo_zoom = QtWidgets.QComboBox(center_widget)
        self.combo_zoom.addItems(["100%", "75%", "50%", "150%", "200%"])
        self.combo_zoom.currentTextChanged.connect(self._on_zoom_combo_changed)
        bottom_bar.addWidget(self.combo_zoom)
        center_layout.addLayout(bottom_bar)

        self.splitter.addWidget(center_widget)

        # 3. Right: Node Parameters Inspector
        self.inspector_scroll = QtWidgets.QScrollArea(self.splitter)
        self.inspector_scroll.setWidgetResizable(True)
        self.inspector_scroll.setMinimumWidth(260)
        self.inspector_scroll.setStyleSheet(f"background-color: {TOKENS['bg_panel']}; border: none;")

        self.inspector_content = QtWidgets.QWidget()
        self.insp_layout = QtWidgets.QVBoxLayout(self.inspector_content)
        self.insp_layout.setContentsMargins(10, 10, 10, 10)
        self.insp_layout.setSpacing(8)

        self.inspector_scroll.setWidget(self.inspector_content)
        self.splitter.addWidget(self.inspector_scroll)

        self.splitter.setHandleWidth(6)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setStretchFactor(2, 0)
        self.splitter.setSizes([260, 840, 320])

        layout.addWidget(self.splitter)

        # Sync with controller events
        self.controller.tilesChanged.connect(self._on_tiles_changed)
        self.controller.activeTileChanged.connect(lambda _tid:self._on_tiles_changed())

        self._setup_live_workspace(True)
        self._refresh_nodes_list()
        self._request_preview()

    def _on_tiles_changed(self):
        self.current_tile = self.controller.current_tile()
        if self.current_tile is not None:
            if getattr(self.current_tile, 'construction_graph', None):
                self.graph = deepcopy(self.current_tile.construction_graph)
            else:self.graph=make_preset(next(iter(PRESETS)))
            self._graph_undo.clear();self._graph_redo.clear()
            self._refresh_nodes_list()
            self._request_preview()

    def _checkpoint_graph(self, interactive_key: str | None = None):
        if interactive_key:
            import time
            now = time.monotonic()
            last = getattr(self, '_interactive_burst', None)
            if last and last[0] == interactive_key and (now - last[1]) < 0.35:
                self._interactive_burst = (interactive_key, now)
                return
            self._interactive_burst = (interactive_key, now)
        else:
            self._interactive_burst = None
        self._graph_undo.append(deepcopy(self.graph));self._graph_undo=self._graph_undo[-50:];self._graph_redo.clear()

    def _zoom_step(self, factor: float):
        self.viewport._view_zoom = max(1e-4, min(1e4, getattr(self.viewport, '_view_zoom', 1.0) * factor))
        self.viewport.update()

    def _set_zoom_factor(self, factor: float):
        self.viewport._view_zoom = factor
        self.viewport.update()

    def _on_zoom_combo_changed(self, text: str):
        try:
            pct = float(text.replace("%", "").strip())
            self._set_zoom_factor(pct / 100.0)
        except Exception:
            pass

    def _toggle_inspector(self):
        vis = not self.inspector_scroll.isVisible()
        self.inspector_scroll.setVisible(vis)

    def _undo_graph(self):
        if not self._graph_undo:return
        self._graph_redo.append(deepcopy(self.graph));self.graph=self._graph_undo.pop();self._refresh_nodes_list();self._request_preview()

    def _redo_graph(self):
        if not self._graph_redo:return
        self._graph_undo.append(deepcopy(self.graph));self.graph=self._graph_redo.pop();self._refresh_nodes_list();self._request_preview()

    def _edit_node_json(self,nid,key,text):
        try:
            value=json.loads(text)
            if not isinstance(value,dict):raise ValueError('Expected JSON object')
            candidate=deepcopy(self.graph)
            node=next(n for n in candidate['nodes'] if n['id']==nid);node[key]=value
            normalize_graph(candidate)
            self._checkpoint_graph();self.graph=candidate;self._refresh_nodes_list();self._request_preview()
        except Exception as error:QtWidgets.QMessageBox.warning(self,'Graph edit',str(error))

    def _set_output(self,nid):
        candidate=deepcopy(self.graph);candidate['output']=nid
        try:normalize_graph(candidate)
        except Exception as error:QtWidgets.QMessageBox.warning(self,'Graph output',str(error));return
        self._checkpoint_graph();self.graph=candidate;self._request_preview()

    def _refresh_nodes_list(self):
        self.node_list.clear()
        ops_icons = {"fiber_source": "🌿", "curl": "🌀", "clump": "🌾", "output": "📤"}
        nodes = self.graph.get("nodes", [])
        for n in nodes:
            nid = n.get("id", "node")
            nop = n.get("op", "op")
            icon_s = ops_icons.get(nop, "▤")
            self.node_list.addItem(f"▶  {icon_s}  {nid}   ({nop})         👁")
        if nodes:
            self.node_list.setCurrentRow(len(nodes) - 1)

    def _on_node_selected(self, row: int):
        nodes = self.graph.get("nodes", [])
        if 0 <= row < len(nodes):
            node = nodes[row]
            self.selected_node_id = node.get("id")
            self._build_node_inspector(node)

    def _build_node_inspector(self, node: dict):
        # Clear existing inspector controls
        while self.insp_layout.count():
            item = self.insp_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        nid = node.get("id", "")
        nop = node.get("op", "")
        params = node.get("params", {})

        ops_icons = {"fiber_source": "🌿", "curl": "🌀", "clump": "🌾", "output": "📤"}
        icon_s = ops_icons.get(nop, "▤")

        lbl_op = QtWidgets.QLabel(f"Operator:  {icon_s} {nid} ({nop})", self.inspector_content)
        lbl_op.setStyleSheet(f"color: {TOKENS['cyan']}; font-weight: 700; font-size: 11px;")
        self.insp_layout.addWidget(lbl_op)

        grp = QtPropertyGroup("OPERATOR PARAMETERS", self.inspector_content)

        PARAM_BOUNDS = {
            'count': (1.0, 5000.0, 1.0, True),
            'points': (4.0, 160.0, 1.0, True),
            'points_per_curve': (4.0, 96.0, 1.0, True),
            'limit': (1.0, 1000.0, 1.0, True),
            'seed': (0.0, 100.0, 1.0, True),
            'waves': (0.5, 20.0, 0.5, False),
            'length': (0.01, 3.0, 0.01, False),
            'width': (0.1, 15.0, 0.05, False),
            'bend': (-1.5, 1.5, 0.01, False),
            'curl': (0.0, 1.0, 0.01, False),
            'frizz': (0.0, 1.0, 0.01, False),
            'angle': (-180.0, 180.0, 1.0, False),
            'x0': (0.0, 1.0, 0.01, False),
            'y0': (0.0, 1.0, 0.01, False),
            'x1': (0.0, 1.0, 0.01, False),
            'y1': (0.0, 1.0, 0.01, False),
            'x_min': (0.0, 1.0, 0.01, False),
            'x_max': (0.0, 1.0, 0.01, False),
            'y_min': (0.0, 1.0, 0.01, False),
            'y_max': (0.0, 1.0, 0.01, False),
            'start': (0.0, 1.0, 0.01, False),
            'end': (0.0, 1.0, 0.01, False),
            'offset': (-1.0, 1.0, 0.01, False),
            'root_scale': (0.0, 5.0, 0.05, False),
            'tip_ratio': (0.0, 1.0, 0.01, False),
            'power': (0.1, 6.0, 0.05, False),
            'scale': (0.01, 3.0, 0.01, False),
            'center_x': (0.0, 1.0, 0.01, False),
            'center_y': (0.0, 1.0, 0.01, False),
            'radius_x': (0.01, 1.0, 0.01, False),
            'radius_y': (0.01, 1.0, 0.01, False),
            'skew': (-1.0, 1.0, 0.01, False),
            'strength': (0.0, 1.0, 0.01, False),
            'threshold': (0.0, 1.0, 0.01, False),
            'frequency': (0.1, 30.0, 0.1, False),
            'phase': (0.0, 6.28, 0.05, False),
            'value': (0.0, 10.0, 0.05, False),
        }

        CHOICE_PARAMS = {
            'side': ['both', 'left', 'right'],
            'mode': ['eye', 'stripes', 'gradient', 'noise', 'constant', 'radial'],
            'axes': ['xy', 'xz', 'yz'],
            'envelope': ['none', 'feather'],
            'axis': ['y', 'x'],
        }

        # Build controls using Qt UI Family controls
        for p_name, p_val in params.items():
            disp_label = p_name.replace("_", " ").title()
            if isinstance(p_val, bool):
                chk = QtWidgets.QCheckBox(grp.content_widget)
                chk.setChecked(p_val)
                chk.toggled.connect(lambda v, pn=p_name: self._on_param_changed(pn, v))
                grp.add_row(disp_label, chk)
            elif isinstance(p_val, str) and (p_val.startswith("#") or "color" in p_name.lower()):
                grp.add_color_picker(
                    disp_label, p_val,
                    callback=lambda c, pn=p_name: self._on_color_param_changed(pn, c)
                )
            elif p_name in CHOICE_PARAMS and isinstance(p_val, str):
                cb = QtWidgets.QComboBox(grp.content_widget)
                items = list(CHOICE_PARAMS[p_name])
                if p_val not in items:
                    items.insert(0, p_val)
                cb.addItems(items)
                cb.setCurrentText(p_val)
                cb.currentTextChanged.connect(lambda v, pn=p_name: self._on_param_changed(pn, v))
                grp.add_row(disp_label, cb)
            elif isinstance(p_val, (int, float)):
                if p_name in PARAM_BOUNDS:
                    min_v, max_v, step_v, is_int = PARAM_BOUNDS[p_name]
                else:
                    is_int = isinstance(p_val, int) and not isinstance(p_val, bool)
                    min_v = 0.0 if p_val >= 0 else float(p_val) * 2.0
                    max_v = max(1.0, float(p_val) * 2.5) if p_val != 0 else 1.0
                    step_v = 1.0 if is_int else 0.01
                grp.add_slider(
                    disp_label, min_v, max_v, float(p_val),
                    step=step_v,
                    is_integer=is_int,
                    callback=lambda v, pn=p_name, integer=is_int: self._on_param_changed(pn, int(round(v)) if integer else v)
                )
            elif isinstance(p_val, str):
                edit = QtWidgets.QLineEdit(p_val, grp.content_widget)
                edit.textChanged.connect(lambda t, pn=p_name: self._on_param_changed(pn, t))
                grp.add_row(disp_label, edit)
            elif isinstance(p_val, (dict, list)):
                btn_struct = QtWidgets.QPushButton(f"Edit {disp_label}…", grp.content_widget)
                btn_struct.clicked.connect(lambda checked=False, pn=p_name: self._edit_structured_param(pn))
                grp.add_row(disp_label, btn_struct)

        self.insp_layout.addWidget(grp)

        # Connection ports group
        ports = OPS[nop].ports if nop in OPS else {}
        if ports:
            grp_ports = QtPropertyGroup("NODE INPUTS", self.inspector_content)
            all_nodes = self.graph.get("nodes", [])
            for port, kind in ports.items():
                combo = QtWidgets.QComboBox(grp_ports.content_widget)
                combo.addItem("Unconnected", None)
                for other in all_nodes:
                    if other.get("id") != nid and OPS.get(other.get("op", ""), None) and OPS[other["op"]].output == kind:
                        combo.addItem(other["id"], other["id"])
                curr_inp = node.get("inputs", {}).get(port)
                idx = combo.findData(curr_inp)
                combo.setCurrentIndex(max(0, idx))
                combo.activated.connect(lambda index, p=port, c=combo: self._on_input_port_changed(p, c.currentData()))
                grp_ports.add_row(f"{port.title()} ({kind})", combo)
            self.insp_layout.addWidget(grp_ports)

        # Output Action Button
        grp_actions = QtPropertyGroup("OPERATOR ACTIONS", self.inspector_content)
        output = QtWidgets.QPushButton("Use as Graph Output", grp_actions.content_widget)
        can_out = (nop in OPS and OPS[nop].output == "curves")
        output.setEnabled(can_out)
        output.clicked.connect(lambda: self._set_output(nid))
        grp_actions.layout.addWidget(output)
        self.insp_layout.addWidget(grp_actions)

        self.insp_layout.addStretch(1)

    def _edit_structured_param(self, param: str):
        node = next((n for n in self.graph.get("nodes", []) if n.get("id") == self.selected_node_id), None)
        if not node:
            return
        val = node.get("params", {}).get(param, {})
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle(f"Edit {param} (JSON)")
        dialog.resize(700, 500)
        l = QtWidgets.QVBoxLayout(dialog)
        text = QtWidgets.QPlainTextEdit(json.dumps(val, ensure_ascii=False, indent=2), dialog)
        l.addWidget(text)
        bbox = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.StandardButton.Ok | QtWidgets.QDialogButtonBox.StandardButton.Cancel, dialog)
        l.addWidget(bbox)
        bbox.accepted.connect(dialog.accept)
        bbox.rejected.connect(dialog.reject)
        if dialog.exec():
            try:
                parsed = json.loads(text.toPlainText())
                self._on_param_changed(param, parsed)
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "JSON Parse Error", str(e))

    def _on_input_port_changed(self, port: str, source_id: str | None):
        self._checkpoint_graph(f"input:{self.selected_node_id}:{port}")
        for n in self.graph.get("nodes", []):
            if n.get("id") == self.selected_node_id:
                inputs = n.setdefault("inputs", {})
                if source_id is None:
                    inputs.pop(port, None)
                else:
                    inputs[port] = source_id
                break
        self._request_preview()

    def _on_color_param_changed(self, param: str, hex_color: str):
        self._checkpoint_graph(f"color:{self.selected_node_id}:{param}")
        for n in self.graph.get("nodes", []):
            if n.get("id") == self.selected_node_id:
                n.setdefault("params", {})[param] = hex_color
                break
        self._request_preview()

    def _on_param_changed(self, param: str, val: Any):
        self._checkpoint_graph(f"param:{self.selected_node_id}:{param}")
        for n in self.graph.get("nodes", []):
            if n.get("id") == self.selected_node_id:
                n.setdefault("params", {})[param] = val
                break
        self._request_preview()

    def _add_node(self):
        op = self.op_combo.currentText()
        self._checkpoint_graph()
        nodes = self.graph.setdefault("nodes", [])
        import uuid
        new_id = "node_"+uuid.uuid4().hex[:12]
        inputs={}
        for port,kind in OPS[op].ports.items():
            matches=[n for n in nodes if OPS[n["op"]].output==kind]
            if matches:inputs[port]=matches[-1]["id"]
        nodes.append({"id": new_id, "op": op, "params": deepcopy(OPS[op].defaults),"inputs":inputs})
        if OPS[op].output=="curves":self.graph["output"]=new_id
        self._refresh_nodes_list()
        self._request_preview()

    def _delete_node(self):
        nodes = self.graph.get("nodes", [])
        row = self.node_list.currentRow()
        if 0 <= row < len(nodes) and len(nodes) > 1:
            self._checkpoint_graph()
            removed=nodes[row]["id"]
            del nodes[row]
            for node in nodes:
                node["inputs"]={k:v for k,v in node.get("inputs",{}).items() if v!=removed}
            if self.graph.get("output")==removed:self.graph["output"]=nodes[-1]["id"]
            self._refresh_nodes_list()
            self._request_preview()

    def _load_preset(self):
        name = self.preset_combo.currentText()
        if name in PRESETS:
            self._checkpoint_graph()
            self.graph = make_preset(name)
            self._refresh_nodes_list()
            self._request_preview()

    def _import_json(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Import Graph JSON", "", "JSON (*.json)")
        if path:
            try:
                data = json.loads(Path(path).read_text(encoding="utf-8"))
                normalize_graph(data)
                self._checkpoint_graph()
                self.graph = data
                self._refresh_nodes_list()
                self._request_preview()
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "Import Error", f"Failed to import graph:\n{e}")

    def _export_json(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Export Graph JSON", "construction_graph.json", "JSON (*.json)")
        if path:
            try:
                Path(path).write_text(json.dumps(self.graph, indent=2, ensure_ascii=False), encoding="utf-8")
                QtWidgets.QMessageBox.information(self, "Exported", f"Saved graph to:\n{path}")
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "Export Error", f"Failed to export graph:\n{e}")

    def _request_preview(self):
        if self.current_tile:
            normalize_graph(self.graph)
            self._request_live_preview()

    def _apply_graph(self, show_dialog: bool = True):
        """Apply edited graph to active project tile."""
        if self.current_tile:
            normalize_graph(self.graph)
            self.controller.snapshot()
            self.current_tile.construction_graph = deepcopy(self.graph)
            self.current_tile.revision += 1
            self.controller.tileUpdated.emit(self.current_tile.id)
            self.controller.graphApplied.emit(self.current_tile.id)
            self.controller.mark_dirty(True)
            self.graphApplied.emit(self.current_tile.id)
            if show_dialog:
                QtWidgets.QMessageBox.information(self, "Graph Applied", f"Successfully applied Construction Graph to {self.current_tile.name}!")



# Alias for studio naming consistency
QtConstructionStudio = QtConstructionGraph
