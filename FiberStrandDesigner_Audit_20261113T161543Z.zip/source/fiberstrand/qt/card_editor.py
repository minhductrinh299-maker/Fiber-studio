"""Card Editor 3D Workspace for Qt 6 / PySide6.

Features:
- Hair card list outliner with multi-selection
- Atlas tile assignment to cards
- Component selection (Card, Root, Row, Vertex, Edge, Face)
- Mode pills (Select, Groom, Shape, Mesh)
- Live interactive 3D perspective wireframe mesh preview with unique ID guarantees
- Direct synchronization with AppController Single Source of Truth
"""
from __future__ import annotations
import math
import numpy as np
from typing import Any
from PySide6 import QtCore, QtGui, QtWidgets
from .viewport import QtViewportHost
from .legacy_card_viewport import LegacyCardViewportMixin
from .inspector import QtPropertyGroup
from .slider import QtNumberSlider
from .theme import TOKENS

from fiberstrand.cards import HairCard, ribbon_mesh


class QtCardEditor(LegacyCardViewportMixin, QtWidgets.QWidget):
    cardsModified = QtCore.Signal()

    def __init__(self, controller, parent: QtWidgets.QWidget | None = None):
        super().__init__(parent)
        self.controller = controller
        self.selected_indices: set[int] = set()

        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Responsive Splitter allowing interactive horizontal resizing of sidebars & viewport
        self.splitter = QtWidgets.QSplitter(QtCore.Qt.Orientation.Horizontal, self)
        self.splitter.setStyleSheet(f"QSplitter::handle {{ background-color: {TOKENS['border']}; width: 2px; }}")

        # 1. Left Sidebar: Card Outliner & Tile Assignment
        self.sidebar = QtWidgets.QWidget(self.splitter)
        sidebar = self.sidebar
        sidebar.setMinimumWidth(180)
        sidebar.setStyleSheet(f"background-color: {TOKENS['bg_panel']};")
        sb_layout = QtWidgets.QVBoxLayout(sidebar)
        sb_layout.setContentsMargins(10, 12, 10, 10)
        sb_layout.setSpacing(8)

        lbl_hdr = QtWidgets.QHBoxLayout()
        lbl = QtWidgets.QLabel("▤ CARD OUTLINER", sidebar)
        lbl.setStyleSheet(f"color: {TOKENS['cyan']}; font-weight: 700; font-size: 11px;")
        lbl_hdr.addWidget(lbl)
        lbl_hdr.addStretch(1)
        btn_filter = QtWidgets.QPushButton("☰", sidebar)
        btn_filter.setFixedSize(22, 22)
        lbl_hdr.addWidget(btn_filter)
        sb_layout.addLayout(lbl_hdr)

        btn_row = QtWidgets.QHBoxLayout()
        btn_add = QtWidgets.QPushButton("+ Add Card", sidebar)
        btn_add.clicked.connect(self._add_card)
        btn_dup = QtWidgets.QPushButton("Duplicate", sidebar)
        btn_dup.clicked.connect(self._duplicate_card)
        btn_del = QtWidgets.QPushButton("Delete", sidebar)
        btn_del.clicked.connect(self._delete_card)
        btn_row.addWidget(btn_add)
        btn_row.addWidget(btn_dup)
        btn_row.addWidget(btn_del)
        sb_layout.addLayout(btn_row)

        # Search bar
        self.search_input = QtWidgets.QLineEdit(sidebar)
        self.search_input.setPlaceholderText("🔍 Search Cards...")
        self.search_input.setStyleSheet(f"background-color: {TOKENS['bg_control']}; border: 1px solid {TOKENS['border']}; border-radius: 4px; padding: 4px 8px;")
        self.search_input.textChanged.connect(self._on_search_text_changed)
        sb_layout.addWidget(self.search_input)

        self.card_list = QtWidgets.QListWidget(sidebar)
        self.card_list.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.ExtendedSelection)
        self.card_list.setStyleSheet(f"background-color: {TOKENS['bg_control']}; border: 1px solid {TOKENS['border']}; border-radius: 4px;")
        sb_layout.addWidget(self.card_list)
        self.card_list.itemSelectionChanged.connect(self._on_selection_changed)
        self.card_list.currentRowChanged.connect(lambda row: self._on_current_row_changed(row))

        lbl_assign = QtWidgets.QLabel("▤ ASSIGN ATLAS TILE", sidebar)
        lbl_assign.setStyleSheet(f"color: {TOKENS['cyan']}; font-weight: 700; font-size: 10px; margin-top: 10px;")
        sb_layout.addWidget(lbl_assign)

        self.tile_combo = QtWidgets.QComboBox(sidebar)
        self.tile_combo.setSizeAdjustPolicy(QtWidgets.QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.tile_combo.setMinimumContentsLength(12)
        self._refresh_tile_choices()
        sb_layout.addWidget(self.tile_combo)

        btn_assign = QtWidgets.QPushButton("🔗 Assign to Selected", sidebar)
        btn_assign.setProperty("class", "primary")
        btn_assign.clicked.connect(self._assign_tile)
        sb_layout.addWidget(btn_assign)

        sb_layout.addStretch(1)
        self.splitter.addWidget(sidebar)

        # 2. Center: 3D Viewport & Tool Pill Header
        center_widget = QtWidgets.QWidget(self)
        center_layout = QtWidgets.QVBoxLayout(center_widget)
        center_layout.setContentsMargins(8, 8, 8, 8)
        center_layout.setSpacing(6)

        header = QtWidgets.QHBoxLayout()
        self.mode_group = QtWidgets.QWidget(center_widget)
        mg_layout = QtWidgets.QHBoxLayout(self.mode_group)
        mg_layout.setContentsMargins(0, 0, 0, 0)
        mg_layout.setSpacing(2)

        self.btn_select = QtWidgets.QPushButton("↖ Select", self.mode_group)
        self.btn_groom = QtWidgets.QPushButton("🖊 Groom", self.mode_group)
        self.btn_shape = QtWidgets.QPushButton("🪢 Shape", self.mode_group)
        self.btn_mesh = QtWidgets.QPushButton("🕸 Mesh", self.mode_group)
        self.btn_shape.setProperty("class", "workspace_pill_active")

        for b in (self.btn_select, self.btn_groom, self.btn_shape, self.btn_mesh):
            mg_layout.addWidget(b)
        header.addWidget(self.mode_group)

        header.addSpacing(14)
        self.comp_combo = QtWidgets.QComboBox(center_widget)
        self.comp_combo.addItems(["Card", "Root", "Row", "Vertex", "Edge", "Face"])
        header.addWidget(self.comp_combo)

        btn_render_lookdev = QtWidgets.QPushButton("✨ GPU Lookdev", center_widget)
        btn_render_lookdev.setToolTip("Chuyển nhanh sang chế độ GPU Lookdev & Studio Lighting của mô hình tóc")
        btn_render_lookdev.clicked.connect(lambda: getattr(self.window(), "_switch_workspace", lambda _: None)("render"))
        header.addWidget(btn_render_lookdev)

        header.addStretch(1)
        btn_frame = QtWidgets.QPushButton("⛶ Frame [F]", center_widget)
        btn_frame.clicked.connect(self._frame_selected)
        header.addWidget(btn_frame)

        card_header_tools = [
            ("⌖", "Focus Center (Origin)", lambda: self._focus_origin()),
            ("▦", "Toggle Wireframe", lambda: self._toggle_wireframe()),
            ("⚪", "Shading Mode: Lit / Flat", lambda: self._toggle_shading()),
            ("⛶", "Toggle Fullscreen / Maximize", lambda: self._toggle_maximize())
        ]
        for icon_s, tip, action_cb in card_header_tools:
            tb = QtWidgets.QToolButton(center_widget)
            tb.setText(icon_s)
            tb.setToolTip(tip)
            tb.setFixedSize(26, 24)
            tb.clicked.connect(action_cb)
            header.addWidget(tb)

        center_layout.addLayout(header)

        self.viewport = QtViewportHost(center_widget)
        self.viewport.orbitChanged.connect(self._on_orbit)
        self.viewport.panChanged.connect(self._on_pan)
        self.viewport.dollyChanged.connect(self._on_dolly)
        self.viewport.wheelZoomed.connect(self._on_wheel_zoom)
        self.viewport.frameRequested.connect(self._frame_selected)
        self.viewport.cancelRequested.connect(self._cancel_interaction)
        self.viewport.toolActionRequested.connect(self._on_tool_requested)
        self.viewport.componentRequested.connect(self._on_component_requested)
        self.viewport.undoRequested.connect(self.controller.undo)
        self.viewport.redoRequested.connect(self.controller.redo)
        self.viewport.duplicateRequested.connect(self._duplicate_card)
        self.viewport.deleteRequested.connect(self._delete_card)
        self.viewport.selectAllRequested.connect(self._select_all_cards)
        self.viewport.tabToggleRequested.connect(self._toggle_inspector)
        center_layout.addWidget(self.viewport, 1)

        self.splitter.addWidget(center_widget)

        # 3. Right: Card Parameters Inspector
        self.inspector_scroll = QtWidgets.QScrollArea(self.splitter)
        self.inspector_scroll.setWidgetResizable(True)
        self.inspector_scroll.setMinimumWidth(260)
        self.inspector_scroll.setStyleSheet(f"background-color: {TOKENS['bg_panel']}; border: none;")

        self.inspector_content = QtWidgets.QWidget()
        self.insp_layout = QtWidgets.QVBoxLayout(self.inspector_content)
        self.insp_layout.setContentsMargins(10, 10, 10, 10)
        self.insp_layout.setSpacing(8)

        # Tab icons bar: Sliders, Cube, Hierarchy, Info
        tab_bar = QtWidgets.QHBoxLayout()
        for icon_symbol, active in [("🎚", True), ("🎲", False), ("▤", False), ("ℹ", False)]:
            b = QtWidgets.QPushButton(icon_symbol, self.inspector_content)
            b.setFixedSize(28, 26)
            if active:
                b.setProperty("class", "workspace_pill_active")
            else:
                b.setProperty("class", "workspace_pill")
            tab_bar.addWidget(b)
        tab_bar.addStretch(1)
        self.insp_layout.addLayout(tab_bar)

        self._build_card_inspector()
        self.inspector_scroll.setWidget(self.inspector_content)
        self.splitter.addWidget(self.inspector_scroll)

        # Configure responsive proportions (e.g. 260px, remaining viewport, 320px)
        self.splitter.setHandleWidth(6)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setStretchFactor(2, 0)
        self.splitter.setSizes([260, 840, 320])

        layout.addWidget(self.splitter)

        # Camera state for 3D card layout
        self.camera_yaw = -0.35
        self.camera_pitch = 0.25
        self.camera_zoom = 1.0
        self._show_grid = False

        # Controller signals
        self.controller.cardsChanged.connect(self._on_cards_changed_from_controller)
        self.controller.tilesChanged.connect(self._refresh_tile_choices)

        self._refresh_card_list()
        self._setup_legacy_card_viewport()
        self._draw_cards_wireframe()

    def _on_cards_changed_from_controller(self):
        self._refresh_card_list()
        self._draw_cards_wireframe()

    def _build_card_inspector(self):
        grp = QtPropertyGroup("CARD PARAMETERS", self.inspector_content)
        self.slider_len = grp.add_slider("Length", 0.1, 10.0, 1.28, step=0.01,
                                         callback=lambda v: self._selected_card_param("length", v))
        self.slider_width = grp.add_slider("Width", 0.01, 2.0, 0.42, step=0.01,
                                           callback=lambda v: self._selected_card_param("width", v))
        self.slider_bend = grp.add_slider("Bend", -1.0, 1.0, 0.68, step=0.01,
                                          callback=lambda v: self._selected_card_param("bend", v))
        self.slider_twist = grp.add_slider("Yaw / Twist", -180.0, 180.0, -12.0, step=1.0,
                                           format_str="{:.3f}°",
                                           callback=lambda v: self._selected_card_param("yaw", v * (math.pi / 180.0)))
        self.slider_segments = grp.add_slider("Segments", 2, 64, 16, is_integer=True,
                                             callback=lambda v: self._selected_card_param("segments", int(v)))
        self.insp_layout.addWidget(grp)
        self.insp_layout.addStretch(1)

    def _selected_card_param(self, param: str, val: Any):
        if not self.selected_indices:
            return
        self.controller.snapshot()
        self.controller.project.cards=[{**card,param:val} if i in self.selected_indices else card
                                       for i,card in enumerate(self.controller.project.cards)]
        self.controller.mark_dirty(True)
        self._draw_cards_wireframe()
        self.cardsModified.emit()

    def _on_search_text_changed(self, text: str):
        query = text.strip().lower()
        for i in range(self.card_list.count()):
            item = self.card_list.item(i)
            item.setHidden(bool(query and query not in item.text().lower()))

    def _refresh_card_list(self):
        ids=set(getattr(self,'_selected_ids',set()))
        self.card_list.blockSignals(True);self.card_list.clear()
        for i,card in enumerate(self.controller.project.cards):
            card_name = card.get('name', f'Card {i+1:03d}')
            is_sel = card['id'] in ids
            item=QtWidgets.QListWidgetItem(f"🪶  {card_name}        👁")
            item.setFlags(item.flags() | QtCore.Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(QtCore.Qt.CheckState.Checked if is_sel else QtCore.Qt.CheckState.Unchecked)
            self.card_list.addItem(item)
            item.setSelected(is_sel)
        self.card_list.blockSignals(False)
        self.selected_indices={i for i,c in enumerate(self.controller.project.cards) if c['id'] in ids}
        if self.controller.project.cards and not self.selected_indices:
            self.card_list.setCurrentRow(0)
            self.selected_indices = {0}
            self._sync_inspector_values()
        elif hasattr(self,'_gpu_view'):
            self._sync_card_selection_from_list()
            self._sync_inspector_values()

    def _refresh_tile_choices(self):
        self.tile_combo.clear()
        for tile in self.controller.project.tiles:
            self.tile_combo.addItem(f"🪶 {tile.name}   1024 × 1024", tile.id)

    def _on_current_row_changed(self, row: int):
        if 0 <= row < len(self.controller.project.cards):
            self.selected_indices = {row}
            self._sync_inspector_values()
            self._draw_cards_wireframe()

    def _on_selection_changed(self):
        rows = [item.row() for item in self.card_list.selectedIndexes()]
        self.selected_indices = set(rows)
        self._sync_inspector_values()
        self._draw_cards_wireframe()
        selected_ids = [self.controller.project.cards[i]['id'] for i in rows if 0 <= i < len(self.controller.project.cards)]
        self.controller.cardSelected.emit(selected_ids)
        if hasattr(self,"_gpu_view"):self._sync_card_selection_from_list()

    def _sync_inspector_values(self):
        if not self.selected_indices or not hasattr(self, 'slider_len'):
            return
        first_idx = next(iter(self.selected_indices))
        if 0 <= first_idx < len(self.controller.project.cards):
            card = self.controller.project.cards[first_idx]
            if hasattr(self, 'slider_len'):
                self.slider_len.setValue(card.get('length', 1.0), notify=False)
            if hasattr(self, 'slider_width'):
                self.slider_width.setValue(card.get('width', 0.2), notify=False)
            if hasattr(self, 'slider_bend'):
                self.slider_bend.setValue(card.get('bend', 0.0), notify=False)
            if hasattr(self, 'slider_twist'):
                self.slider_twist.setValue(card.get('yaw', 0.0) * (180.0 / math.pi), notify=False)
            if hasattr(self, 'slider_segments'):
                self.slider_segments.setValue(card.get('segments', 16), notify=False)

    def _on_orbit(self, dx: float, dy: float):
        return self._legacy_orbit(dx,dy)

    def _on_pan(self, dx: float, dy: float):
        return self._legacy_pan(dx,dy)

    def _on_dolly(self, delta: float):
        return self._legacy_dolly(delta)

    def _on_wheel_zoom(self, factor: float):
        return self._legacy_dolly(factor)

    def _frame_selected(self):
        return self._legacy_frame()

    def _cancel_interaction(self):
        return self._legacy_cancel()

    def _focus_origin(self):
        self._card_target[:] = [0.0, 0.7, 0.0]
        self._card_distance = 4.8
        self._schedule_card_frame()

    def _toggle_wireframe(self):
        self._set_card_wire(not getattr(self, '_show_wire', False))

    def _toggle_shading(self):
        if hasattr(self, '_gpu_view') and self._gpu_view:
            r = self._gpu_view.renderer
            r.show_wire = not getattr(r, 'show_wire', False)
            self._schedule_card_frame()

    def _toggle_maximize(self):
        is_max = self.sidebar.isHidden()
        self.sidebar.setVisible(is_max)
        self.inspector_scroll.setVisible(is_max)

    def _select_all_cards(self):
        self.card_list.selectAll()

    def _toggle_inspector(self):
        vis = not self.inspector_scroll.isVisible()
        self.inspector_scroll.setVisible(vis)

    def _on_tool_requested(self, tool: str):
        return self._card_choose_tool(tool)

    def _on_component_requested(self, comp: str):
        idx = self.comp_combo.findText(comp)
        if idx >= 0:
            self.comp_combo.setCurrentIndex(idx)

    def _add_card(self):
        tile_id = self.tile_combo.currentData()
        self.controller.add_card(tile_id)
        self.cardsModified.emit()

    def _duplicate_card(self):
        if self.selected_indices:
            new_ids = self.controller.duplicate_cards(list(self.selected_indices))
            self._card_select_ids(new_ids)
            self.cardsModified.emit()

    def _delete_card(self):
        if self.selected_indices:
            self.controller.delete_cards(list(self.selected_indices))
            self.selected_indices.clear()
            self.cardsModified.emit()

    def _assign_tile(self):
        tile_id = self.tile_combo.currentData()
        if tile_id and self.selected_indices:
            self.controller.assign_tile_to_cards(list(self.selected_indices), tile_id)
            self.cardsModified.emit()

    def _draw_cards_wireframe_fallback(self):
        """Draw interactive 3D perspective wireframe mesh preview of all cards."""
        dpr=self.viewport.devicePixelRatioF()
        w, h = max(64,round(self.viewport.width()*dpr)),max(64,round(self.viewport.height()*dpr))
        pix = QtGui.QPixmap(w, h)
        pix.fill(QtGui.QColor(TOKENS["bg_dark"]))

        painter = QtGui.QPainter(pix)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)

        # Draw 3D Ground Grid
        painter.setPen(QtGui.QColor(16, 40, 62, 140))
        cx, cy = w // 2, h // 2 + 40
        scale = min(w, h) * 0.25 * self.camera_zoom

        cos_y = math.cos(self.camera_yaw)
        sin_y = math.sin(self.camera_yaw)
        cos_p = math.cos(self.camera_pitch)
        sin_p = math.sin(self.camera_pitch)

        target = getattr(self, "_card_target", np.array([0.0, 0.5, 0.0]))
        cam_dist = max(2.0, getattr(self, "_card_distance", 14.0 if len(self.controller.project.cards) > 20 else 4.8))

        def project_pt(x, y, z):
            # Translate relative to target
            tx = x - target[0]
            ty = y - target[1]
            tz = z - target[2]
            # Rotate Y (yaw)
            rx = tx * cos_y - tz * sin_y
            rz = tx * sin_y + tz * cos_y
            # Rotate X (pitch)
            ry = ty * cos_p - rz * sin_p
            rz2 = ty * sin_p + rz * cos_p + cam_dist
            # Perspective projection
            fov = cam_dist / max(0.5, rz2)
            px = cx + rx * scale * fov + getattr(self, "_pan_x", 0.0) * dpr
            py = cy - ry * scale * fov + getattr(self, "_pan_y", 0.0) * dpr
            return QtCore.QPointF(px, py)

        # Draw grid adaptive to scene bounds (OFF by default)
        if getattr(self, "_show_grid", False):
            grid_half = 8.0 if len(self.controller.project.cards) > 20 else 2.5
            grid_step = 0.5
            steps = int(grid_half / grid_step)
            for i in range(-steps, steps + 1):
                p1 = project_pt(i * grid_step, 0, -grid_half)
                p2 = project_pt(i * grid_step, 0, grid_half)
                painter.drawLine(p1, p2)
                p3 = project_pt(-grid_half, 0, i * grid_step)
                p4 = project_pt(grid_half, 0, i * grid_step)
                painter.drawLine(p3, p4)

        # Draw Card Meshes
        total_tris = 0
        for idx, card_dict in enumerate(self.controller.project.cards):
            card = HairCard.from_dict(card_dict)
            key=repr(card_dict)
            cache=getattr(self,"_mesh_cache",{})
            if cache.get(card.id,(None,))[0]!=key:cache[card.id]=(key,ribbon_mesh(card))
            self._mesh_cache=cache
            verts, uvs, faces, rows = cache[card.id][1]
            total_tris += len(faces)

            is_sel = (idx in self.selected_indices)
            card_col = QtGui.QColor(TOKENS["cyan"]) if is_sel else QtGui.QColor("#4A88B2")
            fill_col = QtGui.QColor(0, 203, 215, 45) if is_sel else QtGui.QColor(16, 40, 62, 55)

            # Draw Triangles
            for tri in faces:
                i0 = int(tri[0])
                i1 = int(tri[1])
                i2 = int(tri[2])
                v0 = verts[i0]
                v1 = verts[i1]
                v2 = verts[i2]

                pt0 = project_pt(v0[0], v0[1], v0[2])
                pt1 = project_pt(v1[0], v1[1], v1[2])
                pt2 = project_pt(v2[0], v2[1], v2[2])

                poly = QtGui.QPolygonF([pt0, pt1, pt2])
                painter.setBrush(QtGui.QBrush(fill_col))
                painter.setPen(QtGui.QPen(card_col, 1.2 if is_sel else 0.8))
                painter.drawPolygon(poly)

            # Draw Yellow Selection Cage & Handles for Selected Cards
            if is_sel:
                painter.setPen(QtGui.QPen(QtGui.QColor("#F5C344"), 1.8))
                painter.setBrush(QtCore.Qt.BrushStyle.NoBrush)
                boundary_pts = [project_pt(verts[i][0], verts[i][1], verts[i][2]) for i in range(0, len(verts), max(1, len(verts)//12))]
                if len(boundary_pts) >= 3:
                    painter.drawPolygon(QtGui.QPolygonF(boundary_pts))
                # Draw vertex handle squares
                painter.setBrush(QtGui.QBrush(QtGui.QColor("#F5C344")))
                for pt in boundary_pts:
                    painter.drawRect(QtCore.QRectF(pt.x() - 3, pt.y() - 3, 6, 6))

                # Draw 3D Transform Gizmo at Card Pivot
                if len(verts) > 0:
                    c_x = sum(v[0] for v in verts) / len(verts)
                    c_y = sum(v[1] for v in verts) / len(verts)
                    c_z = sum(v[2] for v in verts) / len(verts)
                    p_center = project_pt(c_x, c_y, c_z)
                    p_x = project_pt(c_x + 0.35, c_y, c_z)
                    p_y = project_pt(c_x, c_y + 0.35, c_z)
                    p_z = project_pt(c_x, c_y, c_z + 0.35)

                    # Red X Axis
                    painter.setPen(QtGui.QPen(QtGui.QColor("#FF4D4D"), 2.2))
                    painter.drawLine(p_center, p_x)
                    # Green Y Axis
                    painter.setPen(QtGui.QPen(QtGui.QColor("#2ECC71"), 2.2))
                    painter.drawLine(p_center, p_y)
                    # Blue Z Axis
                    painter.setPen(QtGui.QPen(QtGui.QColor("#3498DB"), 2.2))
                    painter.drawLine(p_center, p_z)
                    # Center Gizmo Cube
                    painter.setBrush(QtGui.QBrush(QtGui.QColor("#F1C40F")))
                    painter.setPen(QtCore.Qt.PenStyle.NoPen)
                    painter.drawRect(QtCore.QRectF(p_center.x() - 4, p_center.y() - 4, 8, 8))

        # Draw Bottom-Left 3D Coordinate Axis Indicator
        ax_cx, ax_cy = 46, h - 46
        painter.setPen(QtGui.QPen(QtGui.QColor("#2ECC71"), 2.0))
        painter.drawLine(QtCore.QPointF(ax_cx, ax_cy), QtCore.QPointF(ax_cx, ax_cy - 24))
        painter.drawText(QtCore.QPointF(ax_cx - 4, ax_cy - 28), "Y")

        painter.setPen(QtGui.QPen(QtGui.QColor("#FF4D4D"), 2.0))
        painter.drawLine(QtCore.QPointF(ax_cx, ax_cy), QtCore.QPointF(ax_cx + 20, ax_cy + 10))
        painter.drawText(QtCore.QPointF(ax_cx + 24, ax_cy + 14), "X")

        painter.setPen(QtGui.QPen(QtGui.QColor("#3498DB"), 2.0))
        painter.drawLine(QtCore.QPointF(ax_cx, ax_cy), QtCore.QPointF(ax_cx - 18, ax_cy + 12))
        painter.drawText(QtCore.QPointF(ax_cx - 28, ax_cy + 16), "Z")

        painter.end()
        self.viewport.set_display_pixmap(pix)
        sel_count = len(self.selected_indices)
        self.viewport.set_hud_text(
            f"Cards: {len(self.controller.project.cards)}   Selected: {sel_count}   Tris: {total_tris:,}\n"
            f"Alt+LMB Orbit  |  Alt+RMB Dolly  |  Alt+MMB Pan"
        )

    def _draw_cards_wireframe(self):
        return self._schedule_card_frame()
