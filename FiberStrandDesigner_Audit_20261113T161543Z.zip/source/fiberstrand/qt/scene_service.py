"""Qt lifetime adapter for the existing object, animation and GPU preparation core."""
from types import SimpleNamespace
from copy import deepcopy
import math,uuid
import numpy as np
from PySide6 import QtCore,QtWidgets
from ..object_workspace import ObjectWorkspace
from ..cards import HairCard
from ..kernel.binding import bind,frame,resolved_card
from ..kernel.attachments import topology_signature

class SceneService(QtCore.QObject):
    changed=QtCore.Signal()
    message=QtCore.Signal(str)
    def __init__(self,controller,editor):
        super().__init__(editor);self.controller=controller;self.editor=editor;self.timers=set()
        owner=self
        class App:
            @property
            def project(self):return controller.project
            @property
            def _atlas(self):return controller.atlas
            @property
            def modified(self):return controller.is_dirty
            @modified.setter
            def modified(self,value):controller.mark_dirty(value)
            def _history(self):controller.snapshot()
            def after(self,ms,callback):
                timer=QtCore.QTimer(owner);timer.setSingleShot(True)
                def invoke():
                    owner.timers.discard(timer);timer.deleteLater()
                    if not controller._closed:callback()
                timer.timeout.connect(invoke);owner.timers.add(timer);timer.start(ms);return timer
            def after_cancel(self,timer):
                if timer is not None:timer.stop();owner.timers.discard(timer)
        app=App();app.card_window=SimpleNamespace(winfo_exists=lambda:True,_render_soon=lambda *args:editor._schedule_card_frame());app.render_window=None
        class Backend(ObjectWorkspace):
            def changed(self,refresh=True):
                self.revision+=1;owner.changed.emit();editor._edit_epoch+=1;editor._schedule_card_frame()
        self.backend=Backend(app)
        self.time=QtWidgets.QDoubleSpinBox(editor);self.time.setRange(0,10);self.time.setDecimals(3);self.time.setSingleStep(1/24)
        self.play=QtCore.QTimer(self);self.play.setInterval(42);self.play.timeout.connect(self._step)
        self.backend.window=SimpleNamespace(winfo_exists=lambda:not self.backend.closed,refresh=self.changed.emit,status=SimpleNamespace(set=self.message.emit),playing=False,time_scale=SimpleNamespace(configure=self._range))
        self.time.valueChanged.connect(self.backend.evaluate_time)
    def _range(self,**values):self.time.setRange(values['from_'],values['to'])
    def _step(self):
        if self.backend.pose_request!=self.backend.pose_published:return
        value=self.time.value()+1/24
        self.time.setValue(self.time.minimum() if value>self.time.maximum() else value)
    def toggle_play(self):self.play.stop() if self.play.isActive() else self.play.start()
    def import_model(self,path):
        from ..scene_import import import_scene
        project=self.controller.project
        def done(objects,revision):
            if project is not self.controller.project:return
            self.controller.snapshot();project.objects=[*project.objects,*objects];self.controller.mark_dirty();self.backend.changed()
        self.controller.submit_job('scene_import',lambda cancel:import_scene(path),done)
    def selected_objects(self,ids):return [o for o in self.backend.evaluated_objects() if o['id'] in ids]
    def scatter(self,object_id,tile_id,count=40,seed=42,length=.5,width=.12):
        obj=next((o for o in self.backend.evaluated_objects() if o['id']==object_id),None)
        if obj is None:raise ValueError('Select an imported mesh as surface target')
        if not tile_id:raise ValueError('Select a tile in Atlas Browser')
        project=self.controller.project;source_objects=project.objects;obj=deepcopy(obj)
        def worker(cancel):
            vertices=np.asarray(obj['vertices'],float);faces=np.asarray(obj['triangles'],int);tri=vertices[faces]
            areas=np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1)
            if not areas.sum()>0:raise ValueError('Surface contains no nondegenerate triangles')
            rng=np.random.default_rng(seed);indices=rng.choice(len(faces),min(10000,max(1,int(count))),p=areas/areas.sum())
            topology=topology_signature(vertices,faces);result=[]
            for index in indices:
                if cancel():raise RuntimeError('Distribution cancelled')
                u,v=rng.random(2)
                if u+v>1:u,v=1-u,1-v
                bary=[1-u-v,u,v];point=np.asarray(bary)@tri[index]
                point=point*obj.get('scale',1)+np.asarray(obj.get('position',[0,0,0]))
                normal=np.cross(tri[index,1]-tri[index,0],tri[index,2]-tri[index,0]);normal/=max(np.linalg.norm(normal),1e-12)
                card=HairCard.create(tile_id,'Surface Card',point);card.length=length*rng.uniform(.8,1.2);card.width=width;card.bend=0.;card.segments=12
                card.guide_points=[(normal*t).tolist() for t in (0,.33,.66,1)]
                anchor=dict(kind='skinned' if obj.get('animation_source') else 'surface',object_id=object_id,face=int(index),barycentric=bary,topology=topology,offset=0.,id='attachment:'+uuid.uuid4().hex)
                anchor['bind_frame']=frame(anchor,[obj]).tolist();card.attachment=anchor;result.append(card.to_dict())
            return result
        def publish(cards,revision):
            if project is not self.controller.project or source_objects is not project.objects:return
            self.controller.snapshot();project.cards=[*project.cards,*cards];self.controller.cardsChanged.emit();self.editor._card_select_ids({c['id'] for c in cards});self.backend.changed()
        self.controller.submit_job('surface_distribution',worker,publish)
    def attach(self,object_id,card_ids,kind='surface',joint=''):
        obj=next((o for o in self.backend.evaluated_objects() if o['id']==object_id),None)
        if obj is None:raise ValueError('Select a surface model in the outliner')
        cards=[HairCard.from_dict(c) for c in self.controller.project.cards if c['id'] in card_ids and not c.get('locked')]
        project=self.controller.project;source=project.cards;objects=project.objects;joints=deepcopy(self.backend.joint_poses)
        def worker(cancel):
            result=[]
            for card in cards:
                if cancel():raise RuntimeError('Attachment cancelled')
                card.attachment=bind(card,obj,card.root,kind,joint=joint,joints=joints);result.append(card.to_dict())
            return result
        def publish(result,revision):
            if project is not self.controller.project or project.cards is not source or project.objects is not objects:return
            replacement={c['id']:c for c in result};self.controller.snapshot();project.cards=[replacement.get(c['id'],c) for c in project.cards];self.controller.cardsChanged.emit()
        self.controller.submit_job('surface_attachment',worker,publish)
    def detach(self,card_ids):
        replacements={}
        for raw in self.controller.project.cards:
            if raw['id'] not in card_ids or raw.get('locked'):continue
            card=resolved_card(HairCard.from_dict(raw),self.backend.evaluated_objects(),self.backend.joint_poses,strict=True)
            if card.attachment:
                from ..cards import ribbon_mesh
                _,_,_,points=ribbon_mesh(card);card.guide_points=(points-points[0]).tolist();card.root=points[0].tolist();card.length=1.;card.bend=0.;card.attachment=None
            replacements[card.id]=card.to_dict()
        self.controller.snapshot();self.controller.project.cards=[replacements.get(c['id'],c) for c in self.controller.project.cards];self.controller.cardsChanged.emit()
    def close(self):
        self.play.stop();self.backend.close()
        for timer in tuple(self.timers):timer.stop()
        self.timers.clear()
