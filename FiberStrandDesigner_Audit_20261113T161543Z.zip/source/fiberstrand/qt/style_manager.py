"""Develop Studio: reversible family and layout editing backed by one registry."""
from copy import deepcopy
import json
from PySide6 import QtCore,QtGui,QtWidgets
from .style_registry import (SPEC_PATH,FAMILY_LABELS,UIStyleRegistry,default_spec,
    load_style_spec,save_style_spec,generate_qss_from_spec,resolved_style,widget_text)

DEFAULT_STYLE_SPEC=default_spec()

class _HighlightEdge(QtWidgets.QWidget):
    """Opaque two-pixel edge; no rubber-band/XOR fill over native GL surfaces."""
    def paintEvent(self,event):
        from .theme import TOKENS
        painter=QtGui.QPainter(self);painter.fillRect(self.rect(),QtGui.QColor(TOKENS['cyan']))

class LiveDevModeFilter(QtCore.QObject):
    def __init__(self,main_window,parent=None):
        super().__init__(parent or main_window)
        self.main_window=main_window;self.active=False;self._picked=None;self._current_hover=None
        self.highlight_edges=[]
        for i in range(4):
            edge=_HighlightEdge(main_window);edge.setObjectName('qt_develop_highlight_edge'+str(i))
            edge.setAttribute(QtCore.Qt.WidgetAttribute.WA_TransparentForMouseEvents)
            edge.setAttribute(QtCore.Qt.WidgetAttribute.WA_NoSystemBackground);edge.hide();self.highlight_edges.append(edge)
    def _hide_highlight(self):
        self._current_hover=None
        for edge in self.highlight_edges:edge.hide()
    def toggle(self):
        self.active=not self.active;self._picked=None;self._hide_highlight();return self.active
    def _target(self,watched):
        from .viewport import QtViewportHost
        node=watched
        while node is not None:
            if isinstance(node,QtViewportHost):return None
            node=node.parentWidget()
        target=watched
        while target is not None and not target.property('fsdId'):target=target.parentWidget()
        return target
    def _highlight(self,target):
        from .viewport import QtViewportHost
        if target is None or target.findChildren(QtViewportHost):self._hide_highlight();return
        rect=QtCore.QRect(target.mapTo(self.main_window,QtCore.QPoint()),target.size()).intersected(self.main_window.rect())
        ancestor=target.parentWidget()
        while ancestor is not None and ancestor is not self.main_window:
            rect=rect.intersected(QtCore.QRect(ancestor.mapTo(self.main_window,QtCore.QPoint()),ancestor.size()))
            ancestor=ancestor.parentWidget()
        if rect.isEmpty():self._hide_highlight();return
        geometries=(QtCore.QRect(rect.left(),rect.top(),rect.width(),2),QtCore.QRect(rect.left(),rect.bottom()-1,rect.width(),2),QtCore.QRect(rect.left(),rect.top(),2,rect.height()),QtCore.QRect(rect.right()-1,rect.top(),2,rect.height()))
        self._current_hover=target
        for edge,geometry in zip(self.highlight_edges,geometries):
            if edge.geometry()!=geometry:edge.setGeometry(geometry)
            if not edge.isVisible():edge.show();edge.raise_()
    def eventFilter(self,watched,event):
        if not self.active or not isinstance(watched,QtWidgets.QWidget) or watched.window() is not self.main_window:return False
        if watched in self.highlight_edges:return False
        et=event.type()
        from .viewport import QtViewportHost
        focus=QtWidgets.QApplication.focusWidget()
        if et==QtCore.QEvent.Type.Enter and isinstance(watched,QtViewportHost) and focus is not None and focus.window() is getattr(self.main_window,'_style_studio',None):
            self._hide_highlight();return True  # Hover cannot steal a Develop editor's focus.
        if et in (QtCore.QEvent.Type.Enter,QtCore.QEvent.Type.MouseMove):
            self._highlight(self._target(watched))
        elif et==QtCore.QEvent.Type.Leave and watched is self._current_hover:self._hide_highlight()
        if et==QtCore.QEvent.Type.MouseButtonPress:
            pick=event.button()==QtCore.Qt.MouseButton.RightButton or (event.button()==QtCore.Qt.MouseButton.LeftButton and event.modifiers() & QtCore.Qt.KeyboardModifier.ControlModifier and event.modifiers() & QtCore.Qt.KeyboardModifier.ShiftModifier)
            if pick:
                target=self._target(watched)
                if target is not None:self._picked=target.property('fsdId');event.accept();return True
        if self._picked and et in (QtCore.QEvent.Type.MouseButtonRelease,QtCore.QEvent.Type.ContextMenu):
            ident=self._picked
            if et==QtCore.QEvent.Type.MouseButtonRelease:
                self._picked=None;self._hide_highlight();self.main_window._open_developer_style_manager();self.main_window._style_studio.select_element(ident)
            event.accept();return True
        return False

class QtDeveloperStyleManager(QtWidgets.QDialog):
    def __init__(self,main_window=None,parent=None):
        super().__init__(parent or main_window);self.main_window=main_window
        self.registry=getattr(main_window,'ui_registry',None)
        if self.registry is None:
            if main_window is None:raise ValueError('Develop Studio cần cửa sổ ứng dụng')
            self.registry=UIStyleRegistry(main_window);main_window.ui_registry=self.registry
        self._loading=False;self._element_id=None;self.setWindowTitle('Develop Studio · UI families & layout');self.resize(1100,760)
        root=QtWidgets.QVBoxLayout(self);bar=QtWidgets.QHBoxLayout();root.addLayout(bar)
        self.status=QtWidgets.QLabel();bar.addWidget(self.status,1)
        for title,callback in [('Undo',self.registry.undo),('Redo',self.registry.redo),('Lưu thiết kế',self._save),('Bỏ thay đổi chưa lưu',self.registry.discard)]:
            button=QtWidgets.QPushButton(title);button.clicked.connect(callback);bar.addWidget(button)
        self.tabs=QtWidgets.QTabWidget();root.addWidget(self.tabs,1)
        self._build_families();self._build_elements();self._build_palette();self._build_json()
        self.registry.changed.connect(self._sync)
        self.registry.inventoryChanged.connect(self._refresh_inventory)
        self._style_own_controls()
        self._sync()
    @property
    def spec(self):return self.registry.spec
    def _style_own_controls(self):
        for widget in self.findChildren(QtWidgets.QWidget):
            if widget in self.examples:continue
            if isinstance(widget,(QtWidgets.QAbstractButton,QtWidgets.QLineEdit,QtWidgets.QComboBox,QtWidgets.QAbstractSpinBox,QtWidgets.QAbstractItemView,QtWidgets.QLabel,QtWidgets.QTabBar)):
                widget.setProperty('fsdFamily',self.registry.family_for(widget))

    def keyPressEvent(self,event):
        mods=event.modifiers();key=event.key();K=QtCore.Qt.Key
        if mods & QtCore.Qt.KeyboardModifier.ControlModifier:
            if key==K.Key_S:
                focus=self.focusWidget()
                if focus:focus.clearFocus()
                self._save();event.accept();return
            focus=self.focusWidget();editing=False
            while focus is not None:
                if isinstance(focus,(QtWidgets.QLineEdit,QtWidgets.QAbstractSpinBox,QtWidgets.QComboBox,QtWidgets.QPlainTextEdit)):editing=True;break
                focus=focus.parentWidget()
            if not editing and key in (K.Key_Z,K.Key_Y):
                if key==K.Key_Y or mods & QtCore.Qt.KeyboardModifier.ShiftModifier:self.registry.redo()
                else:self.registry.undo()
                event.accept();return
        super().keyPressEvent(event)

    def _update_color_swatch(self,btn,color_str):
        resolved=color_str.strip()
        if resolved.startswith('$'):resolved=self.spec.get('colors',{}).get(resolved[1:],resolved)
        pix=QtGui.QPixmap(18,18)
        if resolved=='transparent':
            pix.fill(QtCore.Qt.GlobalColor.transparent)
            painter=QtGui.QPainter(pix)
            painter.setPen(QtGui.QPen(QtGui.QColor('#777777'),1,QtCore.Qt.PenStyle.DashLine))
            painter.drawRect(0,0,17,17)
            painter.end()
        else:
            c=QtGui.QColor(resolved)
            if not c.isValid():c=QtGui.QColor('#000000')
            pix.fill(c)
            painter=QtGui.QPainter(pix)
            painter.setPen(QtGui.QColor(0,0,0,60))
            painter.drawRect(0,0,17,17)
            painter.end()
        btn.setIcon(QtGui.QIcon(pix))
        btn.setIconSize(QtCore.QSize(18,18))
        btn.setToolTip(f'Màu hiện tại: {color_str}')

    def _button(self,label,callback,layout):
        button=QtWidgets.QPushButton(label);button.clicked.connect(callback);layout.addWidget(button);return button
    def _build_families(self):
        page=QtWidgets.QWidget();row=QtWidgets.QHBoxLayout(page);self.tabs.addTab(page,'Họ style')
        self.family_list=QtWidgets.QListWidget();row.addWidget(self.family_list,1)
        for key,label in FAMILY_LABELS.items():
            item=QtWidgets.QListWidgetItem(f'{label}  ·  {key}');item.setData(QtCore.Qt.ItemDataRole.UserRole,key);self.family_list.addItem(item)
        right=QtWidgets.QVBoxLayout();row.addLayout(right,2);self.family_description=QtWidgets.QLabel('Nhập các giá trị rồi bấm Áp dụng họ style. Lưu thiết kế để dùng cho lần mở sau. Active / hover thuộc cùng họ.');self.family_description.setWordWrap(True);right.addWidget(self.family_description)
        form=QtWidgets.QFormLayout();right.addLayout(form);self.family_numbers={};self.family_colors={};self.family_swatches={}
        for key,label,lo,hi in [('height','Chiều cao',0,999999),('radius','Bo góc',0,999999),('padding_x','Padding ngang',0,999999),('padding_y','Padding dọc',0,999999),('font_size','Cỡ chữ',1,999999),('font_weight','Độ đậm chữ',1,999999)]:
            spin=QtWidgets.QSpinBox();spin.setRange(lo,hi);spin.setKeyboardTracking(False);form.addRow(label,spin);self.family_numbers[key]=spin
        self.slider_r_button=self.family_numbers['radius']
        # Draft values commit only on Apply, never during a partial numeric edit.
        for key,label in [('background','Nền'),('foreground','Chữ'),('border','Viền'),('hover','Hover'),('active','Active / nhấn')]:
            line=QtWidgets.QComboBox();line.setEditable(True);line.addItems(['$'+k for k in self.spec['colors']]+['transparent']);
            box=QtWidgets.QWidget();layout=QtWidgets.QHBoxLayout(box);layout.setContentsMargins(0,0,0,0);layout.addWidget(line,1)
            btn=self._button('Màu…',lambda checked=False,k=key:self._pick_family_color(k),layout)
            line.currentTextChanged.connect(lambda txt,b=btn:self._update_color_swatch(b,txt))
            form.addRow(label,box);self.family_colors[key]=line;self.family_swatches[key]=btn
        examples=QtWidgets.QHBoxLayout();right.addLayout(examples);self.examples=[]
        for text in ('Normal','Hover','Active','Disabled'):
            b=QtWidgets.QPushButton(text);b.setEnabled(text!='Disabled');b.setProperty('fsdActive',text=='Active');examples.addWidget(b);self.examples.append(b)
        self._button('Áp dụng họ style',self._family_edit,right)
        self._button('Khôi phục họ này',self._reset_family,right);right.addStretch()
        self.family_list.currentRowChanged.connect(self._load_family);self.family_list.setCurrentRow(0)
    def _current_family(self):
        item=self.family_list.currentItem();return item.data(QtCore.Qt.ItemDataRole.UserRole) if item else 'button.action'
    def _load_family(self,*args):
        self._loading=True
        try:
            family=self._current_family();style=self.spec['families'][family]
            for key,spin in self.family_numbers.items():spin.setValue(style[key])
            for key,line in self.family_colors.items():
                line.setCurrentText(style[key])
                if key in self.family_swatches:self._update_color_swatch(self.family_swatches[key],style[key])
            for b in self.examples:b.setProperty('fsdFamily',family)
            qss=generate_qss_from_spec(self.spec)
            if self.styleSheet()!=qss:self.setStyleSheet(qss)
        finally:self._loading=False
    def _compat_radius(self,value):
        if self._loading:return
        # Compatibility accessor; this still edits the family, never one button.
        self._family_edit()
    def _family_edit(self,*args):
        if self._loading:return
        for spin in self.family_numbers.values():spin.interpretText()
        family=self._current_family();patch={**self.spec['families'][family],**{k:w.value() for k,w in self.family_numbers.items()},**{k:w.currentText().strip() for k,w in self.family_colors.items()}}
        try:
            trial=deepcopy(self.spec);trial['families'][family]=patch
            if family=='button.action':trial['geometry']['radius_button']=patch['radius']
            self.registry.replace(trial)
        except ValueError as e:self._error(e)
    def _pick_family_color(self,key):
        current=resolved_style(self.spec,self._current_family())[key]
        color=QtWidgets.QColorDialog.getColor(QtGui.QColor(current),self,'Chọn màu họ style')
        if color.isValid():self.family_colors[key].setCurrentText(color.name());self._family_edit()
    def _reset_family(self):self.registry.edit('families',self._current_family(),default_spec()['families'][self._current_family()])
    def _build_elements(self):
        page=QtWidgets.QWidget();row=QtWidgets.QHBoxLayout(page);self.tabs.addTab(page,'Element & bố cục')
        left=QtWidgets.QVBoxLayout();row.addLayout(left,2);self.search=QtWidgets.QLineEdit();self.search.setPlaceholderText('Tìm ID, tên hoặc họ style…');left.addWidget(self.search)
        self.tree=QtWidgets.QTreeWidget();self.tree.setHeaderLabels(['Element / nhãn','Họ style']);self.tree.header().setSectionResizeMode(0,QtWidgets.QHeaderView.ResizeMode.Stretch);self.tree.header().setSectionResizeMode(1,QtWidgets.QHeaderView.ResizeMode.ResizeToContents);left.addWidget(self.tree);self.search.textChanged.connect(self._filter_tree);self.tree.currentItemChanged.connect(self._element_selected)
        right=QtWidgets.QVBoxLayout();row.addLayout(right,2);self.element_id=QtWidgets.QLabel();self.element_id.setWordWrap(True);right.addWidget(self.element_id)
        form=QtWidgets.QFormLayout();right.addLayout(form)
        self.element_family=QtWidgets.QComboBox()
        for key,label in FAMILY_LABELS.items():self.element_family.addItem(label,key)
        self.element_text=QtWidgets.QLineEdit();self.element_tooltip=QtWidgets.QLineEdit();self.element_width=QtWidgets.QSpinBox();self.element_width.setRange(0,999999);self.element_hidden=QtWidgets.QCheckBox('Ẩn trong giao diện')
        for label,w in [('Họ style',self.element_family),('Nhãn',self.element_text),('Tooltip',self.element_tooltip),('Rộng tối thiểu',self.element_width),('',self.element_hidden)]:form.addRow(label,w)
        self._button('Áp dụng element',self._edit_element,right)
        self._button('Đồng nhất các nút đồng cấp theo họ này',self._align_peers,right)
        self._button('Bỏ override element',lambda:self.registry.edit('elements',self._element_id,None) if self._element_id else None,right)
        right.addWidget(QtWidgets.QLabel('Bố cục của container / hàng chứa element'))
        lf=QtWidgets.QFormLayout();right.addLayout(lf);self.spacing=QtWidgets.QSpinBox();self.spacing.setRange(0,999999);lf.addRow('Khoảng cách',self.spacing);self.margins=[]
        marginbox=QtWidgets.QWidget();ml=QtWidgets.QHBoxLayout(marginbox);ml.setContentsMargins(0,0,0,0)
        for name in ('Trái','Trên','Phải','Dưới'):
            spin=QtWidgets.QSpinBox();spin.setRange(0,999999);spin.setToolTip(name);ml.addWidget(spin);self.margins.append(spin)
        lf.addRow('Lề T / Tr / P / D',marginbox)
        self._button('Áp dụng spacing / lề',self._edit_layout,right)
        moves=QtWidgets.QHBoxLayout();right.addLayout(moves)
        self._button('← / ↑ Trước',lambda:self._move(-1),moves);self._button('Sau → / ↓',lambda:self._move(1),moves)
        self._button('Khôi phục bố cục nhóm',self._reset_layout,right)
        self._button('Xuất audit registry…',self._export_audit,right)
        right.addStretch()
    def _target(self):
        return next((w for ident,e,w in self.registry.widgets() if ident==self._element_id),None)
    def _element_selected(self,item,*args):
        if item is None:return
        self._element_id=item.data(0,QtCore.Qt.ItemDataRole.UserRole);self._load_element()
    def _load_element(self):
        w=self._target()
        if w is None:return
        self.element_id.setText(self._element_id);self.element_text.setText(widget_text(w));self.element_text.setEnabled(isinstance(w,(QtWidgets.QLabel,QtWidgets.QAbstractButton)))
        self.element_tooltip.setText(w.toolTip());self.element_width.setValue(w.minimumWidth());self.element_hidden.setChecked(self.spec['elements'].get(self._element_id,{}).get('hidden',False))
        self.element_family.setCurrentIndex(self.element_family.findData(w.property('fsdFamily')))
        layout=self._layout_target()
        if layout is not None:
            self.spacing.setValue(max(0,layout.spacing()));m=layout.contentsMargins()
            for spin,value in zip(self.margins,(m.left(),m.top(),m.right(),m.bottom())):spin.setValue(value)
    def _layout_target(self):
        w=self._target()
        if w is None:return None
        layout=QtWidgets.QWidget.layout(w)
        if layout is not None and layout.property('fsdLayoutId'):return layout
        layout=self.registry.peer_layout(w)
        if layout is not None and layout.property('fsdLayoutId'):return layout
        return None
    def _edit_element(self):
        if not self._element_id:return
        old=self.spec['elements'].get(self._element_id,{})
        patch={**old,'family':self.element_family.currentData(),'tooltip':self.element_tooltip.text(),'min_width':self.element_width.value(),'hidden':self.element_hidden.isChecked()}
        if self.element_text.isEnabled():patch['text']=self.element_text.text()
        trial=deepcopy(self.spec);trial['elements'][self._element_id]=patch
        w=self._target()
        if isinstance(w,(QtWidgets.QPushButton,QtWidgets.QToolButton)):
            for ident,e,peer in self.registry.widgets():
                if type(peer) is type(w) and peer.parentWidget() is w.parentWidget() and self.registry.peer_layout(peer) is self.registry.peer_layout(w):
                    trial['elements'].setdefault(ident,{})['family']=patch['family']
        self.registry.replace(trial)
    def _align_peers(self):
        w=self._target()
        if w is None or not isinstance(w,(QtWidgets.QPushButton,QtWidgets.QToolButton)):return
        trial=deepcopy(self.spec)
        for ident,e,peer in self.registry.widgets():
            if type(peer) is type(w) and self.registry.peer_layout(peer) is self.registry.peer_layout(w) and peer.parentWidget() is w.parentWidget():trial['elements'].setdefault(ident,{})['family']=self.element_family.currentData()
        self.registry.replace(trial)
    def _edit_layout(self):
        layout=self._layout_target()
        if layout is not None:
            key=layout.property('fsdLayoutId');patch={**self.spec['layouts'].get(key,{}),'spacing':self.spacing.value(),'margins':[s.value() for s in self.margins]};self.registry.edit('layouts',key,patch)
    def _reset_layout(self):
        layout=self._layout_target()
        if layout is not None:self.registry.edit('layouts',layout.property('fsdLayoutId'),None)
    def _move(self,delta):
        w=self._target();layout=self.registry.peer_layout(w) if w else None
        if not isinstance(layout,QtWidgets.QBoxLayout) or not layout.property('fsdLayoutId'):return
        order=[layout.itemAt(i).widget().property('fsdId') for i in range(layout.count()) if layout.itemAt(i).widget() and layout.itemAt(i).widget().property('fsdId')]
        ident=w.property('fsdId')
        if ident not in order:return
        i=order.index(ident);j=max(0,min(len(order)-1,i+delta));order[i],order[j]=order[j],order[i]
        key=layout.property('fsdLayoutId');patch={**self.spec['layouts'].get(key,{}),'order':order};self.registry.edit('layouts',key,patch)
    def _filter_tree(self,text):
        for i in range(self.tree.topLevelItemCount()):
            item=self.tree.topLevelItem(i);item.setHidden(text.lower() not in (item.text(0)+' '+item.text(1)+' '+str(item.data(0,QtCore.Qt.ItemDataRole.UserRole))).lower())
    def select_element(self,ident):
        self.tabs.setCurrentIndex(1)
        for i in range(self.tree.topLevelItemCount()):
            item=self.tree.topLevelItem(i)
            if item.data(0,QtCore.Qt.ItemDataRole.UserRole)==ident:self.search.clear();self.tree.setCurrentItem(item);self.tree.scrollToItem(item);break
    def _pick_palette_color(self,key):
        current=self.spec['colors'].get(key,'#000000')
        color=QtWidgets.QColorDialog.getColor(QtGui.QColor(current),self,f'Chọn màu cho {key}')
        if color.isValid():
            self.palette_fields[key].setText(color.name())
            self._change_palette(key)

    def _build_palette(self):
        page=QtWidgets.QWidget();layout=QtWidgets.QFormLayout(page);self.tabs.addTab(page,'Palette & font');self.palette_fields={};self.palette_swatches={}
        self.font_picker=QtWidgets.QFontComboBox();self.font_picker.currentFontChanged.connect(self._change_font);layout.addRow('Font toàn app',self.font_picker)
        for key in self.spec['colors']:
            line=QtWidgets.QLineEdit()
            line.editingFinished.connect(lambda k=key:self._change_palette(k))
            box=QtWidgets.QWidget();row=QtWidgets.QHBoxLayout(box);row.setContentsMargins(0,0,0,0);row.addWidget(line,1)
            btn=self._button('Màu…',lambda checked=False,k=key:self._pick_palette_color(k),row)
            line.textChanged.connect(lambda txt,b=btn:self._update_color_swatch(b,txt))
            self.palette_fields[key]=line;self.palette_swatches[key]=btn;layout.addRow(key,box)
    def _change_font(self,font):
        if self._loading:return
        self.registry.edit('typography','font_family',font.family())
    def _change_palette(self,key):
        if self._loading:return
        try:
            val=self.palette_fields[key].text().strip()
            self.registry.edit('colors',key,val)
            if key in self.palette_swatches:self._update_color_swatch(self.palette_swatches[key],val)
        except ValueError as e:self._error(e)
    def _build_json(self):
        page=QtWidgets.QWidget();layout=QtWidgets.QVBoxLayout(page);self.tabs.addTab(page,'JSON & audit');self.json_edit=QtWidgets.QPlainTextEdit();layout.addWidget(self.json_edit,1)
        actions=QtWidgets.QHBoxLayout();layout.addLayout(actions)
        self._button('Áp dụng JSON',self._apply_json,actions);self._button('Import…',self._import,actions);self._button('Export…',self._export,actions);self._button('Reset thiết kế mặc định',lambda:self.registry.replace(default_spec()),actions)
        self.audit_label=QtWidgets.QLabel();self.audit_label.setWordWrap(True);layout.addWidget(self.audit_label)
    def _refresh_inventory(self):
        # Inventory refresh must never reload drafts, JSON text or numeric editors.
        ident=self._element_id;scroll=self.tree.verticalScrollBar().value()
        self.tree.blockSignals(True);self.tree.clear()
        for key,e,w in self.registry.widgets():
            item=QtWidgets.QTreeWidgetItem([widget_text(w) or key,w.property('fsdFamily')]);item.setData(0,QtCore.Qt.ItemDataRole.UserRole,key);item.setToolTip(0,key);self.tree.addTopLevelItem(item)
            if key==ident:self.tree.setCurrentItem(item)
        self.tree.blockSignals(False);self.tree.verticalScrollBar().setValue(scroll)
        self._filter_tree(self.search.text())
        audit=self.registry.audit();self.audit_label.setText(f'{audit["element_count"]} elements · {audit["family_count"]} họ · {len(audit["issues"])} xung đột đồng cấp')

    def _sync(self):
        self._loading=True
        try:
            self.status.setText(('⚠ '+self.registry.load_error+' · ' if self.registry.load_error else '')+('● Chưa lưu · ' if self.registry.dirty else '✓ Đã lưu · ')+str(self.registry.path))
            self._refresh_inventory()
            for key,line in self.palette_fields.items():
                val=self.spec['colors'][key]
                line.setText(val)
                if key in self.palette_swatches:self._update_color_swatch(self.palette_swatches[key],val)
            self.font_picker.setCurrentFont(QtGui.QFont(self.spec['typography']['font_family']))
            self.json_edit.setPlainText(json.dumps(self.spec,ensure_ascii=False,indent=2))
            audit=self.registry.audit();self.audit_label.setText(f'{audit["element_count"]} elements · {audit["family_count"]} họ · {len(audit["issues"])} nhóm nút chưa cùng họ. Chi tiết: Xuất audit registry.')
        finally:self._loading=False
        self._load_family();self._load_element();self._filter_tree(self.search.text())
    def _save(self):
        try:self.registry.save()
        except (ValueError,OSError) as e:self._error(e)
    def _error(self,e):QtWidgets.QMessageBox.warning(self,'Thiết kế chưa được áp dụng',str(e))
    def _apply_json(self):
        try:self.registry.replace(json.loads(self.json_edit.toPlainText()))
        except (ValueError,TypeError,KeyError) as e:self._error(e)
    def _import(self):
        path,_=QtWidgets.QFileDialog.getOpenFileName(self,'Import design','','JSON (*.json)')
        if path:
            try:self.registry.replace(load_style_spec(path))
            except (ValueError,OSError,TypeError,KeyError) as e:self._error(e)
    def _export(self):
        path,_=QtWidgets.QFileDialog.getSaveFileName(self,'Export design','fsd_ui_design.json','JSON (*.json)')
        if path:
            try:save_style_spec(self.spec,path)
            except (ValueError,OSError) as e:self._error(e)
    def _export_audit(self):
        path,_=QtWidgets.QFileDialog.getSaveFileName(self,'Export registry audit','fsd_ui_audit.json','JSON (*.json)')
        if path:
            from pathlib import Path
            try:Path(path).write_text(json.dumps(self.registry.audit(),ensure_ascii=False,indent=2),encoding='utf-8')
            except OSError as e:self._error(e)
    def reject(self):
        if self.registry.dirty:
            answer=QtWidgets.QMessageBox.question(self,'Thiết kế chưa lưu','Lưu thiết kế UI trước khi đóng?',QtWidgets.QMessageBox.StandardButton.Save|QtWidgets.QMessageBox.StandardButton.Discard|QtWidgets.QMessageBox.StandardButton.Cancel)
            if answer==QtWidgets.QMessageBox.StandardButton.Cancel:return
            if answer==QtWidgets.QMessageBox.StandardButton.Save:
                try:self.registry.save()
                except (ValueError,OSError) as e:self._error(e);return
            else:self.registry.discard()
        super().reject()
