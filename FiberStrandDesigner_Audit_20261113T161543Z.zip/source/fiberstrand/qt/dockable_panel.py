"""Dockable & Detachable UI Panel System for Fiber Strand Designer.

Allows any workspace panel (Outliner, Library, Node Operators, Inspector) to:
1. Float / Detach into an independent floating tool window (for multi-monitor or free placement)
2. Dock back seamlessly into the workspace layout
3. Swap / Rearrange order (Left ◀ / ▶ Right) inside the splitter
4. Hide / Show with persistent geometry and zero data/backend impact
"""
from __future__ import annotations

from PySide6 import QtCore, QtGui, QtWidgets
from .theme import TOKENS


class FloatingPanelDialog(QtWidgets.QDialog):
    """Sleek modeless floating window for detached DCC panels."""

    closed = QtCore.Signal()

    def __init__(self, title: str, content: QtWidgets.QWidget, parent: QtWidgets.QWidget | None = None):
        super().__init__(parent, QtCore.Qt.WindowType.Tool)
        self.setWindowTitle(f"Fiber Strand Designer · {title}")
        self.resize(360, 680)
        self.setStyleSheet(f"background-color: {TOKENS['bg_panel']}; color: {TOKENS['text']};")

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Header bar with Dock button
        hdr = QtWidgets.QWidget(self)
        hdr.setFixedHeight(28)
        hdr.setStyleSheet(f"background-color: {TOKENS['bg_dark']}; border-bottom: 1px solid {TOKENS['border']};")
        hl = QtWidgets.QHBoxLayout(hdr)
        hl.setContentsMargins(8, 2, 8, 2)
        hl.setSpacing(6)

        lbl = QtWidgets.QLabel(f"⧉ {title}", hdr)
        lbl.setStyleSheet(f"color: {TOKENS['cyan']}; font-weight: 700; font-size: 11px;")
        hl.addWidget(lbl)
        hl.addStretch(1)

        btn_dock = QtWidgets.QPushButton("⤓ Gắn lại (Dock)", hdr)
        btn_dock.setToolTip("Gắn panel trở lại không gian làm việc chính")
        btn_dock.setProperty("class", "workspace_pill")
        btn_dock.clicked.connect(self.close)
        hl.addWidget(btn_dock)

        layout.addWidget(hdr)
        self.content_widget = content
        layout.addWidget(content, 1)

    def closeEvent(self, event: QtGui.QCloseEvent):
        self.closed.emit()
        event.accept()


class DockablePanelWrapper(QtWidgets.QWidget):
    """Wraps a panel widget with a DCC dock header: [Title | ◀ | ▶ | ⧉ Tách ra | ✕]."""

    dockChanged = QtCore.Signal(bool)  # is_floating

    def __init__(
        self,
        title: str,
        content: QtWidgets.QWidget,
        splitter: QtWidgets.QSplitter | None = None,
        parent: QtWidgets.QWidget | None = None,
        fixed_index: int = 0
    ):
        super().__init__(parent)
        self.title_text = title
        self.inner_content = content
        self.splitter = splitter
        self.default_index = fixed_index
        self._floating_dialog: FloatingPanelDialog | None = None
        self._is_floating = False

        self.main_layout = QtWidgets.QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)

        # 1. Dock Title Header
        self.header_bar = QtWidgets.QWidget(self)
        self.header_bar.setFixedHeight(26)
        self.header_bar.setStyleSheet(
            f"background-color: {TOKENS['bg_dark']}; border-bottom: 1px solid {TOKENS['border_subtle']};"
        )
        hb_layout = QtWidgets.QHBoxLayout(self.header_bar)
        hb_layout.setContentsMargins(8, 2, 6, 2)
        hb_layout.setSpacing(4)

        self.lbl_title = QtWidgets.QLabel(title, self.header_bar)
        self.lbl_title.setStyleSheet(f"color: {TOKENS['cyan']}; font-weight: 700; font-size: 10px; letter-spacing: 0.5px;")
        hb_layout.addWidget(self.lbl_title)
        hb_layout.addStretch(1)

        # Move Left Button
        self.btn_move_left = QtWidgets.QToolButton(self.header_bar)
        self.btn_move_left.setText("◀")
        self.btn_move_left.setToolTip("Dịch panel sang trái trong không gian làm việc")
        self.btn_move_left.setFixedSize(20, 20)
        self.btn_move_left.clicked.connect(self._move_left)
        hb_layout.addWidget(self.btn_move_left)

        # Move Right Button
        self.btn_move_right = QtWidgets.QToolButton(self.header_bar)
        self.btn_move_right.setText("▶")
        self.btn_move_right.setToolTip("Dịch panel sang phải trong không gian làm việc")
        self.btn_move_right.setFixedSize(20, 20)
        self.btn_move_right.clicked.connect(self._move_right)
        hb_layout.addWidget(self.btn_move_right)

        # Float / Detach Button
        self.btn_float = QtWidgets.QToolButton(self.header_bar)
        self.btn_float.setText("⧉")
        self.btn_float.setToolTip("Tách panel thành cửa sổ rời tự do (Float window)")
        self.btn_float.setFixedSize(20, 20)
        self.btn_float.clicked.connect(self.toggle_float)
        hb_layout.addWidget(self.btn_float)

        self.main_layout.addWidget(self.header_bar)

        # Placeholder widget shown inside layout when panel is floating
        self.placeholder = QtWidgets.QWidget(self)
        pl_layout = QtWidgets.QVBoxLayout(self.placeholder)
        pl_layout.setContentsMargins(10, 20, 10, 20)
        lbl_ph = QtWidgets.QLabel(f"⧉ {title}\n(Đang hiển thị ở cửa sổ rời)", self.placeholder)
        lbl_ph.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        lbl_ph.setStyleSheet(f"color: {TOKENS['text_muted']}; font-size: 11px;")
        pl_layout.addWidget(lbl_ph)
        btn_re_dock = QtWidgets.QPushButton("⤓ Gắn lại vào đây", self.placeholder)
        btn_re_dock.setProperty("class", "primary")
        btn_re_dock.clicked.connect(self.dock_back)
        pl_layout.addWidget(btn_re_dock, 0, QtCore.Qt.AlignmentFlag.AlignCenter)
        pl_layout.addStretch(1)
        self.placeholder.hide()

        self.main_layout.addWidget(self.inner_content, 1)
        self.main_layout.addWidget(self.placeholder, 1)

    @property
    def is_floating(self) -> bool:
        return self._is_floating

    def toggle_float(self):
        if self._is_floating:
            self.dock_back()
        else:
            self.float_out()

    def float_out(self):
        """Detach panel into an independent floating tool window."""
        if self._is_floating:
            return
        self._is_floating = True

        # Reparent content into floating dialog
        self.main_layout.removeWidget(self.inner_content)
        self.inner_content.setParent(None)
        self.placeholder.show()

        top_win = self.window()
        self._floating_dialog = FloatingPanelDialog(self.title_text, self.inner_content, parent=top_win)
        self._floating_dialog.closed.connect(self.dock_back)

        # Place floating dialog near panel's screen position
        global_pos = self.mapToGlobal(QtCore.QPoint(20, 20))
        self._floating_dialog.move(global_pos)
        self._floating_dialog.show()

        self.btn_float.setText("⤓")
        self.btn_float.setToolTip("Gắn panel trở lại layout chính")
        self.dockChanged.emit(True)

    def dock_back(self):
        """Return panel from floating window back into the workspace."""
        if not self._is_floating:
            return
        self._is_floating = False

        if self._floating_dialog is not None:
            # Safely detach content from dialog layout before closing dialog
            self._floating_dialog.layout().removeWidget(self.inner_content)
            self._floating_dialog.content_widget = None
            self._floating_dialog.close()
            self._floating_dialog.deleteLater()
            self._floating_dialog = None

        self.placeholder.hide()
        self.inner_content.setParent(self)
        self.main_layout.addWidget(self.inner_content, 1)
        self.inner_content.show()

        self.btn_float.setText("⧉")
        self.btn_float.setToolTip("Tách panel thành cửa sổ rời tự do (Float window)")
        self.dockChanged.emit(False)

    def _move_left(self):
        """Swap panel with previous sibling in splitter."""
        if self.splitter is None:
            return
        idx = self.splitter.indexOf(self)
        if idx > 0:
            target_idx = idx - 1
            sizes = self.splitter.sizes()
            self.splitter.insertWidget(target_idx, self)
            sizes[idx], sizes[target_idx] = sizes[target_idx], sizes[idx]
            self.splitter.setSizes(sizes)

    def _move_right(self):
        """Swap panel with next sibling in splitter."""
        if self.splitter is None:
            return
        idx = self.splitter.indexOf(self)
        if idx < self.splitter.count() - 1:
            target_idx = idx + 1
            sizes = self.splitter.sizes()
            # In QSplitter, inserting at target_idx moves after it
            self.splitter.insertWidget(target_idx, self)
            sizes[idx], sizes[target_idx] = sizes[target_idx], sizes[idx]
            self.splitter.setSizes(sizes)
