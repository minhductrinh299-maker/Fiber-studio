"""Fiber Studio: Tile / Graph / Atlas views sharing one project/evaluation source."""
from copy import deepcopy
import json
from pathlib import Path
from PySide6 import QtCore,QtGui,QtWidgets
from .fiber_studio import QtFiberStudio
from .construction_studio import QtConstructionGraph
from .graph_canvas import GraphCanvas
from .inspector import QtPropertyGroup
from ..model import FiberSettings,PRESETS,Tile
from ..construction.core import normalize_graph
from ..construction.presets import node
from ..engine_v2.dependencies import ALL_CHANNELS

GLOBAL_GRAPH_FIELDS={'strand_opacity','fiber_roundness','antialias','specular','anisotropy','transmission','scatter','iridescence'}
def source_node(tile):
    if not tile.construction_graph:return None
    try:
        plan=normalize_graph(tile.construction_graph)
        sources=[plan['nodes'][key] for key in plan['order'] if plan['nodes'][key]['op']=='fiber_source']
        return sources[0] if len(sources)==1 else None
    except ValueError:return None

class IntegratedFiber(QtFiberStudio):
    def _inspector_values(self):
        tile=self.current_tile
        if tile is None:return {}
        mapped=source_node(tile)
        if mapped:
            settings=FiberSettings(**mapped['params']['tile'].get('settings',{})).sanitize()
            values=dict(vars(settings))
            for key in GLOBAL_GRAPH_FIELDS:values[key]=getattr(tile.settings,key)
            return values
        return vars(tile.settings)
    def _dup_tile(self):
        tile=self.controller.current_tile()
        if tile is None:return
        self.controller.snapshot();duplicate=tile.clone();self.controller.project.tiles.append(duplicate);self.controller.set_active_tile(duplicate.id);self.controller.tilesChanged.emit()
    def _setting_changed(self,param,value):
        tile=self.current_tile
        if tile is None:return
        if not tile.construction_graph:return super()._setting_changed(param,value)
        mapped=source_node(tile)
        if param not in GLOBAL_GRAPH_FIELDS and mapped is None:
            self.controller.jobFailed.emit('Simple parameters','This graph has no single Fiber Source mapping. Edit its nodes in Graph view.');return
        self.controller.snapshot_interactive(('tile',tile.id,param))
        if param in GLOBAL_GRAPH_FIELDS:setattr(tile.settings,param,value)
        else:
            graph=deepcopy(tile.construction_graph);target=next(n for n in graph['nodes'] if n['id']==mapped['id']);settings=target['params']['tile'].setdefault('settings',{});settings[param]=value;target['params']['tile']['revision']=target['params']['tile'].get('revision',0)+1;tile.construction_graph=graph
        tile.revision+=1;self.controller.tileUpdated.emit(tile.id);self._request_preview()

class IntegratedGraph(QtConstructionGraph):
    graphChanged=QtCore.Signal()
    def __init__(self,*args,**kwargs):
        self._drafts={};self._draft_project=None;self._reading_source=True;super().__init__(*args,**kwargs);self._reading_source=False
        self.controller.tileUpdated.connect(self._source_updated)
    def _on_tiles_changed(self):
        if not self.isVisible():self._graph_source_pending=True;return
        self._graph_source_pending=False
        project=self.controller.project;tile=self.controller.current_tile()
        if self._draft_project is not project:
            self._drafts.clear();self._draft_project=project;self._loaded_source=None;self._loaded_tile=None
        previous=getattr(self,'current_tile',None)
        if tile is previous and getattr(self,'_loaded_tile',None)==(id(project),tile.id if tile else None) and getattr(self,'_loaded_source',None)==(tile.construction_graph if tile else None):
            self._request_preview();self.graphChanged.emit();return # preserve current node edits and graph history
        if previous is not None and getattr(self,'_loaded_tile',None)==(id(project),previous.id):
            self._drafts[previous.id]=(deepcopy(self.graph),deepcopy(self._graph_undo),deepcopy(self._graph_redo),deepcopy(getattr(self,'_loaded_source',None)))
        self._reading_source=True
        try:
            self.current_tile=tile;self._graph_undo=[];self._graph_redo=[]
            source=tile.construction_graph if tile else None;cached=self._drafts.get(tile.id) if tile else None
            if cached and cached[3]==source:
                self.graph,self._graph_undo,self._graph_redo=deepcopy(cached[:3])
            elif source is not None:self.graph=deepcopy(source)
            elif tile is not None:
                source_tile=deepcopy(tile);source_tile.construction_graph=None
                self.graph={'format':'fsd-construction-graph','version':1,'nodes':[node('generator','fiber_source',tile=source_tile.to_dict())],'output':'generator'}
            else:self.graph={'format':'fsd-construction-graph','version':1,'nodes':[],'output':None}
            self._loaded_tile=(id(project),tile.id if tile else None);self._loaded_source=deepcopy(source)
            self.selected_node_id=None;self._refresh_nodes_list()
            if not self.graph.get('nodes'):self._on_node_selected(-1)
            if tile is not None:self._request_preview()
        finally:self._reading_source=False
        self.graphChanged.emit()
    def _source_updated(self,tid):
        if not self.isVisible():self._graph_source_pending=True;return
        tile=self.controller.current_tile()
        if tile is None or tile.id!=tid:return
        if tile is self.current_tile and tile.construction_graph==self.graph:
            self._loaded_source=deepcopy(tile.construction_graph);return
        self._on_tiles_changed()
    def _on_node_selected(self,row):
        nodes=self.graph.get('nodes',[])
        if not 0<=row<len(nodes):
            self.selected_node_id=None
            body=QtWidgets.QWidget();layout=QtWidgets.QVBoxLayout(body)
            lbl=QtWidgets.QLabel('Tab: add a node')
            lbl.setStyleSheet("color: #9AA5B2; font-style: italic;")
            layout.addWidget(lbl)
            layout.addStretch()
            self.inspector_content=body;self.insp_layout=layout;self.inspector_scroll.setWidget(body)
            return
        node=nodes[row]
        self.selected_node_id=node.get('id')
        self._build_node_inspector(node)

    def _clear_preview(self, label='Graph is empty (add nodes or Tab)'):
        import numpy as np
        from ..engine_v2.preview import STRIDE_FLOATS
        self.controller.cancel_job('graph_live_preview')
        self._preview_strands = ()
        self._live_cached = None
        self._live_display_key = None
        self._live_display_strands = ()
        self._live_packet = None
        self.viewport.set_empty_label(label)
        if self._live_core:
            empty = np.empty((0, STRIDE_FLOATS), np.float32)
            empty.setflags(write=False)
            tile = self.current_tile
            tid = tile.id if tile else 'empty'
            rev = tile.revision if tile else 0
            size = (tile.width, tile.height) if tile else (512, 512)
            settings = tile.settings if tile else None
            self._live_core.publish(tid, rev, size, empty, settings)
        else:
            self.viewport.set_renderer_callback(None)
        self.viewport.update()

    def _request_preview(self):
        if not self.isVisible():self._graph_source_pending=True;return
        if self.current_tile is None:return
        nodes = self.graph.get('nodes', [])
        if not nodes:
            self._clear_preview('Graph is empty (add nodes or Tab)')
            self.graphChanged.emit()
            return
        try:
            normalize_graph(self.graph)
            if not getattr(self,'_reading_source',True) and self.current_tile.construction_graph and self.graph!=self.current_tile.construction_graph:
                self.controller.snapshot();self.current_tile.construction_graph=deepcopy(self.graph);self.current_tile.revision+=1;self._loaded_source=deepcopy(self.current_tile.construction_graph);self.controller.tileUpdated.emit(self.current_tile.id)
            if self.isVisible():super()._request_preview()
        except ValueError as error:
            self._clear_preview(f'Graph evaluation: {error}')
            self.controller.jobFailed.emit('Graph evaluation',str(error))
        self.graphChanged.emit()

class FiberWorkspace(QtWidgets.QWidget):
    inspectorToggle=QtCore.Signal()
    def __init__(self,controller,parent=None):
        super().__init__(parent);self.controller=controller
        self.fiber=IntegratedFiber(controller,self);self.graph=IntegratedGraph(controller,self)
        self.fiber.hide();self.graph.hide();self.viewport=self.fiber.viewport
        self.library_panel=self.fiber.sidebar;self.inspector_panel=QtWidgets.QStackedWidget();self.inspector_panel.addWidget(self.fiber.inspector_scroll);self.inspector_panel.addWidget(self.graph.inspector_scroll)
        self.atlas_inspector=QtWidgets.QScrollArea();self.atlas_inspector.setWidgetResizable(True);self.inspector_panel.addWidget(self.atlas_inspector)
        self.graph.inspector_scroll.setMinimumWidth(220);self.graph.inspector_scroll.setMaximumWidth(16777215)
        self.fiber.inspector_scroll.setMinimumWidth(220);self.fiber.inspector_scroll.setMaximumWidth(16777215)
        layout=QtWidgets.QVBoxLayout(self);layout.setContentsMargins(0,0,0,0);layout.setSpacing(4)
        row=QtWidgets.QHBoxLayout();layout.addLayout(row);self.views=QtWidgets.QTabBar();self.views.addTab('Tile');self.views.addTab('Graph');self.views.addTab('Atlas');self.views.currentChanged.connect(self.set_view);row.addWidget(self.views)
        self.fiber.map_combo.blockSignals(True);self.fiber.map_combo.clear();self.fiber.map_combo.addItem('Live Fiber GPU','live')
        for channel in ALL_CHANNELS:self.fiber.map_combo.addItem(channel)
        self.fiber.map_combo.blockSignals(False);row.addWidget(self.fiber.map_combo);row.addStretch()
        fit=QtWidgets.QPushButton('Fit · F');fit.clicked.connect(self.fit);row.addWidget(fit)
        self.center=QtWidgets.QStackedWidget();layout.addWidget(self.center,1)
        tile_page=QtWidgets.QWidget();tl=QtWidgets.QVBoxLayout(tile_page);tl.setContentsMargins(0,0,0,0);tl.addWidget(self.fiber.viewport);self.center.addWidget(tile_page)
        graph_page=QtWidgets.QWidget();gl=QtWidgets.QVBoxLayout(graph_page);gl.setContentsMargins(0,0,0,0);bar=QtWidgets.QToolBar('Graph tools');bar.setMovable(False);gl.addWidget(bar)
        bar.addWidget(self.graph.op_combo)
        for label,call in [('Add Node',self.graph._add_node),('Delete Selection',lambda:self.canvas.delete_selection()),('Open Current Tile Graph',self.convert_graph),('Import Graph',self.graph._import_json),('Export Graph',self.graph._export_json),('Use Graph for Tile',lambda:self.graph._apply_graph(False))]:
            b=QtWidgets.QPushButton(label);b.clicked.connect(call);bar.addWidget(b)
        split=QtWidgets.QSplitter(QtCore.Qt.Orientation.Horizontal);self.canvas=GraphCanvas(self.graph);split.addWidget(self.graph.viewport);split.addWidget(self.canvas);split.setSizes([320,580]);gl.addWidget(split,1);self.center.addWidget(graph_page)
        self.graph.graphChanged.connect(self._sync_graph_canvas)
        self.canvas.tileDropped.connect(self.open_tile_graph)
        self.fiber.tile_list.itemDoubleClicked.connect(lambda item:self.open_tile_graph(item.data(QtCore.Qt.ItemDataRole.UserRole)))
        self.fiber.isVisible=lambda:self.isVisible() and self.views.currentIndex()!=1
        self.graph.isVisible=lambda:self.isVisible() and self.views.currentIndex()==1
        self.fiber.current_tile=controller.current_tile();self.fiber.tile_list.setIconSize(QtCore.QSize(48,64));self.fiber.tile_list.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.CustomContextMenu);self.fiber.tile_list.customContextMenuRequested.connect(self._tile_menu)
        self.fiber.search_input.textChanged.connect(self._filter)
        self._add_library_controls()
        self.controller.activeTileChanged.connect(self._selected);self.controller.tilesChanged.connect(self._selected);self.controller.tileUpdated.connect(self._tile_changed);self.controller.atlasRebuilt.connect(self._atlas_inspector)
        self._thumb_cache={};self._thumb_timer=QtCore.QTimer(self);self._thumb_timer.setSingleShot(True);self._thumb_timer.timeout.connect(self._thumbnails)
        self.fiber.tile_list.verticalScrollBar().valueChanged.connect(lambda:self._thumb_timer.start(180))
        self._build_simple_inspector();self.set_view(0);self._thumb_timer.start(250)
        self.fiber.viewport.tabToggleRequested.disconnect();self.fiber.viewport.tabToggleRequested.connect(self.toggle_atlas)
    def _add_library_controls(self):
        layout=self.library_panel.layout();self.group_filter=QtWidgets.QComboBox();self.group_filter.addItem('All groups');self.group_filter.currentTextChanged.connect(self._filter);layout.insertWidget(1,self.group_filter)
        row=QtWidgets.QHBoxLayout()
        for title,call in [('Rename',self.rename_tile),('Group',self.group_tile),('Presets',self.choose_preset)]:
            b=QtWidgets.QPushButton(title);b.clicked.connect(call);row.addWidget(b)
        layout.insertLayout(2,row)
    def _filter(self,*args):
        query=self.fiber.search_input.text().lower();group=self.group_filter.currentText();groups=self.controller.project.metadata.get('tile_groups',{})
        for i,tile in enumerate(self.controller.project.tiles):
            item=self.fiber.tile_list.item(i)
            if item:item.setHidden(query not in tile.name.lower() or (group!='All groups' and tile.id not in groups.get(group,[])))
    def rename_tile(self):
        tile=self.controller.current_tile()
        if tile is None:return
        name,ok=QtWidgets.QInputDialog.getText(self,'Rename tile','Name',text=tile.name)
        if ok and name:self.controller.snapshot();tile.name=name;self.controller.tilesChanged.emit()
    def group_tile(self):
        tile=self.controller.current_tile()
        if tile is None:return
        name,ok=QtWidgets.QInputDialog.getText(self,'Tile group','Group name')
        if ok and name:
            self.controller.snapshot();groups=deepcopy(self.controller.project.metadata.get('tile_groups',{}));groups.setdefault(name,[])
            if tile.id not in groups[name]:groups[name].append(tile.id)
            self.controller.project.metadata={**self.controller.project.metadata,'tile_groups':groups};self._selected()
    def choose_preset(self):
        name,ok=QtWidgets.QInputDialog.getItem(self,'Generator preset','Preset',list(PRESETS),0,False)
        tile=self.controller.current_tile()
        if not ok or tile is None:return
        mapped=source_node(tile)
        if tile.construction_graph and mapped is None:
            self.controller.jobFailed.emit('Preset','Complex graph source: use From Current Tile to create a mapped generator or edit the graph. Existing graph was preserved.');return
        self.controller.snapshot()
        if mapped:
            source=Tile.from_dict(mapped['params']['tile']);source.apply_preset(name);graph=deepcopy(tile.construction_graph);next(n for n in graph['nodes'] if n['id']==mapped['id'])['params']['tile']=source.to_dict();tile.construction_graph=graph
        else:tile.apply_preset(name)
        tile.revision+=1;self.controller.tileUpdated.emit(tile.id);self._build_simple_inspector()
    def _tile_menu(self,pos):
        item=self.fiber.tile_list.itemAt(pos)
        if item is not None:self.fiber.tile_list.setCurrentItem(item)
        menu=QtWidgets.QMenu(self)
        for title,call in [('Rename',self.rename_tile),('Duplicate',self.fiber._dup_tile),('Delete',self.fiber._del_tile),('Assign to group',self.group_tile),('Open in Graph',self.convert_graph)]:menu.addAction(title,call)
        menu.exec(self.fiber.tile_list.viewport().mapToGlobal(pos))
    def convert_graph(self):
        tile=self.controller.current_tile()
        if tile is None:return
        if tile.construction_graph is not None:
            self.open_tile_graph(tile.id);return
        source=deepcopy(tile);source.construction_graph=None
        self.controller.snapshot();tile.construction_graph={'format':'fsd-construction-graph','version':1,'nodes':[node('generator','fiber_source',tile=source.to_dict())],'output':'generator'};tile.revision+=1
        self.graph.graph=deepcopy(tile.construction_graph);self.graph.current_tile=tile;self.graph._refresh_nodes_list();self.graph._request_preview();self.controller.tileUpdated.emit(tile.id);self.open_tile_graph(tile.id)
    def _sync_graph_canvas(self):
        if self.views.currentIndex()!=1:return
        self.canvas.sync()
        tile=self.graph.current_tile;context=(id(self.controller.project),tile.id if tile else None)
        if getattr(self,'_graph_canvas_context',None)!=context:
            self._graph_canvas_context=context;self.fit()
    def open_tile_graph(self,tile_id=None):
        tile=self.controller.project.find(tile_id) if tile_id else self.controller.current_tile()
        if tile is None:return
        self.controller.set_active_tile(tile.id)
        self.views.setCurrentIndex(1)
        self.graph._on_tiles_changed();self._sync_graph_canvas();self.fit()
    def set_view(self,index):
        self.center.setCurrentIndex(1 if index==1 else 0);self.inspector_panel.setCurrentIndex(index if index==2 else 1 if index==1 else 0)
        self.viewport=self.graph.viewport if index==1 else self.fiber.viewport
        self.fiber.map_combo.setVisible(index!=1)
        if index==0:self._build_simple_inspector()
        if index==2:self._atlas_inspector()
        if index!=1:self.fiber.mode_combo.setCurrentText('Atlas Mode' if index==2 else 'Tile Mode');self.fiber._request_preview()
        if index==1:
            self.graph._on_tiles_changed()
            self._sync_graph_canvas()
        else:self.controller.cancel_job('graph_live_preview')
    def toggle_atlas(self):self.views.setCurrentIndex(0 if self.views.currentIndex()==2 else 2)
    def fit(self):
        if self.views.currentIndex()==1:self.canvas.fitInView(self.canvas.scene().itemsBoundingRect(),QtCore.Qt.AspectRatioMode.KeepAspectRatio)
        else:self.fiber._on_fit_view()
    def _selected(self,*args):
        if not hasattr(self,'group_filter'):return
        groups=['All groups',*self.controller.project.metadata.get('tile_groups',{})]
        if [self.group_filter.itemText(i) for i in range(self.group_filter.count())]!=groups:
            group=self.group_filter.currentText();blocker=QtCore.QSignalBlocker(self.group_filter);self.group_filter.clear();self.group_filter.addItems(groups);self.group_filter.setCurrentText(group if group in groups else 'All groups')
        if self.views.currentIndex()==0:self._sync_simple_inspector()
        elif self.views.currentIndex()==2:self._atlas_inspector()
        self._filter();self._thumb_timer.start(180)
    def _tile_changed(self,tid):
        if self.controller.current_tile() and tid==self.controller.current_tile().id:self.fiber._request_preview()
    def _sync_simple_inspector(self):
        from shiboken6 import isValid
        tile=self.controller.current_tile()
        if tile is None:
            self._build_simple_inspector();return
        sliders=getattr(self.fiber,'_sliders',None)
        pickers=getattr(self.fiber,'_color_pickers',None)
        content=getattr(self.fiber,'inspector_content',None)
        if not sliders or not pickers or not content or not isValid(content):
            self._build_simple_inspector();return
        if not all(isValid(s) for s in sliders.values()) or not all(isValid(p) for p in pickers.values()):
            self._build_simple_inspector();return
        mapped=source_node(tile)
        # Update graph status banner text if present
        if hasattr(self,'_graph_status_label') and isValid(self._graph_status_label):
            if tile.construction_graph:
                msg='Mapped source: '+mapped['id'] if mapped else 'Graph controls shape/color. Use Graph view; optical controls below remain available.'
                self._graph_status_label.setText(msg);self._graph_status_label.setVisible(True)
            else:
                self._graph_status_label.setText('');self._graph_status_label.setVisible(False)
        self.fiber.current_tile=tile
        self.fiber._sync_inspector_values()
        for key,control in sliders.items():
            control.setEnabled(not tile.construction_graph or mapped is not None or key in GLOBAL_GRAPH_FIELDS)
        for key,picker in pickers.items():
            picker.setEnabled(not tile.construction_graph or mapped is not None)
    def _build_simple_inspector(self):
        scroll=self.fiber.inspector_scroll;body=QtWidgets.QWidget();layout=QtWidgets.QVBoxLayout(body);tile=self.controller.current_tile()
        controls={}
        if tile is None:
            self._graph_status_label=None
            self.fiber._sliders=controls;self.fiber._color_pickers={};self.fiber.current_tile=None;self.fiber.inspector_content=body;self.fiber.insp_layout=layout;scroll.setWidget(body);return
        self.fiber.current_tile=tile;mapped=source_node(tile)
        self._graph_status_label=QtWidgets.QLabel(body)
        self._graph_status_label.setWordWrap(True)
        if tile.construction_graph:
            self._graph_status_label.setText('Mapped source: '+mapped['id'] if mapped else 'Graph controls shape/color. Use Graph view; optical controls below remain available.')
            self._graph_status_label.setVisible(True)
        else:
            self._graph_status_label.setText('')
            self._graph_status_label.setVisible(False)
        layout.addWidget(self._graph_status_label)
        settings=FiberSettings(**mapped['params']['tile'].get('settings',{})).sanitize() if mapped else tile.settings
        definitions=[('Generation',[('Count','count',1,20000,True),('Length','length',.03,.96,False),('Root spread','root_spread',.05,1,False)]),('Shape',[('Bend','bend',-1.5,1.5,False),('Curl','curl',0,.7,False),('Curl frequency','curl_frequency',.1,14,False),('Twist','twist',-1,1,False),('Sag','sag',-.5,.5,False),('Root width','root_width',.15,35,False),('Taper','taper',.15,8,False)]),('Distribution',[('Macro clumps','macro_clumps',1,1000,True),('Micro clumps','micro_clumps',1,3000,True),('Attraction','clump_attraction',0,1,False),('Flyaway','flyaway',0,1,False),('Guard ratio','guard_ratio',0,1,False)]),('Optics',[('Roughness','roughness',0,1,False),('Specular','specular',0,1,False),('Anisotropy','anisotropy',0,1,False),('Transmission','transmission',0,1,False),('Scatter','scatter',0,1,False),('Iridescence','iridescence',0,1,False),('Opacity','strand_opacity',0,1,False),('Fiber roundness','fiber_roundness',0,1,False)]),('Variation',[('Length variation','length_variation',0,1,False),('Width variation','width_variation',0,1.5,False),('Frizz','frizz',0,.7,False),('Hue','hue_variation',0,.5,False),('Value','value_variation',0,1,False)])]
        for index,(title,fields) in enumerate(definitions):
            group=QtPropertyGroup(title,body);layout.addWidget(group)
            for label,key,lo,hi,integer in fields:
                value=getattr(tile.settings if tile.construction_graph and key in GLOBAL_GRAPH_FIELDS else settings,key)
                control=group.add_slider(label,lo,hi,value,is_integer=integer,callback=lambda v,k=key:self.fiber._setting_changed(k,int(v) if k in ('count','macro_clumps','micro_clumps') else v))
                controls[key]=control
                control.setEnabled(not tile.construction_graph or mapped is not None or key in GLOBAL_GRAPH_FIELDS)
            if index>0:group.header_btn.setChecked(False);group._toggle_collapse(False)
        color=QtPropertyGroup('Color',body);layout.addWidget(color)
        color_pickers={}
        for key,label in (('color_root','Root Color'),('color_mid','Mid Color'),('color_tip','Tip Color')):
            val=getattr(s if (s:=settings) else tile.settings,key,'#ffffff')
            picker=color.add_color_picker(
                label,
                val,
                callback=lambda c,k=key:self.fiber._setting_changed(k,c)
            )
            picker.setEnabled(not tile.construction_graph or mapped is not None)
            color_pickers[key]=picker
        layout.addStretch()
        # Replace the control registry before QScrollArea destroys the old body.
        self.fiber._sliders=controls;self.fiber._color_pickers=color_pickers;self.fiber.inspector_content=body;self.fiber.insp_layout=layout;scroll.setWidget(body)
    def _pick_color(self,key,initial):
        color=QtWidgets.QColorDialog.getColor(QtGui.QColor(initial),self)
        if color.isValid():self.fiber._setting_changed(key,color.name())
    def close_fiber(self):self.fiber.close_live_viewport();self.graph.close_live_viewport()

    def input_target(self,focus):
        if self.views.currentIndex()==1 and focus is not None and (focus is self.canvas or self.canvas.isAncestorOf(focus)):return self.canvas
        return self.viewport

    def _thumbnails(self):
        from PIL.ImageQt import ImageQt
        library=self.fiber.tile_list
        if not library.isVisible():return
        first=max(0,library.indexAt(QtCore.QPoint(2,2)).row());tiles=self.controller.project.tiles[first:first+12];project=self.controller.project
        missing=[deepcopy(t) for t in tiles if (id(project),t.id,t.revision) not in self._thumb_cache]
        for index,tile in enumerate(project.tiles):
            cached=self._thumb_cache.get((id(project),tile.id,tile.revision))
            if cached and library.item(index):library.item(index).setIcon(cached)
        if not missing:return
        def worker(cancel):
            from ..raster import render_tile
            result=[]
            for tile in missing:
                if cancel():return result
                rendered=render_tile(tile,size=(48,64),channels=('color','alpha'),should_cancel=cancel);image=rendered.maps['color'].convert('RGBA');image.putalpha(rendered.maps['alpha']);result.append((tile.id,tile.revision,ImageQt(image).copy()))
            return result
        def done(result,revision):
            if project is not self.controller.project:return
            for tid,source_revision,image in result:
                tile=project.find(tid)
                if tile is not None and tile.revision==source_revision:self._thumb_cache[(id(project),tid,source_revision)]=QtGui.QIcon(QtGui.QPixmap.fromImage(image))
            for index,tile in enumerate(project.tiles):
                icon=self._thumb_cache.get((id(project),tile.id,tile.revision))
                if icon and library.item(index):library.item(index).setIcon(icon)
            while len(self._thumb_cache)>256:self._thumb_cache.pop(next(iter(self._thumb_cache)))
        self.controller.submit_job('library_thumbnails',worker,done)

    def _atlas_inspector(self):
        if not hasattr(self,'atlas_inspector'):return
        tile=self.controller.current_tile();atlas=self.controller.atlas_layout
        placement=atlas.placements.get(tile.id) if tile else None
        key=(id(self.controller.project),tile.id if tile else None,tile.name if tile else None,atlas.size,self.controller.project.padding,tuple(getattr(placement,k) for k in ('x','y','width','height','rotation','page','udim')) if placement else None)
        if getattr(self,'_atlas_inspector_key',None)==key:return
        # One retained form: selection/layout changes never destroy focused controls
        # or trigger a global style inventory rebuild through ChildAdded events.
        if not hasattr(self,'_atlas_fields'):
            body=QtWidgets.QWidget();layout=QtWidgets.QVBoxLayout(body);row=QtWidgets.QHBoxLayout();layout.addLayout(row)
            for tool in ('Select','Move','Rotate','Scale'):
                button=QtWidgets.QPushButton(tool);button.clicked.connect(lambda checked=False,k=tool:self.fiber._atlas_set_tool(k));row.addWidget(button)
            self._atlas_title=QtWidgets.QLabel();self._atlas_title.setSizePolicy(QtWidgets.QSizePolicy.Policy.Ignored,QtWidgets.QSizePolicy.Policy.Preferred);layout.addWidget(self._atlas_title)
            form=QtWidgets.QFormLayout();layout.addLayout(form);self._atlas_fields={}
            for field in ('x','y','width','height','rotation'):
                spin=QtWidgets.QDoubleSpinBox();spin.setDecimals(2 if field=='rotation' else 0)
                spin.valueChanged.connect(lambda v,k=field:self._atlas_value_changed(k,v))
                self._atlas_fields[field]=spin;form.addRow(field.title(),spin)
            self._atlas_uv_info=QtWidgets.QLabel();layout.addWidget(self._atlas_uv_info)
            self._atlas_padding=QtWidgets.QSpinBox();self._atlas_padding.setRange(0,128);self._atlas_padding.valueChanged.connect(lambda v:self._padding(v))
            layout.addWidget(QtWidgets.QLabel('Atlas padding (px)'));layout.addWidget(self._atlas_padding)
            self._atlas_selection_buttons=[]
            for label,callback in [('Auto Pack this UDIM',lambda:self.controller.auto_pack_udim(self.fiber._atlas_current_udim())),('Auto Pack all UDIMs',lambda:self.controller.auto_pack_udim(None)),('Duplicate tile and placement',self.fiber._dup_tile),('Reset placement to auto pack',self._reset_placement)]:
                button=QtWidgets.QPushButton(label);button.clicked.connect(callback);layout.addWidget(button);self._atlas_selection_buttons.append(button)
            layout.addStretch();self.atlas_inspector.setWidget(body)
        same_tile=getattr(self,'_atlas_inspector_tile_id',None)==(tile.id if tile else None) and getattr(self,'_atlas_inspector_project',None) is self.controller.project
        self._atlas_inspector_tile_id=tile.id if tile else None;self._atlas_inspector_project=self.controller.project
        self._atlas_inspector_key=key
        title=tile.name+' · UDIM '+str(placement.udim) if tile and placement else 'Select an Atlas tile'
        self._atlas_title.setText(title);self._atlas_title.setToolTip(title)
        deferred=False
        for field,spin in self._atlas_fields.items():
            spin.setEnabled(placement is not None)
            if placement is None:continue
            if same_tile and spin.hasFocus():deferred=True;continue
            blocker=QtCore.QSignalBlocker(spin)
            spin.setRange(-360 if field=='rotation' else 16 if field in ('width','height') else 0,360 if field=='rotation' else atlas.size)
            spin.setValue(getattr(placement,field))
        if placement and tile:
            u0=placement.x/atlas.size;v0=placement.y/atlas.size;u1=(placement.x+placement.width)/atlas.size;v1=(placement.y+placement.height)/atlas.size
            self._atlas_uv_info.setText(f'UV bounds: ({u0:.4f}, {v0:.4f}) – ({u1:.4f}, {v1:.4f})\nAtlas: {atlas.size} × {atlas.size} px\nSource: {tile.width} × {tile.height} px')
        else:self._atlas_uv_info.setText('UV bounds: —\nAtlas: '+str(atlas.size)+' px\nSource: —')
        if not self._atlas_padding.hasFocus():
            blocker=QtCore.QSignalBlocker(self._atlas_padding);self._atlas_padding.setValue(self.controller.project.padding)
        else:deferred=True
        for button in self._atlas_selection_buttons:button.setEnabled(tile is not None)
        if deferred:self._atlas_inspector_key=None
    def _atlas_value_changed(self,key,value):
        tid=getattr(self,'_atlas_inspector_tile_id',None)
        if tid is not None:self._placement_value(tid,key,value)
    def _atlas_commit_field(self,key,control):
        tid=getattr(self,'_atlas_inspector_tile_id',None)
        if tid is not None:self._placement_value(tid,key,control.value())

    def _placement_value(self,tid,key,value):
        tile=self.controller.project.find(tid);placement=self.controller.atlas_layout.placements.get(tid)
        if tile is None or placement is None:return
        patch={k:getattr(placement,k) for k in ('x','y','width','height','rotation','page','udim')}
        if abs(patch[key]-value)<.00001:return
        patch[key]=value;self.controller.snapshot_layout();metadata=deepcopy(self.controller.project.metadata);metadata.setdefault('tile_placements',{})[tid]=patch;self.controller.project.metadata=metadata;self.controller.relayout_atlas();self.controller.ensure_atlas();self._atlas_inspector()
    def _padding(self,value):
        if value==self.controller.project.padding:return
        self.controller.snapshot_layout();self.controller.project.padding=value;self.controller.relayout_atlas();self.controller.ensure_atlas()
    def _reset_placement(self):
        tile=self.controller.current_tile()
        if tile is None:return
        self.controller.snapshot_layout();metadata=deepcopy(self.controller.project.metadata);metadata.setdefault('tile_placements',{}).pop(tile.id,None);self.controller.project.metadata=metadata;self.controller.relayout_atlas();self.controller.ensure_atlas();self._atlas_inspector()
