"""GPU Render Studio Workspace for Qt 6 / PySide6.

Features:
- Lookdev lighting, Marschner hair reflection, scattering, and rim light
- Environment HDRI / Studio preset switching
- Viewport multi-layer OIT transparency and light orientation (Shift+RMB)
- Project Atlas binding (Zero unverified demo atlas overrides; syncs with active project cards)
- Complete parameter inspector matching original RenderStudio (Material, Optics, Lighting, Post, View, Tools)
- Ground grid OFF by default in render viewport with interactive toggle
"""
from __future__ import annotations
import math
from pathlib import Path
from typing import Any
from PySide6 import QtCore, QtGui, QtWidgets
from .viewport import QtViewportHost
from .inspector import QtPropertyGroup, QtColorPicker
from .slider import QtNumberSlider
from .theme import TOKENS

from fiberstrand.rendercore.renderer import GPUHairRenderer, HairMaterial
from fiberstrand.rendercore.lighting import light_color_from_srgb, light_color_hex
from fiberstrand.cards import HairCard


ASSET_ROOT = Path(__file__).resolve().parents[2] / 'samples' / 'rendercore'

DEBUG_MODE_MAP = {
    "Rendered": 0,
    "Alpha Coverage": 1,
    "Normal": 2,
    "Fiber Direction": 3,
    "Roughness": 4,
    "Specular": 5,
    "Iridescence": 6,
    "Self Shadow": 7,
    "Original Alpha": 8,
    "Effective Coverage": 9,
    "Transparency Overdraw": 10,
    "Mipmap Level": 11,
    "Alpha Cutoff": 12,
    "Silhouette": 13,
    "Motion Vectors": 14,
    "Temporal History": 15,
    "Ordered Layer Overflow": 16,
    "Base Color": 17,
    "Depth": 18,
}

LIGHT_COLOR_MAP = {
    'light_intensity': 'key_color',
    'fill_intensity': 'fill_color',
    'ambient_intensity': 'ambient_color',
    'rim_intensity': 'rim_color',
}


class QtRenderStudio(QtWidgets.QWidget):
    def __init__(self, controller, parent: QtWidgets.QWidget | None = None):
        super().__init__(parent)
        self.controller = controller
        from ..settings import AppSettings
        self._view_settings = AppSettings.load()

        from ..rendercore.settings import material_from_project
        self.material = material_from_project(controller.project)
        self.renderer: GPUHairRenderer | None = None
        self.sliders: dict[str, QtNumberSlider] = {}
        self.color_buttons: dict[str, QtWidgets.QPushButton] = {}
        self._sweep_timer: QtCore.QTimer | None = None

        # Turn OFF ground grid by default in render viewport per user specification
        self.show_grid = False

        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.splitter = QtWidgets.QSplitter(QtCore.Qt.Orientation.Horizontal, self)
        self.splitter.setStyleSheet(f"QSplitter::handle {{ background-color: {TOKENS['border']}; width: 2px; }}")

        # Center Viewport & Lookdev Tool Header
        center_widget = QtWidgets.QWidget(self.splitter)
        center_layout = QtWidgets.QVBoxLayout(center_widget)
        center_layout.setContentsMargins(8, 8, 8, 8)
        center_layout.setSpacing(6)

        header = QtWidgets.QHBoxLayout()
        header.setSpacing(6)
        lbl_brand = QtWidgets.QLabel("FIBERLIGHT R3", center_widget)
        lbl_brand.setStyleSheet(f"color: {TOKENS['cyan']}; font-weight: 700; font-size: 11px;")
        header.addWidget(lbl_brand)

        # Ground Grid Toggle Button (Default OFF)
        self.btn_grid = QtWidgets.QPushButton("⊞ Grid: Off", center_widget)
        self.btn_grid.setToolTip("Toggle 3D ground grid in viewport (currently OFF)")
        self.btn_grid.clicked.connect(self._toggle_grid)
        header.addWidget(self.btn_grid)

        self.btn_studio_env = QtWidgets.QPushButton("🖼 Studio Env", center_widget)
        self.btn_studio_env.setProperty("class", "workspace_pill_active")
        self.btn_studio_env.clicked.connect(self._set_studio_env)
        header.addWidget(self.btn_studio_env)

        self.btn_hdri_env = QtWidgets.QPushButton("🌄 HDRI Env", center_widget)
        self.btn_hdri_env.setProperty("class", "workspace_pill")
        self.btn_hdri_env.clicked.connect(self._load_hdri_env)
        header.addWidget(self.btn_hdri_env)

        header.addStretch(1)

        lbl_dbg = QtWidgets.QLabel("Debug View:", center_widget)
        lbl_dbg.setStyleSheet(f"color: {TOKENS['text_muted']}; font-weight: 500;")
        header.addWidget(lbl_dbg)

        # Full 19 Debug Views from original Render Studio
        self.debug_combo = QtWidgets.QComboBox(center_widget)
        self.debug_combo.addItems(list(DEBUG_MODE_MAP.keys()))
        self.debug_combo.currentTextChanged.connect(self._on_debug_changed)
        header.addWidget(self.debug_combo)

        lbl_oit = QtWidgets.QLabel("OIT / Transparency:", center_widget)
        lbl_oit.setStyleSheet(f"color: {TOKENS['text_muted']}; font-weight: 500;")
        header.addWidget(lbl_oit)

        # Full 5 OIT transparency modes
        self.oit_combo = QtWidgets.QComboBox(center_widget)
        self.oit_combo.addItems([
            "Auto · GPU Budget",
            "Weighted · Fast",
            "Hybrid · 2 Layers",
            "Hybrid · 4 Layers",
            "Hybrid · 8 Layers"
        ])
        self.oit_combo.currentTextChanged.connect(self._on_oit_changed)
        header.addWidget(self.oit_combo)

        self.btn_capture = QtWidgets.QPushButton("📷 Capture PNG/EXR", center_widget)
        self.btn_capture.setProperty("class", "gold_action")
        self.btn_capture.clicked.connect(self._capture_frame)
        header.addWidget(self.btn_capture)

        btn_back_cards = QtWidgets.QPushButton("◀ Back to Groom 3D", center_widget)
        btn_back_cards.setToolTip("Quay lại màn hình chính 3D Groom & Card Editor")
        btn_back_cards.clicked.connect(lambda: getattr(self.window(), "_switch_workspace", lambda _: None)("cards"))
        header.addWidget(btn_back_cards)

        center_layout.addLayout(header)

        self.viewport = QtViewportHost(center_widget)
        self.viewport.set_view_kind("studio")
        self.viewport.radiusChanged.connect(self._on_light_radius)
        self.viewport.interactionStarted.connect(self._begin_view_gesture)
        self.viewport.interactionFinished.connect(self._end_view_gesture)
        self.viewport.lightOrbitChanged.connect(self._on_light_orbit)
        self.viewport.orbitChanged.connect(self._on_camera_orbit)
        self.viewport.panChanged.connect(self._on_camera_pan)
        self.viewport.dollyChanged.connect(self._on_camera_dolly)
        self.viewport.wheelZoomed.connect(self._on_wheel_zoom)
        self.viewport.frameRequested.connect(self._frame_all)
        self.viewport.cancelRequested.connect(self._cancel_interactions)
        self.viewport.tabToggleRequested.connect(self._toggle_inspector)
        self.viewport.resized.connect(self._on_viewport_resized)
        self.viewport.renderFailed.connect(lambda error: self.controller.jobFailed.emit("viewport", error))
        center_layout.addWidget(self.viewport, 1)

        self.splitter.addWidget(center_widget)

        # Right: Render Material & Lighting Inspector
        self.inspector_scroll = QtWidgets.QScrollArea(self.splitter)
        self.inspector_scroll.setWidgetResizable(True)
        self.inspector_scroll.setMinimumWidth(320)
        self.inspector_scroll.setStyleSheet(f"background-color: {TOKENS['bg_panel']}; border: none;")

        self.inspector_content = QtWidgets.QWidget()
        self.insp_layout = QtWidgets.QVBoxLayout(self.inspector_content)
        self.insp_layout.setContentsMargins(6, 6, 6, 6)
        self.insp_layout.setSpacing(6)

        self._build_full_render_inspector()
        self.inspector_scroll.setWidget(self.inspector_content)
        self.splitter.addWidget(self.inspector_scroll)

        self.splitter.setStretchFactor(0, 1)
        self.splitter.setStretchFactor(1, 0)
        self.splitter.setSizes([960, 380])

        layout.addWidget(self.splitter)

        # Camera orientation
        self.camera_yaw = 0.0
        self.camera_pitch = 0.2
        self.camera_distance = 3.5
        self.viewport.set_orientation_cube(True, self.camera_yaw, self.camera_pitch)

        # Legacy convenience aliases
        self.slider_long_r = self.sliders.get('longitudinal_roughness')
        self.slider_azim_r = self.sliders.get('azimuthal_roughness')
        self.slider_ior = self.sliders.get('ior')
        self.slider_shift = self.sliders.get('cuticle_tilt')
        self.slider_azim = self.sliders.get('light_azimuth')
        self.slider_elev = self.sliders.get('light_elevation')
        self.slider_intensity = self.sliders.get('light_intensity')
        self.slider_fill = self.sliders.get('fill_intensity')
        self.slider_env = self.sliders.get('environment_strength')
        self.slider_exposure = self.sliders.get('exposure')

        # Controller signals
        self.controller.projectLoaded.connect(self._reload_project_material)
        self.controller.cardsChanged.connect(self._sync_cards_to_renderer)
        self.controller.atlasRebuilt.connect(self._sync_atlas_to_renderer)

        # Initialize hardware renderer on idle
        QtCore.QTimer.singleShot(100, self._init_gpu_renderer)

    def _toggle_grid(self):
        """Toggle ground grid on/off."""
        self.show_grid = not self.show_grid
        self.btn_grid.setText(f"⊞ Grid: {'On' if self.show_grid else 'Off'}")
        if hasattr(self, 'cb_grid'):
            self.cb_grid.blockSignals(True)
            self.cb_grid.setChecked(self.show_grid)
            self.cb_grid.blockSignals(False)
        self._request_frame()

    def _make_color_button(self, field: str, parent: QtWidgets.QWidget) -> QtColorPicker:
        """Create interactive color picker swatch button for light colors."""
        current_linear = getattr(self.material, field, (1.0, 1.0, 1.0))
        current_hex = light_color_hex(current_linear)

        def on_color_changed(hex_val: str):
            c = QtGui.QColor(hex_val)
            if c.isValid():
                new_linear = light_color_from_srgb((c.red(), c.green(), c.blue()))
                setattr(self.material, field, new_linear)
                self.controller.set_render_material(self.material)
                self._request_frame()

        picker = QtColorPicker(
            initial_color=current_hex,
            title=f"Choose {field.replace('_', ' ').title()}",
            compact=True,
            callback=on_color_changed,
            parent=parent,
        )
        self.color_buttons[field] = picker
        return picker

    def _add_param_slider(self, grp: QtPropertyGroup, field: str, label: str, lo: float, hi: float, step: float = 0.01) -> QtNumberSlider:
        val = float(getattr(self.material, field, lo))
        color_field = LIGHT_COLOR_MAP.get(field)
        if color_field:
            row_box = QtWidgets.QWidget()
            row_l = QtWidgets.QHBoxLayout(row_box)
            row_l.setContentsMargins(0, 0, 0, 0)
            row_l.setSpacing(4)
            cbtn = self._make_color_button(color_field, row_box)
            row_l.addWidget(cbtn)
            slider = QtNumberSlider(from_=lo, to=hi, step=step, value=val, parent=row_box)
            slider.valueChanged.connect(lambda v, f=field: self._update_mat(f, v))
            row_l.addWidget(slider, 1)
            grp.add_row(label, row_box)
            self.sliders[field] = slider
            return slider
        else:
            slider = grp.add_slider(label, lo, hi, val, step=step, callback=lambda v, f=field: self._update_mat(f, v))
            self.sliders[field] = slider
            return slider

    def _build_full_render_inspector(self):
        """Construct full 6-tab parameter inspector matching all original Render Studio settings."""
        self.tabs = QtWidgets.QTabWidget(self.inspector_content)
        self.tabs.setProperty("fsdFamily", "navigation.tabs")

        # ----------------------------------------------------
        # TAB 1: MATERIAL
        # ----------------------------------------------------
        scroll_mat, page_mat = self._create_tab_scroll_page()
        
        # Shading model selection
        grp_shading = QtPropertyGroup("SHADING MODEL & OPTICS", page_mat)
        self.shading_combo = QtWidgets.QComboBox(page_mat)
        self.shading_combo.addItems(["Physical", "Legacy"])
        self.shading_combo.setCurrentText(getattr(self.material, "shading_mode", "Physical"))
        self.shading_combo.currentTextChanged.connect(self._on_shading_mode_changed)
        grp_shading.add_row("Shading Model", self.shading_combo)

        self.cb_artistic = QtWidgets.QCheckBox("Artistic specular / sheen / iridescence", page_mat)
        self.cb_artistic.setChecked(getattr(self.material, "artistic_optics", True))
        self.cb_artistic.toggled.connect(self._on_artistic_optics_toggled)
        grp_shading.add_row("", self.cb_artistic)
        page_mat.layout().addWidget(grp_shading)

        # Hair Reflection Group (10 parameters)
        grp_refl = QtPropertyGroup("HAIR REFLECTION", page_mat)
        self._add_param_slider(grp_refl, "cuticle_tilt", "Cuticle Tilt · °", -10.0, 10.0, 0.1)
        self._add_param_slider(grp_refl, "longitudinal_roughness", "Longitudinal Roughness", 0.03, 1.0, 0.01)
        self._add_param_slider(grp_refl, "azimuthal_roughness", "Azimuthal Roughness", 0.03, 1.0, 0.01)
        self._add_param_slider(grp_refl, "ior", "Fiber IOR", 1.01, 2.0, 0.01)
        self._add_param_slider(grp_refl, "absorption", "Pigment Absorption", 0.0, 3.0, 0.01)
        self._add_param_slider(grp_refl, "roughness", "Roughness", 0.02, 1.0, 0.01)
        self._add_param_slider(grp_refl, "specular", "Primary Specular", 0.0, 2.0, 0.01)
        self._add_param_slider(grp_refl, "secondary", "Secondary Specular", 0.0, 1.5, 0.01)
        self._add_param_slider(grp_refl, "anisotropy", "Anisotropy", 0.0, 1.0, 0.01)
        self._add_param_slider(grp_refl, "sheen", "Sheen", 0.0, 1.0, 0.01)
        page_mat.layout().addWidget(grp_refl)
        page_mat.layout().addStretch(1)
        self.tabs.addTab(scroll_mat, "🎨 Material")

        # ----------------------------------------------------
        # TAB 2: OPTICS & SCATTERING
        # ----------------------------------------------------
        scroll_optics, page_optics = self._create_tab_scroll_page()
        grp_optics = QtPropertyGroup("SCATTERING & TRANSPARENCY", page_optics)
        self._add_param_slider(grp_optics, "backlight", "Backlight", 0.0, 1.0, 0.01)
        self._add_param_slider(grp_optics, "iridescence", "Iridescence", 0.0, 1.0, 0.01)
        self._add_param_slider(grp_optics, "alpha_gain", "Coverage Gain", 0.1, 2.0, 0.01)
        self._add_param_slider(grp_optics, "alpha_cutoff", "Diagnostic Alpha Cutoff", 0.0, 1.0, 0.01)
        self._add_param_slider(grp_optics, "scatter_strength", "Fiber Scattering", 0.0, 1.0, 0.01)
        self._add_param_slider(grp_optics, "shadow_strength", "Self Shadow", 0.0, 1.0, 0.01)
        page_optics.layout().addWidget(grp_optics)
        page_optics.layout().addStretch(1)
        self.tabs.addTab(scroll_optics, "✨ Optics")

        # ----------------------------------------------------
        # TAB 3: LIGHTING & ENVIRONMENT
        # ----------------------------------------------------
        scroll_light, page_light = self._create_tab_scroll_page()
        
        # Environment IBL
        grp_env = QtPropertyGroup("ENVIRONMENT IBL", page_light)
        self._add_param_slider(grp_env, "environment_strength", "Environment Intensity", 0.0, 3.0, 0.05)
        self._add_param_slider(grp_env, "environment_rotation", "Environment Rotation · °", -180.0, 180.0, 1.0)
        btn_env_row = QtWidgets.QHBoxLayout()
        btn_load_hdri = QtWidgets.QPushButton("Load HDRI...", page_light)
        btn_load_hdri.clicked.connect(self._load_hdri_env)
        btn_studio_env = QtWidgets.QPushButton("Studio Preset", page_light)
        btn_studio_env.clicked.connect(self._set_studio_env)
        btn_env_row.addWidget(btn_load_hdri)
        btn_env_row.addWidget(btn_studio_env)
        grp_env.add_row("HDRI Source", self._wrap_layout(btn_env_row))
        page_light.layout().addWidget(grp_env)

        # Studio Lighting
        grp_studio_light = QtPropertyGroup("STUDIO LIGHTING", page_light)
        self._add_param_slider(grp_studio_light, "light_azimuth", "Key Azimuth · °", -180.0, 180.0, 1.0)
        self._add_param_slider(grp_studio_light, "light_elevation", "Key Elevation · °", -85.0, 85.0, 1.0)
        self._add_param_slider(grp_studio_light, "light_intensity", "Key Intensity", 0.1, 3.0, 0.05)
        self._add_param_slider(grp_studio_light, "fill_intensity", "Fill Intensity", 0.0, 2.0, 0.05)
        self._add_param_slider(grp_studio_light, "ambient_intensity", "Ambient Light", 0.0, 1.5, 0.05)
        self._add_param_slider(grp_studio_light, "light_size", "Key Source Angle · °", 0.0, 360.0, 1.0)
        self._add_param_slider(grp_studio_light, "exposure", "Exposure", -2.0, 3.0, 0.1)
        page_light.layout().addWidget(grp_studio_light)

        # Rim Light
        grp_rim = QtPropertyGroup("RIM LIGHT", page_light)
        self._add_param_slider(grp_rim, "rim_intensity", "Rim Intensity", 0.0, 3.0, 0.05)
        self._add_param_slider(grp_rim, "rim_azimuth", "Rim Azimuth · °", -180.0, 180.0, 1.0)
        self._add_param_slider(grp_rim, "rim_elevation", "Rim Elevation · °", -85.0, 85.0, 1.0)
        self._add_param_slider(grp_rim, "rim_width", "Rim Softness", 0.0, 1.0, 0.01)
        page_light.layout().addWidget(grp_rim)

        # Quick Light Actions
        btn_light_tools = QtWidgets.QHBoxLayout()
        btn_reset_light = QtWidgets.QPushButton("Reset Light", page_light)
        btn_reset_light.clicked.connect(self._reset_light)
        btn_sweep = QtWidgets.QPushButton("Light Sweep", page_light)
        btn_sweep.clicked.connect(self._toggle_sweep)
        btn_light_tools.addWidget(btn_reset_light)
        btn_light_tools.addWidget(btn_sweep)
        page_light.layout().addLayout(btn_light_tools)

        page_light.layout().addStretch(1)
        self.tabs.addTab(scroll_light, "💡 Lighting")

        # ----------------------------------------------------
        # TAB 4: POST EFFECTS
        # ----------------------------------------------------
        scroll_post, page_post = self._create_tab_scroll_page()
        grp_bloom = QtPropertyGroup("BLOOM & GLOW", page_post)
        self._add_param_slider(grp_bloom, "bloom", "Bloom", 0.0, 2.0, 0.05)
        self._add_param_slider(grp_bloom, "bloom_threshold", "Bloom Threshold", 0.0, 3.0, 0.05)
        self._add_param_slider(grp_bloom, "bloom_radius", "Bloom Radius · px", 1.0, 32.0, 0.5)
        page_post.layout().addWidget(grp_bloom)

        grp_color = QtPropertyGroup("COLOR & OPTICAL DEFECTS", page_post)
        self._add_param_slider(grp_color, "chroma", "Chroma · px", 0.0, 12.0, 0.1)
        self._add_param_slider(grp_color, "desaturate", "Desaturate", 0.0, 1.0, 0.01)
        self._add_param_slider(grp_color, "vignette", "Vignette", 0.0, 1.0, 0.01)
        self._add_param_slider(grp_color, "noise", "Film Grain", 0.0, 1.0, 0.01)
        self._add_param_slider(grp_color, "noise_size", "Grain Size · px", 1.0, 8.0, 0.1)
        page_post.layout().addWidget(grp_color)
        page_post.layout().addStretch(1)
        self.tabs.addTab(scroll_post, "🎞 Post")

        # ----------------------------------------------------
        # TAB 5: VIEW & SAMPLING
        # ----------------------------------------------------
        scroll_view, page_view = self._create_tab_scroll_page()
        grp_sampling = QtPropertyGroup("SAMPLING & QUALITY", page_view)

        self.combo_quality = QtWidgets.QComboBox(page_view)
        self.combo_quality.addItems(["Edit", "Lookdev", "Capture"])
        self.combo_quality.setCurrentText("Lookdev")
        self.combo_quality.currentTextChanged.connect(self._set_sampling)
        grp_sampling.add_row("Quality Preset", self.combo_quality)

        self.combo_scale = QtWidgets.QComboBox(page_view)
        self.combo_scale.addItems(["Auto", "1x", "1.5x", "2x"])
        self.combo_scale.setCurrentText("Auto")
        self.combo_scale.currentTextChanged.connect(self._set_sampling)
        grp_sampling.add_row("Resolution Scale", self.combo_scale)

        self.combo_aa = QtWidgets.QComboBox(page_view)
        self.combo_aa.addItems(["Off", "Spatial", "Temporal", "MSAA4"])
        self.combo_aa.setCurrentText("Temporal")
        self.combo_aa.currentTextChanged.connect(self._set_sampling)
        grp_sampling.add_row("Anti-Aliasing", self.combo_aa)

        self.spin_samples = QtWidgets.QSpinBox(page_view)
        self.spin_samples.setRange(1, 4096)
        self.spin_samples.setValue(256)
        grp_sampling.add_row("Capture Samples", self.spin_samples)
        page_view.layout().addWidget(grp_sampling)

        grp_view_toggles = QtPropertyGroup("VIEWPORT OVERLAYS", page_view)
        self.cb_grid = QtWidgets.QCheckBox("Show Ground Grid (Default: Off)", page_view)
        self.cb_grid.setChecked(self.show_grid) # OFF by default
        self.cb_grid.toggled.connect(self._on_grid_toggled)
        grp_view_toggles.add_row("", self.cb_grid)

        self.cb_gizmo = QtWidgets.QCheckBox("Show 3D Orientation Gizmo", page_view)
        self.cb_gizmo.setChecked(True)
        self.cb_gizmo.toggled.connect(self._on_gizmo_toggled)
        grp_view_toggles.add_row("", self.cb_gizmo)

        self.cb_hud = QtWidgets.QCheckBox("Show HUD Diagnostics Overlay", page_view)
        self.cb_hud.setChecked(True)
        self.cb_hud.toggled.connect(self._on_hud_toggled)
        grp_view_toggles.add_row("", self.cb_hud)

        self.cb_checker = QtWidgets.QCheckBox("Checkerboard Background", page_view)
        self.cb_checker.setChecked(False)
        self.cb_checker.toggled.connect(self._on_checker_toggled)
        grp_view_toggles.add_row("", self.cb_checker)
        page_view.layout().addWidget(grp_view_toggles)

        btn_compare_row = QtWidgets.QHBoxLayout()
        btn_pin = QtWidgets.QPushButton("Pin Before", page_view)
        btn_pin.clicked.connect(self._pin_before)
        btn_clear = QtWidgets.QPushButton("Clear Compare", page_view)
        btn_clear.clicked.connect(self._clear_compare)
        btn_compare_row.addWidget(btn_pin)
        btn_compare_row.addWidget(btn_clear)
        page_view.layout().addLayout(btn_compare_row)

        page_view.layout().addStretch(1)
        self.tabs.addTab(scroll_view, "👁 View")

        # ----------------------------------------------------
        # TAB 6: TOOLS & WORKFLOW
        # ----------------------------------------------------
        scroll_tools, page_tools = self._create_tab_scroll_page()
        grp_tools = QtPropertyGroup("WORKFLOW & ASSETS", page_tools)

        self.tile_combo = QtWidgets.QComboBox(page_tools)
        self._refresh_workflow_tiles()
        grp_tools.add_row("Source Tile", self.tile_combo)

        btn_frame = QtWidgets.QPushButton("Frame All [F]", page_tools)
        btn_frame.clicked.connect(self._frame_all)
        grp_tools.add_row("", btn_frame)

        btn_outliner = QtWidgets.QPushButton("Outliner / Import Models", page_tools)
        btn_outliner.clicked.connect(self._open_object_outliner)
        grp_tools.add_row("", btn_outliner)

        btn_atlas = QtWidgets.QPushButton("Load Atlas Folder...", page_tools)
        btn_atlas.clicked.connect(self.load_atlas_folder)
        grp_tools.add_row("", btn_atlas)

        btn_demo = QtWidgets.QPushButton("Load Sample Demo", page_tools)
        btn_demo.clicked.connect(self.load_demo)
        grp_tools.add_row("", btn_demo)
        page_tools.layout().addWidget(grp_tools)

        page_tools.layout().addStretch(1)
        self.tabs.addTab(scroll_tools, "🛠 Tools")

        self.insp_layout.addWidget(self.tabs)

    def _create_tab_scroll_page(self) -> tuple[QtWidgets.QScrollArea, QtWidgets.QWidget]:
        """Create a scrollable container for each inspector tab."""
        scroll = QtWidgets.QScrollArea(self.tabs)
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet(f"background-color: {TOKENS['bg_panel']}; border: none;")
        body = QtWidgets.QWidget(scroll)
        body_layout = QtWidgets.QVBoxLayout(body)
        body_layout.setContentsMargins(4, 4, 4, 4)
        body_layout.setSpacing(6)
        scroll.setWidget(body)
        return scroll, body

    def _wrap_layout(self, layout: QtWidgets.QLayout) -> QtWidgets.QWidget:
        w = QtWidgets.QWidget()
        w.setLayout(layout)
        return w

    def _refresh_workflow_tiles(self):
        self.tile_combo.clear()
        if hasattr(self.controller, 'project') and self.controller.project:
            for t in self.controller.project.tiles:
                self.tile_combo.addItem(f"{t.name} ({t.id})", t.id)

    def _on_grid_toggled(self, checked: bool):
        self.show_grid = checked
        self.btn_grid.setText(f"⊞ Grid: {'On' if self.show_grid else 'Off'}")
        self._request_frame()

    def _on_gizmo_toggled(self, checked: bool):
        if self.renderer:
            self.renderer.show_axis_gizmo = checked
        self.viewport.set_orientation_cube(checked, self.camera_yaw, self.camera_pitch)
        self._request_frame()

    def _on_hud_toggled(self, checked: bool):
        if self.renderer:
            self.renderer.show_hud = checked
        self.viewport._show_hud = checked
        self._request_frame()

    def _on_checker_toggled(self, checked: bool):
        if self.renderer and hasattr(self.renderer, 'checker'):
            self.renderer.checker = checked
            self.renderer.invalidate_history('checker mode changed')
        self._request_frame()

    def _on_shading_mode_changed(self, mode: str):
        self.material.shading_mode = mode
        self.controller.set_render_material(self.material)
        if self.renderer:
            self.renderer.invalidate_history('shading mode changed')
        self._request_frame()

    def _on_artistic_optics_toggled(self, checked: bool):
        self.material.artistic_optics = checked
        self.controller.set_render_material(self.material)
        if self.renderer:
            self.renderer.invalidate_history('artistic optics changed')
        self._request_frame()

    def _on_debug_changed(self, text: str):
        self.material.debug = DEBUG_MODE_MAP.get(text, 0)
        self._request_frame()

    def _reset_light(self):
        self.material.light_azimuth = 35.0
        self.material.light_elevation = 25.0
        self.material.light_intensity = 1.2
        self.material.fill_intensity = 0.2
        self.material.ambient_intensity = 0.1
        self.material.light_size = 15.0
        self.material.exposure = 0.0
        self._reload_project_material()
        self._request_frame()

    def _toggle_sweep(self):
        if self._sweep_timer is not None and self._sweep_timer.isActive():
            self._sweep_timer.stop()
            self._sweep_timer = None
        else:
            if self._sweep_timer is None:
                self._sweep_timer = QtCore.QTimer(self)
                self._sweep_timer.timeout.connect(self._step_sweep)
            self._sweep_timer.start(30)

    def _step_sweep(self):
        az = (self.material.light_azimuth + 1.5 + 180.0) % 360.0 - 180.0
        self.material.light_azimuth = az
        if 'light_azimuth' in self.sliders:
            self.sliders['light_azimuth'].setValue(az, notify=False)
        self._request_frame()

    def _set_sampling(self):
        if self.renderer is None:
            return
        scale_txt = self.combo_scale.currentText()
        scale = None if scale_txt == "Auto" else float(scale_txt.rstrip("x"))
        quality = self.combo_quality.currentText()
        aa = self.combo_aa.currentText()
        try:
            self.renderer.set_quality(quality, scale, aa)
            if hasattr(self, 'oit_combo'):
                oit_txt = "Weighted · Fast" if self.renderer.transparency_mode == "weighted" else f"Hybrid · {self.renderer.peel_layers} Layers"
                idx = self.oit_combo.findText(oit_txt)
                if idx >= 0:
                    self.oit_combo.setCurrentIndex(idx)
            self._request_frame()
        except Exception as e:
            self.controller.jobFailed.emit("sampling", str(e))

    def _pin_before(self):
        if self.renderer is not None:
            try:
                self.renderer.clear_reference()
                self.renderer.render()
                self.renderer.pin_reference()
                self.viewport.set_hud_text("Compare: Left = Pinned, Right = Current")
                self._request_frame()
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "Compare", str(e))

    def _clear_compare(self):
        if self.renderer is not None:
            self.renderer.clear_reference()
            self._request_frame()

    def _open_object_outliner(self):
        getattr(self.window(), "_switch_workspace", lambda _: None)("cards")

    def load_atlas_folder(self):
        folder = QtWidgets.QFileDialog.getExistingDirectory(self, "Select Atlas Texture Folder")
        if folder and self.renderer:
            try:
                self.renderer.load_atlas_folder(folder)
                self._request_frame()
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "Atlas", str(e))

    def load_demo(self):
        if self.renderer:
            try:
                self.renderer.load_demo()
                self._request_frame()
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "Demo", str(e))

    def _update_mat(self, prop: str, val: float):
        setattr(self.material, prop, val)
        self.controller.set_render_material(self.material)
        self._request_frame()

    def _reload_project_material(self):
        from ..rendercore.settings import material_from_project
        self.material = material_from_project(self.controller.project)
        for field, slider in self.sliders.items():
            if hasattr(self.material, field):
                slider.setValue(float(getattr(self.material, field)), notify=False)
        for field, btn in self.color_buttons.items():
            current_linear = getattr(self.material, field, (1.0, 1.0, 1.0))
            current_hex = light_color_hex(current_linear)
            btn.setStyleSheet(f"background-color: {current_hex}; border: 1px solid {TOKENS['border']}; border-radius: 4px;")
        if self.renderer:
            self.renderer.material = self.material
            self.renderer.invalidate_history('project material changed')
        self._request_frame()

    def _init_gpu_renderer(self):
        if not self.isVisible() or self.renderer is not None:
            return
        """Bind discrete GPU and bind Project Atlas cache into RenderCore."""
        try:
            hwnd = self.viewport.get_hwnd()
            w = max(64, round(self.viewport.width() * self.viewport.devicePixelRatioF()))
            h = max(64, round(self.viewport.height() * self.viewport.devicePixelRatioF()))

            self.renderer = GPUHairRenderer(w, h, hwnd=hwnd, async_sampling=True, native_owner="qt")
            self.renderer.material = self.material
            self.renderer.show_grid = self.show_grid # OFF by default
            self.viewport.set_renderer_callback(self._paint_frame)

            # Load project atlas cache directly
            self._sync_atlas_to_renderer()
            self._sync_cards_to_renderer()
            self._request_frame()
        except Exception as e:
            self.viewport.set_hud_text(f"GPU Render Studio: {e}\nAlt+LMB Orbit  ·  Shift+RMB Light Angle")
            self._draw_fallback_render()

    def _sync_atlas_to_renderer(self):
        if not self.isVisible():
            return
        if self.renderer is not None:
            try:
                self.controller.ensure_atlas()
                cache = self.controller.atlas
                self.renderer.load_atlas_cache(cache)
                self._request_frame()
            except Exception as error:
                self.controller.jobFailed.emit("render", str(error))

    def _sync_cards_to_renderer(self):
        if not self.isVisible():
            return
        if self.renderer is not None:
            try:
                cache = self.controller.atlas
                cards = [HairCard.from_dict(c) for c in self.controller.project.cards]
                if not cards and self.controller.project.tiles:
                    cards = [HairCard.create(t.id, root=[i * 0.35, 0, 0]) for i, t in enumerate(self.controller.project.tiles)]
                self.renderer.load_cards(cards, cache.layout.placements, cache.layout.size)
                self._request_frame()
            except Exception as error:
                self.controller.jobFailed.emit("render", str(error))

    def _on_viewport_resized(self, w: int, h: int):
        if self.renderer is not None and w > 32 and h > 32:
            try:
                self.renderer.resize(w, h)
                self._request_frame()
            except Exception as error:
                self.controller.jobFailed.emit("render", str(error))

    def _request_frame(self):
        if self.isVisible():
            self.viewport.update()

    def _paint_frame(self):
        if not self.isVisible():
            return
        if self.renderer is not None:
            try:
                self.renderer.yaw = self.camera_yaw
                self.renderer.pitch = self.camera_pitch
                self.renderer.distance = self.camera_distance
                self.material.debug = DEBUG_MODE_MAP.get(self.debug_combo.currentText(), 0)
                self.renderer.material = self.material
                self.renderer.show_hud = self.cb_hud.isChecked() if hasattr(self, 'cb_hud') else getattr(self._view_settings, 'show_hud', True)
                self.renderer.show_grid = self.show_grid # OFF by default!
                self.renderer.show_axis_gizmo = self.cb_gizmo.isChecked() if hasattr(self, 'cb_gizmo') else getattr(self._view_settings, 'show_axis_gizmo', True)
                self.renderer.up_axis = self._view_settings.up_axis
                self.renderer.hud_lines = (
                    self.renderer.info.gpu_renderer,
                    f"{self.renderer.quality_mode} | samples {self.renderer.info.history_count}/{self.renderer.info.history_limit}"
                )
                self.renderer.render()
                if self.renderer.sampling_pending or self.renderer.info.history_count < self.renderer.info.history_limit:
                    if not getattr(self, "_settle_pending", False):
                        self._settle_pending = True
                        QtCore.QTimer.singleShot(16, self._settle_frame)
                gpu_name = getattr(self.renderer.info, 'gpu_renderer', 'Discrete GPU')
                grid_status = "Grid: On" if self.show_grid else "Grid: Off"
                self.viewport.set_hud_text(
                    f"FIBERLIGHT R3  ·  {gpu_name}  [{grid_status}]\n"
                    f"Light Azimuth: {self.material.light_azimuth:.1f}°  |  Elevation: {self.material.light_elevation:.1f}°"
                )
                return
            except Exception as error:
                self.controller.jobFailed.emit("render", str(error))
        self._draw_fallback_render()

    def _draw_fallback_render(self):
        az = self.material.light_azimuth
        el = self.material.light_elevation
        grid_status = "Grid: On" if self.show_grid else "Grid: Off"
        self.viewport.set_hud_text(
            f"GPU unavailable — no rendered image  [{grid_status}]\n"
            f"Light: Azimuth {az:.1f}° · Elevation {el:.1f}°  |  Maya Orbit [Alt+LMB]"
        )

    def _on_light_orbit(self, d_azimuth: float, d_elevation: float):
        if not getattr(self, "_light_edit_started", False):
            self.controller.snapshot()
            self._light_edit_started = True
        az = (self.material.light_azimuth + d_azimuth + 180.0) % 360.0 - 180.0
        el = max(-85.0, min(85.0, self.material.light_elevation + d_elevation))
        self.material.light_azimuth = az
        self.material.light_elevation = el
        if 'light_azimuth' in self.sliders:
            self.sliders['light_azimuth'].setValue(az, notify=False)
        if 'light_elevation' in self.sliders:
            self.sliders['light_elevation'].setValue(el, notify=False)
        self.controller.mark_dirty(True)
        self._request_frame()

    def _on_camera_orbit(self, dx: float, dy: float):
        self.camera_yaw -= dx * .009
        self.camera_pitch = max(-1.25, min(1.25, self.camera_pitch + dy * .008))
        self._request_frame()

    def _on_camera_pan(self, dx, dy):
        if self.renderer:
            from ..navigation import pan_target
            self.renderer.target[:] = pan_target(
                self.renderer.target, self.camera_yaw, self.camera_pitch, self.camera_distance,
                self.viewport.height(), dx, dy, math.radians(44)
            )
        self._request_frame()

    def _on_camera_dolly(self, factor):
        distance = self.camera_distance * factor
        if math.isfinite(distance) and distance > 0:
            self.camera_distance = max(1e-5, distance)
        self._request_frame()

    def _on_wheel_zoom(self, factor):
        self._on_camera_dolly(factor)

    def _frame_all(self):
        import numpy as np
        self.camera_yaw = 0.0
        self.camera_pitch = 0.1
        roots = [c.get('root', [0, 0, 0]) for c in self.controller.project.cards if c.get('visible', True)]
        if self.renderer and roots:
            points = np.asarray(roots, float)
            self.renderer.target[:] = points.mean(axis=0) + [0, 0.5, 0]
            self.camera_distance = float(max(np.ptp(points, axis=0).max(), 1.0) * 3.2)
        elif self.renderer:
            self.renderer.target[:] = [0, 0.48, 0]
            self.camera_distance = 4.1
        self._request_frame()

    def _begin_view_gesture(self, mode, pos):
        self._view_gesture = mode
        self._light_edit_started = False
        self._gesture_project = self.controller.project
        if self.renderer:
            self.renderer.set_interaction(True)
        if mode == 'light' and self.renderer:
            self.renderer.yaw = self.camera_yaw
            self.renderer.pitch = self.camera_pitch
            self.renderer.distance = self.camera_distance
            self.controller.snapshot()
            self._light_edit_started = True
            from .viewport_math import light_target_under_cursor
            self.material.key_target = light_target_under_cursor(
                self.renderer, pos.x(), pos.y(), self.viewport.width(), self.viewport.height()
            )

    def _on_light_radius(self, delta):
        if not getattr(self, '_light_edit_started', False):
            self.controller.snapshot()
            self._light_edit_started = True
        self.material.light_size = max(0.0, min(360.0, self.material.light_size + delta))
        if 'light_size' in self.sliders:
            self.sliders['light_size'].setValue(self.material.light_size, notify=False)
        self._request_frame()

    def _end_view_gesture(self, mode, cancelled):
        if self.renderer:
            self.renderer.set_interaction(False)
        if mode in ('light', 'radius') and getattr(self, '_gesture_project', None) is self.controller.project:
            from ..rendercore.settings import store_material
            store_material(self.controller.project, self.material)
        self._view_gesture = None
        self._request_frame()

    def _cancel_interactions(self):
        self._request_frame()

    def _toggle_inspector(self):
        vis = not self.inspector_scroll.isVisible()
        self.inspector_scroll.setVisible(vis)

    def _on_oit_changed(self, text: str):
        if self.renderer is not None:
            try:
                if "Weighted" in text:
                    self.renderer.set_transparency("weighted")
                elif "2 Layers" in text:
                    self.renderer.set_transparency("hybrid", 2)
                elif "4 Layers" in text:
                    self.renderer.set_transparency("hybrid", 4)
                elif "8 Layers" in text:
                    self.renderer.set_transparency("hybrid", 8)
                else:
                    self.renderer.set_transparency("auto", 2)
                self._request_frame()
            except Exception as error:
                self.controller.jobFailed.emit("render", str(error))

    def _set_studio_env(self):
        self.material.environment_path = ""
        self.controller.set_render_material(self.material)
        if self.renderer:
            self.renderer.invalidate_history('environment source changed')
        self._request_frame()

    def _load_hdri_env(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Choose HDRI Environment", "", "Image Files (*.hdr *.png *.jpg *.jpeg *.tif *.tiff)"
        )
        if path:
            self.material.environment_path = path
            self.controller.set_render_material(self.material)
            if self.renderer:
                self.renderer.invalidate_history('environment source changed')
            self._request_frame()

    def _capture_frame(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Capture Viewport Image", "capture.png", "PNG Image (*.png);;OpenEXR (*.exr)"
        )
        if path and self.renderer is not None:
            try:
                samples = self.spin_samples.value() if hasattr(self, 'spin_samples') else 256
                if path.lower().endswith(".exr") and hasattr(self.renderer, "capture_exr"):
                    self.renderer.capture_exr(path)
                else:
                    self.renderer.capture_transparent().save(path)
                QtWidgets.QMessageBox.information(self, "Captured", f"Frame saved cleanly ({samples} samples) to:\n{path}")
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "Capture", f"Capture error: {e}")

    def cancel_capture(self):
        if self.renderer and hasattr(self.renderer, "cancel_capture"):
            self.renderer.cancel_capture()

    def close_renderer(self):
        self.viewport.set_renderer_callback(None)
        if self.renderer:
            self.renderer.close()
            self.renderer = None

    def _settle_frame(self):
        self._settle_pending = False
        self._request_frame()

    def showEvent(self, event):
        super().showEvent(event)
        if self.renderer is None:
            QtCore.QTimer.singleShot(0, self._init_gpu_renderer)
        else:
            self._sync_atlas_to_renderer()
            self._sync_cards_to_renderer()
            self._request_frame()

    def hideEvent(self, event):
        if self.renderer is not None:
            self.renderer.release_inactive()
        super().hideEvent(event)
