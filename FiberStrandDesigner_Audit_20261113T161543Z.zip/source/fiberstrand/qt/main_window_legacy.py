"""Fiber Strand Designer - Qt 6 / PySide6 Main Application Shell.

Reconstructed to match the target UI design:
- Top Title Header with Peacock Feather branding, title, and centered 4-workspace pills
- Top Action Button: "▶ Bake Tile" (Gold gradient button)
- Standard DCC Menu bar (File, Edit, Create, Modify, View, Windows, Help)
- Tool Shelf / Ribbon below menu bar (Select, Move, Rotate, Scale, Pen, Comb, Cube, Grid, Frame)
- Bottom Status Bar with Ready status, active workspace metrics, and GPU VRAM progress bar
"""
from __future__ import annotations

import sys
from copy import deepcopy
from pathlib import Path
from PySide6 import QtCore, QtGui, QtWidgets

from .theme import TOKENS, get_stylesheet
from .controller import AppController
from .action_registry import ActionRegistry
from .fiber_studio import QtFiberStudio
from .card_editor import QtCardEditor
from .construction_studio import QtConstructionGraph
from .render_studio import QtRenderStudio

from fiberstrand.cards import export_obj
from fiberstrand.resources import branding_asset

ASSETS = Path(__file__).resolve().parents[2] / 'assets' / 'branding'


class FSDMainWindow(QtWidgets.QMainWindow):
    def __init__(self, controller: AppController | None = None, project=None):
        super().__init__()
        if controller is None:
            controller = AppController(project=project)
        self.controller = controller
        self.action_registry = ActionRegistry(self)
        self._bind_action_registry()

        self.setWindowTitle("Fiber Strand Designer — Professional 3D Grooming")
        self.resize(1440, 900)

        # Apply Global Peacock Stylesheet
        self.setStyleSheet(get_stylesheet())

        # Set Window Icon
        icon_path = branding_asset("icon")
        if icon_path.exists():
            self.setWindowIcon(QtGui.QIcon(str(icon_path)))

        self._build_header_bar()
        self._build_menu_and_toolshelf()
        self._build_footer_status_bar()
        self._build_central_workspace()

        for workspace in (self.fiber_studio,self.construction_studio,self.card_editor,self.render_studio):
            viewport=workspace.viewport
            viewport.interactionStarted.connect(lambda mode,pos,v=viewport:self.controller.set_interacting(v,True))
            viewport.interactionFinished.connect(lambda mode,cancelled,v=viewport:self.controller.set_interacting(v,False))

        # Connect controller signals
        self.controller.projectLoaded.connect(self._on_project_loaded)
        self.controller.projectSaved.connect(self._on_project_saved)
        self.controller.jobFailed.connect(self._on_background_error)
        self.controller.projectModified.connect(self._update_window_title)

        from .input_router import WorkspaceInputRouter
        self._input_router=WorkspaceInputRouter(self)
        
        from .style_registry import UIStyleRegistry
        self.ui_registry=UIStyleRegistry(self)
        self._style_studio=None

        # Initialize Develop Mode live inspector filter
        from .style_manager import LiveDevModeFilter
        self.dev_filter = LiveDevModeFilter(self)
        app = QtWidgets.QApplication.instance()
        if app:
            app.installEventFilter(self.dev_filter)

        self._update_window_title(self.controller.is_dirty)

    @property
    def project(self):
        return self.controller.project

    def _update_window_title(self, is_dirty: bool):
        proj_name = self.controller.project.name
        dirty_mark = " *" if is_dirty else ""
        file_part = f" — [{self.controller.project_path.name}]" if self.controller.project_path else ""
        self.setWindowTitle(f"Fiber Strand Designer — {proj_name}{file_part}{dirty_mark}")

    def _build_header_bar(self):
        """Top Header Bar with Peacock Logo, Title, Centered Workspace Pills, and Gold Action."""
        header = QtWidgets.QWidget(self)
        header.setFixedHeight(48)
        header.setStyleSheet(f"background-color: {TOKENS['bg_dark']}; border-bottom: 1px solid {TOKENS['border_subtle']};")
        h_layout = QtWidgets.QHBoxLayout(header)
        h_layout.setContentsMargins(14, 4, 14, 4)
        h_layout.setSpacing(12)

        # 1. Left: Brand Feather Logo & Title
        left_box = QtWidgets.QWidget(header)
        left_layout = QtWidgets.QHBoxLayout(left_box)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(8)

        logo_path = branding_asset("logo")
        lbl_logo = QtWidgets.QLabel(left_box)
        if logo_path.exists():
            pix = QtGui.QPixmap(str(logo_path)).scaled(26, 26, QtCore.Qt.AspectRatioMode.KeepAspectRatio, QtCore.Qt.TransformationMode.SmoothTransformation)
            lbl_logo.setPixmap(pix)
        else:
            lbl_logo.setText("🪶")
            lbl_logo.setStyleSheet(f"font-size: 20px; color: {TOKENS['cyan']};")
        left_layout.addWidget(lbl_logo)

        lbl_sep = QtWidgets.QLabel("|", left_box)
        lbl_sep.setStyleSheet(f"color: {TOKENS['border']}; font-size: 16px;")
        left_layout.addWidget(lbl_sep)

        lbl_title = QtWidgets.QLabel("Fiber Strand Designer", left_box)
        lbl_title.setStyleSheet(f"color: {TOKENS['text']}; font-weight: 700; font-size: 15px;")
        left_layout.addWidget(lbl_title)
        h_layout.addWidget(left_box, 0, QtCore.Qt.AlignmentFlag.AlignLeft)

        # 2. Center: Centered Workspace Capsule Pills
        h_layout.addStretch(1)
        ws_container = QtWidgets.QWidget(header)
        ws_layout = QtWidgets.QHBoxLayout(ws_container)
        ws_layout.setContentsMargins(0, 0, 0, 0)
        ws_layout.setSpacing(6)

        self.btn_fiber = QtWidgets.QPushButton("🌿 Fiber & Atlas Studio", ws_container)
        self.btn_graph = QtWidgets.QPushButton("Construction Graph", ws_container)
        self.btn_cards = QtWidgets.QPushButton("✨ 3D Groom & Lookdev", ws_container)
        self.btn_render = QtWidgets.QPushButton("GPU Render Studio", ws_container)

        self.btn_graph.hide()
        self.btn_render.hide()

        self.btn_fiber.setToolTip("Procedural 2D Fiber Generation, Maps & Construction Graph (F1)")
        self.btn_graph.setToolTip("Node-based Operator Flow (F2)")
        self.btn_cards.setToolTip("3D Hair Card Grooming, Placement & Realtime Lookdev (F3)")
        self.btn_render.setToolTip("High-Fidelity Realtime GPU Lookdev (F4)")

        self.btn_fiber.clicked.connect(lambda: self._switch_workspace("fiber"))
        self.btn_graph.clicked.connect(lambda: self._switch_workspace("graph"))
        self.btn_cards.clicked.connect(lambda: self._switch_workspace("cards"))
        self.btn_render.clicked.connect(lambda: self._switch_workspace("render"))

        for b in (self.btn_fiber, self.btn_graph, self.btn_cards, self.btn_render):
            b.setProperty("class", "workspace_pill")
            ws_layout.addWidget(b)

        h_layout.addWidget(ws_container, 0, QtCore.Qt.AlignmentFlag.AlignCenter)
        h_layout.addStretch(1)

        # 3. Right: Gold Bake Tile Action Button
        self.btn_bake_tile = QtWidgets.QPushButton("▶ Bake Tile", header)
        self.btn_primary_action = self.btn_bake_tile
        self.btn_bake_tile.setProperty("class", "gold_action")
        self.btn_bake_tile.clicked.connect(self._on_bake_tile_clicked)
        h_layout.addWidget(self.btn_bake_tile, 0, QtCore.Qt.AlignmentFlag.AlignRight)

        self.header_widget = header

    def _build_menu_and_toolshelf(self):
        """Standard DCC Menu Bar & Toolshelf underneath Header."""
        # 1. Native QMenuBar docked at the absolute top of QMainWindow
        menubar = QtWidgets.QMenuBar(self)
        self.main_menubar = menubar
        reg = self.action_registry
        
        # File Menu
        file_menu = menubar.addMenu("File")
        self.project_menu = file_menu
        file_menu.addAction(reg.create_qaction("file.new", self))
        file_menu.addAction(reg.create_qaction("file.open", self))
        file_menu.addAction(reg.create_qaction("file.sample_300", self))
        file_menu.addSeparator()
        file_menu.addAction(reg.create_qaction("file.save", self))
        file_menu.addAction(reg.create_qaction("file.save_as", self))
        file_menu.addSeparator()
        undo_action = reg.create_qaction("edit.undo", self)
        redo_action = reg.create_qaction("edit.redo", self)
        file_menu.addAction(undo_action)
        file_menu.addAction(redo_action)
        file_menu.addSeparator()
        file_menu.addAction(reg.create_qaction("file.export_obj", self))
        file_menu.addSeparator()
        file_menu.addAction(reg.create_qaction("file.exit", self))

        # Edit Menu
        edit_menu = menubar.addMenu("Edit")
        edit_menu.addAction(undo_action)
        edit_menu.addAction(redo_action)
        edit_menu.addSeparator()
        edit_menu.addAction(reg.create_qaction("edit.duplicate", self))
        edit_menu.addAction(reg.create_qaction("edit.delete", self))
        edit_menu.addAction(reg.create_qaction("edit.select_all", self))

        # View Menu
        view_menu = menubar.addMenu("View")
        view_menu.addAction(reg.create_qaction("view.frame_selected", self))
        view_menu.addAction(reg.create_qaction("view.fit_view", self))
        view_menu.addSeparator()
        view_menu.addAction(reg.create_qaction("view.toggle_wireframe", self))
        view_menu.addAction(reg.create_qaction("view.toggle_grid", self))

        # Create Menu
        create_menu = menubar.addMenu("Create")
        create_menu.addAction(reg.create_qaction("cards.add", self))
        create_menu.addAction(reg.create_qaction("cards.draw_guide", self))
        create_menu.addSeparator()
        create_menu.addAction(reg.create_qaction("fiber.new_tile", self))
        create_menu.addAction(reg.create_qaction("graph.add_node", self))

        # Modify Menu
        mod_menu = menubar.addMenu("Modify")
        mod_menu.addAction(reg.create_qaction("cards.reset_overrides", self))
        mod_menu.addAction(reg.create_qaction("cards.make_unique", self))
        mod_menu.addAction(reg.create_qaction("cards.insert_row", self))
        mod_menu.addAction(reg.create_qaction("cards.remove_row", self))

        # Windows Menu
        win_menu = menubar.addMenu("Windows")
        win_menu.addAction(reg.create_qaction("workspace.fiber", self))
        win_menu.addAction(reg.create_qaction("workspace.graph", self))
        win_menu.addAction(reg.create_qaction("workspace.cards", self))
        win_menu.addAction(reg.create_qaction("workspace.render", self))
        win_menu.addSeparator()
        dock_menu = win_menu.addMenu("⧉ Dockable Panels")
        dock_menu.addAction("Gắn lại tất cả Panel (Dock All)", self._dock_all_panels)
        dock_menu.addAction("Tách tất cả Panel thành cửa sổ rời (Float All)", self._float_all_panels)
        win_menu.addSeparator()
        win_menu.addAction("🔄 Khôi Phục Giao Diện Mặc Định (Reset UI to Default)", self._reset_ui_to_default)

        # Settings Menu (Standard DCC User Settings & Preferences)
        settings_menu = menubar.addMenu("Settings")
        settings_menu.addAction("⚙ Preferences (Tùy chọn ứng dụng)...", self._open_preferences_dialog)
        settings_menu.addSeparator()
        self.action_dev_mode = settings_menu.addAction("🛠 Develop Mode: Sửa trực tiếp UI (F11)", self._toggle_dev_mode, QtGui.QKeySequence("F11"))
        self.action_dev_mode.setCheckable(True)
        settings_menu.addAction("🎨 UI Theme & Style Studio (F12)...", self._open_developer_style_manager, QtGui.QKeySequence("F12"))
        settings_menu.addAction("🍱 Custom Layout Studio: Sắp Xếp Nút & Xuất JSON...", self._open_custom_layout_builder)
        settings_menu.addSeparator()
        qual_menu = settings_menu.addMenu("⚡ Render Quality Presets")
        qual_menu.addAction("Draft / Fast (Weighted OIT)", lambda: self._apply_quality_preset("draft"))
        qual_menu.addAction("High Fidelity (Hybrid Peeling)", lambda: self._apply_quality_preset("high"))
        qual_menu.addAction("Cinematic Lookdev (8 Layers Peeling)", lambda: self._apply_quality_preset("cinematic"))
        settings_menu.addSeparator()
        settings_menu.addAction("🔄 Khôi Phục Giao Diện Mặc Định (Reset UI to Default)", self._reset_ui_to_default)

        # Help Menu
        help_menu = menubar.addMenu("Help")
        help_menu.addAction("Documentation & Guides", lambda: QtWidgets.QMessageBox.information(self, "FSD Documentation", "Fiber Strand Designer 2.0\n\n• Alt + LMB: Orbit Camera\n• Alt + MMB: Pan Camera\n• Alt + RMB: Dolly Zoom\n• Shift + RMB: Rotate Viewport Light\n• F11: Develop Mode (Live UI picking)\n• F12: UI Style Studio"))
        help_menu.addAction("About Fiber Strand Designer", lambda: QtWidgets.QMessageBox.about(self, "About FSD", "Fiber Strand Designer 2.0\nProfessional 3D Hair & Feather DCC Tool\nDeep Dark Peacock Theme Edition"))

        self.setMenuBar(menubar)

        # 2. Tool Shelf Ribbon (Select, Move, Rotate, Scale, Pen, Comb, Cube, Grid, Frame)
        toolshelf = QtWidgets.QWidget(self)
        toolshelf.setFixedHeight(34)
        toolshelf.setStyleSheet(f"background-color: {TOKENS['bg_dark']}; border-bottom: 1px solid {TOKENS['border']};")
        ts_layout = QtWidgets.QHBoxLayout(toolshelf)
        ts_layout.setContentsMargins(10, 2, 10, 2)
        ts_layout.setSpacing(4)

        shelf_tools = [
            ("↖", "Select Tool (Q)", lambda: self._on_shelf_tool("Select")),
            ("✢", "Move Tool (W)", lambda: self._on_shelf_tool("Move")),
            ("↻", "Rotate Tool (E)", lambda: self._on_shelf_tool("Rotate")),
            ("⛶", "Scale Tool (R)", lambda: self._on_shelf_tool("Scale")),
            ("✎", "Draw Guide Curve", self._action_draw_guide_curve),
            ("彡", "Comb & Groom Brush", lambda: self._on_shelf_tool("Brush")),
            ("|", "", None),
            ("🧊", "Toggle 3D Bounding Box", self._toggle_bounding_box),
            ("⊞", "Toggle Ground Grid", self._toggle_ground_grid),
            ("⊡", "Frame Selected (F)", self._frame_selected)
        ]

        for icon_str, tip, action_cb in shelf_tools:
            if icon_str == "|":
                sep = QtWidgets.QLabel("|", toolshelf)
                sep.setStyleSheet(f"color: {TOKENS['border']}; margin: 0 4px;")
                ts_layout.addWidget(sep)
            else:
                tb = QtWidgets.QToolButton(toolshelf)
                tb.setText(icon_str)
                tb.setToolTip(tip)
                tb.setFixedSize(28, 26)
                if action_cb is not None:
                    tb.clicked.connect(action_cb)
                tb.setProperty("fsdFamily", "button.icon")
                ts_layout.addWidget(tb)

        ts_layout.addStretch(1)
        self.shelf_widget = toolshelf

    def _build_central_workspace(self):
        container = QtWidgets.QWidget(self)
        vbox = QtWidgets.QVBoxLayout(container)
        vbox.setContentsMargins(0, 0, 0, 0)
        vbox.setSpacing(0)
        vbox.addWidget(self.header_widget)
        vbox.addWidget(self.shelf_widget)

        # Stacked Widget for instantaneous workspace switching without reload
        self.workspace_stack = QtWidgets.QStackedWidget(container)

        self.fiber_studio = QtFiberStudio(self.controller, self.workspace_stack)
        self.construction_studio = QtConstructionGraph(self.controller, self.workspace_stack)
        self.card_editor = QtCardEditor(self.controller, self.workspace_stack)
        self.render_studio = QtRenderStudio(self.controller, self.workspace_stack)

        self.workspace_stack.addWidget(self.fiber_studio)        # Index 0
        self.workspace_stack.addWidget(self.construction_studio) # Index 1
        self.workspace_stack.addWidget(self.card_editor)          # Index 2
        self.workspace_stack.addWidget(self.render_studio)        # Index 3

        vbox.addWidget(self.workspace_stack, 1)
        self.setCentralWidget(container)

        self._switch_workspace("cards") # Default to Card Editor 3D as in screenshot 1

    def _build_footer_status_bar(self):
        """Rich DCC Status Bar with Ready status, active workspace metrics, and GPU VRAM progress bar."""
        sb = self.statusBar()
        sb.setFixedHeight(28)
        sb.setStyleSheet(f"background-color: {TOKENS['bg_dark']}; border-top: 1px solid {TOKENS['border']}; color: {TOKENS['text_muted']}; font-size: 11px;")

        self.lbl_ready = QtWidgets.QLabel("● Ready", sb)
        self.lbl_status=self.lbl_ready
        self.lbl_ready.setStyleSheet(f"color: {TOKENS['success']}; font-weight: 700; margin-left: 8px;")
        sb.addWidget(self.lbl_ready)

        lbl_sep1 = QtWidgets.QLabel("|", sb)
        lbl_sep1.setStyleSheet(f"color: {TOKENS['border']};")
        sb.addWidget(lbl_sep1)

        self.lbl_ws_info = QtWidgets.QLabel("Workspace: Card Editor 3D", sb)
        sb.addWidget(self.lbl_ws_info)

        lbl_sep2 = QtWidgets.QLabel("|", sb)
        lbl_sep2.setStyleSheet(f"color: {TOKENS['border']};")
        sb.addWidget(lbl_sep2)

        self.lbl_stats = QtWidgets.QLabel("Cards: 4  |  Selected: 2  |  Tris: 3,840", sb)
        sb.addWidget(self.lbl_stats)

        # Right side permanent widgets: GPU, Progress bar, VRAM
        right_container = QtWidgets.QWidget(sb)
        rc_layout = QtWidgets.QHBoxLayout(right_container)
        rc_layout.setContentsMargins(0, 0, 8, 0)
        rc_layout.setSpacing(10)

        lbl_gpu = QtWidgets.QLabel("🖥 GPU: not measured", right_container)
        lbl_gpu.setStyleSheet(f"color: {TOKENS['text_muted']};")
        rc_layout.addWidget(lbl_gpu)

        pbar = QtWidgets.QProgressBar(right_container)
        pbar.setFixedSize(110, 8)
        pbar.setValue(0)
        pbar.setTextVisible(False)
        pbar.setStyleSheet(f"""
            QProgressBar {{
                background-color: {TOKENS['bg_control']};
                border: none;
                border-radius: 4px;
            }}
            QProgressBar::chunk {{
                background-color: {TOKENS['cyan']};
                border-radius: 4px;
            }}
        """)
        rc_layout.addWidget(pbar)

        lbl_vram = QtWidgets.QLabel("VRAM: not measured", right_container)
        lbl_vram.setStyleSheet(f"color: {TOKENS['text_muted']};")
        rc_layout.addWidget(lbl_vram)

        sb.addPermanentWidget(right_container)

    def _switch_workspace(self, name: str):
        buttons = {
            "fiber": (self.btn_fiber, 0, "🌿 Fiber & Atlas Studio", "Tile: Peacock_Feather_A  |  Atlas: Atlas_01 (4×4)"),
            "graph": (self.btn_graph, 1, "Construction Graph", "Nodes: 4 (fiber_source → curl → clump → output)"),
            "cards": (self.btn_cards, 2, "✨ 3D Groom & Lookdev", "Cards: 4  |  Selected: 2  |  Tris: 3,840"),
            "render": (self.btn_render, 3, "GPU Render Studio", "OIT: Auto · GPU Budget  |  Res: 4096×2304  |  Samples: 256"),
        }

        bake_tooltips = {
            "fiber": "Bake active procedural fiber tile and refresh atlas cache (B)",
            "graph": "Evaluate construction graph nodes and commit to tile (Ctrl+Enter)",
            "cards": "Export hair cards to OBJ with MTL and textures (Ctrl+E)",
            "render": "Capture lookdev frame to transparent PNG (F10)"
        }
        self.btn_bake_tile.setToolTip(bake_tooltips.get(name, "Bake Tile"))

        for ws_key, (btn, idx, label_text, stats_text) in buttons.items():
            if ws_key == name:
                btn.setProperty("class", "workspace_pill_active")
                self.workspace_stack.setCurrentIndex(idx)
                self.lbl_ws_info.setText(f"Workspace: {label_text}")
                self.lbl_stats.setText(f"Tiles: {len(self.project.tiles)} | Cards: {len(self.project.cards)}")
            else:
                btn.setProperty("class", "workspace_pill")
            btn.style().unpolish(btn)
            btn.style().polish(btn)

    def _on_bake_tile_clicked(self):
        """Top Bake Tile button click handler."""
        idx = self.workspace_stack.currentIndex()
        if idx == 0:
            self.fiber_studio._request_preview()
            self.lbl_ready.setText("● Baking Tile...")
        elif idx == 1:
            self.construction_studio._apply_graph()
            self.lbl_ready.setText("● Graph Applied")
        elif idx == 2:
            self._action_export_obj()
        elif idx == 3:
            self.render_studio._capture_frame()

    def _frame_selected(self):
        idx = self.workspace_stack.currentIndex()
        if idx == 0:
            self.fiber_studio._on_fit_view()
        elif idx == 1:
            self.construction_studio.viewport.fit_view()
        elif idx == 2:
            self.card_editor._frame_selected()
        elif idx == 3:
            self.render_studio.viewport.fit_view()

    def _fit_view(self):
        self._frame_selected()

    def _action_reset_transforms(self):
        if self.workspace_stack.currentIndex() == 2:
            self.card_editor._card_context_action('Reset Overrides')
            self.lbl_ready.setText("● Card Transforms Reset")

    def _action_draw_guide_curve(self):
        self._switch_workspace("cards")
        self.card_editor._draw_guide_card()
        self.lbl_ready.setText("● Draw Guide Curve: Click points, Enter to commit")

    def _on_shelf_tool(self, tool_name: str):
        idx = self.workspace_stack.currentIndex()
        if idx == 2:
            self.card_editor._card_choose_tool(tool_name)
            self.lbl_ready.setText(f"● Card Tool: {tool_name}")
        elif idx == 0:
            if hasattr(self.fiber_studio, '_atlas_set_tool') and self.fiber_studio._is_atlas():
                self.fiber_studio._atlas_set_tool(tool_name)
                self.lbl_ready.setText(f"● Atlas Tool: {tool_name}")

    def _toggle_bounding_box(self):
        idx = self.workspace_stack.currentIndex()
        if idx == 2:
            wire = not getattr(self.card_editor, '_show_wire', False)
            self.card_editor._set_card_wire(wire)
            self.lbl_ready.setText(f"● Wireframe / Bounds: {'On' if wire else 'Off'}")
        else:
            ws = self.workspace_stack.currentWidget()
            if hasattr(ws, 'viewport') and hasattr(ws.viewport, '_show_cube'):
                ws.viewport.set_orientation_cube(not ws.viewport._show_cube)

    def _toggle_ground_grid(self):
        idx = self.workspace_stack.currentIndex()
        if idx == 2:
            self.card_editor._show_grid = not getattr(self.card_editor, '_show_grid', False)
            settings = getattr(self.card_editor, '_legacy_settings', None)
            if settings:
                settings.show_grid = self.card_editor._show_grid
            self.card_editor._draw_cards_wireframe()
            self.lbl_ready.setText(f"● Ground Grid: {'On' if self.card_editor._show_grid else 'Off'}")
        elif idx == 3:
            if hasattr(self.render_studio, '_toggle_grid'):
                self.render_studio._toggle_grid()
                self.lbl_ready.setText(f"● Ground Grid: {'On' if self.render_studio.show_grid else 'Off'}")
        elif idx == 0:
            if hasattr(self.fiber_studio, '_show_grid'):
                self.fiber_studio._show_grid = not getattr(self.fiber_studio, '_show_grid', False)
                self.fiber_studio._request_preview()
                self.lbl_ready.setText(f"● Ground Grid: {'On' if self.fiber_studio._show_grid else 'Off'}")

    def _action_duplicate(self):
        if self.workspace_stack.currentIndex() == 2:
            self.card_editor._duplicate_card()

    def _action_delete(self):
        if self.workspace_stack.currentIndex() == 2:
            self.card_editor._delete_card()

    def _action_new(self):
        if not self._check_unsaved_changes():
            return
        self.controller.new_project()
        self.lbl_ready.setText("● New Project")

    def _action_open(self):
        if not self._check_unsaved_changes():
            return
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Open FSD Project", "", "FSD Project (*.fsd)")
        if path:
            try:
                self.lbl_ready.setText("● Loading project…")
                self.controller.open_project_async(path,lambda project:self.lbl_ready.setText(f"● Loaded {Path(path).name}"))
            except Exception as e:
                QtWidgets.QMessageBox.critical(self, "Open Error", f"Failed to load project:\n{e}")

    def _action_open_sample_300(self):
        sample_path = Path(__file__).resolve().parents[2] / "projects" / "sample_300_fibers.fsd"
        if not sample_path.exists():
            from tools.generate_sample_300 import generate_300_sample_project
            generate_300_sample_project(sample_path)
        if sample_path.exists():
            try:
                self.lbl_ready.setText("● Loading 300 clusters…")
                def loaded(project):
                    self._switch_workspace("cards")
                    self.card_editor._frame_selected()
                    self.lbl_ready.setText("● Loaded 300 Diverse Clusters Showcase!")
                self.controller.open_project_async(sample_path,loaded)
            except Exception as e:
                QtWidgets.QMessageBox.critical(self, "Sample Load Error", f"Failed to load sample project:\n{e}")

    def _action_save(self):
        if self.controller.project_path is None:
            self._action_save_as()
        else:
            try:
                saved = self.controller.save_project()
                self.lbl_ready.setText(f"● Saved {saved.name}")
            except Exception as e:
                QtWidgets.QMessageBox.critical(self, "Save Error", f"Failed to save project:\n{e}")

    def _action_save_as(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Save FSD Project As", "", "FSD Project (*.fsd)")
        if path:
            try:
                saved = self.controller.save_project(path)
                self.lbl_ready.setText(f"● Saved {saved.name}")
            except Exception as e:
                QtWidgets.QMessageBox.critical(self, "Save Error", f"Failed to save project:\n{e}")

    def _action_undo(self):
        if self.controller.undo():
            self.lbl_ready.setText("● Undo")

    def _action_redo(self):
        if self.controller.redo():
            self.lbl_ready.setText("● Redo")

    def _action_export_obj(self):
        from .export_dialog import QtAtlasExportDialog
        dlg = QtAtlasExportDialog(self.controller, self)
        if dlg.exec() != QtWidgets.QDialog.DialogCode.Accepted:
            return
        cfg = dlg.get_export_config()
        folder = cfg["folder"]
        mode = cfg["mode"]
        channels = cfg["channels"]
        folder.mkdir(parents=True, exist_ok=True)
        snapshot = deepcopy(self.controller.project)
        self.lbl_status.setText(f'Exporting {mode.upper()} snapshot: baking tiles and writing texture sets in background...')
        def worker(cancel):
            from fiberstrand.atlas import AtlasCache
            from fiberstrand.raster import render_tile
            from fiberstrand.cards import HairCard
            cache = AtlasCache(snapshot)
            for tile in snapshot.tiles:
                if cancel():
                    raise RuntimeError('Export canceled')
                tile.settings.bake_samples=16;tile.settings.ao_mode='geometry'
                result=None
                import os
                if os.environ.get('FSD_FIBERBAKE_BACKEND','auto') not in ('cpu','legacy-gpu'):
                    try:
                        from ..fiberbake_x.atlas import prepare_production
                        result=prepare_production(tile,channels,cancel)
                    except Exception:
                        if cancel() or os.environ.get('FSD_FIBERBAKE_BACKEND')=='gpu':raise
                if result is None:result=render_tile(tile,channels=channels,should_cancel=cancel)
                cache=cache.staged_tile(result)
            cache._cancel=cancel
            return export_obj([HairCard.from_dict(c) for c in snapshot.cards], snapshot, cache, folder, mode=mode, channels=channels)
        def done(path, revision):
            self.lbl_status.setText('Exported: ' + str(path))
            QtWidgets.QMessageBox.information(self, 'Export complete', f'Successfully exported in {mode.upper()} format to:\n{path}')
        self.controller.submit_job('export_obj', worker, done)

    def _check_unsaved_changes(self) -> bool:
        if not self.controller.is_dirty:
            return True
        reply = QtWidgets.QMessageBox.question(
            self,
            "Unsaved Changes",
            "Project có những thay đổi chưa lưu. Bạn có muốn lưu trước không?",
            QtWidgets.QMessageBox.StandardButton.Save | QtWidgets.QMessageBox.StandardButton.Discard | QtWidgets.QMessageBox.StandardButton.Cancel
        )
        if reply == QtWidgets.QMessageBox.StandardButton.Save:
            self._action_save()
            return not self.controller.is_dirty
        elif reply == QtWidgets.QMessageBox.StandardButton.Discard:
            return True
        return False

    def _bind_action_registry(self):
        """Bind unified ActionRegistry handlers to concrete methods."""
        reg = self.action_registry
        reg.bind_handler("file.new", self._action_new)
        reg.bind_handler("file.open", self._action_open)
        reg.bind_handler("file.sample_300", self._action_open_sample_300)
        reg.bind_handler("file.save", self._action_save)
        reg.bind_handler("file.save_as", self._action_save_as)
        reg.bind_handler("file.export_obj", self._action_export_obj)
        reg.bind_handler("file.exit", self.close)

        reg.bind_handler("edit.undo", self._action_undo)
        reg.bind_handler("edit.redo", self._action_redo)
        reg.bind_handler("edit.duplicate", self._action_duplicate)
        reg.bind_handler("edit.delete", self._action_delete)
        reg.bind_handler("edit.select_all", lambda: self.card_editor._select_all_cards() if self.workspace_stack.currentIndex() == 2 else None)

        reg.bind_handler("view.frame_selected", self._frame_selected)
        reg.bind_handler("view.fit_view", self._fit_view)
        reg.bind_handler("view.toggle_wireframe", self._toggle_bounding_box)
        reg.bind_handler("view.toggle_grid", self._toggle_ground_grid)

        reg.bind_handler("workspace.fiber", lambda: self._switch_workspace("fiber"))
        reg.bind_handler("workspace.graph", lambda: self._switch_workspace("graph"))
        reg.bind_handler("workspace.cards", lambda: self._switch_workspace("cards"))
        reg.bind_handler("workspace.render", lambda: self._switch_workspace("render"))

        reg.bind_handler("cards.add", lambda: self.controller.add_card())
        reg.bind_handler("cards.draw_guide", self._action_draw_guide_curve)
        reg.bind_handler("cards.reset_overrides", self._action_reset_transforms)
        reg.bind_handler("cards.make_unique", lambda: self.card_editor._card_context_action('Make Unique'))
        reg.bind_handler("cards.insert_row", lambda: self.card_editor._card_context_action('Insert Row'))
        reg.bind_handler("cards.remove_row", lambda: self.card_editor._card_context_action('Remove Row'))
        reg.bind_handler("cards.assign_tile", lambda: self.card_editor._assign_tile())

        reg.bind_handler("fiber.new_tile", lambda: self.fiber_studio._new_tile())
        reg.bind_handler("fiber.duplicate_tile", lambda: self.fiber_studio._dup_tile())
        reg.bind_handler("fiber.delete_tile", lambda: self.fiber_studio._del_tile())
        reg.bind_handler("fiber.bake_tile", lambda: self.fiber_studio._request_preview())

        reg.bind_handler("graph.add_node", lambda: self.construction_studio._add_node())
        reg.bind_handler("graph.delete_node", lambda: self.construction_studio._delete_node())
        reg.bind_handler("graph.load_preset", lambda: self.construction_studio._load_preset())
        reg.bind_handler("graph.import_json", lambda: self.construction_studio._import_json())
        reg.bind_handler("graph.export_json", lambda: self.construction_studio._export_json())
        reg.bind_handler("graph.apply_tile", lambda: self.construction_studio._apply_graph())

        reg.bind_handler("render.capture", lambda: self.render_studio._capture_frame())
        reg.bind_handler("render.export_exr", lambda: self.render_studio._export_exr())

    def _open_custom_layout_builder(self):
        """Open the interactive Layout Builder Studio to organize buttons and export JSON."""
        from .layout_builder import LayoutBuilderDialog
        dialog = LayoutBuilderDialog(self.action_registry, self)
        dialog.exec()

    def _reset_ui_to_default(self):
        """Khôi phục toàn bộ giao diện, panels, nút chức năng và kích thước splitter về mặc định sạch."""
        # 1. Dock all floating panels back into splitter
        self._dock_all_panels()

        # 2. Reset and ensure all panels/widgets are visible across all workspaces
        if hasattr(self, 'shelf_widget') and self.shelf_widget:
            self.shelf_widget.setVisible(True)

        for ws in (self.fiber_studio, self.construction_studio, self.card_editor, self.render_studio):
            if hasattr(ws, 'splitter') and ws.splitter:
                ws.splitter.setVisible(True)
                # Unhide all children in splitter
                for i in range(ws.splitter.count()):
                    w = ws.splitter.widget(i)
                    if w:
                        w.setVisible(True)
                # Reset splitter ratio to standard DCC default: [sidebar 260, viewport 840, inspector 320]
                ws.splitter.setSizes([260, 840, 320])

        # 3. Reset UI styling spec to factory clean state if modified
        if hasattr(self, 'ui_registry') and self.ui_registry:
            from .style_registry import default_spec
            self.ui_registry.load(default_spec())
            self.ui_registry.save()
            self.ui_registry.apply()

        # 4. Notify user
        self.lbl_ready.setText("● Đã khôi phục toàn bộ giao diện và các cụm nút về mặc định!")
        QtWidgets.QMessageBox.information(
            self,
            "Khôi Phục Giao Diện Mặc Định",
            "Đã khôi phục hoàn tất:\n"
            "✓ Gắn lại tất cả các Panel vào khung làm việc\n"
            "✓ Hiển thị lại toàn bộ Toolbars, Shelves, Outliner và Inspector\n"
            "✓ Đặt lại tỷ lệ panel chuẩn (260 : 840 : 320)\n"
            "✓ Đưa toàn bộ kiểu dáng nút về mặc định gốc của Peacock Dark."
        )

    def _dock_all_panels(self):
        """Dock all floating panels back into their parent workspaces."""
        from .dockable_panel import DockablePanelWrapper
        for panel in self.findChildren(DockablePanelWrapper):
            if panel.is_floating:
                panel.dock_back()

    def _float_all_panels(self):
        """Float all dockable panels into modeless tool windows."""
        from .dockable_panel import DockablePanelWrapper
        for panel in self.findChildren(DockablePanelWrapper):
            if not panel.is_floating:
                panel.float_out()

    def _confirm_ui_design(self):
        registry=getattr(self,'ui_registry',None)
        if registry is None or not registry.dirty:return True
        answer=QtWidgets.QMessageBox.question(self,'Thiết kế UI chưa lưu','Lưu thiết kế UI trước khi thoát?',QtWidgets.QMessageBox.StandardButton.Save|QtWidgets.QMessageBox.StandardButton.Discard|QtWidgets.QMessageBox.StandardButton.Cancel)
        if answer==QtWidgets.QMessageBox.StandardButton.Cancel:return False
        if answer==QtWidgets.QMessageBox.StandardButton.Save:
            try:registry.save()
            except (OSError,ValueError) as error:
                QtWidgets.QMessageBox.warning(self,'Không lưu được UI',str(error));return False
        else:registry.discard()
        return True

    def closeEvent(self, event: QtGui.QCloseEvent):
        if self._confirm_ui_design() and self._check_unsaved_changes():
            self.fiber_studio.close_live_viewport()
            self.construction_studio.close_live_viewport()
            self.card_editor.close_card_viewport()
            self.render_studio.close_renderer()
            self.controller.shutdown()
            event.accept()
        else:
            event.ignore()

    def _on_background_error(self,name,error):
        self.lbl_ready.setText(f"● {name}: {error}")
        if name=="open_project":QtWidgets.QMessageBox.critical(self,"Open Error",str(error))

    def _on_project_loaded(self):
        self._update_window_title(self.controller.is_dirty)

    def _on_project_saved(self, path: str):
        self._update_window_title(False)

    def _open_developer_style_manager(self):
        from .style_manager import QtDeveloperStyleManager
        if self._style_studio is None:self._style_studio=QtDeveloperStyleManager(main_window=self)
        self._style_studio.show();self._style_studio.raise_();self._style_studio.activateWindow()

    def _toggle_dev_mode(self):
        active=self.dev_filter.toggle();self.action_dev_mode.setChecked(active)
        self.lbl_ready.setText('Develop: chuột phải / Ctrl+Shift+click để chọn UI · F12 mở Studio' if active else '● Ready')

    def _open_preferences_dialog(self):
        """Open Modern Application Preferences modal dialog."""
        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle("Preferences — Fiber Strand Designer")
        dlg.setFixedSize(560, 440)
        dlg.setStyleSheet(f"background-color: {TOKENS['bg_panel']}; color: {TOKENS['text']}; font-family: Segoe UI;")
        
        layout = QtWidgets.QVBoxLayout(dlg)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)
        
        title = QtWidgets.QLabel("⚙ Application Preferences", dlg)
        title.setStyleSheet(f"font-size: 16px; font-weight: 700; color: {TOKENS['cyan']};")
        layout.addWidget(title)
        
        tabs = QtWidgets.QTabWidget(dlg)
        
        # Tab 1: Appearance & UI
        tab_ui = QtWidgets.QWidget()
        ui_layout = QtWidgets.QFormLayout(tab_ui)
        ui_layout.setContentsMargins(14, 14, 14, 14)
        ui_layout.setSpacing(12)
        
        lbl_theme = QtWidgets.QLabel("Deep Dark Peacock (#040B13 / #00CBD7)", tab_ui)
        lbl_font = QtWidgets.QLabel("Segoe UI (11-12px)", tab_ui)
        lbl_dpi = QtWidgets.QLabel("Per-Monitor High-DPI V2 (Active)", tab_ui)
        lbl_ws_def = QtWidgets.QLabel("✨ 3D Groom & Lookdev", tab_ui)
        
        ui_layout.addRow("Active Theme:", lbl_theme)
        ui_layout.addRow("Typography:", lbl_font)
        ui_layout.addRow("Display Scaling:", lbl_dpi)
        ui_layout.addRow("Default Workspace:", lbl_ws_def)
        tabs.addTab(tab_ui, "Appearance")
        
        # Tab 2: GPU & Render Engine
        tab_gpu = QtWidgets.QWidget()
        gpu_layout = QtWidgets.QFormLayout(tab_gpu)
        gpu_layout.setContentsMargins(14, 14, 14, 14)
        gpu_layout.setSpacing(12)
        
        from fiberstrand.gpu_bootstrap import launch_status
        status = launch_status()
        gpu_mode = status.get('mode', 'Direct OpenGL')
        gpu_cand = status.get('candidate', 'Auto DXGI Detected')
        vram_mb = status.get('candidate_vram_mb', 'N/A')
        
        lbl_mode = QtWidgets.QLabel(str(gpu_mode), tab_gpu)
        lbl_gpu = QtWidgets.QLabel(f"{gpu_cand} ({vram_mb} MB Dedicated VRAM)", tab_gpu)
        lbl_oit = QtWidgets.QLabel("Hybrid Depth Peeling (8 front layers + Tail)", tab_gpu)
        lbl_shadows = QtWidgets.QLabel("Dual RGBA16F (8 bins @ 1024)", tab_gpu)
        
        gpu_layout.addRow("GPU Mode:", lbl_mode)
        gpu_layout.addRow("Discrete GPU:", lbl_gpu)
        gpu_layout.addRow("OIT Transparency:", lbl_oit)
        gpu_layout.addRow("Shadow Quality:", lbl_shadows)
        tabs.addTab(tab_gpu, "GPU & Hardware")
        
        # Tab 3: Authoring & Engine
        tab_engine = QtWidgets.QWidget()
        eng_layout = QtWidgets.QFormLayout(tab_engine)
        eng_layout.setContentsMargins(14, 14, 14, 14)
        eng_layout.setSpacing(12)
        
        lbl_atlas_size = QtWidgets.QLabel("4096 x 4096 (16-bit Float linear)", tab_engine)
        lbl_strand_steps = QtWidgets.QLabel("32 subdivisions per spline", tab_engine)
        lbl_undo = QtWidgets.QLabel("100 steps (Undo / Redo)", tab_engine)
        
        eng_layout.addRow("Atlas Resolution:", lbl_atlas_size)
        eng_layout.addRow("Spline Steps:", lbl_strand_steps)
        eng_layout.addRow("Undo History Limit:", lbl_undo)
        tabs.addTab(tab_engine, "Authoring & Engine")
        
        layout.addWidget(tabs)
        
        btn_box = QtWidgets.QHBoxLayout()
        btn_box.addStretch(1)
        btn_close = QtWidgets.QPushButton("Close", dlg)
        btn_close.setProperty("class", "primary")
        btn_close.setFixedWidth(90)
        btn_close.clicked.connect(dlg.accept)
        btn_box.addWidget(btn_close)
        layout.addLayout(btn_box)
        
        dlg.exec()

    def _apply_quality_preset(self, preset: str):
        """Switch render quality preset across active studios."""
        preset_name = preset.lower()
        if hasattr(self, 'render_studio') and self.render_studio:
            if hasattr(self.render_studio, 'oit_combo'):
                idx = 0 if preset_name == 'draft' else (1 if preset_name == 'high' else 2)
                if idx < self.render_studio.oit_combo.count():
                    self.render_studio.oit_combo.setCurrentIndex(idx)
        self.lbl_ready.setText(f"● Applied Quality Preset: {preset.capitalize()}")


