"""Native High-Performance GPU & 2D Composite Viewport Surface for Qt 6 / PySide6.

Features:
- Dual-mode presentation:
  1. Direct GPU Direct3D 12 / OpenGL WGL native window embedding (zero-copy swapchain)
  2. 2D Tile / Atlas / Curve preview rendering via high-precision QPainter with anti-aliasing
- Interactive Maya navigation: Alt+LMB (orbit), Alt+MMB (pan), Alt+RMB (dolly zoom)
- Interactive Studio Light orientation: Shift+RMB (horizontal = azimuth, vertical = elevation)
- High-DPI physical coordinate mapping
- HUD statistics overlay (FPS, card counts, resolution)
"""
from __future__ import annotations

import sys
import math
from typing import Callable
from PySide6 import QtCore, QtGui, QtWidgets
from .theme import TOKENS


class _LiveGPUSurface(QtWidgets.QWidget):
    """Retained WGL child: raster preview never shares its pixel-format/DC."""
    def __init__(self,parent):
        super().__init__(parent);self.setObjectName('qt_fsd_live_surface')
        for attribute in (QtCore.Qt.WidgetAttribute.WA_NativeWindow,QtCore.Qt.WidgetAttribute.WA_PaintOnScreen,QtCore.Qt.WidgetAttribute.WA_NoSystemBackground,QtCore.Qt.WidgetAttribute.WA_TransparentForMouseEvents):self.setAttribute(attribute,True)
        self.setFocusPolicy(QtCore.Qt.FocusPolicy.NoFocus);self.setGeometry(parent.rect());self.hide()
    def paintEngine(self):return None
    def paintEvent(self,event):
        owner=self.parentWidget();callback=getattr(owner,'_renderer_callback',None)
        if callback is not None and not callable(getattr(owner,'_map_canvas',None)):
            try:callback()
            except Exception as error:owner.renderFailed.emit(str(error))

class QtViewportHost(QtWidgets.QWidget):
    """Adaptive Viewport widget hosting both hardware GPU swapchain and 2D high-res previews."""

    renderFailed = QtCore.Signal(str)
    interactionStarted = QtCore.Signal(str, object)
    interactionFinished = QtCore.Signal(str, bool)
    radiusChanged = QtCore.Signal(float)
    doubleClicked = QtCore.Signal(object)
    pointerPressed = QtCore.Signal(object, int, int)
    pointerMoved = QtCore.Signal(object, int)
    pointerReleased = QtCore.Signal(object, int, int)
    hoverMoved = QtCore.Signal(object)
    repeatRequested = QtCore.Signal()
    piePressed = QtCore.Signal(object)
    pieReleased = QtCore.Signal(object)
    snapChanged = QtCore.Signal(bool)
    contextRequested = QtCore.Signal(object)
    acceptRequested = QtCore.Signal()

    orbitChanged = QtCore.Signal(float, float)        # dx, dy
    panChanged = QtCore.Signal(float, float)          # dx, dy
    dollyChanged = QtCore.Signal(float)               # delta
    lightOrbitChanged = QtCore.Signal(float, float)   # azimuth, elevation
    wheelZoomed = QtCore.Signal(float)                # factor
    resized = QtCore.Signal(int, int)                 # width, height
    frameRequested = QtCore.Signal()                  # Key F
    cancelRequested = QtCore.Signal()                 # Escape
    toolActionRequested = QtCore.Signal(str)          # Tool key ('select', 'move', 'rotate', 'scale', 'brush')
    componentRequested = QtCore.Signal(str)           # Component 1..6 ('Card', 'Root', 'Row', 'Vertex', 'Edge', 'Face')
    undoRequested = QtCore.Signal()                   # Ctrl+Z
    redoRequested = QtCore.Signal()                   # Ctrl+Y / Ctrl+Shift+Z
    duplicateRequested = QtCore.Signal()              # Shift+D / Ctrl+D
    deleteRequested = QtCore.Signal()                 # Delete / BackSpace
    selectAllRequested = QtCore.Signal()              # Ctrl+A
    tabToggleRequested = QtCore.Signal()              # Tab

    def __init__(self, parent: QtWidgets.QWidget | None = None):
        super().__init__(parent)
        # Note: We do NOT set WA_PaintOnScreen = True globally so that QPainter works reliably
        # for 2D previews, HUD text, and grid overlays when GPU swapchain is not actively presenting.
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_NativeWindow, True)
        self.setFocusPolicy(QtCore.Qt.FocusPolicy.StrongFocus)
        self.setMouseTracking(True)

        self._pen_pressure=1.
        self._view_kind='map'
        self._view_zoom=1.;self._view_pan=QtCore.QPointF();self._view_angle=0.;self._raw_view_angle=0.
        self._gesture_button=None;self._gesture=None;self._space_down=False;self._s_down=False
        self._last_mouse_pos = QtCore.QPointF()
        self._nav_mode: str | None = None
        self._light_mode: bool = False

        self._pixmap: QtGui.QPixmap | None = None
        self._hud_text: str = ""
        self._hud_pill_left: str = ""
        self._hud_pill_right: str = ""
        self._show_cube: bool = False
        self._camera_yaw: float = 0.0
        self._camera_pitch: float = 0.2
        self._empty_label: str = "Viewport Ready"
        self._renderer_callback: Callable[[], None] | None = None

    def set_orientation_cube(self, enabled: bool, yaw: float = 0.0, pitch: float = 0.2):
        self._show_cube = enabled
        self._camera_yaw = yaw
        self._camera_pitch = pitch
        self.update()

    def set_hud_pills(self, left_pill: str = "", right_pill: str = ""):
        self._hud_pill_left = left_pill
        self._hud_pill_right = right_pill
        self.update()

    def set_display_pixmap(self, pixmap: QtGui.QPixmap | None):
        """Set 2D tile raster or atlas texture preview."""
        self._pixmap = pixmap
        self.update()

    def set_hud_text(self, text: str):
        """Set viewport status / diagnostics overlay."""
        if self._hud_text==text:return
        self._hud_text = text
        if self._renderer_callback is None:self.update()

    def set_empty_label(self, label: str):
        self._empty_label = label
        self.update()

    def set_renderer_callback(self, cb: Callable[[], None]):
        """Optional hook for manual frame paint from an external renderer."""
        self._renderer_callback = cb
        if cb is None:
            self.hide_live_surface();self._gpu_texture_image_size=None
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_NoSystemBackground, cb is not None)
        self.update()

    def update(self,*args):
        super().update(*args)
        surface=getattr(self,'_live_surface',None)
        if surface is not None and surface.isVisible() and getattr(self,'_renderer_callback',None) is not None and not callable(getattr(self,'_map_canvas',None)):surface.update()

    def live_surface(self):
        surface=getattr(self,'_live_surface',None)
        if surface is None:self._live_surface=surface=_LiveGPUSurface(self)
        return surface
    def hide_live_surface(self):
        surface=getattr(self,'_live_surface',None)
        if surface is not None:surface.hide()
    def paintEngine(self):
        return super().paintEngine()

    def _image_rect(self):
        gpu_size=getattr(self,'_gpu_texture_image_size',None) if self._renderer_callback is not None else None
        if gpu_size:pw,ph=gpu_size
        elif self._pixmap is None or self._pixmap.isNull():return QtCore.QRectF(0,0,self.width(),self.height())
        else:pw,ph=self._pixmap.width(),self._pixmap.height()
        scale=min((self.width()-32)/pw,(self.height()-32)/ph)
        w,h=max(1,int(pw*scale)),max(1,int(ph*scale))
        return QtCore.QRectF((self.width()-w)//2,(self.height()-h)//2,w,h)

    def _image_transform(self):
        transform=QtGui.QTransform()
        transform.translate(self.width()/2+self._view_pan.x(),self.height()/2+self._view_pan.y())
        transform.rotate(-self._view_angle);transform.scale(self._view_zoom,self._view_zoom)
        transform.translate(-self.width()/2,-self.height()/2)
        return transform

    def image_uv(self,pos):
        point=self._image_transform().inverted()[0].map(pos);rect=self._image_rect()
        return ((point.x()-rect.x())/rect.width(),(point.y()-rect.y())/rect.height())

    def image_point(self,u,v):
        rect=self._image_rect()
        return self._image_transform().map(QtCore.QPointF(rect.x()+u*rect.width(),rect.y()+v*rect.height()))

    def get_hwnd(self) -> int:
        """Returns the Win32 native HWND handle for WGL/D3D12 device attachment."""
        return int(self.winId())

    def resizeEvent(self, event: QtGui.QResizeEvent):
        super().resizeEvent(event)
        surface=getattr(self,'_live_surface',None)
        if surface is not None:surface.setGeometry(self.rect())
        self.resized.emit(round(self.width()*self.devicePixelRatioF()), round(self.height()*self.devicePixelRatioF()))

    def paintEvent(self, event: QtGui.QPaintEvent):
        # A 2D canvas owns presentation exclusively (Atlas); a late live callback
        # must not return before the canvas paint and retain the previous GL frame.
        if self._renderer_callback is not None and not callable(getattr(self,'_map_canvas',None)):
            try:
                self._renderer_callback()
                return
            except Exception as error:
                self.renderFailed.emit(str(error))
                return

        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QtGui.QPainter.RenderHint.SmoothPixmapTransform)

        rect = self.rect()

        # 1. Dark Viewport Background
        painter.fillRect(rect, QtGui.QColor(TOKENS["bg_dark"]))

        canvas=getattr(self,'_map_canvas',None)
        if canvas:canvas(painter)
        else:
            painter.save()
            painter.translate(self.width()/2+self._view_pan.x(),self.height()/2+self._view_pan.y())
            painter.rotate(-self._view_angle);painter.scale(self._view_zoom,self._view_zoom)
            painter.translate(-self.width()/2,-self.height()/2)
            # 2. Draw 2D Pixmap / Tile Texture
            if self._pixmap and not self._pixmap.isNull():
                # Fit into viewport maintaining aspect ratio
                pw = self._pixmap.width()
                ph = self._pixmap.height()
                if pw > 0 and ph > 0:
                    scale = min((self.width() - 32) / pw, (self.height() - 32) / ph)
                    target_w = max(1, int(pw * scale))
                    target_h = max(1, int(ph * scale))
                    target_x = (self.width() - target_w) // 2
                    target_y = (self.height() - target_h) // 2
                    target_rect = QtCore.QRect(target_x, target_y, target_w, target_h)

                    # Draw subtle drop shadow/boundary around tile
                    painter.fillRect(target_rect.adjusted(-1, -1, 1, 1), QtGui.QColor(TOKENS["border"]))
                    painter.drawPixmap(target_rect, self._pixmap)
            else:
                # Subtle background grid & prompt when no pixmap or direct HWND scene loaded
                self._draw_viewport_grid(painter, rect)

            painter.restore()
        overlay=getattr(self,"_map_overlay",None)
        if overlay:overlay(painter)
        # 3. Draw HUD text (Top-Left)
        if self._hud_text:
            painter.setPen(QtGui.QColor(TOKENS["cyan"]))
            font = self.font()
            font.setPointSize(9)
            font.setBold(True)
            painter.setFont(font)
            top_offset = 64 if self._show_cube else 14
            painter.drawText(
                rect.adjusted(14, top_offset, -14, -14),
                QtCore.Qt.AlignmentFlag.AlignTop | QtCore.Qt.AlignmentFlag.AlignLeft,
                self._hud_text,
            )

        # 4. Draw 3D Orientation Cube Widget (Top-Left)
        if self._show_cube:
            self._draw_orientation_cube(painter, QtCore.QPointF(42, 42))

        # 5. Draw Bottom HUD Pills (Bottom-Left and Bottom-Right)
        if self._hud_pill_left or self._hud_pill_right:
            self._draw_hud_pills(painter, rect)

    def _draw_orientation_cube(self, painter: QtGui.QPainter, center: QtCore.QPointF):
        """Draw a sleek DCC 3D navigation cube (FRONT, RIGHT, TOP)."""
        painter.save()
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        cx, cy = center.x(), center.y()
        size = 22.0

        # Isometric projection angles with subtle camera influence
        cyaw = math.cos(self._camera_yaw)
        syaw = math.sin(self._camera_yaw)

        # Draw Top Face
        top_poly = QtGui.QPolygonF([
            QtCore.QPointF(cx, cy - size),
            QtCore.QPointF(cx + size * 0.86, cy - size * 0.5),
            QtCore.QPointF(cx, cy),
            QtCore.QPointF(cx - size * 0.86, cy - size * 0.5)
        ])
        painter.setBrush(QtGui.QColor(24, 46, 68, 200))
        painter.setPen(QtGui.QPen(QtGui.QColor(TOKENS["cyan"]), 1.0))
        painter.drawPolygon(top_poly)

        # Draw Front / Left Face
        left_poly = QtGui.QPolygonF([
            QtCore.QPointF(cx - size * 0.86, cy - size * 0.5),
            QtCore.QPointF(cx, cy),
            QtCore.QPointF(cx, cy + size),
            QtCore.QPointF(cx - size * 0.86, cy + size * 0.5)
        ])
        painter.setBrush(QtGui.QColor(16, 32, 48, 220))
        painter.drawPolygon(left_poly)

        # Draw Right Face
        right_poly = QtGui.QPolygonF([
            QtCore.QPointF(cx, cy),
            QtCore.QPointF(cx + size * 0.86, cy - size * 0.5),
            QtCore.QPointF(cx + size * 0.86, cy + size * 0.5),
            QtCore.QPointF(cx, cy + size)
        ])
        painter.setBrush(QtGui.QColor(10, 22, 34, 230))
        painter.drawPolygon(right_poly)

        # Labels
        f = painter.font()
        f.setPointSize(6)
        f.setBold(True)
        painter.setFont(f)
        painter.setPen(QtGui.QColor(TOKENS["cyan"]))
        painter.drawText(QtCore.QRectF(cx - size * 0.86, cy, size * 0.86, size * 0.6), QtCore.Qt.AlignmentFlag.AlignCenter, "FRONT")
        painter.drawText(QtCore.QRectF(cx, cy, size * 0.86, size * 0.6), QtCore.Qt.AlignmentFlag.AlignCenter, "RIGHT")
        painter.drawText(QtCore.QRectF(cx - size * 0.5, cy - size * 0.8, size, size * 0.5), QtCore.Qt.AlignmentFlag.AlignCenter, "TOP")
        painter.restore()

    def _draw_hud_pills(self, painter: QtGui.QPainter, rect: QtCore.QRect):
        """Draw interactive bottom-docked status pills like professional renderers."""
        painter.save()
        f = painter.font()
        f.setPointSize(9)
        f.setBold(True)
        painter.setFont(f)
        fm = QtGui.QFontMetrics(f)

        margin = 12
        pill_h = 24
        py = rect.bottom() - pill_h - margin

        # Left Pill
        if self._hud_pill_left:
            txt_w = fm.horizontalAdvance(self._hud_pill_left) + 20
            pill_rect = QtCore.QRectF(rect.left() + margin, py, txt_w, pill_h)
            painter.setBrush(QtGui.QColor(8, 16, 26, 210))
            painter.setPen(QtGui.QPen(QtGui.QColor(TOKENS["border"]), 1.0))
            painter.drawRoundedRect(pill_rect, 12, 12)
            painter.setPen(QtGui.QColor(TOKENS["cyan"]))
            painter.drawText(pill_rect, QtCore.Qt.AlignmentFlag.AlignCenter, self._hud_pill_left)

        # Right Pill
        if self._hud_pill_right:
            txt_w = fm.horizontalAdvance(self._hud_pill_right) + 20
            pill_rect = QtCore.QRectF(rect.right() - margin - txt_w, py, txt_w, pill_h)
            painter.setBrush(QtGui.QColor(8, 16, 26, 210))
            painter.setPen(QtGui.QPen(QtGui.QColor(TOKENS["border"]), 1.0))
            painter.drawRoundedRect(pill_rect, 12, 12)
            painter.setPen(QtGui.QColor(TOKENS["text_muted"]))
            painter.drawText(pill_rect, QtCore.Qt.AlignmentFlag.AlignCenter, self._hud_pill_right)

        painter.restore()

    def _draw_viewport_grid(self, painter: QtGui.QPainter, rect: QtCore.QRect):
        painter.setPen(QtGui.QColor(16, 40, 62, 120))
        cx = rect.center().x()
        cy = rect.center().y()
        step = 40
        for x in range(cx % step, rect.width(), step):
            painter.drawLine(x, 0, x, rect.height())
        for y in range(cy % step, rect.height(), step):
            painter.drawLine(0, y, rect.width(), y)

        if self._empty_label:
            painter.setPen(QtGui.QColor(TOKENS["text_muted"]))
            font = self.font()
            font.setPointSize(11)
            font.setBold(True)
            painter.setFont(font)
            painter.drawText(rect, QtCore.Qt.AlignmentFlag.AlignCenter, self._empty_label)

    def set_view_kind(self,kind):
        self._view_kind=kind

    def fit_view(self):
        self._view_zoom=1.;self._view_pan=QtCore.QPointF();self._view_angle=self._raw_view_angle=0.;self.update()

    def _finish_gesture(self,cancelled=False):
        mode=self._gesture
        self._gesture=self._gesture_button=self._nav_mode=None;self._light_mode=False
        if mode:self.interactionFinished.emit(mode,cancelled)

    def mouseDoubleClickEvent(self,event):
        if not event.modifiers() & QtCore.Qt.KeyboardModifier.AltModifier:
            self.doubleClicked.emit(event.position());event.accept();return
        super().mouseDoubleClickEvent(event)

    def mousePressEvent(self,event):
        if self._gesture_button is not None:event.accept();return
        if not getattr(self,'_tablet_dispatch',False):self._pen_pressure=1.
        self.setFocus();self._last_mouse_pos=event.position();mods=event.modifiers();btn=event.button()
        self._gesture_button=btn;mode='edit'
        if mods & QtCore.Qt.KeyboardModifier.AltModifier:
            mode={QtCore.Qt.MouseButton.LeftButton:'orbit',QtCore.Qt.MouseButton.MiddleButton:'pan',QtCore.Qt.MouseButton.RightButton:'dolly'}.get(btn,'edit')
        elif (self._view_kind=='studio' or (getattr(self,'_light_enabled',False) and btn==QtCore.Qt.MouseButton.RightButton)) and mods & QtCore.Qt.KeyboardModifier.ControlModifier and btn in (QtCore.Qt.MouseButton.LeftButton,QtCore.Qt.MouseButton.RightButton):mode='radius'
        elif mods & QtCore.Qt.KeyboardModifier.ShiftModifier and btn==QtCore.Qt.MouseButton.RightButton and (self._view_kind!='cards' or getattr(self,'_light_enabled',False)):mode='light'
        if mode=='edit' and btn==QtCore.Qt.MouseButton.MiddleButton and getattr(self,'_atlas_navigation',False):mode='pan'
        self._gesture=mode
        self._context_suppressed=mode!='edit'
        self.interactionStarted.emit(mode,event.position())
        if mode=='edit':self.pointerPressed.emit(event.position(),btn.value,mods.value)
        event.accept()

    def mouseMoveEvent(self,event):
        pos=event.position();dx=pos.x()-self._last_mouse_pos.x();dy=pos.y()-self._last_mouse_pos.y();self._last_mouse_pos=pos
        mode=self._gesture
        if dx==0 and dy==0:return
        if mode=='orbit':
            if self._view_kind=='map':
                self._raw_view_angle=(self._raw_view_angle-dx*.4)%360
                self._view_angle=round(self._raw_view_angle/90)*90 if event.modifiers() & QtCore.Qt.KeyboardModifier.ShiftModifier else self._raw_view_angle;self.update()
            self.orbitChanged.emit(dx,dy)
        elif mode=='pan':
            if self._view_kind=='map':self._view_pan+=QtCore.QPointF(dx,dy);self.update()
            self.panChanged.emit(dx,dy)
        elif mode=='dolly':
            from ..navigation import dolly_factor
            factor=dolly_factor(dx)
            if self._view_kind=='map':self._view_zoom=max(1e-8,self._view_zoom/factor);self.update()
            self.dollyChanged.emit(factor)
        elif mode=='light':self.lightOrbitChanged.emit(-dx*.42,-dy*.42)
        elif mode=='radius':self.radiusChanged.emit(dx*.6)
        elif mode=='edit':self.pointerMoved.emit(pos,event.modifiers().value)
        else:self.hoverMoved.emit(pos)
        event.accept()

    def mouseReleaseEvent(self,event):
        if self._gesture_button!=event.button():event.accept();return
        self.mouseMoveEvent(event)
        if self._gesture=='edit':self.pointerReleased.emit(event.position(),event.button().value,event.modifiers().value)
        self._finish_gesture();event.accept()

    def contextMenuEvent(self,event):
        if getattr(self,'_context_suppressed',False):self._context_suppressed=False;event.accept();return
        if self._view_kind in ('cards', 'map') and self._gesture is None:self.contextRequested.emit(event.globalPos())
        event.accept()

    def wheelEvent(self,event):
        delta=event.angleDelta().y() or event.pixelDelta().y()
        if not delta:event.ignore();return
        up,down={'cards':(.86,1.16),'studio':(.90,1.10)}.get(self._view_kind,(1/1.2,1.2))
        factor=(up if delta>0 else down)**(abs(delta)/120 if event.angleDelta().y() else abs(delta)/60)
        if self._view_kind=='map':
            anchor=self._image_transform().inverted()[0].map(event.position()) if getattr(self,'_atlas_navigation',False) else None
            self._view_zoom=max(1e-8,self._view_zoom/factor)
            if anchor is not None:self._view_pan+=event.position()-self._image_transform().map(anchor)
            self.update()
        self.wheelZoomed.emit(factor);event.accept()

    def enterEvent(self,event):
        self.setFocus(QtCore.Qt.FocusReason.MouseFocusReason);super().enterEvent(event)

    def focusOutEvent(self,event):
        self._finish_gesture(True)
        if self._s_down:self._s_down=False;self.snapChanged.emit(False)
        if self._space_down:self._space_down=False;self.cancelRequested.emit()
        super().focusOutEvent(event)

    def hideEvent(self,event):
        self._finish_gesture(True)
        if self._s_down:self._s_down=False;self.snapChanged.emit(False)
        if self._space_down:self._space_down=False;self.cancelRequested.emit()
        super().hideEvent(event)

    def event(self,event):
        if event.type()==QtCore.QEvent.Type.ShortcutOverride and self.hasFocus():
            k=event.key();mods=event.modifiers()
            if k in (QtCore.Qt.Key.Key_Alt,QtCore.Qt.Key.Key_F,QtCore.Qt.Key.Key_Tab,QtCore.Qt.Key.Key_Space,QtCore.Qt.Key.Key_Escape) or (mods & QtCore.Qt.KeyboardModifier.ControlModifier and k in (QtCore.Qt.Key.Key_Z,QtCore.Qt.Key.Key_Y,QtCore.Qt.Key.Key_A,QtCore.Qt.Key.Key_D)):
                event.accept();return True
        if event.type()==QtCore.QEvent.Type.KeyPress and event.key()==QtCore.Qt.Key.Key_Tab and self.hasFocus():self.keyPressEvent(event);return True
        return super().event(event)

    def keyPressEvent(self,event):
        key=event.key();mods=event.modifiers();ctrl=bool(mods & QtCore.Qt.KeyboardModifier.ControlModifier);shift=bool(mods & QtCore.Qt.KeyboardModifier.ShiftModifier)
        K=QtCore.Qt.Key
        if key==K.Key_Alt:event.accept();return
        if key==K.Key_Escape:self._finish_gesture(True);self._space_down=False;self._s_down=False;self.snapChanged.emit(False);self.cancelRequested.emit()
        elif key==K.Key_F and not ctrl:
            if self._view_kind=='map':self.fit_view()
            self.frameRequested.emit()
        elif key==K.Key_Tab:self.tabToggleRequested.emit()
        elif key==K.Key_Z and ctrl:(self.redoRequested if shift else self.undoRequested).emit()
        elif key==K.Key_Y and ctrl:self.redoRequested.emit()
        elif key==K.Key_A and ctrl:self.selectAllRequested.emit()
        elif key==K.Key_D and (ctrl or shift):self.duplicateRequested.emit()
        elif key in (K.Key_Delete,K.Key_Backspace):self.deleteRequested.emit()
        elif key==K.Key_Space and not ctrl:
            if not event.isAutoRepeat() and not self._space_down:self._space_down=True;self.piePressed.emit(self._last_mouse_pos)
        elif key==K.Key_S and not ctrl:
            if not event.isAutoRepeat():self._s_down=True;self.snapChanged.emit(True)
        elif key in (K.Key_Return,K.Key_Enter):self.acceptRequested.emit()
        elif not ctrl and not (mods & QtCore.Qt.KeyboardModifier.AltModifier):
            tools={K.Key_Q:'Select',K.Key_W:'Move',K.Key_E:'Rotate',K.Key_R:'Scale',K.Key_B:'Brush'}
            components={K.Key_1:'Card',K.Key_2:'Root',K.Key_3:'Row',K.Key_4:'Vertex',K.Key_5:'Edge',K.Key_6:'Face'}
            if key in tools:self.toolActionRequested.emit(tools[key])
            elif key in components:self.componentRequested.emit(components[key])
            elif key==K.Key_G:self.repeatRequested.emit()
            else:super().keyPressEvent(event);return
        else:super().keyPressEvent(event);return
        event.accept()

    def keyReleaseEvent(self,event):
        if event.key()==QtCore.Qt.Key.Key_Alt:event.accept();return
        if event.isAutoRepeat():event.accept();return
        if event.key()==QtCore.Qt.Key.Key_Space and self._space_down:self._space_down=False;self.pieReleased.emit(self._last_mouse_pos);event.accept();return
        if event.key()==QtCore.Qt.Key.Key_S and self._s_down:self._s_down=False;self.snapChanged.emit(False);event.accept();return
        super().keyReleaseEvent(event)

    def tabletEvent(self,event):
        kind=event.type();self._pen_pressure=max(0.,min(1.,event.pressure()))
        mapped={QtCore.QEvent.Type.TabletPress:QtCore.QEvent.Type.MouseButtonPress,QtCore.QEvent.Type.TabletMove:QtCore.QEvent.Type.MouseMove,QtCore.QEvent.Type.TabletRelease:QtCore.QEvent.Type.MouseButtonRelease}
        if kind not in mapped:event.ignore();return
        button=event.button() if event.button()!=QtCore.Qt.MouseButton.NoButton else QtCore.Qt.MouseButton.LeftButton
        mouse=QtGui.QMouseEvent(mapped[kind],event.position(),event.globalPosition(),button,event.buttons(),event.modifiers())
        self._tablet_dispatch=True
        if kind==QtCore.QEvent.Type.TabletPress:self.mousePressEvent(mouse)
        elif kind==QtCore.QEvent.Type.TabletMove:self.mouseMoveEvent(mouse)
        else:self.mouseReleaseEvent(mouse);self._pen_pressure=1.
        self._tablet_dispatch=False;event.accept()
