"""Quiet Graphite: neutral layered surfaces, muted teal accents and shared Qt chrome.

Only presentation tokens; scene/material colors and input behavior are independent.
"""
from __future__ import annotations

TOKENS = {
    "bg_dark": "#050E17",        # Darkest navy viewport & window background
    "bg_panel": "#091724",       # Sidebar and inspector panels
    "bg_control": "#0F2638",     # Button, input, and slider base
    "bg_hover": "#163E56",       # Hover highlight
    "bg_active": "#00CBD7",      # Active cyan indicator
    "cyan": "#00CBD7",           # Primary Cyan highlight
    "teal": "#0EA965",           # Secondary Peacock Green
    "gold": "#D4A017",           # Bake Tile Gold Button
    "gold_hover": "#E6B800",
    "text": "#E8F3FA",           # Crisp high-contrast text
    "text_muted": "#8EA6B8",     # Secondary text & shortcuts
    "border": "#0E3547",         # Panel and frame boundaries
    "border_subtle": "#0A2433",
    "selection": "#00CBD7",      # Selected item highlight
    "danger": "#FF6B6B",         # Error / Delete
    "success": "#0EA965",        # Success / Ready
}

# Branding manifest-derived palette is the source of truth for Qt as well as Tk.
import json
from pathlib import Path
_brand_colors=json.loads((Path(__file__).resolve().parents[2]/'assets/branding/ui_theme.json').read_text(encoding='utf-8'))['colors']
TOKENS.update({key:_brand_colors[role] for key,role in {
    'bg_dark':'background','bg_panel':'panel','bg_control':'control','bg_hover':'hover',
    'bg_active':'accent','cyan':'cyan','teal':'teal','gold':'selection','gold_hover':'selection',
    'text':'text','text_muted':'muted','border':'border','border_subtle':'border',
    'selection':'selection','danger':'danger','success':'success'}.items()})

TOKENS.update({'bg_dark': '#111418', 'bg_panel': '#191D23', 'bg_control': '#22272F', 'bg_hover': '#2C343E', 'bg_active': '#7DD3C0', 'cyan': '#7DD3C0', 'teal': '#69B9AB', 'gold': '#DCC191', 'gold_hover': '#E8D3AE', 'text': '#E7EBEF', 'text_muted': '#9AA5B2', 'border': '#343C47', 'border_subtle': '#262D36', 'selection': '#293F40', 'danger': '#EE939B', 'success': '#87C8A4'})
BRAND_TOKENS=dict(TOKENS)

QSS_TEMPLATE = """
QWidget {{ background-color:{bg_dark};color:{text};font-family:'Segoe UI';font-size:12px; }}
QMainWindow,QDialog {{ background:{bg_dark}; }}
QLabel {{background:transparent;border:none;}}
QToolBar {{ background:{bg_panel};border:none;border-bottom:1px solid {border_subtle};padding:5px 8px;spacing:5px; }}
QToolBar::separator {{background:{border};width:1px;margin:6px;}}
QPushButton,QToolButton {{background:{bg_control};color:{text};border:1px solid {border_subtle};border-radius:6px;padding:4px 10px;font-weight:500;}}
QPushButton:hover,QToolButton:hover {{background:{bg_hover};border-color:{border};}}
QPushButton:pressed,QToolButton:pressed {{background:{selection};border-color:{cyan};}}
QPushButton:checked,QToolButton:checked {{background:{selection};color:{cyan};border-color:{teal};}}
QPushButton:focus,QToolButton:focus {{border-color:{cyan};}}
QPushButton:disabled,QToolButton:disabled {{color:{text_muted};background:{bg_dark};}}
QPushButton[class="workspace_pill_active"] {{background:{selection};color:{cyan};border-color:{teal};}}
QPushButton[class="primary"],QPushButton[class="gold_action"] {{background:{cyan};color:{bg_dark};font-weight:600;}}
QLineEdit,QSpinBox,QDoubleSpinBox,QComboBox,QPlainTextEdit,QTextEdit {{background:{bg_control};color:{text};border:1px solid {border_subtle};border-radius:6px;padding:4px 8px;selection-background-color:{selection};selection-color:{text};}}
QLineEdit:focus,QSpinBox:focus,QDoubleSpinBox:focus,QComboBox:focus,QPlainTextEdit:focus,QTextEdit:focus {{border-color:{cyan};}}
QComboBox::drop-down {{border:none;width:20px;}}
QComboBoxPrivateContainer {{background:{bg_panel};border:1px solid {border};border-radius:4px;}}
QComboBox QAbstractItemView {{background:transparent;color:{text};border:none;padding:2px;selection-background-color:{selection};selection-color:{cyan};outline:none;}}
QListView,QListWidget,QTreeView,QTreeWidget {{background:{bg_panel};border:1px solid {border_subtle};border-radius:6px;padding:4px;outline:none;alternate-background-color:{bg_control};}}
QListView::item,QListWidget::item,QTreeView::item {{padding:5px 6px;margin:1px 0;border-radius:4px;border:none;}}
QListView::item:hover,QListWidget::item:hover,QTreeView::item:hover {{background:{bg_hover};}}
QListView::item:selected,QListWidget::item:selected,QTreeView::item:selected {{background:{selection};color:{cyan};}}
QHeaderView::section {{background:{bg_panel};color:{text_muted};border:none;border-bottom:1px solid {border_subtle};padding:6px;font-size:11px;}}
QDockWidget {{border:none;}}
QDockWidget::title {{background:{bg_panel};color:{text_muted};padding:9px 10px;border-bottom:1px solid {border_subtle};font-size:11px;font-weight:600;}}
QDockWidget::close-button,QDockWidget::float-button {{border:none;border-radius:3px;padding:2px;}}
QDockWidget::close-button:hover,QDockWidget::float-button:hover {{background:{bg_hover};}}
QMainWindow::separator {{background:{bg_dark};width:5px;height:5px;}}
QMainWindow::separator:hover,QSplitter::handle:hover {{background:{teal};}}
QGroupBox {{background:{bg_panel};border:1px solid {border_subtle};border-radius:6px;margin-top:10px;padding-top:12px;}}
QGroupBox::title {{color:{text_muted};subcontrol-origin:margin;left:10px;padding:0 5px;}}
QCheckBox,QRadioButton {{background:transparent;spacing:7px;}}
QCheckBox::indicator,QRadioButton::indicator {{width:14px;height:14px;background:{bg_control};border:1px solid {border};border-radius:4px;}}
QRadioButton::indicator {{border-radius:7px;}}
QCheckBox::indicator:checked,QRadioButton::indicator:checked {{background:{cyan};border-color:{cyan};}}
QCheckBox::indicator:disabled,QRadioButton::indicator:disabled {{background:{bg_dark};border-color:{border_subtle};}}
QScrollArea,QTabWidget::pane {{border:none;background:{bg_panel};}}
QScrollBar {{background:transparent;border:none;margin:2px;}}
QScrollBar:vertical {{width:8px;}}
QScrollBar:horizontal {{height:8px;}}
QScrollBar::handle {{background:{border};border-radius:3px;min-width:24px;min-height:24px;}}
QScrollBar::handle:hover {{background:{text_muted};}}
QScrollBar::add-line,QScrollBar::sub-line {{width:0;height:0;}}
QScrollBar::add-page,QScrollBar::sub-page {{background:transparent;}}
QMenuBar {{background:{bg_dark};padding:3px 8px;border-bottom:1px solid {border_subtle};}}
QMenu {{background:{bg_panel};border:1px solid {border};border-radius:6px;padding:5px;}}
QMenu::item,QMenuBar::item {{background:transparent;padding:6px 14px;border-radius:4px;}}
QMenu::item:selected,QMenuBar::item:selected {{background:{bg_hover};color:{cyan};}}
QMenu::item:disabled {{color:{text_muted};}}
QMenu::separator {{background:{border_subtle};height:1px;margin:4px 8px;}}
QTabBar::tab {{background:{bg_panel};color:{text_muted};padding:7px 14px;border:none;border-bottom:2px solid transparent;}}
QTabBar::tab:selected {{background:{selection};color:{cyan};border-bottom-color:{cyan};}}
QTabBar::tab:hover {{background:{bg_hover};}}
QProgressBar {{background:{bg_control};border:none;border-radius:4px;text-align:center;}}
QProgressBar::chunk {{background:{teal};border-radius:4px;}}
QStatusBar {{background:{bg_dark};color:{text_muted};border-top:1px solid {border_subtle};padding:3px 8px;font-size:11px;}}
QStatusBar::item {{border:none;}}
QToolTip {{background:{bg_hover};color:{text};border:1px solid {border};padding:6px 8px;border-radius:4px;}}
"""

def get_stylesheet() -> str:
    from .popups import popup_qss
    return QSS_TEMPLATE.format(**TOKENS)+popup_qss(TOKENS)


class FSDTheme:
    BG_MAIN = TOKENS["bg_dark"]
    BG_DARK = TOKENS["bg_dark"]
    BG_PANEL = TOKENS["bg_panel"]
    BG_CONTROL = TOKENS["bg_control"]
    BG_HOVER = TOKENS["bg_hover"]
    BG_ACTIVE = TOKENS["bg_active"]
    ACCENT_CYAN = TOKENS["cyan"]
    ACCENT_TEAL = TOKENS["teal"]
    ACCENT_GOLD = TOKENS["gold"]
    TEXT = TOKENS["text"]
    TEXT_MAIN = TOKENS["text"]
    TEXT_MUTED = TOKENS["text_muted"]
    BORDER = TOKENS["border"]
    BORDER_DEFAULT = TOKENS["border"]
    SELECTION = TOKENS["selection"]
    DANGER = TOKENS["danger"]
    SUCCESS = TOKENS["success"]
    GOLD = TOKENS["gold"]
    RADIUS_PILL = 14
    RADIUS_BASE = 6


def setup_qt_application(argv: list[str] | None = None):
    from PySide6 import QtWidgets
    app = QtWidgets.QApplication.instance()
    if app is None:
        app = QtWidgets.QApplication(argv or [])
    app.setStyle("Fusion")
    app.setStyleSheet(get_stylesheet())
    from .popups import install_popup_policy
    install_popup_policy(app)
    return app
