"""3D Studio: one retained editor/render GPU surface, contextual scene tools."""
from copy import deepcopy
from pathlib import Path
import math,json
import numpy as np
from PySide6 import QtCore,QtGui,QtWidgets
from .card_editor import QtCardEditor
from .inspector import QtPropertyGroup, QtColorPicker
from .scene_service import SceneService
from ..rendercore.settings import material_from_project,store_material
from ..cards import HairCard

class SceneStudio(QtCardEditor):
    inspectorToggle=QtCore.Signal()
    def __init__(self,controller,parent=None):
        super().__init__(controller,parent)
        self._studio_material=material_from_project(controller.project);self.studio_display='Rendered';self._light_enabled=True
        self.viewport._light_enabled=True;self._light_transaction=False
        self.scene_service=SceneService(controller,self);self.scene_service.message.connect(lambda m:controller.jobFailed.emit('scene',m) if m.startswith(('Error','Mesh prepare:','Snap:')) else None)
        self.scene_service.changed.connect(self._scene_changed)
        self._scene_ids=set();self._tree_loading=False;self._tree_stamp=None
        self._build_unified_ui()
        self.viewport.lightOrbitChanged.connect(self._light_move);self.viewport.radiusChanged.connect(self._radius_move)
        self.viewport.interactionStarted.connect(self._start_light);self.viewport.interactionFinished.connect(self._end_light)
        controller.projectLoaded.connect(self._reload_scene);controller.cardsChanged.connect(self._refresh_tree);controller.tilesChanged.connect(self._refresh_tree)
        controller.cardSelected.connect(self._sync_tree_selection)
        self._refresh_tree()
    @property
    def renderer(self):return self._gpu_view.renderer if self._gpu_view else None
    def _build_unified_ui(self):
        self.splitter.hide();self.layout().removeWidget(self.splitter)
        self.central=QtWidgets.QWidget(self);layout=QtWidgets.QVBoxLayout(self.central);layout.setContentsMargins(0,0,0,0);layout.setSpacing(4)
        row=QtWidgets.QToolBar('Card tools');row.setMovable(False);layout.addWidget(row);self.studio_mode_buttons={}
        for title,call in [('Select',lambda:self._card_set_mode('Select')),('Groom',lambda:self._card_set_mode('Groom')),('Shape',lambda:self._card_set_mode('Shape')),('Mesh',lambda:self._card_set_mode('Mesh')),('Draw Guide',self._draw_guide_card),('Create Card',self._add_card)]:
            b=QtWidgets.QPushButton(title);b.clicked.connect(call);row.addWidget(b)
            if title in ('Select','Groom','Shape','Mesh'):b.setCheckable(True);self.studio_mode_buttons[title]=b
        row.addWidget(self.comp_combo);self.tool_label=QtWidgets.QLabel('Select · Select');row.addWidget(self.tool_label);row.addSeparator()
        self.display_combo=QtWidgets.QComboBox();self.display_combo.addItems(['Rendered','Textured','Wireframe','Coverage','Normals','Depth']);self.display_combo.addItems(['Fiber Direction','Roughness','Specular','Self Shadow','Original Alpha','Effective Coverage','Transparency Overdraw','Mipmap Level','Alpha Cutoff','Silhouette','Motion Vectors','Temporal History','Ordered Layer Overflow']);self.display_combo.currentTextChanged.connect(self._display);row.addWidget(self.display_combo)
        self.shading_combo=QtWidgets.QComboBox();self.shading_combo.addItems(['Physical','Legacy']);self.shading_combo.currentTextChanged.connect(lambda v:self._material('shading_mode',v));row.addWidget(self.shading_combo)
        self.quality_combo=QtWidgets.QComboBox();self.quality_combo.addItems(['Edit','Lookdev','Capture']);self.quality_combo.setCurrentText('Lookdev');self.quality_combo.currentTextChanged.connect(self._quality);row.addWidget(self.quality_combo)
        second=QtWidgets.QToolBar('Display and scene');second.setMovable(False);layout.addWidget(second)
        self.transparency_combo=QtWidgets.QComboBox();self.transparency_combo.addItems(['Weighted','Hybrid 2','Hybrid 4']);self.transparency_combo.currentTextChanged.connect(self._transparency);second.addWidget(self.transparency_combo)
        for title,call in [('Frame Selected',self.frame_context),('Frame All',self.frame_all),('Import OBJ / FBX',self.import_model),('Capture PNG',self.capture)]:
            b=QtWidgets.QPushButton(title);b.clicked.connect(call);second.addWidget(b)
        layout.addWidget(self.viewport,1);self.layout().addWidget(self.central)
        self.library_panel=QtWidgets.QWidget();left=QtWidgets.QVBoxLayout(self.library_panel);left.setContentsMargins(6,6,6,6)
        self.scene_search=QtWidgets.QLineEdit();self.scene_search.setPlaceholderText('Search models, cards, groups…');self._search_timer=QtCore.QTimer(self);self._search_timer.setSingleShot(True);self._search_timer.timeout.connect(lambda:self._refresh_tree(force=True));self.scene_search.textChanged.connect(lambda:self._search_timer.start(160));left.addWidget(self.scene_search)
        self.scene_tree=QtWidgets.QTreeWidget();self.scene_tree.setHeaderLabels(['Scene','Visible','Lock']);self.scene_tree.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.ExtendedSelection);self.scene_tree.setUniformRowHeights(True)
        self.scene_tree.itemSelectionChanged.connect(self._tree_selection);self.scene_tree.itemChanged.connect(self._tree_edit);self.scene_tree.itemExpanded.connect(self._expand_tree);self.scene_tree.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.CustomContextMenu);self.scene_tree.customContextMenuRequested.connect(self._tree_menu);left.addWidget(self.scene_tree)
        self.inspector_scroll.setMaximumWidth(16777215);self.inspector_panel=QtWidgets.QTabWidget();self.inspector_panel.addTab(self.inspector_scroll,'Card');self._build_profiles()
        self.model_panel=QtWidgets.QWidget();self.model_form=QtWidgets.QFormLayout(self.model_panel);self.inspector_panel.addTab(self.model_panel,'Model')
        self._build_light_panel();self._build_distribution_panel()
        self.bottom_panel=QtWidgets.QTabWidget();self.tile_browser=QtWidgets.QListWidget();self.tile_browser.setViewMode(QtWidgets.QListView.ViewMode.IconMode);self.tile_browser.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.SingleSelection)
        self.tile_browser.itemDoubleClicked.connect(lambda item:self.assign_browser());self.bottom_panel.addTab(self.tile_browser,'Atlas Browser')
        controls=QtWidgets.QWidget();l=QtWidgets.QHBoxLayout(controls);l.addWidget(self.tile_combo)
        b=QtWidgets.QPushButton('Assign tile to selection');b.clicked.connect(self._assign_tile);l.addWidget(b);l.addStretch();self.bottom_panel.addTab(controls,'Assignment')
        timeline=QtWidgets.QWidget();tl=QtWidgets.QHBoxLayout(timeline);tl.addWidget(QtWidgets.QLabel('FBX time (seconds)'));tl.addWidget(self.scene_service.time);play=QtWidgets.QPushButton('Play / Pause');play.clicked.connect(self.scene_service.toggle_play);tl.addWidget(play);tl.addStretch();self.bottom_panel.addTab(timeline,'Animation')
        self.profiler=QtWidgets.QLabel('GPU initializes when 3D Studio becomes visible.');self.profiler.setWordWrap(True);self.bottom_panel.addTab(self.profiler,'Profiler')
        self._profile_timer=QtCore.QTimer(self);self._profile_timer.setInterval(700);self._profile_timer.timeout.connect(self._profile_status);self._profile_timer.start()
        self.controller.tilesChanged.connect(self._refresh_browser);self._refresh_browser()
    def _build_profiles(self):
        group=QtPropertyGroup('WIDTH & TWIST PROFILES',self.inspector_content)
        self.profile_controls=[group.add_slider(f'Width {index+1}',.05,3.,1.,step=.01,callback=lambda v,i=index:self._width_knot(i,v)) for index in range(5)]
        group.add_slider('Twist',-6.28,6.28,0.,step=.01,callback=lambda v:self._selected_card_param('twist',v))
        group.add_slider('Width topology',1,16,1,is_integer=True,callback=lambda v:self._selected_card_param('width_segments',int(v)))
        self.insp_layout.insertWidget(max(0,self.insp_layout.count()-1),group)
    def _width_knot(self,index,value):
        selected=self._selected_ids
        if not selected:return
        self.controller.snapshot_interactive(('width',tuple(sorted(selected)),index));cards=[]
        for raw in self.controller.project.cards:
            if raw['id'] in selected and not raw.get('locked'):
                source=raw.get('width_profile',[1.]*5);widths=np.interp(np.linspace(0,1,5),np.linspace(0,1,len(source)),source).tolist();widths[index]=value;raw={**raw,'width_profile':widths}
            cards.append(raw)
        self.controller.project.cards=cards;self.controller.cardsChanged.emit()
    def _build_light_panel(self):
        scroll=QtWidgets.QScrollArea();scroll.setWidgetResizable(True);body=QtWidgets.QWidget();layout=QtWidgets.QVBoxLayout(body);scroll.setWidget(body);self.light_panel=scroll;self.inspector_panel.addTab(scroll,'Lighting / Material')
        definitions=[('Lighting',[('Key intensity','light_intensity',0,10),('Key azimuth','light_azimuth',-180,180),('Key elevation','light_elevation',-85,85),('Source angle','light_size',0,360),('Fill','fill_intensity',0,5),('Ambient','ambient_intensity',0,3),('Rim','rim_intensity',0,5),('Environment','environment_strength',0,3)]),('Optics',[('Longitudinal roughness','longitudinal_roughness',.01,1),('Azimuthal roughness','azimuthal_roughness',.01,1),('IOR','ior',1,2),('Specular','specular',0,1),('Anisotropy','anisotropy',0,1)]),('Post',[('Exposure','exposure',-5,5),('Bloom','bloom',0,1),('Chroma','chroma',0,1),('Desaturate','desaturate',0,1),('Noise','noise',0,1),('Vignette','vignette',0,1)])]
        self.light_controls={}
        self.light_color_pickers={}
        for name,fields in definitions:
            group=QtPropertyGroup(name,body);layout.addWidget(group)
            for label,key,lo,hi in fields:self.light_controls[key]=group.add_slider(label,lo,hi,getattr(self._studio_material,key),step=.01,callback=lambda v,k=key:self._material(k,v))
            if name=='Lighting':
                for key,slider_key in [('key_color','light_intensity'),('fill_color','fill_intensity'),('ambient_color','ambient_intensity'),('rim_color','rim_intensity')]:
                    picker=QtColorPicker(
                        initial_color="#ffffff",
                        title=f"Choose {key.replace('_', ' ').title()}",
                        compact=True,
                        callback=lambda c,k=key:self._on_light_color_picked(k,c),
                        parent=body,
                    )
                    self.light_color_pickers[key]=picker
                    self._update_light_color_button(key)
                    self.light_controls[slider_key].parentWidget().layout().addWidget(picker)
                for title,call in [('Load HDRI',self.load_hdri),('Built-in studio',lambda:self._material('environment_path',''))]:
                    button=QtWidgets.QPushButton(title);button.clicked.connect(call);group.layout.addWidget(button)
        extra=QtPropertyGroup('Advanced optics / light / post',body);layout.addWidget(extra)
        definitions=[('Cuticle tilt','cuticle_tilt',-10,10),('Absorption','absorption',0,3),('Roughness','roughness',.02,1),('Secondary specular','secondary',0,1.5),('Sheen','sheen',0,1),('Backlight','backlight',0,1),('Iridescence','iridescence',0,1),('Coverage gain','alpha_gain',.1,2),('Alpha cutoff (diagnostic)','alpha_cutoff',0,1),('Self shadow','shadow_strength',0,1),('Fiber scatter','scatter_strength',0,1),('Environment rotation','environment_rotation',-180,180),('Rim azimuth','rim_azimuth',-180,180),('Rim elevation','rim_elevation',-85,85),('Rim width','rim_width',.01,1),('Bloom threshold','bloom_threshold',0,3),('Bloom radius','bloom_radius',0,32),('Noise size','noise_size',.1,10)]
        for label,key,lo,hi in definitions:self.light_controls[key]=extra.add_slider(label,lo,hi,getattr(self._studio_material,key),step=.01,callback=lambda v,k=key:self._material(k,v))
        for label,key in [('Artistic optics','artistic_optics'),('Checker background (capture stays transparent)','checker')]:
            check=QtWidgets.QCheckBox(label);check.setChecked(getattr(self._studio_material,key));check.toggled.connect(lambda v,k=key:self._material(k,v));extra.layout.addWidget(check)
        extra.header_btn.setChecked(False);extra._toggle_collapse(False)
        view=QtPropertyGroup('Viewport',body);layout.addWidget(view)
        for label,key in [('Ground grid','show_grid'),('Axis gizmo','show_axis_gizmo'),('HUD','show_hud')]:
            check=QtWidgets.QCheckBox(label);check.setChecked(getattr(self._legacy_settings,key));check.toggled.connect(lambda v,k=key:self._view_setting(k,v));view.layout.addWidget(check)
        axis=QtWidgets.QComboBox();axis.addItems(['Y-Up','Z-Up']);axis.setCurrentText(self._legacy_settings.up_axis);axis.currentTextChanged.connect(lambda value:self._view_setting('up_axis',value));view.layout.addWidget(axis)
        layout.addStretch()
    def _view_setting(self,key,value):setattr(self._legacy_settings,key,value);self._schedule_card_frame()
    def _selected_card_param(self,param,val):
        if not self._selected_ids:return
        self.controller.snapshot_interactive(('card',tuple(sorted(self._selected_ids)),param));self.controller.project.cards=[{**c,param:val} if c['id'] in self._selected_ids and not c.get('locked') else c for c in self.controller.project.cards];self.controller.cardsChanged.emit();self._schedule_card_frame()
    def _build_distribution_panel(self):
        body=QtWidgets.QWidget();form=QtWidgets.QFormLayout(body);self.inspector_panel.addTab(body,'Distribution / Attach')
        self.surface_target=QtWidgets.QComboBox();form.addRow('Target mesh',self.surface_target)
        self.scatter_count=QtWidgets.QSpinBox();self.scatter_count.setRange(1,10000);self.scatter_count.setValue(40);form.addRow('Card count',self.scatter_count)
        self.scatter_seed=QtWidgets.QSpinBox();self.scatter_seed.setRange(0,2**30);self.scatter_seed.setValue(42);form.addRow('Seed',self.scatter_seed)
        for title,callback in [('Scatter on surface',self.scatter),('Bind selection to surface',lambda:self.attach('surface')),('Bind to skinned surface',lambda:self.attach('skinned')),('Parent to object transform',lambda:self.attach('object')),('Detach (preserve world guide)',lambda:self.scene_service.detach(self._selected_ids))]:
            button=QtWidgets.QPushButton(title);button.clicked.connect(callback);form.addRow(button)
        self.joint_name=QtWidgets.QLineEdit();form.addRow('Joint path / name',self.joint_name)
        button=QtWidgets.QPushButton('Bind to joint');button.clicked.connect(self.attach_joint);form.addRow(button)
    def _refresh_browser(self):
        self.tile_browser.clear()
        for t in self.controller.project.tiles:
            item=QtWidgets.QListWidgetItem(t.name);item.setData(QtCore.Qt.ItemDataRole.UserRole,t.id);self.tile_browser.addItem(item)
    def assign_browser(self):
        item=self.tile_browser.currentItem()
        if item is None:return
        self.tile_combo.setCurrentIndex(self.tile_combo.findData(item.data(QtCore.Qt.ItemDataRole.UserRole)));self._assign_tile()
    def _item(self,parent,label,kind,key,record=None):
        item=QtWidgets.QTreeWidgetItem(parent,[label,'','']);item.setData(0,QtCore.Qt.ItemDataRole.UserRole,(kind,key))
        if record is not None:
            item.setFlags(item.flags()|QtCore.Qt.ItemFlag.ItemIsEditable|QtCore.Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(1,QtCore.Qt.CheckState.Checked if record.get('visible',True) else QtCore.Qt.CheckState.Unchecked);item.setCheckState(2,QtCore.Qt.CheckState.Checked if record.get('locked') else QtCore.Qt.CheckState.Unchecked)
        return item
    def _refresh_tree(self,force=False):
        if not hasattr(self,'scene_tree'):return
        project=self.controller.project;stamp=(id(project),id(project.cards),id(project.objects),tuple((t.id,t.name) for t in project.tiles))
        if not force and stamp==self._tree_stamp:return
        expanded=set();iterator=QtWidgets.QTreeWidgetItemIterator(self.scene_tree)
        while iterator.value():
            item=iterator.value();data=item.data(0,QtCore.Qt.ItemDataRole.UserRole)
            if data and item.isExpanded():expanded.add(tuple(data))
            iterator+=1
        blocker=QtCore.QSignalBlocker(self.scene_tree);self._tree_stamp=stamp;self._tree_loading=True;self.scene_tree.clear();search=self.scene_search.text().lower()
        models=self._item(self.scene_tree,'Models','root','models')
        for obj in project.objects:
            if search not in obj['name'].lower():continue
            self._item(models,obj['name'],'object',obj['id'],obj)
        models.setExpanded(True);cards=self._item(self.scene_tree,'Cards / Groups','root','cards');self._groups={}
        explicit=project.metadata.get('card_groups',{});claimed=set()
        for name,ids in explicit.items():self._groups[name]=[c for c in project.cards if c['id'] in ids];claimed.update(ids)
        for card in project.cards:
            if card['id'] in claimed:continue
            tile=project.find(card['tile_id']);name=tile.name if tile else 'Missing tile';self._groups.setdefault(name,[]).append(card)
        for name,group in self._groups.items():
            if search:group=[c for c in group if search in (c['name']+' '+name).lower()]
            if not group:continue
            item=self._item(cards,f'{name} ({len(group)})','group',name);item.setChildIndicatorPolicy(QtWidgets.QTreeWidgetItem.ChildIndicatorPolicy.ShowIndicator)
            if search:
                for card in group:self._item(item,card['name'],'card',card['id'],card)
                item.setExpanded(True)
        cards.setExpanded(True)
        guides=self._item(self.scene_tree,'Fiber Assemblies / Guides','root','guides');self._assemblies={}
        for key,record in project.kernel_data.get('records',{}).items():
            if record['kind']=='assembly':
                self._assemblies[key]=record;item=self._item(guides,record['payload'].get('workflow','Assembly')+' · '+key[-8:],'assembly',key);item.setChildIndicatorPolicy(QtWidgets.QTreeWidgetItem.ChildIndicatorPolicy.ShowIndicator)
        attachments=self._item(self.scene_tree,'Attachments','root','attachments')
        for card in project.cards:
            if card.get('attachment'):self._item(attachments,card['name']+' → '+card['attachment'].get('kind',''),'attachment',card['id'])
        materials=self._item(self.scene_tree,'Materials','root','materials');self._item(materials,'Fiber optical material','material','hair')
        lights=self._item(self.scene_tree,'Lights','root','lights')
        for key in ('Key','Fill','Ambient','Rim','Environment'):self._item(lights,key,'light',key)
        iterator=QtWidgets.QTreeWidgetItemIterator(self.scene_tree)
        while iterator.value():
            item=iterator.value();data=item.data(0,QtCore.Qt.ItemDataRole.UserRole)
            if data and tuple(data) in expanded:self._expand_tree(item);self._tree_loading=True;item.setExpanded(True)
            if data and data[0]=='object':item.setSelected(data[1] in self._scene_ids)
            iterator+=1
        blocker.unblock();self._tree_loading=False;self._sync_tree_selection(list(self._selected_ids));self._refresh_targets()
    def _expand_tree(self,item):
        data=item.data(0,QtCore.Qt.ItemDataRole.UserRole)
        if not data or item.childCount():return
        kind,key=data;self._tree_loading=True
        if kind=='group':
            for raw in self._groups.get(key,[]):self._item(item,raw['name'],'card',raw['id'],raw)
        elif kind=='assembly':
            for guide in self._assemblies[key]['payload'].get('guides',[]):self._item(item,guide,'guide',guide)
        self._tree_loading=False
    def _tree_selection(self):
        if self._tree_loading:return
        cards=set();objects=set();context=None
        for item in self.scene_tree.selectedItems():
            kind,key=item.data(0,QtCore.Qt.ItemDataRole.UserRole);context=(kind,key)
            if kind=='card':cards.add(key)
            elif kind=='group':cards.update(c['id'] for c in self._groups.get(key,[]))
            elif kind=='object':objects.add(key)
        self._scene_ids=objects
        if cards:self._card_select_ids(cards);self.inspector_panel.setCurrentIndex(0)
        elif context:
            self._card_select_ids(set())
            kind,key=context
            if kind=='object':self._model_inspector(key);self.inspector_panel.setCurrentWidget(self.model_panel)
            elif kind in ('light','material'):self.inspector_panel.setCurrentWidget(self.light_panel)
            elif kind in ('guide','assembly'):self._guide_inspector(kind,key);self.inspector_panel.setCurrentWidget(self.model_panel)
    def _sync_tree_selection(self,ids):
        if not hasattr(self,'scene_tree') or self._tree_loading:return
        self._tree_loading=True;it=QtWidgets.QTreeWidgetItemIterator(self.scene_tree)
        while it.value():
            item=it.value();data=item.data(0,QtCore.Qt.ItemDataRole.UserRole)
            if data and data[0]=='card':item.setSelected(data[1] in ids)
            it+=1
        self._tree_loading=False
        card=next((c for c in self.controller.project.cards if c['id'] in ids),None)
        if card is not None:
            self._sync_inspector_values()
            for control,value in zip(getattr(self,'profile_controls',[]),card.get('width_profile',[1.]*5)):control.setValue(value,notify=False)
    def _tree_edit(self,item,column):
        if self._tree_loading:return
        kind,key=item.data(0,QtCore.Qt.ItemDataRole.UserRole)
        if kind not in ('card','object'):return
        patch={'name':item.text(0)} if column==0 else {('visible' if column==1 else 'locked'):item.checkState(column)==QtCore.Qt.CheckState.Checked}
        self.controller.snapshot();field='cards' if kind=='card' else 'objects';source=getattr(self.controller.project,field);setattr(self.controller.project,field,[{**raw,**patch} if raw['id']==key else raw for raw in source])
        self.controller.cardsChanged.emit();self.scene_service.backend.changed()
    def _tree_menu(self,pos):
        menu=QtWidgets.QMenu(self)
        for label,call in [('Create card group',self.create_group),('Frame selected',self.frame_context),('Import OBJ / FBX',self.import_model),('Delete selected',self.delete_context)]:menu.addAction(label,call)
        menu.exec(self.scene_tree.viewport().mapToGlobal(pos))
    def create_group(self):
        if not self._selected_ids:return
        name,ok=QtWidgets.QInputDialog.getText(self,'Card group','Group name')
        if ok and name:
            self.controller.snapshot();groups={**self.controller.project.metadata.get('card_groups',{}),name:sorted(self._selected_ids)};self.controller.project.metadata={**self.controller.project.metadata,'card_groups':groups};self._refresh_tree(True)
    def _clear_model(self):
        while self.model_form.count():
            item=self.model_form.takeAt(0)
            if item.widget():item.widget().deleteLater()
    def _model_inspector(self,key):
        self._clear_model();obj=next(o for o in self.controller.project.objects if o['id']==key)
        self.model_form.addRow(QtWidgets.QLabel(f'{obj["name"]}\n{len(obj["vertices"]):,} vertices · {len(obj["triangles"]):,} triangles'))
        for axis in range(3):
            spin=QtWidgets.QDoubleSpinBox();spin.setRange(-1e6,1e6);spin.setDecimals(4);spin.setValue(obj.get('position',[0,0,0])[axis]);spin.setEnabled(not obj.get('locked'))
            spin.valueChanged.connect(lambda v,a=axis:self._object_transform(key,a,v))
            self.model_form.addRow('XYZ'[axis],spin)
        scale=QtWidgets.QDoubleSpinBox();scale.setRange(.0001,10000);scale.setValue(obj.get('scale',1));scale.setEnabled(not obj.get('locked'))
        scale.valueChanged.connect(lambda v:self._object_transform(key,3,v))
        self.model_form.addRow('Scale',scale)
        from ..scene_import import material_default
        for channel in ('color','normal','roughness','alpha','specular','metallic','ao','emission'):
            button=QtWidgets.QPushButton('Relink '+channel);button.clicked.connect(lambda checked=False,ch=channel:self._object_map(key,ch));self.model_form.addRow(button)
        self.model_form.addRow(QtWidgets.QLabel('Animated FBX' if obj.get('animation_source') else 'Static mesh'))
    def _object_transform(self,key,axis,value):
        source=next(o for o in self.controller.project.objects if o['id']==key)
        if source.get('locked'):return
        obj=deepcopy(source)
        if axis==3:obj['scale']=value
        else:obj.setdefault('position',[0,0,0])[axis]=value
        self.controller.snapshot();self.controller.project.objects=[obj if o['id']==key else o for o in self.controller.project.objects];self.scene_service.backend.changed()
    def _object_map(self,key,channel):
        path,_=QtWidgets.QFileDialog.getOpenFileName(self,'Relink '+channel,'','Images (*.png *.jpg *.tif *.tiff *.bmp)')
        if path:
            self.controller.snapshot();objects=[]
            for o in self.controller.project.objects:
                if o['id']==key:o={**o,'material':{**o['material'],'maps':{**o['material'].get('maps',{}),channel:path}}}
                objects.append(o)
            self.controller.project.objects=objects;self.scene_service.backend.changed()
    def _guide_inspector(self,kind,key):
        self._clear_model();record=self.controller.project.kernel_data['records'].get(key,{})
        self.model_form.addRow(QtWidgets.QLabel(kind+' · '+key));text=QtWidgets.QPlainTextEdit(json.dumps(record.get('payload',{}),indent=2));self.model_form.addRow(text)
        button=QtWidgets.QPushButton('Apply source payload');self.model_form.addRow(button)
        def commit():
            from ..kernel.scene import kernel
            data=json.loads(text.toPlainText());service=kernel(self.controller.project);registry=service.synchronize().fork()
            with registry.transaction('Edit guide source') as tx:tx.put(record['kind'],data,inputs=record.get('inputs',[]),id=key)
            self.controller.snapshot();service.publish_registry(registry);self.controller.cardsChanged.emit();self.controller.tilesChanged.emit()
        button.clicked.connect(lambda:self._safe(commit))
    def _refresh_targets(self):
        selected=self.surface_target.currentData();self.surface_target.blockSignals(True);self.surface_target.clear()
        for o in self.controller.project.objects:self.surface_target.addItem(o['name'],o['id'])
        index=self.surface_target.findData(selected);self.surface_target.setCurrentIndex(max(0,index));self.surface_target.blockSignals(False)
        self.bottom_panel.setTabEnabled(2,any(o.get('animation_source') for o in self.controller.project.objects))
    def _safe(self,call):
        try:return call()
        except Exception as error:self.controller.jobFailed.emit('3D Studio',str(error))
    def scatter(self):self._safe(lambda:self.scene_service.scatter(self.surface_target.currentData(),self.tile_combo.currentData(),self.scatter_count.value(),self.scatter_seed.value()))
    def attach(self,kind):self._safe(lambda:self.scene_service.attach(self.surface_target.currentData(),self._selected_ids,kind))
    def attach_joint(self):
        key=self.surface_target.currentData();name=self.joint_name.text().strip()
        if not name:return
        self.scene_service.backend.request_joint(key,name,self.scene_service.time.value())
        project=self.controller.project;ids=set(self._selected_ids);request=self.scene_service.backend.pose_request
        def ready(attempt=0):
            backend=self.scene_service.backend
            if project is not self.controller.project:return
            if backend.pose_published>=request:
                if (key,name) in backend.joint_poses:self._safe(lambda:self.scene_service.attach(key,ids,'joint',name))
                else:self.controller.jobFailed.emit('Joint binding','Joint not found in evaluated skeleton: '+name)
            elif attempt<200:QtCore.QTimer.singleShot(50,self,lambda:ready(attempt+1))
            else:self.controller.jobFailed.emit('Joint binding','Timed out evaluating skeleton')
        ready()
    def import_model(self):
        path,_=QtWidgets.QFileDialog.getOpenFileName(self,'Import model','','Supported models (*.obj *.fbx)')
        if path:self.scene_service.import_model(path)
    def delete_context(self):
        if self._scene_ids:
            ids=self._scene_ids;self.controller.snapshot();self.controller.project.objects=[o for o in self.controller.project.objects if o['id'] not in ids or o.get('locked')];self.scene_service.backend.changed()
        else:
            indices=[i for i,c in enumerate(self.controller.project.cards) if c['id'] in self._selected_ids and not c.get('locked')]
            if indices:self.controller.delete_cards(indices)
    def frame_context(self):
        if self._scene_ids:
            objects=self.scene_service.selected_objects(self._scene_ids);points=np.concatenate([np.asarray(o['vertices'])*o.get('scale',1)+o.get('position',[0,0,0]) for o in objects]);self._card_target[:]=(points.min(0)+points.max(0))/2;self._card_distance=max(.1,float(np.ptp(points,axis=0).max())*2.5);self._schedule_card_frame()
        else:self._legacy_frame()
    def frame_all(self):
        from ..cards import ribbon_mesh
        clouds=[np.asarray(o['vertices'])*o.get('scale',1)+o.get('position',[0,0,0]) for o in self.scene_service.backend.evaluated_objects() if o.get('visible',True) and o.get('vertices')]
        clouds.extend(ribbon_mesh(HairCard.from_dict(c))[0] for c in self.controller.project.cards if c.get('visible',True))
        if clouds:
            points=np.concatenate(clouds);self._card_target[:]=(points.min(0)+points.max(0))/2;self._card_distance=max(.1,float(np.ptp(points,axis=0).max())*2.5);self._schedule_card_frame()
    def _display(self,text):self.studio_display=text;self._show_wire=text=='Wireframe';self._schedule_card_frame()
    def _quality(self,value):
        if self.renderer:self.renderer.set_quality(value,1.,'Spatial')
        self._schedule_card_frame()
    def _transparency(self,text):
        if self.renderer:self.renderer.set_transparency('weighted' if text=='Weighted' else 'hybrid',4 if text.endswith('4') else 2)
        self._schedule_card_frame()
    def _material(self,key,value):
        self.controller.snapshot_interactive(('material',key));setattr(self._studio_material,key,value);store_material(self.controller.project,self._studio_material,self.quality_combo.currentText());self._schedule_card_frame()
    def _update_light_color_button(self,key):
        picker=getattr(self,'light_color_pickers',{}).get(key)
        if picker is None:return
        old=np.asarray(getattr(self._studio_material,key,(1.,1.,1.)))
        srgb=np.where(old<=.0031308,old*12.92,1.055*np.maximum(old,0)**(1/2.4)-.055)
        qc=QtGui.QColor.fromRgbF(*np.clip(srgb,0,1))
        picker.setColor(qc.name(),notify=False)
    def _on_light_color_picked(self,key,hex_color):
        color=QtGui.QColor(hex_color)
        if color.isValid():
            values=np.array(color.getRgbF()[:3])
            self._material(key,tuple(np.where(values<=.04045,values/12.92,((values+.055)/1.055)**2.4)))
    def load_hdri(self):
        path,_=QtWidgets.QFileDialog.getOpenFileName(self,'Environment HDRI','','Images (*.hdr *.png *.jpg *.tif)')
        if path:self._material('environment_path',path)
    def _start_light(self,mode,pos):
        if mode not in ('light','radius'):return
        self.controller.snapshot();self._light_transaction=True
        if self.renderer:
            from .viewport_math import light_target_under_cursor
            self._studio_material.key_target=light_target_under_cursor(self.renderer,pos.x(),pos.y(),self.viewport.width(),self.viewport.height())
    def _light_move(self,az,el):
        self._studio_material.light_azimuth=(self._studio_material.light_azimuth+az+180)%360-180;self._studio_material.light_elevation=max(-85,min(85,self._studio_material.light_elevation+el));self._schedule_card_frame()
    def _radius_move(self,delta):self._studio_material.light_size=max(0,min(360,self._studio_material.light_size+delta));self._schedule_card_frame()
    def _end_light(self,mode,cancelled):
        if self._light_transaction:
            store_material(self.controller.project,self._studio_material);self._light_transaction=False
            for key,w in self.light_controls.items():w.setValue(getattr(self._studio_material,key),notify=False)
    def capture(self):
        if self.renderer is None:return
        path,_=QtWidgets.QFileDialog.getSaveFileName(self,'Capture transparent PNG','capture.png','PNG (*.png);;OpenEXR (*.exr)')
        if path:self._safe(lambda:self._capture_to(path))
    def _capture_to(self,path):
        if path.lower().endswith('.exr'):
            from ..rendercore.exr import write_linear
            write_linear(path,self.renderer.capture_linear())
        else:self.renderer.capture_transparent().save(path)
    def _scene_changed(self):self._refresh_tree();self._schedule_card_frame()
    def _reload_scene(self):
        self._studio_material=material_from_project(self.controller.project);self._tree_stamp=None;self._refresh_tree()
        for key,control in self.light_controls.items():control.setValue(getattr(self._studio_material,key),notify=False)
        for key in getattr(self,'light_color_pickers',{}):self._update_light_color_button(key)
    def _toggle_inspector(self):self.inspectorToggle.emit()
    def _profile_status(self):
        if self.renderer:
            s=self.renderer.editor_stats;self.profiler.setText(f'{self.renderer.info.gpu_renderer}\nCPU {s.cpu_ms:.2f} ms · GPU {s.gpu_ms:.2f} ms\nVisible {s.visible_cards}/{s.total_cards} · triangles {s.triangles}\nGeometry upload {s.geometry_upload_bytes} bytes · transforms {s.transform_upload_bytes} bytes')
    def close_scene(self):self._profile_timer.stop();self.scene_service.close();self.close_card_viewport()

    def _card_choose_tool(self,tool):
        super()._card_choose_tool(tool)
        if hasattr(self,'tool_label'):self.tool_label.setText(self._card_mode+' · '+self._card_tool)
    def _card_set_mode(self,mode):
        super()._card_set_mode(mode)
        for name,button in getattr(self,'studio_mode_buttons',{}).items():button.setChecked(name==mode)
    def _draw_cards_wireframe_fallback(self):
        self.viewport.set_renderer_callback(None);self.viewport.set_display_pixmap(None)
        self.viewport.set_empty_label('GPU viewport unavailable — see Console for driver/context error')
