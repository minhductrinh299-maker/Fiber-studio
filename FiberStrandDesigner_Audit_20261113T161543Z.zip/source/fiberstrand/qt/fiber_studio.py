"""Fiber Studio & Atlas Workspace Editor for Qt 6 / PySide6.

Features:
- Procedural shape, clusters, melanin, color, feather tabs
- Live interactive tile preview and atlas layout
- Dynamic parameters linked to AppController Single Source of Truth
- Asynchronous non-blocking tile preview on background worker
"""
from __future__ import annotations
from typing import Any
from copy import deepcopy
from PySide6 import QtCore, QtGui, QtWidgets
from PIL.ImageQt import ImageQt
from .viewport import QtViewportHost
from .tile_library import TileLibraryList
from .live_workspace import LiveWorkspaceMixin
from .atlas_viewport import AtlasViewportMixin
from .inspector import QtPropertyGroup
from .slider import QtNumberSlider
from .theme import TOKENS

from fiberstrand.model import Tile
from fiberstrand.raster import render_tile


class QtFiberStudio(AtlasViewportMixin, LiveWorkspaceMixin, QtWidgets.QWidget):
    tileModified = QtCore.Signal(str)

    def __init__(self, controller, parent: QtWidgets.QWidget | None = None):
        super().__init__(parent)
        self.controller = controller
        self.current_tile = controller.project.tiles[0] if controller.project.tiles else None

        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.splitter = QtWidgets.QSplitter(QtCore.Qt.Orientation.Horizontal, self)
        self.splitter.setStyleSheet(f"QSplitter::handle {{ background-color: {TOKENS['border']}; width: 2px; }}")

        # 1. Left Sidebar: Tile Library
        self.sidebar = QtWidgets.QWidget(self.splitter)
        self.sidebar.setMinimumWidth(180)
        self.sidebar.setStyleSheet(f"background-color: {TOKENS['bg_panel']};")
        sb_layout = QtWidgets.QVBoxLayout(self.sidebar)
        sb_layout.setContentsMargins(10, 12, 10, 10)
        sb_layout.setSpacing(8)

        lbl_hdr = QtWidgets.QHBoxLayout()
        lbl_lib = QtWidgets.QLabel("▤ Tile Library", self.sidebar)
        lbl_lib.setStyleSheet(f"color: {TOKENS['cyan']}; font-weight: 700; font-size: 11px;")
        lbl_hdr.addWidget(lbl_lib)
        lbl_hdr.addStretch(1)
        btn_filter = QtWidgets.QPushButton("☰", self.sidebar)
        btn_filter.setFixedSize(22, 22)
        lbl_hdr.addWidget(btn_filter)
        sb_layout.addLayout(lbl_hdr)

        btn_row = QtWidgets.QHBoxLayout()
        self.btn_new = QtWidgets.QPushButton("+ New Tile", self.sidebar)
        self.btn_new.clicked.connect(self._new_tile)
        self.btn_dup = QtWidgets.QPushButton("Duplicate", self.sidebar)
        self.btn_dup.clicked.connect(self._dup_tile)
        self.btn_del = QtWidgets.QPushButton("Delete", self.sidebar)
        self.btn_del.clicked.connect(self._del_tile)
        btn_row.addWidget(self.btn_new)
        btn_row.addWidget(self.btn_dup)
        btn_row.addWidget(self.btn_del)
        sb_layout.addLayout(btn_row)

        # Search bar
        self.search_input = QtWidgets.QLineEdit(self.sidebar)
        self.search_input.setPlaceholderText("🔍 Search Tiles...")
        self.search_input.setStyleSheet(f"background-color: {TOKENS['bg_control']}; border: 1px solid {TOKENS['border']}; border-radius: 4px; padding: 4px 8px;")
        self.search_input.textChanged.connect(self._on_search_tiles_changed)
        sb_layout.addWidget(self.search_input)

        self.tile_list = TileLibraryList(self.sidebar)
        self.tile_list.setStyleSheet(f"background-color: {TOKENS['bg_control']}; border: 1px solid {TOKENS['border']}; border-radius: 4px;")
        sb_layout.addWidget(self.tile_list)
        self.tile_list.currentRowChanged.connect(self._on_tile_selected)

        self.splitter.addWidget(self.sidebar)

        # 2. Center: Viewport & Workspace Tool Header
        center_widget = QtWidgets.QWidget(self)
        center_layout = QtWidgets.QVBoxLayout(center_widget)
        center_layout.setContentsMargins(8, 8, 8, 8)
        center_layout.setSpacing(6)

        # Row 1: Mode Switcher & Map Channels Bar
        header = QtWidgets.QHBoxLayout()
        self.mode_combo = QtWidgets.QComboBox(center_widget)
        self.mode_combo.addItems(["Tile Mode", "Atlas Mode"])
        self.mode_combo.currentTextChanged.connect(self._on_mode_changed)
        header.addWidget(self.mode_combo)

        btn_graph_toggle = QtWidgets.QPushButton("☁ Graph", center_widget)
        btn_graph_toggle.setToolTip("Chuyển nhanh sang Construction Node Graph của tile này")
        btn_graph_toggle.setMaximumWidth(75)
        btn_graph_toggle.clicked.connect(lambda: getattr(self.window(), "_switch_workspace", lambda _: None)("graph"))
        header.addWidget(btn_graph_toggle)

        lbl_map_hdr = QtWidgets.QLabel("Map:", center_widget)
        lbl_map_hdr.setStyleSheet(f"color: {TOKENS['text_muted']}; font-weight: 600; margin-left: 4px;")
        header.addWidget(lbl_map_hdr)

        self.map_combo = QtWidgets.QComboBox(center_widget)
        self.map_combo.addItems(["lit", "color", "alpha", "normal", "flow", "ao", "roughness", "depth", "id"])
        self.map_combo.currentTextChanged.connect(lambda _: self._on_map_combo_changed())
        self.map_combo.hide() # Hidden backing combobox for API parity

        self.map_btn_group = QtWidgets.QWidget(center_widget)
        mbg_layout = QtWidgets.QHBoxLayout(self.map_btn_group)
        mbg_layout.setContentsMargins(0, 0, 0, 0)
        mbg_layout.setSpacing(2)

        self.map_buttons = {}
        maps_meta = [
            ("live", "⚡ Live"),
            ("lit", "💡 Lit"),
            ("color", "⚪ Color"),
            ("alpha", "Alpha"),
            ("normal", "Norm"),
            ("flow", "Flow"),
            ("ao", "AO"),
            ("roughness", "Rgh"),
            ("depth", "Dep"),
            ("id", "ID")
        ]
        for m_key, m_label in maps_meta:
            b = QtWidgets.QPushButton(m_label, self.map_btn_group)
            b.setCheckable(True)
            if m_key == "live":
                b.setChecked(True)
                b.setProperty("class", "workspace_pill_active")
            else:
                b.setProperty("class", "workspace_pill")
            b.clicked.connect(lambda _, k=m_key: self._set_map_channel(k))
            self.map_buttons[m_key] = b
            mbg_layout.addWidget(b)
        header.addWidget(self.map_btn_group)
        header.addStretch(1)
        center_layout.addLayout(header)

        # Row 2: Sub-header with Tile/Map name, Fit View [F], and Light Angle
        sub_header = QtWidgets.QHBoxLayout()
        init_tname = self.current_tile.name if self.current_tile else "Tile"
        self.lbl_tile_info = QtWidgets.QLabel(f"Tile: {init_tname}   Map: Live Fiber GPU", center_widget)
        self.lbl_tile_info.setStyleSheet(f"color: {TOKENS['cyan']}; font-weight: 600; font-size: 11px;")
        sub_header.addWidget(self.lbl_tile_info)

        sub_header.addStretch(1)
        self.btn_fit = QtWidgets.QPushButton("⛶ Fit View [F]", center_widget)
        sub_header.addWidget(self.btn_fit)

        lbl_angle = QtWidgets.QLabel("Light Angle:", center_widget)
        lbl_angle.setStyleSheet(f"color: {TOKENS['text_muted']}; font-weight: 500;")
        sub_header.addWidget(lbl_angle)

        self.light_slider = QtNumberSlider(from_=-180, to=180, step=1.0, value=315.0, format_str="{:.0f}°", parent=center_widget)
        self.light_slider.setMinimumWidth(110)
        self.light_slider.setMaximumWidth(140)
        self.light_slider.valueChanged.connect(self._live_light_changed)
        sub_header.addWidget(self.light_slider)

        center_layout.addLayout(sub_header)

        self.viewport = QtViewportHost(center_widget)
        self.viewport.set_empty_label("Rendering Tile Preview...")
        self.viewport.lightOrbitChanged.connect(self._on_viewport_light_orbit)
        self.viewport.frameRequested.connect(self._on_fit_view)
        self.viewport.cancelRequested.connect(lambda: None)
        self.viewport.undoRequested.connect(self.controller.undo)
        self.viewport.redoRequested.connect(self.controller.redo)
        self.viewport.tabToggleRequested.connect(self._toggle_tile_atlas)
        self.btn_fit.clicked.connect(self._on_fit_view)
        center_layout.addWidget(self.viewport, 1)

        # Row 3: Bottom Viewport Toolbar (Icons, UV, Bounds, Atlas Grid, Tile Size)
        bottom_bar = QtWidgets.QHBoxLayout()
        for icon_s, tip, action_cb in [
            ("▦", "Toggle Wireframe / Grid", lambda: self._toggle_viewport_grid()),
            ("⬚", "Toggle UV Overlay", lambda: self._toggle_uv_mode()),
            ("⬡", "Toggle Hair Isolation", lambda: self._toggle_isolation()),
            ("◯", "Reset Zoom / View (1:1)", lambda: self._on_fit_view())
        ]:
            tb = QtWidgets.QToolButton(center_widget)
            tb.setText(icon_s)
            tb.setToolTip(tip)
            tb.setFixedSize(24, 22)
            tb.clicked.connect(action_cb)
            bottom_bar.addWidget(tb)

        sep_b = QtWidgets.QLabel("|", center_widget)
        sep_b.setStyleSheet(f"color: {TOKENS['border']}; margin: 0 4px;")
        bottom_bar.addWidget(sep_b)

        btn_uv = QtWidgets.QPushButton("UV", center_widget)
        btn_uv.setFixedSize(32, 22)
        btn_uv.clicked.connect(self._toggle_uv_mode)
        bottom_bar.addWidget(btn_uv)

        self.chk_bounds = QtWidgets.QCheckBox("Show Tile Bounds", center_widget)
        self.chk_bounds.setChecked(True)
        self.chk_bounds.toggled.connect(lambda _: self.viewport.update())
        self.chk_grid = QtWidgets.QCheckBox("Show Atlas Grid", center_widget)
        self.chk_grid.toggled.connect(lambda _: self.viewport.update())
        bottom_bar.addWidget(self.chk_bounds)
        bottom_bar.addWidget(self.chk_grid)

        bottom_bar.addStretch(1)
        lbl_ts = QtWidgets.QLabel("Tile Size:", center_widget)
        lbl_ts.setStyleSheet(f"color: {TOKENS['text_muted']};")
        bottom_bar.addWidget(lbl_ts)

        self.combo_tw = QtWidgets.QComboBox(center_widget)
        self.combo_tw.addItems(["1024", "2048", "4096", "512"])
        self.combo_th = QtWidgets.QComboBox(center_widget)
        self.combo_th.addItems(["1024", "2048", "4096", "512"])
        self.combo_tw.currentTextChanged.connect(self._on_tile_size_changed)
        self.combo_th.currentTextChanged.connect(self._on_tile_size_changed)
        bottom_bar.addWidget(self.combo_tw)
        lbl_x = QtWidgets.QLabel("×", center_widget)
        bottom_bar.addWidget(lbl_x)
        bottom_bar.addWidget(self.combo_th)

        center_layout.addLayout(bottom_bar)

        self.splitter.addWidget(center_widget)

        # 3. Right: Procedural Parameters Inspector
        self.inspector_scroll = QtWidgets.QScrollArea(self.splitter)
        self.inspector_scroll.setWidgetResizable(True)
        self.inspector_scroll.setMinimumWidth(260)
        self.inspector_scroll.setStyleSheet(f"background-color: {TOKENS['bg_panel']}; border: none;")

        self.inspector_content = QtWidgets.QWidget()
        self.insp_layout = QtWidgets.QVBoxLayout(self.inspector_content)
        self.insp_layout.setContentsMargins(10, 10, 10, 10)
        self.insp_layout.setSpacing(8)

        # Tab icons bar: Sliders, Dial, Hierarchy, Info
        tab_bar = QtWidgets.QHBoxLayout()
        for icon_symbol, active in [("🎚", True), ("⏱", False), ("▤", False), ("ℹ", False)]:
            b = QtWidgets.QPushButton(icon_symbol, self.inspector_content)
            b.setFixedSize(28, 26)
            if active:
                b.setProperty("class", "workspace_pill_active")
            else:
                b.setProperty("class", "workspace_pill")
            tab_bar.addWidget(b)
        tab_bar.addStretch(1)
        self.insp_layout.addLayout(tab_bar)

        self._build_inspector()
        self.inspector_scroll.setWidget(self.inspector_content)
        self.splitter.addWidget(self.inspector_scroll)

        self.splitter.setHandleWidth(6)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setStretchFactor(2, 0)
        self.splitter.setSizes([260, 840, 320])

        layout.addWidget(self.splitter)

        # Controller signal subscriptions
        self.controller.tilesChanged.connect(self._on_tiles_changed_from_controller)
        self.viewport.deleteRequested.connect(self._del_tile)

        self._setup_live_workspace(False)
        self._setup_atlas_viewport()
        self._refresh_tile_list()
        self._set_map_channel("live")

    def showEvent(self, event: QtGui.QShowEvent):
        super().showEvent(event)
        self._on_workspace_activated()

    def _on_workspace_activated(self):
        if self.current_tile is None and self.controller.project.tiles:
            self.current_tile = self.controller.project.tiles[0]
        self._sync_header_tile_info()
        self._request_preview()
        self.viewport.update()

    def _current_map_channel_key(self) -> str:
        for k, b in getattr(self, "map_buttons", {}).items():
            if b.isChecked():
                return k
        data = self.map_combo.currentData()
        if data:
            return str(data).lower()
        txt = self.map_combo.currentText().lower()
        return "live" if "live" in txt else txt

    def _sync_header_tile_info(self):
        if not hasattr(self, 'lbl_tile_info'): return
        is_atlas = hasattr(self, "mode_combo") and self.mode_combo.currentText() == "Atlas Mode"
        ch_key = self._current_map_channel_key()
        ch_display = "Live Fiber GPU" if ch_key == "live" else ch_key.capitalize()
        if is_atlas:
            cur_udim = 1001 + (self._atlas_page() if hasattr(self, "_atlas_page") else 0)
            self.lbl_tile_info.setText(f"Atlas: UDIM {cur_udim}   Map: {ch_display}")
        elif self.current_tile:
            self.lbl_tile_info.setText(f"Tile: {self.current_tile.name}   Map: {ch_display}")

    def _on_tiles_changed_from_controller(self):
        self._refresh_tile_list()
        self._request_preview()

    def _on_mode_changed(self):
        is_atlas = self.mode_combo.currentText() == "Atlas Mode"
        model=self.map_combo.model()
        if hasattr(model,'item'):
            for index in range(self.map_combo.count()):
                if self.map_combo.itemData(index)=='live' or 'live fiber gpu' in self.map_combo.itemText(index).lower():model.item(index).setEnabled(not is_atlas)
        if is_atlas:
            self.viewport.set_renderer_callback(None)
            self.viewport.set_display_pixmap(None)
            self._preview_strands=()
            cur_key = self._current_map_channel_key()
            if cur_key in ("live", "Live Fiber GPU"):
                self._set_map_channel("color")
                return
        self._sync_header_tile_info()
        self._request_preview()

    def _set_map_channel(self, map_key: str):
        map_key=str(map_key).strip().lower()
        if map_key in ('live','live fiber gpu'):map_key='live'
        # A channel picker never changes the workspace mode behind its tab.
        if map_key=='live' and self._is_atlas():map_key='color'
        for k, b in getattr(self, "map_buttons", {}).items():
            if k == map_key:
                b.setChecked(True)
                b.setProperty("class", "workspace_pill_active")
            else:
                b.setChecked(False)
                b.setProperty("class", "workspace_pill")
            b.style().unpolish(b)
            b.style().polish(b)
        self.map_combo.blockSignals(True)
        if map_key == "live":
            self.map_combo.setCurrentIndex(0)
        else:
            idx = self.map_combo.findText(map_key)
            if idx >= 0:
                self.map_combo.setCurrentIndex(idx)
        self.map_combo.blockSignals(False)
        self._sync_header_tile_info()
        self._request_preview()

    def _on_map_combo_changed(self):
        m = self.map_combo.currentData() or self.map_combo.currentText().lower()
        self._set_map_channel(m)

    def _sync_inspector_values(self):
        from shiboken6 import isValid
        settings=getattr(self.current_tile,'settings',None)
        if settings is None:return
        provider=getattr(self,'_inspector_values',None)
        values=provider() if provider else vars(settings)
        if hasattr(self,'_sliders'):
            for param,slider in list(self._sliders.items()):
                if not isValid(slider):
                    self._sliders.pop(param,None)
                    continue
                if param in values:slider.setValue(values[param],notify=False)
        if hasattr(self,'_color_pickers'):
            for param,picker in list(self._color_pickers.items()):
                if not isValid(picker):
                    self._color_pickers.pop(param,None)
                    continue
                if param in values and hasattr(picker,'setColor'):
                    picker.setColor(values[param],notify=False)

    def _build_inspector(self):
        s = self.current_tile.settings if self.current_tile else None
        self._sliders = {}
        self._color_pickers = {}

        # Fiber Geometry Group
        grp_geom = QtPropertyGroup("Fiber Geometry", self.inspector_content)
        self._sliders["count"] = grp_geom.add_slider("Count", 10, 5000, getattr(s, 'count', 1280), is_integer=True,
                           callback=lambda v: self._setting_changed("count", int(v)))
        self._sliders["length"] = grp_geom.add_slider("Length", 0.05, 5.0, getattr(s, 'length', 1.000), step=0.01,
                           callback=lambda v: self._setting_changed("length", v))
        self._sliders["root_width"] = grp_geom.add_slider("Root Width", 0.01, 5.0, getattr(s, 'root_width', 0.120), step=0.01,
                           callback=lambda v: self._setting_changed("root_width", v))
        self._sliders["bend"] = grp_geom.add_slider("Bend", -1.0, 1.0, getattr(s, 'bend', 0.420), step=0.01,
                           callback=lambda v: self._setting_changed("bend", v))
        self.insp_layout.addWidget(grp_geom)

        # Shape & Curl Group
        grp_shape = QtPropertyGroup("Shape & Curl", self.inspector_content)
        self._sliders["curl"] = grp_shape.add_slider("Curl", 0.0, 1.0, getattr(s, 'curl', 0.680), step=0.01,
                            callback=lambda v: self._setting_changed("curl", v))
        self._sliders["curl_frequency"] = grp_shape.add_slider("Curl Freq", 0.0, 20.0, getattr(s, 'curl_frequency', 3.200), step=0.1,
                            callback=lambda v: self._setting_changed("curl_frequency", v))
        self._sliders["frizz"] = grp_shape.add_slider("Frizz", 0.0, 1.0, getattr(s, 'frizz', 0.180), step=0.01,
                            callback=lambda v: self._setting_changed("frizz", v))
        self.insp_layout.addWidget(grp_shape)

        # Pigment & Color Group
        grp_color = QtPropertyGroup("Pigment & Roughness", self.inspector_content)
        self._sliders["roughness"] = grp_color.add_slider("Roughness", 0.0, 1.0, getattr(s, 'roughness', 0.380), step=0.01,
                            callback=lambda v: self._setting_changed("roughness", v))
        self._sliders["specular"] = grp_color.add_slider("Specular", 0.0, 1.0, getattr(s, 'specular', 0.980), step=0.01,
                            callback=lambda v: self._setting_changed("specular", v))
        self._sliders["anisotropy"] = grp_color.add_slider("Anisotropy", 0.0, 1.0, getattr(s, 'anisotropy', 0.780), step=0.01,
                            callback=lambda v: self._setting_changed("anisotropy", v))

        self._color_pickers["color_root"] = grp_color.add_color_picker(
            "Root Color", getattr(s, 'color_root', '#44372e'),
            callback=lambda c: self._setting_changed("color_root", c)
        )
        self._color_pickers["color_mid"] = grp_color.add_color_picker(
            "Mid Color", getattr(s, 'color_mid', '#a98d6f'),
            callback=lambda c: self._setting_changed("color_mid", c)
        )
        self._color_pickers["color_tip"] = grp_color.add_color_picker(
            "Tip Color", getattr(s, 'color_tip', '#dfc9a6'),
            callback=lambda c: self._setting_changed("color_tip", c)
        )
        self.insp_layout.addWidget(grp_color)

        self.insp_layout.addStretch(1)

    def _on_search_tiles_changed(self, text: str):
        query = text.strip().lower()
        for i in range(self.tile_list.count()):
            item = self.tile_list.item(i)
            item.setHidden(bool(query and query not in item.text().lower()))

    def _refresh_tile_list(self):
        active=self.controller.current_tile()
        self.tile_list.blockSignals(True)
        self.tile_list.clear()
        self._tile_items_map={}
        selected_row=-1
        for row,tile in enumerate(self.controller.project.tiles):
            item=QtWidgets.QListWidgetItem(f"▼ 🪶  {tile.name}   {tile.width}×{tile.height}       👁")
            item.setData(QtCore.Qt.ItemDataRole.UserRole,tile.id)
            self.tile_list.addItem(item);self._tile_items_map[row]=tile
            if active is not None and tile.id==active.id:selected_row=row
        self.tile_list.setCurrentRow(selected_row)
        self.current_tile=active
        self.tile_list.blockSignals(False)
        if selected_row>=0:self._on_tile_selected(selected_row)

    def _on_tile_selected(self, row: int):
        tile = getattr(self, '_tile_items_map', {}).get(row)
        if tile is None and 0 <= row < len(self.controller.project.tiles):
            tile = self.controller.project.tiles[row]
        if tile is not None:
            self.current_tile = tile
            self.controller.set_active_tile(self.current_tile.id)
            self._sync_inspector_values()
            self._sync_tile_size_combos()
            self._update_tile_udim_ui()
            self._sync_header_tile_info()
            if hasattr(self, 'mode_combo') and self.mode_combo.currentText() == 'Atlas Mode':
                self._atlas_ids = {tile.id}
                self.viewport.update()
            else:
                self._request_preview()

    def _update_tile_udim_ui(self):
        pass # UDIM is determined spatially in the Atlas canvas.

    def _sync_tile_size_combos(self):
        if hasattr(self, 'combo_tw') and hasattr(self, 'combo_th') and self.current_tile:
            self.combo_tw.blockSignals(True)
            self.combo_th.blockSignals(True)
            w_str = str(self.current_tile.width)
            h_str = str(self.current_tile.height)
            if self.combo_tw.findText(w_str) < 0:
                self.combo_tw.addItem(w_str)
            if self.combo_th.findText(h_str) < 0:
                self.combo_th.addItem(h_str)
            self.combo_tw.setCurrentText(w_str)
            self.combo_th.setCurrentText(h_str)
            self.combo_tw.blockSignals(False)
            self.combo_th.blockSignals(False)

    def _on_viewport_light_orbit(self, d_az: float, d_el: float):
        self._light_elevation=max(-85.,min(85.,getattr(self,"_light_elevation",40.)+d_el))
        val = self.light_slider.value() + d_az
        val = (val + 180.0) % 360.0 - 180.0
        self.light_slider.setValue(val)

    def _toggle_viewport_grid(self):
        self.chk_grid.setChecked(not self.chk_grid.isChecked())

    def _toggle_uv_mode(self):
        self._set_map_channel("normal" if self.map_combo.currentText() == "color" else "color")

    def _toggle_isolation(self):
        self._set_map_channel("alpha" if self.map_combo.currentText() != "alpha" else "color")

    def _on_tile_size_changed(self):
        if not self.current_tile:
            return
        try:
            w = int(self.combo_tw.currentText())
            h = int(self.combo_th.currentText())
            if self.current_tile.width != w or self.current_tile.height != h:
                self.controller.snapshot()
                self.current_tile.width = w
                self.current_tile.height = h
                self.current_tile.revision += 1
                self.controller.mark_dirty(True)
                self._request_preview()
        except Exception:
            pass

    def _on_fit_view(self):
        if self._is_atlas():self._atlas_fit()
        else:self.viewport.fit_view()

    def _toggle_tile_atlas(self):
        self.mode_combo.setCurrentIndex(1-self.mode_combo.currentIndex())
        self._request_preview()

    def _toggle_inspector(self):
        vis = not self.inspector_scroll.isVisible()
        self.inspector_scroll.setVisible(vis)

    def _setting_changed(self, param: str, value: Any):
        if self.current_tile and hasattr(self.current_tile, 'settings'):
            self.controller.snapshot_interactive(('tile',self.current_tile.id,param))
            setattr(self.current_tile.settings, param, value)
            self.controller.mark_dirty(True)
            self.current_tile.revision += 1
            self._request_preview()
            self.controller.tileUpdated.emit(self.current_tile.id)
            self.tileModified.emit(self.current_tile.id)

    def _new_tile(self):
        self.controller.snapshot()
        tile = Tile.create(f"Tile {len(self.controller.project.tiles)+1:02d}", "Soft Cat Undercoat")
        self.controller.project.tiles.append(tile)
        self.controller.mark_dirty(True)
        self._refresh_tile_list()
        self.current_tile = tile
        self._request_preview()
        self.controller.tilesChanged.emit()

    def _dup_tile(self):
        if self.current_tile:
            self.controller.snapshot()
            dup = self.current_tile.clone()
            self.controller.project.tiles.append(dup)
            self.controller.mark_dirty(True)
            self._refresh_tile_list()
            self.current_tile = dup
            self._request_preview()
            self.controller.tilesChanged.emit()

    def _del_tile(self):
        project=self.controller.project
        tile=self.controller.current_tile()
        ids=set(self._atlas_ids) if self._is_atlas() and self._atlas_ids else ({tile.id} if tile else set())
        ids.intersection_update(t.id for t in project.tiles)
        if not ids:return
        self.controller.snapshot()
        self.controller.cancel_job('fiber_studio_preview')
        project.tiles=[t for t in project.tiles if t.id not in ids]
        metadata=deepcopy(project.metadata)
        for key in ('tile_placements','tile_udims'):
            if isinstance(metadata.get(key),dict):metadata[key]={k:v for k,v in metadata[key].items() if k not in ids}
        if isinstance(metadata.get('tile_groups'),dict):
            metadata['tile_groups']={k:[tid for tid in values if tid not in ids] for k,values in metadata['tile_groups'].items()}
        project.metadata=metadata
        self._atlas_ids.difference_update(ids)
        self.current_tile=next((t for t in project.tiles if t.id==self.controller.active_tile_id),None)
        if self.current_tile is None:self.current_tile=project.tiles[0] if project.tiles else None
        self.controller.active_tile_id=self.current_tile.id if self.current_tile else None
        self.controller._rebuild_atlas_cache()
        self.controller.tilesChanged.emit()

    def _request_preview(self):
        if self.current_tile is None and not self._is_atlas():
            if hasattr(self,'_preview_timer'):self._preview_timer.stop()
            self.controller.cancel_job('fiber_studio_preview')
            self._preview_serial=getattr(self,'_preview_serial',0)+1
            self._pending_channel_key=None;self._preview_strands=()
            self.viewport.set_renderer_callback(None)
            self.viewport.set_display_pixmap(None)
            self.viewport._map_canvas=None
            self.viewport.set_hud_text('No tile selected · Create a tile to begin')
            self.viewport.update()
            return
        # Coalesce combo/slider bursts before taking snapshots or scheduling work.
        if hasattr(self,'_atlas_ids') and self._is_atlas():
            self._preview_serial=getattr(self,'_preview_serial',0)+1
            self._pending_channel_key=None
            if hasattr(self,'_preview_timer'):self._preview_timer.stop()
            self.controller.cancel_job('fiber_studio_preview')
            self._request_atlas_canvas();return
        self.viewport._map_canvas=None
        self.viewport._atlas_navigation=False
        if not self._use_live() and getattr(self,'_texture_presenter',None) is None:self.viewport.set_renderer_callback(None)
        if hasattr(self,"_atlas_saved_cube"):self.viewport._show_cube=self._atlas_saved_cube
        if not hasattr(self,'_preview_timer'):
            from collections import OrderedDict
            self._channel_cache=OrderedDict();self._channel_cache_bytes=0;self._preview_serial=0
            self._preview_timer=QtCore.QTimer(self);self._preview_timer.setSingleShot(True)
            self._preview_timer.timeout.connect(self._dispatch_preview)
        if self.current_tile and self._is_atlas():
            channel=self.map_combo.currentText();channel='color' if channel in ('lit','Live Fiber GPU') else channel
            key=self._atlas_preview_key(channel,self._atlas_page())
            if getattr(self,'_display_channel_key',None)==key and self.viewport._pixmap is not None:return
            if getattr(self,'_pending_channel_key',None)==key and 'fiber_studio_preview' in self.controller._active_jobs:return
        self._preview_serial+=1
        self.controller.cancel_job('fiber_studio_preview')
        if self.current_tile:
            if self._use_live():
                key=self._preview_source_key()
                cached=getattr(self,'_live_cached',None)
                if (cached and cached[0]==key) or getattr(self,'_live_display_key',None)==key:
                    self._preview_timer.stop();self._dispatch_preview();return
            else:
                channel=self.map_combo.currentText();channel='color' if channel in ('lit','Live Fiber GPU') else channel
                atlas_mode=self.mode_combo.currentText()=='Atlas Mode'
                key=self._atlas_preview_key(channel,self._atlas_page()) if atlas_mode else ('tile',self._preview_source_key(),channel)
                if key in self._channel_cache:
                    self._preview_timer.stop();self._dispatch_preview();return
        self._preview_timer.start(35)

    def _preview_source_key(self):
        tile=self.current_tile
        return (id(self.controller.project),id(tile),tile.id,tile.revision)

    def _dispatch_preview(self):
        if self._is_atlas():
            self._request_atlas_canvas();return
        if not self.current_tile or self.controller._closed:return
        if self._use_live():
            self._pending_channel_key=None
            if self.current_tile:
                self.viewport.set_hud_text(f'TILE: {self.current_tile.name} · LIVE FIBER GPU')
            self._request_live_preview();return
        from PIL import Image
        if getattr(self,'_texture_presenter',None) is None:self.viewport.set_renderer_callback(None)
        serial=self._preview_serial;source=self._preview_source_key()
        channel=self.map_combo.currentText();channel='color' if channel in ('lit','Live Fiber GPU') else channel
        display_ch=self._current_map_channel_key()
        atlas_mode=self.mode_combo.currentText()=='Atlas Mode'
        if atlas_mode:self.controller.request_atlas_channel(channel)
        page=self._atlas_page();generation=self.controller._atlas_generation
        key=self._atlas_preview_key(channel,page) if atlas_mode else ('tile',source,channel)
        cached=self._channel_cache.get(key)
        if cached is not None:
            self._channel_cache.move_to_end(key);self._preview_strands=cached[1];self._display_channel_key=key;self._present_channel(cached[0],channel,atlas_mode,page,display_ch);return
        self._pending_channel_key=key
        tile=deepcopy(self.current_tile) if not atlas_mode else None
        # Capture an image reference only; resize/copy and QImage conversion are worker work.
        atlas_image=self.controller.atlas._pages.get((channel,page)) if atlas_mode else None
        size=self.controller.atlas.layout.size
        def worker(cancel):
            if atlas_mode:
                if atlas_image is not None:
                    image=atlas_image.copy()
                else:
                    # A cold preview is a layout placeholder, never a second atlas baker.
                    # The controller publishes production tiles incrementally in the background.
                    mode='RGBA' if channel=='color' else ('L' if channel in ('alpha','depth','ao','roughness','specular','anisotropy','transmission','scatter','iridescence') else 'RGB')
                    bg=255 if channel=='ao' else (0 if mode=='L' else (0,)*len(mode))
                    image=Image.new(mode,(min(size,1024),min(size,1024)),bg)
                strands=()
            else:
                scale=min(1.,512/max(tile.width,tile.height))
                dimensions=(max(16,round(tile.width*scale)),max(16,round(tile.height*scale)))
                import os,sys
                if not getattr(self,'_gpu_preview_disabled',False) and channel!='lit' and sys.platform=='win32' and os.environ.get('QT_QPA_PLATFORM')!='offscreen' and os.environ.get('FSD_FIBERBAKE_BACKEND','auto')!='cpu':
                    try:
                        from ..fiberbake_x.service import prepare_preview
                        return prepare_preview(tile,dimensions,channel,cancel)
                    except Exception:
                        if cancel():raise RuntimeError('Render cancelled')
                        # Unsupported GL/source features retain the CPU display path.
                result=render_tile(tile,size=dimensions,channels=(channel,),should_cancel=cancel)
                image=result.maps[channel];strands=result.strands
            if cancel():return None
            if max(image.size)>1024:
                image.thumbnail((1024,1024),Image.Resampling.BILINEAR)
            qimage=ImageQt(image).copy()
            return qimage,strands
        def done(result,revision):
            from ..fiberbake_x.service import PreviewPacket
            if isinstance(result,PreviewPacket):
                if serial!=self._preview_serial or self.current_tile is None or self._is_atlas() or self._use_live() or self._preview_source_key()!=source:
                    result.close();return
                try:
                    from ..fiberbake_x.presenter import TexturePresenter
                    if getattr(self,'_texture_presenter',None) is None:self._texture_presenter=TexturePresenter(self.viewport,result)
                    else:self._texture_presenter.set_packet(result)
                    self._preview_strands=result.truth;self._pending_channel_key=None;self._display_channel_key=key
                    self.viewport.set_renderer_callback(self._texture_presenter.frame)
                    self.viewport.set_hud_text(f'TILE: {self.current_tile.name} · {channel.upper()} · FiberBake X GPU')
                    self.viewport.update()
                except Exception as error:
                    result.close();self._gpu_preview_disabled=True;self._pending_channel_key=None;self.controller.jobFailed.emit('GPU texture preview',str(error));self._preview_timer.start(0)
                return
            if result is None or serial!=self._preview_serial or self.current_tile is None:return
            if not atlas_mode and self._preview_source_key()!=source:return
            if atlas_mode and self._atlas_preview_key(channel,page)!=key:return
            self._pending_channel_key=None;self._display_channel_key=key
            image,strands=result;pixmap=QtGui.QPixmap.fromImage(image)
            self._preview_strands=strands
            cost=pixmap.width()*pixmap.height()*4
            self._channel_cache[key]=(pixmap,strands);self._channel_cache_bytes+=cost
            while self._channel_cache_bytes>64*1024*1024 and len(self._channel_cache)>1:
                _,old=self._channel_cache.popitem(last=False);self._channel_cache_bytes-=old[0].width()*old[0].height()*4
            self._present_channel(pixmap,channel,atlas_mode,page,display_ch)
        self.controller.submit_job('fiber_studio_preview',worker,done)

    def _present_channel(self,pixmap,channel,atlas_mode,page,display_key=None):
        # Continuous Atlas canvas never consumes a single-tile/page pixmap.
        if atlas_mode or self._is_atlas():return
        self.viewport.set_display_pixmap(pixmap)
        cur_udim = 1001 + page
        label=f'ATLAS UDIM {cur_udim} (Page {page})' if atlas_mode else f'TILE: {self.current_tile.name}'
        if atlas_mode:
            cache=self.controller.atlas;ids=[tid for tid,p in cache.layout.placements.items() if p.page==page];ready=sum((tid,channel) in cache._channel_versions for tid in ids)
            if ready<len(ids):label+=f' · baking {ready}/{len(ids)} tiles'
        shown_ch = (display_key or channel).upper()
        self.viewport.set_hud_text(f'{label} · {shown_ch} · {pixmap.width()}×{pixmap.height()} preview')
