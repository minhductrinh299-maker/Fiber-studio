"""Versioned asynchronous source baking/export with progress and cancellation."""
from copy import deepcopy
from pathlib import Path
import hashlib,json
from PySide6 import QtCore,QtWidgets
from ..raster import render_tile
from ..model import MAP_NAMES,EXTRA_MAP_NAMES

class BakePanel(QtWidgets.QWidget):
    progress=QtCore.Signal(int,int,int)
    tileBaked=QtCore.Signal(int,object,str,object,str)
    def __init__(self,controller,parent=None):
        super().__init__(parent);self.controller=controller;self.task='studio_bake';self.result_tokens={};self._ticket=0
        layout=QtWidgets.QVBoxLayout(self);row=QtWidgets.QHBoxLayout();layout.addLayout(row)
        for title,callback in [('Bake Selected',lambda:self.bake('selected')),('Bake Dirty',lambda:self.bake('dirty')),('Bake Atlas',lambda:self.bake('all')),('Export Maps…',self.export_maps),('Cancel',self.cancel)]:
            button=QtWidgets.QPushButton(title);button.clicked.connect(callback);row.addWidget(button)
        self.format=QtWidgets.QComboBox();self.format.addItems(['PNG','TIFF']);row.addWidget(self.format)
        self.resolution=QtWidgets.QComboBox();self.resolution.addItems(['Source resolution','256','512','1024','2048','4096']);row.addWidget(self.resolution)
        self.quality=QtWidgets.QComboBox();self.quality.addItems(['Final · 16 samples','Draft · 1 sample']);row.addWidget(self.quality)
        self.bar=QtWidgets.QProgressBar();layout.addWidget(self.bar);self.status=QtWidgets.QLabel('Ready · source resolution, all implemented map channels');self.status.setWordWrap(True);layout.addWidget(self.status)
        self.progress.connect(self._progress);self.tileBaked.connect(self._accept_tile);controller.jobFailed.connect(self._failed)
    def _token(self,tile):return hashlib.sha256(json.dumps(tile.to_dict(),sort_keys=True).encode()).hexdigest()
    def _progress(self,ticket,current,total):
        if ticket!=self._ticket:return
        self.bar.setRange(0,max(1,total));self.bar.setValue(current);self.status.setText(f'Baking {current}/{total}')
    def bake(self,mode='selected',folder=None):
        self._ticket+=1;ticket=self._ticket
        project=self.controller.project;resolution=self.resolution.currentText();final_quality=self.quality.currentIndex()==0;self._bake_final_quality=final_quality
        tiles=[self.controller.current_tile()] if mode=='selected' else list(project.tiles)
        tiles=[t for t in tiles if t is not None and (mode!='dirty' or self.result_tokens.get((t.id,resolution,final_quality))!=self._token(t))]
        snapshots=[deepcopy(t) for t in tiles];tokens={t.id:self._token(t) for t in snapshots};format=self.format.currentText();resolution=self.resolution.currentText()
        self._progress(ticket,0,len(tiles))
        def work(cancel):
            completed=0
            for index,tile in enumerate(snapshots):
                tile.settings.bake_samples=16 if final_quality else 1;tile.settings.ao_mode='geometry' if final_quality else 'proximity'
                if cancel():raise RuntimeError('Bake cancelled')
                size=None if resolution=='Source resolution' else (max(16,round(int(resolution)*tile.width/max(tile.width,tile.height))),max(16,round(int(resolution)*tile.height/max(tile.width,tile.height))))
                result=None
                if size is None and not folder:
                    import os
                    if os.environ.get('FSD_FIBERBAKE_BACKEND','auto') not in ('cpu','legacy-gpu'):
                        try:
                            from ..fiberbake_x.atlas import prepare_production
                            result=prepare_production(tile,MAP_NAMES+EXTRA_MAP_NAMES,cancel)
                        except Exception:
                            if cancel() or os.environ.get('FSD_FIBERBAKE_BACKEND')=='gpu':raise
                if result is None:result=render_tile(tile,size=size,channels=MAP_NAMES+EXTRA_MAP_NAMES,should_cancel=cancel)
                if folder:
                    target=Path(folder)/tile.id;target.mkdir(parents=True,exist_ok=True)
                    for channel,image in result.maps.items():
                        if cancel():raise RuntimeError('Export cancelled')
                        image.save(target/(channel+('.png' if format=='PNG' else '.tif')),format=format)
                self.tileBaked.emit(ticket,result,tokens[tile.id],project,resolution);completed+=1;self.progress.emit(ticket,index+1,len(snapshots))
            return completed
        def done(count,revision):
            if project is not self.controller.project or ticket!=self._ticket:return
            self.status.setText(f'Complete · {count} tiles'+(' · '+str(folder) if folder else ''))
        self.controller.submit_job(self.task,work,done)
    def _accept_tile(self,ticket,result,token,project,resolution):
        if ticket!=self._ticket or project is not self.controller.project:return
        tile=project.find(result.tile_id)
        if tile is None or self._token(tile)!=token:return
        self.result_tokens[(tile.id,resolution,getattr(self,'_bake_final_quality',True))]=token
        if resolution=='Source resolution' and tile.id in self.controller.atlas.layout.placements:self.controller.update_tile_atlas(result,self.controller._atlas_token(tile))
    def export_maps(self):
        folder=QtWidgets.QFileDialog.getExistingDirectory(self,'Export source maps')
        if folder:self.bake('all',folder)
    def cancel(self):self._ticket+=1;self.controller.cancel_job(self.task);self.status.setText('Cancelled · completed files retained; source project unchanged')
    def _failed(self,name,error):
        if name==self.task:self.status.setText(error)
