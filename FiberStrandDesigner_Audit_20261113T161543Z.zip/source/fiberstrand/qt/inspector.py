"""Modern Property Inspector & Collapsible Parameter System for Qt 6 / PySide6.

Styled exactly like professional DCC software with:
- Top tool icon buttons (sliders, graph/cube, hierarchy, info)
- Collapsible section headers with chevron indicators (▾ / ▸)
- Two-column parameter rows (Label on left, Slider + Numeric box on right)
"""
from __future__ import annotations
from typing import Callable, Any
from PySide6 import QtCore, QtGui, QtWidgets
from .slider import QtNumberSlider
from .theme import TOKENS


class QtPropertyRow(QtWidgets.QWidget):
    def __init__(
        self,
        label: str,
        widget: QtWidgets.QWidget,
        tooltip: str = "",
        parent: QtWidgets.QWidget | None = None,
    ):
        super().__init__(parent)
        from .style_registry import slug
        self.setObjectName("parameter_"+slug(label))
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(4, 2, 4, 2)
        layout.setSpacing(10)

        lbl = QtWidgets.QLabel(label, self)
        lbl.setMinimumWidth(85)
        lbl.setMaximumWidth(110)
        lbl.setStyleSheet(f"color: {TOKENS['text']}; font-size: 11px; font-weight: 500;")
        if tooltip:
            lbl.setToolTip(tooltip)
            widget.setToolTip(tooltip)

        layout.addWidget(lbl, 0)
        layout.addWidget(widget, 1)


class QtPropertyGroup(QtWidgets.QWidget):
    """Collapsible Parameter Group with sleek header bar."""

    def __init__(self, title: str, parent: QtWidgets.QWidget | None = None):
        super().__init__(parent)
        from .style_registry import slug
        self.setObjectName("group_"+slug(title))
        self.main_layout = QtWidgets.QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 4, 0, 8)
        self.main_layout.setSpacing(4)

        # Header Toggle Button
        self.header_btn = QtWidgets.QToolButton(self)
        self.header_btn.setText(title)
        self.header_btn.setArrowType(QtCore.Qt.ArrowType.DownArrow)
        self.header_btn.setToolButtonStyle(QtCore.Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.header_btn.setCheckable(True)
        self.header_btn.setChecked(True)
        self.header_btn.setStyleSheet(f"""
            QToolButton {{
                color: {TOKENS['text']};
                font-weight: 700;
                font-size: 11px;
                background-color: transparent;
                border: none;
                text-align: left;
                padding: 4px 2px;
            }}
            QToolButton:hover {{
                color: {TOKENS['cyan']};
            }}
        """)
        self.header_btn.clicked.connect(self._toggle_collapse)
        self.main_layout.addWidget(self.header_btn)

        # Content Container
        self.content_widget = QtWidgets.QWidget(self)
        self.layout = QtWidgets.QVBoxLayout(self.content_widget)
        self.layout.setContentsMargins(6, 2, 6, 2)
        self.layout.setSpacing(4)
        self.main_layout.addWidget(self.content_widget)

    def _toggle_collapse(self, checked: bool):
        title = self.header_btn.text()
        if title.startswith(("▾","▸")):title=title[1:].lstrip()
        if checked:
            self.header_btn.setText(title)
            self.header_btn.setArrowType(QtCore.Qt.ArrowType.DownArrow)
            self.content_widget.show()
        else:
            self.header_btn.setText(title)
            self.header_btn.setArrowType(QtCore.Qt.ArrowType.RightArrow)
            self.content_widget.hide()

    def add_row(self, label: str, widget: QtWidgets.QWidget, tooltip: str = "") -> QtPropertyRow:
        row = QtPropertyRow(label, widget, tooltip=tooltip, parent=self.content_widget)
        self.layout.addWidget(row)
        return row

    def add_slider(
        self,
        label: str,
        from_: float,
        to: float,
        value: float,
        step: float = 0.01,
        is_integer: bool = False,
        callback: Callable[[float], None] | None = None,
        tooltip: str = "",
        format_str: str | None = None,
    ) -> QtNumberSlider:
        slider = QtNumberSlider(
            from_=from_,
            to=to,
            step=step,
            value=value,
            is_integer=is_integer,
            format_str=format_str,
            parent=self.content_widget,
        )
        if callback:
            slider.valueChanged.connect(callback)
        self.add_row(label, slider, tooltip=tooltip)
        return slider

    def add_color_picker(
        self,
        label: str,
        color: str | tuple[float, float, float] | QtGui.QColor,
        callback: Callable[[str], None] | None = None,
        tooltip: str = "",
        show_alpha: bool = False,
    ) -> QtColorPicker:
        picker = QtColorPicker(
            initial_color=color,
            title=f"Choose {label}",
            callback=callback,
            show_alpha=show_alpha,
            parent=self.content_widget,
        )
        self.add_row(label, picker, tooltip=tooltip)
        return picker


class QtColorPicker(QtWidgets.QWidget):
    """Professional DCC Color Picker & Preview Control.

    Adheres strictly to the Qt UI Family & Design Specification:
    - Zero inline per-widget setStyleSheet; visual rendering is fully owned
      by paintEvent, respecting tokens and fsdStyle properties.
    - Displays a live color preview swatch box on the left and hex readout on the right.
    - Click opens QColorDialog; supports keyboard activation (Space/Enter).
    - Can also be used as a compact standalone swatch button (e.g. adjacent to sliders).
    """
    colorChanged = QtCore.Signal(str)

    def __init__(
        self,
        initial_color: str | tuple[float, float, float] | QtGui.QColor = "#ffffff",
        title: str = "Select Color",
        callback: Callable[[str], None] | None = None,
        show_alpha: bool = False,
        compact: bool = False,
        parent: QtWidgets.QWidget | None = None,
    ):
        super().__init__(parent)
        self._title = title
        self._show_alpha = show_alpha
        self._compact = compact
        self._current_hex = self._normalize_to_hex(initial_color)
        self._hovered = False
        self._dialog_open = False

        self.setFocusPolicy(QtCore.Qt.FocusPolicy.StrongFocus)
        self.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        h = 24 if compact else 26
        self.setFixedHeight(h)
        if compact:
            self.setFixedWidth(28)
            self.setSizePolicy(QtWidgets.QSizePolicy.Policy.Fixed, QtWidgets.QSizePolicy.Policy.Fixed)
        else:
            self.setMinimumWidth(80)
            self.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding, QtWidgets.QSizePolicy.Policy.Fixed)

        if callback:
            self.colorChanged.connect(callback)
        self._update_tooltip()

    @staticmethod
    def _normalize_to_hex(color: str | tuple[float, float, float] | QtGui.QColor) -> str:
        if isinstance(color, str):
            c = color.strip()
            if c.startswith('#') and len(c) in (4, 7, 9):
                return c
            qc = QtGui.QColor(c)
            return qc.name() if qc.isValid() else "#ffffff"
        if isinstance(color, (tuple, list)):
            vals = [int(round(max(0.0, min(1.0, float(v))) * 255)) for v in color[:3]]
            return f"#{vals[0]:02x}{vals[1]:02x}{vals[2]:02x}"
        if isinstance(color, QtGui.QColor):
            return color.name()
        return "#ffffff"

    def _update_tooltip(self):
        self.setToolTip(f"{self._title}: {self._current_hex.upper()} (Click to change)")

    def color(self) -> str:
        return self._current_hex

    def qcolor(self) -> QtGui.QColor:
        return QtGui.QColor(self._current_hex)

    def setColor(self, color: str | tuple[float, float, float] | QtGui.QColor, notify: bool = False):
        hex_val = self._normalize_to_hex(color)
        if hex_val != self._current_hex:
            self._current_hex = hex_val
            self._update_tooltip()
            self.update()
            if notify:
                self.colorChanged.emit(self._current_hex)

    def enterEvent(self, event: QtGui.QEnterEvent):
        self._hovered = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event: QtCore.QEvent):
        self._hovered = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event: QtGui.QMouseEvent):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.open_dialog()
            event.accept()
        else:
            super().mousePressEvent(event)

    def keyPressEvent(self, event: QtGui.QKeyEvent):
        if event.key() in (QtCore.Qt.Key.Key_Return, QtCore.Qt.Key.Key_Enter, QtCore.Qt.Key.Key_Space):
            self.open_dialog()
            event.accept()
        else:
            super().keyPressEvent(event)

    def open_dialog(self):
        if self._dialog_open:
            return
        self._dialog_open = True
        try:
            init_qcolor = QtGui.QColor(self._current_hex)
            dlg = QtWidgets.QColorDialog(init_qcolor, self)
            dlg.setWindowTitle(self._title)
            if self._show_alpha:
                dlg.setOption(QtWidgets.QColorDialog.ColorDialogOption.ShowAlphaChannel, True)
            
            # Realtime color change while moving sliders/palette in dialog
            def on_current_color_changed(qc: QtGui.QColor):
                if qc.isValid():
                    h_val = qc.name()
                    if h_val != self._current_hex:
                        self._current_hex = h_val
                        self._update_tooltip()
                        self.update()
                        self.colorChanged.emit(h_val)

            dlg.currentColorChanged.connect(on_current_color_changed)
            original_hex = self._current_hex

            if dlg.exec():
                chosen = dlg.selectedColor()
                if chosen.isValid():
                    final_hex = chosen.name()
                    if final_hex != self._current_hex:
                        self._current_hex = final_hex
                        self._update_tooltip()
                        self.update()
                        self.colorChanged.emit(final_hex)
            else:
                # Cancelled: restore original color if changed during preview
                if self._current_hex != original_hex:
                    self._current_hex = original_hex
                    self._update_tooltip()
                    self.update()
                    self.colorChanged.emit(original_hex)
        finally:
            self._dialog_open = False

    def paintEvent(self, event: QtGui.QPaintEvent):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)

        style = self.property("fsdStyle") or {}
        w = float(self.width())
        h = float(self.height())
        radius = float(style.get("radius", 4))

        # Colors from style or tokens
        border_col = QtGui.QColor(style.get("active", TOKENS["cyan"])) if (self.hasFocus() or self._hovered) else QtGui.QColor(style.get("border", TOKENS["border"]))
        swatch_color = QtGui.QColor(self._current_hex)

        if self._compact:
            # Standalone compact swatch button (e.g. for light sliders in 3D Scene / Render)
            rect = QtCore.QRectF(1.0, 1.0, w - 2.0, h - 2.0)
            painter.setBrush(swatch_color)
            pen = QtGui.QPen(border_col, 1.5 if (self.hasFocus() or self._hovered) else 1.0)
            painter.setPen(pen)
            painter.drawRoundedRect(rect, radius, radius)
            return

        # Full parameter row control:
        # Background container
        bg_col = QtGui.QColor(style.get("background", TOKENS["bg_control"]))
        container_rect = QtCore.QRectF(0.5, 0.5, w - 1.0, h - 1.0)
        painter.setBrush(bg_col)
        pen = QtGui.QPen(border_col, 1.5 if (self.hasFocus() or self._hovered) else 1.0)
        painter.setPen(pen)
        painter.drawRoundedRect(container_rect, radius, radius)

        # Left: Color swatch preview box
        swatch_pad = 3.0
        swatch_w = min(36.0, max(24.0, (w - swatch_pad * 3) * 0.35))
        swatch_h = h - swatch_pad * 2.0
        swatch_rect = QtCore.QRectF(swatch_pad, swatch_pad, swatch_w, swatch_h)
        painter.setBrush(swatch_color)
        inner_border = border_col if self._hovered else QtGui.QColor(TOKENS.get("border_subtle", "#262D36"))
        painter.setPen(QtGui.QPen(inner_border, 1.0))
        painter.drawRoundedRect(swatch_rect, max(2.0, radius - 1.0), max(2.0, radius - 1.0))

        # Right: Hex text readout
        text_rect = QtCore.QRectF(
            swatch_pad + swatch_w + 6.0,
            0.0,
            w - (swatch_pad + swatch_w + 10.0),
            h,
        )
        fg_col = QtGui.QColor(style.get("active", TOKENS["cyan"])) if (self.hasFocus() or self._hovered) else QtGui.QColor(style.get("foreground", TOKENS["text"]))
        painter.setPen(fg_col)

        font = self.font()
        font.setFamily("Consolas")
        font.setPixelSize(int(style.get("font_size", 11)))
        font.setWeight(QtGui.QFont.Weight.Medium)
        painter.setFont(font)
        painter.drawText(
            text_rect,
            QtCore.Qt.AlignmentFlag.AlignLeft | QtCore.Qt.AlignmentFlag.AlignVCenter,
            self._current_hex.upper(),
        )


# Backward-compatible alias
QtColorPickerButton = QtColorPicker

