"""Layout-only source history and asynchronous lossless page relocation."""
from copy import deepcopy
from PySide6 import QtCore
from ..atlas import AtlasLayout

class AtlasManagement:
    @property
    def atlas_layout(self):return getattr(self,'_atlas_pending_layout',None) or self._atlas.layout
    def _layout_history_record(self):
        return {'__atlas_layout_undo__':True,'state':dict(tile_placements=deepcopy(self.project.metadata.get('tile_placements',{})),active_udims=deepcopy(self.project.metadata.get('active_udims')),padding=self.project.padding,atlas_size=self.project.atlas_size)}
    def snapshot_layout(self):
        self._undo_stack.append(self._layout_history_record());self._undo_stack=self._undo_stack[-self._max_history:];self._redo_stack.clear();self._revision+=1;self.cancel_job('open_project');self.mark_dirty()
    def _restore_layout_record(self,record):
        state=record['state'];metadata=dict(self.project.metadata);metadata['tile_placements']=deepcopy(state['tile_placements'])
        if state['active_udims'] is None:metadata.pop('active_udims',None)
        else:metadata['active_udims']=deepcopy(state['active_udims'])
        self.project.metadata=metadata;self.project.padding=state['padding'];self.project.atlas_size=state['atlas_size'];self._revision+=1;self.mark_dirty();self.relayout_atlas()
    def relayout_atlas(self):
        if self._closed:return
        layout=AtlasLayout(self.project);project=self.project;base=self._atlas
        self._atlas_pending_layout=layout;self._atlas_relayout_serial=getattr(self,'_atlas_relayout_serial',0)+1;serial=self._atlas_relayout_serial
        self.atlasRebuilt.emit()
        order=tuple(tile.id for tile in project.tiles)
        def worker(cancel):return base.relocated(layout,cancel,order)
        def publish(result,revision):
            if serial!=self._atlas_relayout_serial or project is not self.project:return
            if base is not self._atlas:
                QtCore.QTimer.singleShot(0,self.relayout_atlas);return
            cache,invalid=result;self._atlas=cache;self._atlas_pending_layout=None;self._atlas_generation+=1
            for tid in invalid:self._baked_tokens.pop(tid,None)
            self.atlasRebuilt.emit();self._start_atlas_stage();QtCore.QTimer.singleShot(0,self.ensure_atlas)
        self.submit_job('atlas_relayout',worker,publish)
