"""Qt-independent camera query math used by viewport input adapters."""
import math
import numpy as np
from ..rendercore.renderer import look_at

def light_target_under_cursor(renderer,x,y,width,height):
    eye=np.asarray(renderer.target)+renderer.distance*np.array([math.sin(renderer.yaw)*math.cos(renderer.pitch),math.sin(renderer.pitch),math.cos(renderer.yaw)*math.cos(renderer.pitch)])
    mvp=renderer.projection_matrix(width/max(1,height))@look_at(eye,renderer.target)
    inverse=np.linalg.inv(mvp);ndc=[2*x/max(1,width)-1,1-2*y/max(1,height)]
    q=inverse@np.array([*ndc,1.,1.]);direction=q[:3]/q[3]-eye;direction/=max(np.linalg.norm(direction),1e-12)
    best=float('inf');hit=None
    for entry in getattr(renderer,'_card_draw_cache',{}).values():
        tri=entry['data'][:,:3].reshape(-1,3,3).astype(float)
        edge1=tri[:,1]-tri[:,0];edge2=tri[:,2]-tri[:,0]
        h=np.cross(np.broadcast_to(direction,edge2.shape),edge2);det=np.einsum('ij,ij->i',edge1,h)
        valid=np.abs(det)>1e-9;inv=np.divide(1.,det,out=np.zeros_like(det),where=valid)
        v=eye-tri[:,0];u=np.einsum('ij,ij->i',v,h)*inv;q=np.cross(v,edge1)
        b=q@direction*inv;distance=np.einsum('ij,ij->i',edge2,q)*inv
        valid&=(u>=0)&(b>=0)&(u+b<=1)&(distance>0)
        if np.any(valid):
            d=float(np.min(distance[valid]))
            if d<best:best=d;hit=eye+direction*d
    if hit is None:
        normal=eye-np.asarray(renderer.target);normal/=max(np.linalg.norm(normal),1e-12)
        denom=float(np.dot(direction,normal))
        hit=eye+direction*(float(np.dot(np.asarray(renderer.target)-eye,normal))/denom) if abs(denom)>1e-9 else renderer.target
    return tuple(map(float,hit))
