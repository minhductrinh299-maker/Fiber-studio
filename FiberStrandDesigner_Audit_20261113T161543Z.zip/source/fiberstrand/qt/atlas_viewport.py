"""Continuous, sparse UDIM canvas. No source evaluation or GL on preview workers."""
import math
from time import perf_counter
from collections import OrderedDict
from PySide6 import QtCore,QtGui,QtWidgets
from PIL import Image
from PIL.ImageQt import ImageQt
from ..atlas_edit_ops import transform_atlas
from ..atlas import udim_to_uv_tile,uv_tile_to_udim
from .theme import TOKENS


class AtlasViewportMixin:
    def _setup_atlas_viewport(self):
        self._atlas_ids=set();self._atlas_drag=None;self._atlas_tool='Select';self._atlas_handles=[]
        self._atlas_page_cache=OrderedDict();self._atlas_cache_bytes=0;self._atlas_pending=None
        self._atlas_tile_cache=OrderedDict();self._atlas_frozen=None;self._atlas_model_key=None;self._atlas_perf={'paint_ms':0.,'draws':0,'jobs':0}
        self._atlas_timer=QtCore.QTimer(self);self._atlas_timer.setSingleShot(True)
        self._atlas_timer.timeout.connect(self._atlas_load_visible)
        v=self.viewport
        v.pointerPressed.connect(self._atlas_press);v.pointerMoved.connect(self._atlas_move);v.pointerReleased.connect(self._atlas_release)
        v.doubleClicked.connect(self._atlas_double);v.toolActionRequested.connect(self._atlas_set_tool)
        v.cancelRequested.connect(self._atlas_cancel);v.contextRequested.connect(self._on_atlas_context_menu)
        v.interactionFinished.connect(lambda mode,cancelled:self._atlas_cancel() if cancelled else None)
        self.controller.atlasRebuilt.connect(self._atlas_updated)
        self.controller.tilesChanged.connect(self._atlas_invalidate_model)

    def _is_atlas(self):return self.mode_combo.currentText()=='Atlas Mode'
    def _atlas_current_udim(self):
        p=self.controller.atlas_layout.placements.get(self.current_tile.id) if self.current_tile else None
        return p.udim if p else 1001
    def _atlas_page(self):return self._atlas_current_udim()-1001
    def _atlas_updated(self):
        self._atlas_ids.intersection_update(self.controller.atlas_layout.placements)
        if self._is_atlas():self._request_atlas_canvas()

    def _atlas_base(self):
        v=self.viewport;side=max(32.,min(v.width()-80.,v.height()-100.))
        return (v.width()-side)/2.,(v.height()-side)/2.,side
    def _atlas_point(self,x,y):
        left,top,side=self._atlas_base();size=self.controller.atlas_layout.size
        return self.viewport._image_transform().map(QtCore.QPointF(left+x/size*side,top+y/size*side))
    def _atlas_xy(self,pos):
        p=self.viewport._image_transform().inverted()[0].map(QtCore.QPointF(pos));left,top,side=self._atlas_base()
        size=self.controller.atlas_layout.size
        return (p.x()-left)/side*size,(p.y()-top)/side*size
    def _atlas_invalidate_model(self,*args):self._atlas_model_key=None
    def _atlas_model(self):
        layout=getattr(self.controller,'atlas_layout',self.controller.atlas_layout)
        key=(id(self.controller.atlas),id(layout),id(self.controller.project),id(self.controller.project.tiles),len(self.controller.project.tiles))
        if key!=self._atlas_model_key:
            size=layout.size;self._atlas_model_key=key
            self._atlas_records_cache={tid:(udim_to_uv_tile(p.udim)[0]*size+p.x,-udim_to_uv_tile(p.udim)[1]*size+p.y,p.width,p.height,p.rotation) for tid,p in layout.placements.items()}
            self._atlas_names={tile.id:tile.name for tile in self.controller.project.tiles}
        return layout
    def _atlas_records(self):
        self._atlas_model();return dict(self._atlas_records_cache)
    def _atlas_visible(self):
        v=self.viewport
        points=[self._atlas_xy(QtCore.QPointF(x,y)) for x,y in ((0,0),(v.width(),0),(v.width(),v.height()),(0,v.height()))]
        return min(p[0] for p in points),min(p[1] for p in points),max(p[0] for p in points),max(p[1] for p in points)
    def _atlas_fit(self):
        v=self.viewport;v.fit_view();size=self.controller.atlas_layout.size
        cells=[udim_to_uv_tile(p.udim) for p in self.controller.atlas_layout.placements.values()] or [(0,0)]
        x0=min(u for u,w in cells)*size;y0=-max(w for u,w in cells)*size
        x1=(max(u for u,w in cells)+1)*size;y1=(1-min(w for u,w in cells))*size
        left,top,side=self._atlas_base()
        v._view_zoom=max(1e-8,min(max(64,v.width()-100)/((x1-x0)/size*side),max(64,v.height()-120)/((y1-y0)/size*side)))
        center=QtCore.QPointF(left+(x0+x1)/2/size*side,top+(y0+y1)/2/size*side)
        v._view_pan+=QtCore.QPointF(v.width()/2,v.height()/2)-v._image_transform().map(center)
        v.update()

    def _request_atlas_canvas(self):
        v=self.viewport;v.set_renderer_callback(None);v._map_canvas=self._paint_atlas_canvas;v._atlas_navigation=True
        if not hasattr(self,"_atlas_saved_cube"):self._atlas_saved_cube=v._show_cube
        v._show_cube=False
        v._pixmap=None;self._preview_strands=()
        project=id(self.controller.project)
        if getattr(self,'_atlas_camera_project',None)!=project:
            self._atlas_camera_project=project;self._atlas_fit()
            QtCore.QTimer.singleShot(0,lambda:self._atlas_fit() if self._is_atlas() and id(self.controller.project)==project else None)
        channel=self._atlas_channel();self.controller.request_atlas_channel(channel)
        v.set_hud_text(f'ATLAS · {channel.upper()} · MMB pan · wheel zoom · drag tile across UDIMs · F fit')
        if not self._atlas_timer.isActive():self._atlas_timer.start(0)
        v.update()
    def _atlas_channel(self):
        text=self.map_combo.currentText()
        return 'color' if text in ('lit','Live Fiber GPU','live') else text
    def _atlas_preview_key(self,channel,page):
        cache=self.controller.atlas
        versions=tuple((tid,cache._channel_versions.get((tid,channel))) for tid,p in cache.layout.placements.items() if p.page==page)
        return (id(self.controller.project),id(cache.layout),page,channel,versions)
    def _atlas_visible_pages(self):
        size=self.controller.atlas_layout.size;x0,y0,x1,y1=self._atlas_visible()
        pages=set()
        drag=self._atlas_drag
        for tid,p in self.controller.atlas_layout.placements.items():
            u,v=udim_to_uv_tile(p.udim)
            visible=u*size<=x1 and (u+1)*size>=x0 and -v*size<=y1 and (1-v)*size>=y0
            if drag and not drag.get('box') and tid in drag['current']:
                x,y,w,h,rot=drag['current'][tid]
                visible=visible or (x<=x1 and x+w>=x0 and y<=y1 and y+h>=y0)
            if visible:pages.add(p.page)
        return sorted(pages)
    def _atlas_tile_version(self,tid,channel):
        cache=self.controller.atlas;p=cache.layout.placements.get(tid)
        version=cache._channel_versions.get((tid,channel))
        return (version,p.width,p.height,p.rotation) if p is not None and version is not None else None
    def _try_gpu_atlas(self):
        import os,sys
        if sys.platform!='win32' or os.environ.get('QT_QPA_PLATFORM')=='offscreen' or os.environ.get('FSD_FIBERBAKE_BACKEND','auto')=='cpu':return False
        from ..fiberbake_x.service import request_atlas_tiles
        channel=self._atlas_channel();x0,y0,x1,y1=self._atlas_visible();requests=[]
        for tid,(x,y,w,h,rotation) in self._atlas_records().items():
            if x+w<x0 or x>x1 or y+h<y0 or y>y1:continue
            version=self.controller.atlas._channel_versions.get((tid,channel))
            if version is None:return False
            requests.append((tid,channel,version))
        if not requests:return False
        signature=(id(self.controller.project),tuple(requests))
        presenter=getattr(self,'_gpu_atlas_presenter',None)
        if presenter is not None and getattr(self,'_gpu_atlas_signature',None)==signature:
            if self.viewport._map_canvas is not None or getattr(self.viewport._renderer_callback,'__self__',None) is not presenter:
                self.viewport._map_canvas=None;self.viewport.set_renderer_callback(presenter.frame)
            return True
        future=getattr(self,'_atlas_gpu_future',None)
        if future is not None:
            if not future.done():
                if not self._atlas_timer.isActive():self._atlas_timer.start(24)
                return False
            self._atlas_gpu_future=None
            try:packets=future.result()
            except Exception:return False
            if self._atlas_gpu_pending_signature!=signature or set(packets)!={tid for tid,_,_ in requests}:
                for packet in packets.values():packet.close()
                return False
            try:
                from ..fiberbake_x.presenter import AtlasPresenter
                if presenter is None:self._gpu_atlas_presenter=presenter=AtlasPresenter(self,packets)
                else:presenter.replace_packets(packets)
                self._gpu_atlas_signature=signature;self.viewport._map_canvas=None;self.viewport.set_renderer_callback(presenter.frame);self.viewport.update();return True
            except Exception:
                for packet in packets.values():packet.close()
                return False
        self._atlas_gpu_future=request_atlas_tiles(requests);self._atlas_gpu_pending_signature=signature
        if self._atlas_gpu_future is not None and not self._atlas_timer.isActive():self._atlas_timer.start(24)
        return False

    def _atlas_load_visible(self):
        if not self._is_atlas() or self.controller._closed:return
        if self._atlas_drag is not None or self.viewport._gesture is not None:
            self._atlas_timer.start(80);return
        if self._try_gpu_atlas():return
        presenter=getattr(self,'_gpu_atlas_presenter',None)
        if presenter is not None and getattr(self.viewport._renderer_callback,'__self__',None) is presenter:
            self.viewport.set_renderer_callback(None);self.viewport._map_canvas=self._paint_atlas_canvas;self.viewport.update()
        if 'atlas_canvas_preview' in self.controller._active_jobs:return
        cache=self.controller.atlas;channel=self._atlas_channel();project=self.controller.project
        layout=self._atlas_model();x0,y0,x1,y1=self._atlas_visible();scale=self._atlas_base()[2]/layout.size*self.viewport._view_zoom
        requests=[];pixels=0
        for tid,(x,y,w,h,rot) in self._atlas_records_cache.items():
            if x+w<x0 or x>x1 or y+h<y0 or y>y1:continue
            version=self._atlas_tile_version(tid,channel);source_p=cache.layout.placements.get(tid)
            if version is None or source_p is None:continue
            source=cache._pages.get((channel,source_p.page))
            if source is None:source=getattr(cache,'_gpu_tiles',{}).get(tid)
            if source is None:continue
            extent=max(w,h)*scale;edge=next((n for n in (64,128,256,512) if n>=extent),512)
            entry=self._atlas_tile_cache.get((id(project),tid,channel))
            if entry and entry[1]==version and max(entry[0].width(),entry[0].height())>=min(edge,max(source_p.width,source_p.height)):continue
            requests.append((tid,version,source,source_p,edge));pixels+=edge*edge
            if len(requests)>=8 or pixels>=256*1024:break
        if not requests:return
        self._atlas_perf['jobs']+=1
        def worker(cancel):
            result=[]
            for tid,version,source,p,edge in requests:
                if cancel():return result
                if hasattr(source,'ensure'):
                    from ..fiberbake_x.atlas import compatibility_tile
                    image=compatibility_tile(source,p,(channel,))[channel]
                else:image=source.crop((p.x,p.y,p.x+p.width,p.y+p.height))
                image.thumbnail((edge,edge),Image.Resampling.BILINEAR)
                result.append((tid,version,ImageQt(image).copy(),p.rotation))
            return result
        def publish(result,revision):
            if project is not self.controller.project:return
            for tid,version,image,rotation in result:
                if self._atlas_tile_version(tid,channel)!=version:continue
                key=(id(project),tid,channel);previous=self._atlas_tile_cache.pop(key,None)
                if previous:self._atlas_cache_bytes-=previous[0].width()*previous[0].height()*4
                pixmap=QtGui.QPixmap.fromImage(image);self._atlas_tile_cache[key]=(pixmap,version,rotation)
                self._atlas_cache_bytes+=pixmap.width()*pixmap.height()*4
            while self._atlas_cache_bytes>64*1024**2 and self._atlas_tile_cache:
                _,old=self._atlas_tile_cache.popitem(last=False);self._atlas_cache_bytes-=old[0].width()*old[0].height()*4
            self.viewport.update()
            if not self._atlas_timer.isActive():self._atlas_timer.start(24)
        self.controller.submit_job('atlas_canvas_preview',worker,publish)

    def _paint_atlas_canvas(self,painter):
        started=perf_counter();layout=self._atlas_model();size=layout.size;channel=self._atlas_channel()
        painter.save();painter.setClipRect(self.viewport.rect());records=dict(self._atlas_records_cache);drag=self._atlas_drag
        if drag and not drag.get('box'):records.update(drag['current'])
        x0,y0,x1,y1=self._atlas_visible();left,top,side=self._atlas_base();painter.setTransform(self.viewport._image_transform(),True)
        images=self._atlas_frozen if self._atlas_frozen is not None else self._atlas_tile_cache;draws=0
        for tid,(x,y,w,h,rotation) in records.items():
            if x+w<x0 or x>x1 or y+h<y0 or y>y1:continue
            key=(id(self.controller.project),tid,channel);entry=images.get(key)
            if entry is None:continue
            pixmap,version,old_rotation=entry;draws+=1
            if images is self._atlas_tile_cache:images.move_to_end(key)
            target=QtCore.QRectF(left+x/size*side,top+y/size*side,w/size*side,h/size*side)
            delta=(rotation-old_rotation)%360.
            if abs(delta)>1e-5:
                painter.save();painter.setClipRect(target,QtCore.Qt.ClipOperation.IntersectClip);painter.translate(target.center());painter.rotate(-delta)
                painter.drawPixmap(QtCore.QRectF(-target.width()/2,-target.height()/2,target.width(),target.height()),pixmap,QtCore.QRectF(pixmap.rect()));painter.restore()
            else:painter.drawPixmap(target,pixmap,QtCore.QRectF(pixmap.rect()))
        painter.restore();self._atlas_perf.update(paint_ms=(perf_counter()-started)*1000,draws=draws)
        if not self._atlas_timer.isActive():self._atlas_timer.start(24)

    def _atlas_set_tool(self,tool):
        if self._is_atlas() and tool.title() in ('Select','Move','Rotate','Scale'):
            self._atlas_tool=tool.title();self.viewport.update()
    def _atlas_cancel(self):self._atlas_frozen=None;self._atlas_drag=None;self._atlas_pending_single=None;self.viewport.update()
    def _atlas_hit(self,ax,ay):
        records=self._atlas_records()
        return next((t.id for t in reversed(self.controller.project.tiles) if t.id in records and records[t.id][0]<=ax<=records[t.id][0]+records[t.id][2] and records[t.id][1]<=ay<=records[t.id][1]+records[t.id][3]),None)
    def _atlas_start(self,ax,ay,handle='center'):
        orig={tid:v for tid,v in self._atlas_records().items() if tid in self._atlas_ids}
        if not orig:return
        x0=min(v[0] for v in orig.values());y0=min(v[1] for v in orig.values());x1=max(v[0]+v[2] for v in orig.values());y1=max(v[1]+v[3] for v in orig.values())
        cx,cy=(x0+x1)/2,(y0+y1)/2;mode=self._atlas_tool.lower()
        if mode=='select':mode='move' # direct manipulation in Select mode
        px=x1 if 'w' in handle else x0 if 'e' in handle else cx;py=y1 if 'n' in handle else y0 if 's' in handle else cy
        if mode!='scale':px,py=cx,cy
        self._atlas_frozen=self._atlas_tile_cache.copy()
        self._atlas_drag=dict(project=self.controller.project,mode=mode,handle=handle,start_ax=ax,start_ay=ay,pivot_x=px,pivot_y=py,group_box=(x0,y0,x1,y1),start_angle=math.degrees(math.atan2(ay-py,ax-px)),orig=orig,current=dict(orig),delta_deg=0.)
    def _atlas_press(self,pos,button,mods):
        if not self._is_atlas() or button!=QtCore.Qt.MouseButton.LeftButton.value:return
        ax,ay=self._atlas_xy(pos);shift=bool(mods & QtCore.Qt.KeyboardModifier.ShiftModifier.value);ctrl=bool(mods & QtCore.Qt.KeyboardModifier.ControlModifier.value)
        for name,point in self._atlas_handles:
            if (pos-point).manhattanLength()<12 and self._atlas_tool in ('Scale','Rotate'):self._atlas_start(ax,ay,name);return
        tid=self._atlas_hit(ax,ay)
        if tid:
            if ctrl:self._atlas_ids.symmetric_difference_update({tid})
            elif shift:self._atlas_ids.add(tid)
            elif tid not in self._atlas_ids:self._atlas_ids={tid}
            self._atlas_pending_single=tid if not shift and not ctrl else None
            if tid in self._atlas_ids:
                self.current_tile=self.controller.project.find(tid);self.controller.set_active_tile(tid);self._atlas_start(ax,ay)
        else:
            if not shift and not ctrl:self._atlas_ids=set()
            self._atlas_drag=dict(project=self.controller.project,box=True,start=(ax,ay),end=(ax,ay),orig=set(self._atlas_ids),ctrl=ctrl,shift=shift)
        self.viewport.update()
    def _atlas_move(self,pos,mods):
        d=self._atlas_drag
        if not self._is_atlas() or not d:return
        ax,ay=self._atlas_xy(pos)
        if d.get('box'):d['end']=(ax,ay)
        else:
            if abs(ax-d['start_ax'])+abs(ay-d['start_ay'])<2:return
            self._atlas_pending_single=None
            shift=bool(mods & QtCore.Qt.KeyboardModifier.ShiftModifier.value)
            transform_atlas(d,ax,ay,shift,self.controller.atlas_layout.size,self.controller.atlas_layout.gutter,32 if shift else 0,free_space=True)
        self.viewport.update()
    def _atlas_release(self,pos,button,mods):
        if not self._is_atlas() or button!=QtCore.Qt.MouseButton.LeftButton.value:return
        d=self._atlas_drag;self._atlas_drag=None;self._atlas_frozen=None
        if d and d.get("project") is not self.controller.project:return
        if d and d.get('box'):
            x0,x1=sorted((d['start'][0],d['end'][0]));y0,y1=sorted((d['start'][1],d['end'][1]))
            hits={tid for tid,(x,y,w,h,rot) in self._atlas_records().items() if not(x+w<x0 or x>x1 or y+h<y0 or y>y1)}
            self._atlas_ids=d['orig']-hits if d['ctrl'] else d['orig']|hits if d['shift'] else hits
        elif d and d['current']!=d['orig']:
            size=self.controller.atlas_layout.size;pad=self.controller.atlas_layout.gutter
            metadata=dict(self.controller.project.metadata);placements=dict(metadata.get('tile_placements',{}))
            for tid,(x,y,w,h,rot) in d['current'].items():
                # Persist one complete tile per UDIM; choose by the tile center.
                u=max(0,min(9,math.floor((x+w/2)/size)));v=max(0,math.floor(1-(y+h/2)/size))
                udim=uv_tile_to_udim(u,v)
                lx=max(pad,min(size-w-pad,round(x-u*size)));ly=max(pad,min(size-h-pad,round(y+v*size)))
                placements[tid]=dict(udim=udim,page=udim-1001,x=lx,y=ly,width=w,height=h,rotation=rot%360.)
            if any(metadata.get('tile_placements',{}).get(tid)!=placements[tid] for tid in d['current']):
                self.controller.snapshot_layout();metadata['tile_placements']=placements;self.controller.project.metadata=metadata
                self.controller.relayout_atlas();self.controller.ensure_atlas();self.controller.mark_dirty(True)
        elif getattr(self,'_atlas_pending_single',None):self._atlas_ids={self._atlas_pending_single}
        self._atlas_pending_single=None;self.viewport.update()
    def _atlas_double(self,pos):
        if not self._is_atlas():return
        tid=self._atlas_hit(*self._atlas_xy(pos))
        if tid:self.current_tile=self.controller.project.find(tid);self.controller.set_active_tile(tid);self.mode_combo.setCurrentText('Tile Mode')
    def _on_atlas_context_menu(self,global_pos):
        if not self._is_atlas():return
        menu=QtWidgets.QMenu(self);menu.addAction('Fit all UDIMs',self._atlas_fit)
        menu.addAction('Auto Pack all UDIMs',lambda:self.controller.auto_pack_udim(None))
        for name in ('Select','Move','Rotate','Scale'):menu.addAction(name,lambda name=name:self._atlas_set_tool(name))
        menu.exec(global_pos)

    def _paint_atlas_overlay(self,painter):
        if not self._is_atlas():return
        size=self.controller.atlas_layout.size;x0,y0,x1,y1=self._atlas_visible();d=self._atlas_drag
        transform=self.viewport._image_transform();left,top,side=self._atlas_base();unit=side/size
        def map_point(x,y):return transform.map(QtCore.QPointF(left+x*unit,top+y*unit))
        painter.save();painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing,False)
        minor=QtGui.QColor(TOKENS['border']);major=QtGui.QColor(TOKENS['text_muted']);accent=QtGui.QColor(TOKENS['text_muted'])
        # Standard UDIM: ten columns, positive V upwards. Only visible grid is drawn.
        delta=map_point(size,0)-map_point(0,0)
        spacing=max(1e-12,math.hypot(delta.x(),delta.y()))
        v0=max(0,math.floor(1-y1/size));v1=max(v0,math.ceil(1-y0/size))
        stride=max(1,math.ceil(16/spacing));label_stride=max(1,math.ceil(60/spacing))
        painter.setPen(QtGui.QPen(minor,1))
        for u in range(11):painter.drawLine(map_point(u*size,min(0,y0)),map_point(u*size,min(size,y1)))
        for v in range(v0//stride*stride,v1+1,stride):painter.drawLine(map_point(0,(1-v)*size),map_point(10*size,(1-v)*size))
        font=painter.font();font.setPointSize(8);font.setBold(False);painter.setFont(font)
        for v in range(v0//label_stride*label_stride,v1+1,label_stride):
            for u in range(max(0,math.floor(x0/size)),min(9,math.floor(x1/size))+1):
                point=map_point(u*size,-v*size)
                painter.setPen(major);painter.drawText(point+QtCore.QPointF(6,14),str(uv_tile_to_udim(u,v)))
                if spacing>180 and getattr(self,'chk_grid',None) and self.chk_grid.isChecked():
                    painter.setPen(QtGui.QPen(minor,1,QtCore.Qt.PenStyle.DotLine))
                    for i in range(1,4):
                        painter.drawLine(map_point((u+i/4)*size,-v*size),map_point((u+i/4)*size,(1-v)*size))
                        painter.drawLine(map_point(u*size,(-v+i/4)*size),map_point((u+1)*size,(-v+i/4)*size))
        # Coordinate axes cross at UV (0,0), the lower left of UDIM 1001.
        painter.setPen(QtGui.QPen(accent,1.2));painter.drawLine(map_point(min(0,x0),size),map_point(max(10*size,x1),size));painter.drawLine(map_point(0,max(size,y1)),map_point(0,min(0,y0)))
        painter.setPen(major)
        for u in range(1,11):painter.drawText(map_point(u*size,size)+QtCore.QPointF(4,16),str(u))
        for v in range(max(1,v0)//label_stride*label_stride,v1+1,label_stride):
            if v>0:painter.drawText(map_point(0,(1-v)*size)+QtCore.QPointF(-22,-4),str(v))
        origin=map_point(0,size);painter.drawText(origin+QtCore.QPointF(5,18),'0,0')
        painter.drawText(map_point(min(10*size,x1),size)+QtCore.QPointF(-18,-6),'U');painter.drawText(map_point(0,min(0,y0))+QtCore.QPointF(6,14),'V')
        records=self._atlas_records()
        if d and not d.get('box'):records.update(d['current'])
        self._atlas_handles=[];selected=[];ordinary=[];highlight=[]
        for tid,(x,y,w,h,rot) in records.items():
            is_selected=tid in self._atlas_ids
            if is_selected:selected.append((x,y,w,h))
            if x+w<x0 or x>x1 or y+h<y0 or y>y1:continue
            if not is_selected and not self.chk_bounds.isChecked():continue
            rectangle=QtCore.QRectF(left+x*unit,top+y*unit,w*unit,h*unit)
            (highlight if is_selected else ordinary).append(rectangle)
        painter.save();painter.setTransform(transform,True);painter.setBrush(QtCore.Qt.BrushStyle.NoBrush)
        for rectangles,color,width in ((ordinary,TOKENS['cyan'],1),(highlight,TOKENS['gold'],2)):
            if rectangles:
                pen=QtGui.QPen(QtGui.QColor(color),width);pen.setCosmetic(True);painter.setPen(pen);painter.drawRects(rectangles)
        painter.restore()
        if selected:
            a=min(p[0] for p in selected);b=min(p[1] for p in selected);c=max(p[0]+p[2] for p in selected);e=max(p[1]+p[3] for p in selected)
            painter.setPen(QtGui.QPen(QtGui.QColor(TOKENS['gold']),1));painter.setBrush(QtGui.QColor(TOKENS['gold']))
            if self._atlas_tool=='Scale':
                for name,x,y in [('nw',a,b),('n',(a+c)/2,b),('ne',c,b),('e',c,(b+e)/2),('se',c,e),('s',(a+c)/2,e),('sw',a,e),('w',a,(b+e)/2)]:
                    p=map_point(x,y);self._atlas_handles.append((name,p));painter.drawRect(QtCore.QRectF(p.x()-4,p.y()-4,8,8))
            elif self._atlas_tool=='Rotate':
                p=map_point((a+c)/2,b)+QtCore.QPointF(0,-28);self._atlas_handles.append(('center',p));painter.drawEllipse(p,6,6)
        if d and d.get('box'):
            painter.setPen(QtGui.QPen(accent,1,QtCore.Qt.PenStyle.DashLine));painter.setBrush(QtCore.Qt.BrushStyle.NoBrush)
            painter.drawRect(QtCore.QRectF(map_point(*d['start']),map_point(*d['end'])).normalized())
        painter.restore()
