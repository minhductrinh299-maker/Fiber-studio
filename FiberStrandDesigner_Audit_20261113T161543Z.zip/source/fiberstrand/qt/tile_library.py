"""Tile source IDs for Library → Graph drag/drop; no rendered data in MIME."""
from PySide6 import QtCore,QtWidgets

TILE_MIME='application/x-fsd-tile-id'

class TileLibraryList(QtWidgets.QListWidget):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.setDragEnabled(True)
        self.setDragDropMode(QtWidgets.QAbstractItemView.DragDropMode.DragOnly)
    def mimeTypes(self):return [TILE_MIME]
    def mimeData(self,items):
        data=QtCore.QMimeData()
        if items:
            tile_id=items[0].data(QtCore.Qt.ItemDataRole.UserRole)
            if tile_id:data.setData(TILE_MIME,str(tile_id).encode('utf-8'))
        return data
    def supportedDropActions(self):return QtCore.Qt.DropAction.CopyAction
