"""Data model and presets for Fiber Strand Designer.

Project data is JSON serializable and does not hold transient raster buffers.
Coordinates of fiber geometry are tile-local normalized [0, 1].
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from copy import deepcopy
import hashlib
import json
import uuid
from typing import Any

VERSION = "1.9.0-dev-unified-kernel-v1"
MAP_NAMES = ("color", "alpha", "normal", "flow", "depth", "ao", "id", "roughness", "rgb_mask")
EXTRA_MAP_NAMES = ("specular", "anisotropy", "transmission", "scatter", "iridescence", "cluster_id", "material_id", "material_mask")
KINDS = ("fur", "hair", "feather", "fuzz", "stylized")
PATTERNS = ("solid", "banded", "agouti", "speckle", "ombre")


def stable_int(*components: object) -> int:
    """Stable 64 bit seed. Never use built-in hash(), which is process-salted."""
    payload = ":".join(str(x) for x in components).encode("utf-8")
    return int.from_bytes(hashlib.blake2b(payload, digest_size=8).digest(), "little")


def clamp_float(value: Any, lo: float, hi: float) -> float:
    return min(hi, max(lo, float(value)))


@dataclass
class FiberSettings:
    bake_samples: int = 1
    ao_mode: str = "proximity"
    count: int = 360
    length: float = .67
    length_variation: float = .30
    root_width: float = 2.8  # reference px at 512 px tile width
    width_variation: float = .30
    taper: float = 1.25
    tip_width: float = .035
    width_profile: list[float] = field(default_factory=lambda:[1.0]*5)  # 5 multiplier knots root->tip
    mid_bulge: float = .10
    root_spread: float = .90
    root_angle: float = .0
    bend: float = .16
    curl: float = .03
    curl_frequency: float = 1.6
    twist: float = .0
    frizz: float = .05
    frizz_frequency: float = 7.0
    sag: float = .02
    macro_clumps: int = 10
    micro_clumps: int = 42
    clump_attraction: float = .36
    clump_tip: float = .35
    flyaway: float = .085
    guard_ratio: float = .24
    guard_length: float = 1.30
    guard_width: float = 1.24
    color_root: str = "#44372e"
    color_mid: str = "#a98d6f"
    color_tip: str = "#dfc9a6"
    hue_variation: float = .055
    value_variation: float = .18
    saturation_variation: float = .09
    pattern: str = "solid"
    band_count: int = 4
    band_strength: float = .50
    speckle: float = .25
    roughness: float = .62
    specular: float = .5
    anisotropy: float = .8
    transmission: float = .25
    scatter: float = .2
    iridescence: float = .0
    fiber_roundness: float = .65
    strand_opacity: float = 1.0
    feather_width: float = .55
    feather_asymmetry: float = .10
    feather_barbules: int = 0
    antialias: float = 1.0

    def sanitize(self) -> "FiberSettings":
        try:self.bake_samples=min((1,4,9,16),key=lambda n:abs(n-int(self.bake_samples)))
        except (ValueError,TypeError,OverflowError):self.bake_samples=1
        if self.ao_mode not in ('proximity','geometry'):self.ao_mode='proximity'
        self.count = max(1, min(120000, int(self.count)))
        self.macro_clumps = max(1, min(10000, int(self.macro_clumps)))
        self.micro_clumps = max(1, min(30000, int(self.micro_clumps)))
        self.band_count = max(1, min(20, int(self.band_count)))
        self.feather_barbules = max(0, min(8, int(self.feather_barbules)))
        bounds = {
            "length": (.03, .96), "length_variation": (0, 1),
            "root_width": (.15, 35), "width_variation": (0, 1.5),
            "taper": (.15, 8), "tip_width": (0, 1), "mid_bulge": (-.7, 2),
            "root_spread": (.05, 1), "root_angle": (-1.5, 1.5),
            "bend": (-1.5, 1.5), "curl": (0, .7),
            "curl_frequency": (.1, 14), "twist": (-1, 1),
            "frizz": (0, .7), "frizz_frequency": (1, 50), "sag": (-.5, .5),
            "clump_attraction": (0, 1), "clump_tip": (0, 1),
            "flyaway": (0, 1), "guard_ratio": (0, 1),
            "guard_length": (.5, 3), "guard_width": (.4, 3),
            "hue_variation": (0, .5), "value_variation": (0, 1),
            "saturation_variation": (0, 1), "band_strength": (0, 1),
            "speckle": (0, 1), "roughness": (0, 1),
            "specular": (0, 1), "anisotropy": (0, 1), "transmission": (0, 1),
            "scatter": (0, 1), "iridescence": (0, 1),
            "fiber_roundness": (0, 1), "strand_opacity": (0, 1),
            "feather_width": (.1, .95), "feather_asymmetry": (-.8, .8),
            "antialias": (.3, 3),
        }
        for key, (lo, hi) in bounds.items():
            setattr(self, key, clamp_float(getattr(self, key), lo, hi))
        if not isinstance(self.width_profile,(list,tuple)) or len(self.width_profile)!=5:
            self.width_profile=[1.0]*5
        self.width_profile=[clamp_float(v,.05,3.0) for v in self.width_profile]
        if self.pattern not in PATTERNS:
            self.pattern = "solid"
        for key in ("color_root", "color_mid", "color_tip"):
            value = getattr(self, key)
            if not isinstance(value, str) or len(value) != 7 or not value.startswith("#"):
                setattr(self, key, "#b09a81")
            else:
                try: int(value[1:], 16)
                except ValueError: setattr(self, key, "#b09a81")
        return self


PRESETS: dict[str, dict[str, Any]] = {
    "Soft Cat Undercoat": dict(kind="fur", count=650, length=.43, length_variation=.34,
                               root_width=2.2, root_spread=.95, clump_attraction=.19,
                               guard_ratio=.07, flyaway=.06, bend=.12, frizz=.07,
                               color_root="#4e4235", color_mid="#bca991", color_tip="#e9d8be"),
    "Cat Guard Fur": dict(kind="fur", count=320, length=.73, root_width=2.6,
                          guard_ratio=.50, guard_length=1.45, clump_attraction=.32,
                          bend=.22, flyaway=.13, color_root="#4c3c32",
                          color_mid="#a67c57", color_tip="#edcda7"),
    "Brown Wavy Hair": dict(kind="hair", count=260, length=.87, root_width=4.0,
                            macro_clumps=9, micro_clumps=26, clump_attraction=.65,
                            curl=.16, curl_frequency=2.6, frizz=.035,
                            color_root="#241810", color_mid="#63402b", color_tip="#9f7952"),
    "Curly Hair": dict(kind="hair", count=360, length=.76, root_width=3.0,
                       macro_clumps=12, clump_attraction=.72, curl=.24,
                       curl_frequency=5.0, frizz=.10, bend=.08,
                       color_root="#271d1b", color_mid="#6b4435", color_tip="#9e725a"),
    "Bird Feather": dict(kind="feather", count=540, length=.79, root_width=3.4,
                         feather_width=.66, band_count=5, pattern="banded",
                         band_strength=.55, color_root="#40392d",
                         color_mid="#b18f5b", color_tip="#e0c68b"),
    "Clothing Fuzz": dict(kind="fuzz", count=850, length=.18, root_width=1.6,
                          length_variation=.55, clump_attraction=.06, frizz=.19,
                          guard_ratio=.03, color_root="#686269",
                          color_mid="#a7a2a9", color_tip="#e1dee4"),
    "Stylized Golden Tuft": dict(kind="stylized", count=110, length=.76,
                                  root_width=7.5, taper=.72, clump_attraction=.83,
                                  macro_clumps=5, micro_clumps=14, bend=.20,
                                  color_root="#753e21", color_mid="#e79e3f",
                                  color_tip="#ffe4a2", flyaway=.045),
    "Agouti Fur": dict(kind="fur", count=490, length=.66, root_width=2.65,
                       pattern="agouti", band_count=5, band_strength=.65,
                       color_root="#3c3228", color_mid="#bdad88", color_tip="#e4d2a4"),
}


@dataclass
class Tile:
    id: str
    name: str
    kind: str = "fur"
    width: int = 384
    height: int = 512
    seed: int = 42
    settings: FiberSettings = field(default_factory=FiberSettings)
    overrides: dict[str, dict[str, Any]] = field(default_factory=dict)
    construction_graph: dict[str, Any] | None = None
    revision: int = 0

    @classmethod
    def create(cls, name: str, preset: str = "Soft Cat Undercoat") -> "Tile":
        t = cls(id=uuid.uuid4().hex[:12], name=name)
        t.apply_preset(preset)
        return t

    def apply_preset(self, preset: str) -> None:
        desc = PRESETS[preset]
        self.kind = desc.get("kind", "fur")
        self.settings = FiberSettings()
        for key, value in desc.items():
            if key != "kind" and hasattr(self.settings, key):
                setattr(self.settings, key, value)
        self.settings.sanitize()
        self.revision += 1

    def clone(self) -> "Tile":
        new = deepcopy(self)
        new.id = uuid.uuid4().hex[:12]
        new.name = self.name + " Copy"
        new.revision = 0
        return new

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Tile":
        src = {k: v for k, v in data.items() if k in {"id", "name", "kind", "width", "height", "seed", "overrides", "construction_graph", "revision"}}
        s = {k: v for k, v in data.get("settings", {}).items() if k in FiberSettings.__dataclass_fields__}
        tile = cls(**src, settings=FiberSettings(**s).sanitize())
        tile.width = max(64, min(4096, int(tile.width)))
        tile.height = max(64, min(4096, int(tile.height)))
        tile.kind = tile.kind if tile.kind in KINDS else "fur"
        return tile


@dataclass
class Project:
    name: str = "Untitled Fiber Project"
    tiles: list[Tile] = field(default_factory=list)
    atlas_size: int = 2048
    padding: int = 8
    metadata: dict[str, Any] = field(default_factory=dict)
    cards: list[dict[str, Any]] = field(default_factory=list)
    objects: list[dict[str, Any]] = field(default_factory=list)
    kernel_data: dict[str,Any] = field(default_factory=lambda:dict(schema=1,revision=0,records={}))

    @classmethod
    def sample(cls) -> "Project":
        project = cls("Cat Fur Starter")
        project.tiles = [Tile.create("01 · Undercoat", "Soft Cat Undercoat"),
                         Tile.create("02 · Guard Fur", "Cat Guard Fur"),
                         Tile.create("03 · Agouti", "Agouti Fur")]
        from .cards import HairCard
        for i in range(7):
            card=HairCard.create(project.tiles[min(i//3,2)].id,f"Card {i+1:03d}",[(i-3)*.27,0,(i%3)*-.025])
            card.length=.85+(i%3)*.16
            card.width=.18+(i%2)*.045
            card.bend=(i-3)*.035
            card.yaw=(i-3)*.045
            project.cards.append(card.to_dict())
        return project

    def to_dict(self) -> dict[str, Any]:
        return {"format": "fiber-strand-designer", "format_version": 1,
                "app_version": VERSION, "name": self.name,
                "atlas_size": self.atlas_size, "padding": self.padding,
                "metadata": self.metadata, "tiles": [t.to_dict() for t in self.tiles], "cards": self.cards,
                "objects":self.objects,"kernel_data":self.kernel_data}

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Project":
        if d.get("format") != "fiber-strand-designer":
            raise ValueError("Not a Fiber Strand Designer project")
        if d.get("format_version") != 1:
            raise ValueError("Unsupported project format version")
        p = cls(name=str(d.get("name", "Untitled")),
                atlas_size=max(512, min(8192, int(d.get("atlas_size", 2048)))),
                padding=max(2, min(64, int(d.get("padding", 8)))),
                metadata=d.get("metadata", {}),
                tiles=[Tile.from_dict(x) for x in d.get("tiles", [])],
                cards=list(d.get("cards", [])),objects=list(d.get('objects',[])),
                kernel_data=d.get('kernel_data',dict(schema=1,revision=0,records={})))
        from .kernel.registry import Registry
        Registry(p.kernel_data)
        for items,label in ((p.cards,'card'),(p.objects,'object')):
            keys=[item['id'] for item in items]
            if len(keys)!=len(set(keys)):raise ValueError('Duplicate '+label+' IDs')
        ids = [t.id for t in p.tiles]
        if len(ids) != len(set(ids)):
            raise ValueError("Duplicate tile ids")
        return p

    def __deepcopy__(self,memo):
        # Runtime kernels, locks, workers and windows are never project source.
        result=Project.from_dict(deepcopy(self.to_dict(),memo));memo[id(self)]=result
        return result

    def find(self, tile_id: str) -> Tile | None:
        return next((tile for tile in self.tiles if tile.id == tile_id), None)

    def digest(self) -> str:
        return hashlib.sha256(json.dumps(self.to_dict(),sort_keys=True).encode()).hexdigest()
