"""Atomic, versioned project persistence; project files contain source data.
Cache renders deliberately excluded to keep projects small and reproducible.
"""
from __future__ import annotations
from pathlib import Path
import json
import os
import tempfile
import zipfile
import hashlib
import re
from .model import Project


def save_project(project:Project,filename:str|Path) -> Path:
    from .kernel.scene import kernel
    kernel(project).synchronize()
    path=Path(filename)
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,temp_path=tempfile.mkstemp(prefix=".fsd_",suffix=".tmp",dir=path.parent)
    os.close(fd)
    try:
        with zipfile.ZipFile(temp_path,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            payload=project.to_dict();objects=[];written=set();packed_bytes=0
            # Render settings are source data. Pack HDRI by content hash, without
            # mutating the live material path or project metadata dictionary.
            render=project.metadata.get('rendercore',{})
            environment=render.get('material',{}).get('environment_path','')
            if environment:
                source=Path(environment)
                if not source.is_file():raise ValueError('Environment missing; relink HDRI before saving: '+str(source))
                if source.stat().st_size>128*1024**2:raise ValueError('Environment exceeds 128 MiB packing budget')
                content=source.read_bytes();digest=hashlib.sha256(content).hexdigest()
                suffix=source.suffix.lower()
                if suffix not in ('.hdr','.png','.jpg','.jpeg','.tif','.tiff'):raise ValueError('Unsupported environment file type')
                name='assets/environments/'+digest+suffix
                z.writestr(name,content);written.add(name);packed_bytes+=len(content)
                packed_render={**render,'material':{**render['material'],'environment_path':'fsd-asset:'+name},
                               'environment_asset_id':digest}
                payload['metadata']={**project.metadata,'rendercore':packed_render}
            for record in project.objects:
                material=record.get('material',{});maps={}
                for channel,filename in material.get('maps',{}).items():
                    texture=Path(filename)
                    if texture.is_file():
                        if texture.stat().st_size>128*1024**2:raise ValueError('Texture exceeds 128 MiB packing budget')
                        content=texture.read_bytes();digest=hashlib.sha256(content).hexdigest()
                        suffix=texture.suffix.lower() if re.fullmatch(r'\.[a-z0-9]{1,8}',texture.suffix.lower()) else '.bin'
                        name='assets/textures/'+digest+suffix
                        if name not in written:
                            packed_bytes+=len(content)
                            if packed_bytes>512*1024**2:raise ValueError('Packed textures exceed 512 MiB budget')
                            z.writestr(name,content);written.add(name)
                        maps[channel]='fsd-asset:'+name
                    else:maps[channel]=filename
                packed={**record,'material':{**material,'maps':maps}}
                animation=record.get('animation_source')
                if animation:
                    source=Path(animation)
                    if not source.is_file():raise ValueError('Animation source is missing; relink FBX before saving: '+str(source))
                    if source.stat().st_size>512*1024**2:raise ValueError('Animation source exceeds 512 MiB budget')
                    content=source.read_bytes();name='assets/animation/'+hashlib.sha256(content).hexdigest()+'.fbx'
                    if name not in written:
                        packed_bytes+=len(content)
                        if packed_bytes>1024*1024**2:raise ValueError('Packed source assets exceed 1 GiB budget')
                        z.writestr(name,content);written.add(name)
                    packed['animation_source']='fsd-asset:'+name
                objects.append(packed)
            payload['objects']=objects
            data=json.dumps(payload,ensure_ascii=False,sort_keys=True,indent=2)
            z.writestr("project.json",data)
            z.writestr("README.txt","Fiber Strand Designer source project; edit using the application.\n")
        os.replace(temp_path,path)
    finally:
        if os.path.exists(temp_path): os.remove(temp_path)
    return path


def load_project(filename:str|Path) -> Project:
    with zipfile.ZipFile(filename,"r") as z:
        if z.getinfo('project.json').file_size>512*1024**2:raise ValueError('Project JSON exceeds 512 MiB budget')
        data=json.loads(z.read("project.json").decode("utf-8"))
        total=0;resolved={}
        render=data.get('metadata',{}).get('rendercore',{})
        environment=render.get('material',{}).get('environment_path','')
        if environment.startswith('fsd-asset:'):
            name=environment[len('fsd-asset:'):]
            if not re.fullmatch(r'assets/environments/[0-9a-f]{64}\.(hdr|png|jpg|jpeg|tif|tiff)',name):raise ValueError('Invalid packed environment path')
            info=z.getinfo(name);total+=info.file_size
            if info.file_size>128*1024**2:raise ValueError('Environment asset budget exceeded')
            content=z.read(name)
            if hashlib.sha256(content).hexdigest()!=Path(name).stem:raise ValueError('Environment checksum mismatch')
            folder=Path(tempfile.gettempdir())/'FSD_Environment_Assets';folder.mkdir(parents=True,exist_ok=True)
            target=folder/Path(name).name
            if not target.is_file() or hashlib.sha256(target.read_bytes()).hexdigest()!=Path(name).stem:target.write_bytes(content)
            render['material']['environment_path']=str(target)
        for record in data.get('objects',[]):
            animation=record.get('animation_source','')
            if animation.startswith('fsd-asset:'):
                name=animation[len('fsd-asset:'):]
                if not re.fullmatch(r'assets/animation/[0-9a-f]{64}\.fbx',name):raise ValueError('Invalid packed animation path')
                if name not in resolved:
                    info=z.getinfo(name);total+=info.file_size
                    if info.file_size>512*1024**2 or total>1024*1024**2:raise ValueError('Animation asset budget exceeded')
                    content=z.read(name)
                    if hashlib.sha256(content).hexdigest()!=Path(name).stem:raise ValueError('Animation checksum mismatch')
                    folder=Path(tempfile.gettempdir())/'FSD_Imported_Animation';folder.mkdir(parents=True,exist_ok=True)
                    target=folder/Path(name).name
                    if not target.is_file() or hashlib.sha256(target.read_bytes()).hexdigest()!=Path(name).stem:target.write_bytes(content)
                    resolved[name]=str(target)
                record['animation_source']=resolved[name]
            maps=record.get('material',{}).get('maps',{})
            for channel,path in list(maps.items()):
                if not str(path).startswith('fsd-asset:'):continue
                name=path[len('fsd-asset:'):]
                if not re.fullmatch(r'assets/textures/[0-9a-f]{64}\.[a-z0-9]{1,8}',name):raise ValueError('Invalid packed texture path')
                if name in resolved:maps[channel]=resolved[name];continue
                info=z.getinfo(name);total+=info.file_size
                if info.file_size>128*1024**2 or total>1024*1024**2:raise ValueError('Packed asset budget exceeded')
                content=z.read(name)
                if hashlib.sha256(content).hexdigest()!=Path(name).stem:raise ValueError('Packed texture checksum mismatch')
                folder=Path(tempfile.gettempdir())/'FSD_Imported_Textures';folder.mkdir(parents=True,exist_ok=True)
                target=folder/Path(name).name
                if not target.is_file() or hashlib.sha256(target.read_bytes()).digest()!=hashlib.sha256(content).digest():
                    target.write_bytes(content)
                maps[channel]=str(target)
                resolved[name]=str(target)
    project=Project.from_dict(data)
    from .kernel.scene import kernel
    kernel(project).synchronize()
    return project
