"""Independent ufbx reader through the bundled x64 C ABI (no Blender/Python ABI).

Only loaded when FBX is requested. Native pointers are copied while the scene
handle is alive; no numpy view or native pointer escapes the finally/free block.
"""
import ctypes as C
import hashlib
import os
from pathlib import Path
import sys
import tempfile
import numpy as np

CHANNELS=('color','normal','roughness','alpha','specular','metallic','ao','emission')


class MeshView(C.Structure):
    _fields_=[('name',C.c_char_p),('data',C.POINTER(C.c_float)),('corners',C.c_uint64),
              ('color',C.c_float*3),('roughness',C.c_float),('paths',C.c_char_p*8),
              ('content',C.c_void_p*8),('sizes',C.c_uint64*8),('flags',C.c_uint32)]


def _library():
    if sys.platform!='win32' or C.sizeof(C.c_void_p)!=8:
        raise RuntimeError('Bundled FBX reader currently requires 64-bit Windows Python')
    path=Path(__file__).parent/'native'/'fsd_fbx.dll'
    if not path.is_file():
        raise RuntimeError('Missing bundled fsd_fbx.dll. Restore the source package DLL or rebuild with native_fbx/build_windows.bat. Blender is not required.')
    directory=os.add_dll_directory(str(path.parent)) if hasattr(os,'add_dll_directory') else None
    try:
        try:lib=C.CDLL(str(path))
        except OSError as error:raise RuntimeError(f'Could not load bundled FBX reader: {error}') from error
    finally:
        if directory:directory.close()
    signatures={
        'fsd_fbx_abi':(C.c_uint32,[]),
        'fsd_fbx_library_version':(C.c_uint32,[]),
        'fsd_fbx_load':(C.c_void_p,[C.c_char_p,C.c_uint64,C.c_void_p,C.c_uint64]),
        'fsd_fbx_mesh_count':(C.c_uint64,[C.c_void_p]),
        'fsd_fbx_mesh':(C.c_int,[C.c_void_p,C.c_uint64,C.POINTER(MeshView)]),
        'fsd_fbx_free':(None,[C.c_void_p])}
    for name,(result,args) in signatures.items():
        fn=getattr(lib,name);fn.restype=result;fn.argtypes=args
    if lib.fsd_fbx_abi()!=1:raise RuntimeError('FBX reader ABI mismatch; restore matching reader DLL/source')
    return lib


def _texture_path(source,raw):
    raw=Path(raw.replace('\\','/'))
    candidates=[raw] if raw.is_absolute() else []
    candidates.extend((source.parent/raw,source.parent/raw.name,source.with_suffix('.fbm')/raw.name))
    return str(next((p for p in candidates if p.is_file()),source.parent/raw).resolve())


def read_fbx(filename,max_triangles=1000000):
    source=Path(filename).resolve()
    if not 0<max_triangles<=1000000:raise ValueError('Invalid FBX triangle budget')
    if source.stat().st_size>512*1024**2:raise ValueError('FBX exceeds 512 MiB input budget')
    lib=_library();error=C.create_string_buffer(4096)
    handle=lib.fsd_fbx_load(str(source).encode('utf-8'),max_triangles,error,len(error))
    if not handle:raise ValueError('FBX: '+error.value.decode('utf-8',errors='replace'))
    try:
        count=lib.fsd_fbx_mesh_count(handle)
        if not 0<count<=4096:raise ValueError('FBX mesh/material part count outside supported budget')
        records=[];total=0;embedded_bytes=0;extracted={}
        for index in range(count):
            view=MeshView()
            if not lib.fsd_fbx_mesh(handle,index,C.byref(view)):raise ValueError('Failed to read FBX mesh part')
            corners=int(view.corners)
            if not corners or corners%3 or corners>max_triangles*3:raise ValueError('Invalid FBX triangle buffer')
            total+=corners//3
            if total>max_triangles:raise ValueError('FBX exceeds triangle budget')
            data=np.ctypeslib.as_array(view.data,shape=(corners*8,)).reshape(-1,8).copy()
            if not np.isfinite(data).all():raise ValueError('FBX contains nonfinite vertex data')
            maps={};notes=[]
            for slot,channel in enumerate(CHANNELS):
                raw=(view.paths[slot] or b'').decode('utf-8',errors='replace')
                size=int(view.sizes[slot]);pointer=view.content[slot]
                if size and pointer:
                    key=(pointer,size)
                    if key not in extracted:
                        embedded_bytes+=size
                        if size>128*1024**2 or embedded_bytes>256*1024**2:raise ValueError('FBX embedded texture budget exceeded')
                        content=C.string_at(pointer,size);digest=hashlib.sha256(content).hexdigest()
                        suffix=Path(raw.replace('\\','/')).suffix.lower()
                        if suffix not in ('.png','.jpg','.jpeg','.tif','.tiff','.tga','.bmp','.dds','.webp','.exr'):suffix='.bin'
                        folder=Path(tempfile.gettempdir())/'FSD_FBX_Embedded';folder.mkdir(parents=True,exist_ok=True)
                        path=folder/(digest+suffix)
                        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=digest:path.write_bytes(content)
                        extracted[key]=str(path)
                    maps[channel]=extracted[key]
                elif raw:maps[channel]=_texture_path(source,raw)
            if view.flags&1:notes.append('Layered/procedural material simplified to first file texture')
            if view.flags&2:notes.append('Material UV transforms/custom UV selection are not reconstructed; first mesh UV set used')
            if view.flags&4:notes.append('Scalar material opacity not reconstructed; model viewport uses alpha texture cutout')
            if view.flags&8:notes.append('Imported rest mesh; enable FBX Animation in Outliner for skin/blend-shape playback')
            color=np.asarray(view.color,dtype=float)
            rough=float(view.roughness)
            if not np.isfinite(color).all() or not np.isfinite(rough):raise ValueError('Nonfinite FBX material')
            # Native pointers are fully copied before Scene is freed below.
            records.append(dict(name=(view.name or b'Mesh').decode('utf-8',errors='replace'),
                source=str(source),vertices=data[:,:3].tolist(),normals=data[:,3:6].tolist(),uv=data[:,6:8].tolist(),
                triangles=np.arange(corners,dtype=np.int32).reshape(-1,3).tolist(),
                material=dict(color=np.clip(color,0,1).tolist(),roughness=float(np.clip(rough,.03,1)),maps=maps),
                import_backend='ufbx-0.23.1-native',source_part=index,warnings=notes))
        return records
    finally:
        lib.fsd_fbx_free(handle)


class AnimationSession:
    """Worker-owned persistent source scene; each evaluated frame is released."""
    def __init__(self,filename):
        self.lib=_library();error=C.create_string_buffer(4096)
        self.handle=self.lib.fsd_fbx_load(str(Path(filename).resolve()).encode(),1000000,error,len(error))
        if not self.handle:raise ValueError(error.value.decode(errors='replace'))
        self.lib.fsd_fbx_evaluate.restype=C.c_void_p
        self.lib.fsd_fbx_evaluate.argtypes=[C.c_void_p,C.c_double,C.c_uint64,C.c_void_p,C.c_uint64]
        self.lib.fsd_fbx_time_range.restype=C.c_int
        self.lib.fsd_fbx_time_range.argtypes=[C.c_void_p,C.POINTER(C.c_double),C.POINTER(C.c_double)]
        self.lib.fsd_fbx_node_matrix.restype=C.c_int
        self.lib.fsd_fbx_node_matrix.argtypes=[C.c_void_p,C.c_char_p,C.POINTER(C.c_double)]
        a,b=C.c_double(),C.c_double();self.lib.fsd_fbx_time_range(self.handle,C.byref(a),C.byref(b))
        self.range=(a.value,b.value)

    def frame(self,seconds,joints=()):
        error=C.create_string_buffer(4096)
        handle=self.lib.fsd_fbx_evaluate(self.handle,float(seconds),1000000,error,len(error))
        if not handle:raise ValueError(error.value.decode(errors='replace'))
        try:
            meshes={}
            for index in range(self.lib.fsd_fbx_mesh_count(handle)):
                view=MeshView()
                if not self.lib.fsd_fbx_mesh(handle,index,C.byref(view)):raise ValueError('Missing animated mesh part')
                array=np.ctypeslib.as_array(view.data,shape=(int(view.corners)*8,)).reshape(-1,8).copy()
                if not np.isfinite(array).all():raise ValueError('Nonfinite animated mesh')
                array.setflags(write=False);meshes[index]=array
            poses={}
            for name in joints:
                matrix=(C.c_double*16)()
                if not self.lib.fsd_fbx_node_matrix(handle,name.encode(),matrix):raise ValueError('Joint not found: '+name)
                poses[name]=np.asarray(matrix).reshape(4,4).copy()
            return meshes,poses,self.range
        finally:self.lib.fsd_fbx_free(handle)

    def close(self):
        if self.handle:self.lib.fsd_fbx_free(self.handle);self.handle=None
