"""Windows PMv2 startup, per-window UI metrics and physical viewport sizing.

Tk coordinates under PMv2 are already client pixels. Never multiply them by
DPR again when allocating a WGL framebuffer or handling a pointer event.
"""
import ctypes as C
import sys
from dataclasses import dataclass

_awareness=None
_user=None


def enable_high_dpi():
    global _awareness,_user
    if _awareness is not None:return _awareness
    _awareness='platform native'
    if sys.platform!='win32':return _awareness
    _user=C.WinDLL('user32',use_last_error=True)
    try:
        f=_user.SetProcessDpiAwarenessContext;f.argtypes=[C.c_void_p];f.restype=C.c_int
        if f(C.c_void_p(-4)):
            _awareness='Per-Monitor V2';return _awareness
        # An embedding host may have fixed process awareness already. Set this
        # GUI thread before its first HWND instead of misreporting process V2.
        f=_user.SetThreadDpiAwarenessContext;f.argtypes=[C.c_void_p];f.restype=C.c_void_p
        if f(C.c_void_p(-4)):
            _awareness='Per-Monitor V2 GUI thread';return _awareness
    except AttributeError:pass
    try:
        sh=C.WinDLL('shcore');f=sh.SetProcessDpiAwareness;f.argtypes=[C.c_int];f.restype=C.c_long
        hr=f(2);_awareness='Per-Monitor V1' if hr==0 else 'host DPI policy (PMv2 unavailable)'
    except (OSError,AttributeError):
        _awareness='legacy Windows DPI policy'
    return _awareness


def window_dpi(widget):
    if sys.platform=='win32':
        enable_high_dpi()
        try:
            f=_user.GetDpiForWindow;f.argtypes=[C.c_void_p];f.restype=C.c_uint
            value=f(C.c_void_p(widget.winfo_id()))
            if value:return float(value)
        except (AttributeError,RuntimeError):pass
    try:return float(widget.winfo_fpixels('1i'))
    except Exception:return 96.


def pixels(widget,value):return round(float(value)*window_dpi(widget)/96.)
def font_pixels(widget,points):return -max(1,round(points*window_dpi(widget)/72.))


@dataclass(frozen=True)
class ViewportMetrics:
    logical_width:float
    logical_height:float
    dpr:float
    physical_width:int
    physical_height:int


def viewport_metrics(widget):
    w,h=max(1,widget.winfo_width()),max(1,widget.winfo_height())
    if sys.platform=='win32':
        class RECT(C.Structure):_fields_=[('left',C.c_long),('top',C.c_long),('right',C.c_long),('bottom',C.c_long)]
        enable_high_dpi()
        f=_user.GetClientRect;f.argtypes=[C.c_void_p,C.POINTER(RECT)];f.restype=C.c_int
        rect=RECT()
        if f(C.c_void_p(widget.winfo_id()),C.byref(rect)):w,h=max(1,rect.right),max(1,rect.bottom)
    dpr=window_dpi(widget)/96.
    return ViewportMetrics(w/dpr,h/dpr,dpr,w,h)


class DpiManager:
    """Rerasterize fonts and rescale logical layout metrics per top-level.

    Uses independent pixel fonts/styles per window rather than changing global
    `tk scaling` whenever a secondary window crosses monitors. No bitmap UI
    stretch. Widgets created later (including popup menus) are picked up too.
    """
    def __init__(self,root):
        import tkinter.font as font
        from tkinter import ttk
        self.root=root;self.font=font;self.ttk=ttk
        self.windows={};self.records={};self.fonts={};self._ticks=0
        self.awareness=enable_high_dpi()
        root.tk.call('tk','scaling',window_dpi(root)/72.)
        self.watch(root)
        self._timer=root.after(250,self._poll)

    def watch(self,window):
        self.windows[str(window)]={'window':window,'dpi':None}
        window.after_idle(lambda:self._apply_window(window,initial=True))

    def _dimensions(self,value,ratio):
        try:
            values=self.root.tk.splitlist(value) if isinstance(value,str) else value if isinstance(value,(tuple,list)) else [value]
            return tuple(round(float(v)*ratio) for v in values)
        except (ValueError,TypeError):return value

    def _capture(self,w):
        key=str(w)
        if key in self.records:return self.records[key]
        record={'widget':w,'font':None,'pack':{},'grid':{},'options':{}}
        options=w.keys()
        spec=None
        if 'font' in options:spec=w.cget('font')
        style=None
        if isinstance(w,self.ttk.Widget):
            style=w.cget('style') or w.winfo_class()
            if not w.cget('style') and w.winfo_class() in ('TScale','TScrollbar','TProgressbar','TSeparator','TPanedwindow'):
                try:style=str(w.cget('orient')).title()+'.'+style
                except Exception:pass
            if not spec:spec=self.ttk.Style(w).lookup(style,'font')
            record['style']=style
            style_padding=self.ttk.Style(w).lookup(style,'padding')
            if style_padding:record['style_padding']=style_padding
            if w.winfo_class()=='Treeview':record['rowheight']=self.ttk.Style(w).lookup(style,'rowheight') or 20
            metrics={}
            for metric in ('arrowsize','indicatorsize','troughborderwidth','sliderlength','sliderthickness','borderwidth'):
                value=self.ttk.Style(w).lookup(style,metric)
                if value:metrics[metric]=value
            record['style_metrics']=metrics
        if spec:
            try:record['font']=self.font.Font(root=w,font=spec).actual()
            except Exception:pass
        try:
            if w.winfo_manager()=='pack':
                record['pack']={k:v for k,v in w.pack_info().items() if k in ('padx','pady','ipadx','ipady')}
            elif w.winfo_manager()=='grid':
                record['grid']={k:v for k,v in w.grid_info().items() if k in ('padx','pady','ipadx','ipady')}
        except Exception:pass
        for name in ('padding','borderwidth','highlightthickness'):
            if name in options:record['options'][name]=w.cget(name)
        if w.winfo_class() in ('Frame','TFrame','Canvas','Panedwindow','PanedWindow'):
            for name in ('width','height'):
                if name in options:record['options'][name]=w.cget(name)
        self.records[key]=record
        return record

    def _apply_widget(self,w,dpi):
        r=self._capture(w);ratio=dpi/96.
        if r.get('applied_dpi')==dpi:
            if isinstance(w,self.ttk.Panedwindow):
                horizontal=str(w.cget('orient'))=='horizontal'
                extent=w.winfo_width() if horizontal else w.winfo_height()
                if extent>1:r['sashes']=[w.sashpos(i)/extent for i in range(max(0,len(w.panes())-1))]
            return
        if r['font']:
            values=dict(r['font']);size=values.pop('size')
            values['size']=-max(1,round(size*dpi/72. if size>0 else abs(size)*ratio))
            f=self.font.Font(root=w,**values);self.fonts[str(w)]=f
            if 'font' in w.keys():w.configure(font=f)
            elif 'style' in r:
                name='dpi'+str(w.winfo_id())+'.'+r['style']
                s=self.ttk.Style(w);s.configure(name,font=f)
                if w.winfo_class()=='Treeview':s.configure(name+'.Heading',font=f)
                w.configure(style=name)
        if 'style' in r:
            name='dpi'+str(w.winfo_id())+'.'+r['style'];s=self.ttk.Style(w)
            if 'style_padding' in r:s.configure(name,padding=self._dimensions(r['style_padding'],ratio))
            if 'rowheight' in r:s.configure(name,rowheight=round(float(r['rowheight'])*ratio))
            for metric,value in r.get('style_metrics',{}).items():
                scaled=self._dimensions(value,ratio)
                if isinstance(scaled,tuple) and len(scaled)==1:s.configure(name,**{metric:scaled[0]})
            w.configure(style=name)
        for k,v in r['options'].items():
            try:
                scaled=self._dimensions(v,ratio)
                w.configure(**{k:scaled if k=='padding' else scaled[0] if isinstance(scaled,tuple) and len(scaled)==1 else scaled})
            except Exception:pass
        if r['pack']:w.pack_configure(**{k:self._dimensions(v,ratio) for k,v in r['pack'].items()})
        if r['grid']:w.grid_configure(**{k:self._dimensions(v,ratio) for k,v in r['grid'].items()})
        if r.get('applied_dpi') is not None and r.get('sashes'):
            w.after_idle(lambda pane=w,fractions=list(r['sashes']):self._restore_sashes(pane,fractions))
        r['applied_dpi']=dpi

    def _restore_sashes(self,pane,fractions):
        if not pane.winfo_exists():return
        extent=pane.winfo_width() if str(pane.cget('orient'))=='horizontal' else pane.winfo_height()
        for i,fraction in enumerate(fractions):
            if i<len(pane.panes())-1:pane.sashpos(i,round(extent*fraction))

    def _apply_window(self,window,initial=False):
        if not window.winfo_exists():return
        dpi=window_dpi(window);state=self.windows[str(window)];old=state['dpi']
        if initial and old is not None:return
        if old!=dpi:
            # Never pump Tk's event loop inside an idle DPI callback: nested
            # viewport/context creation can invalidate the active WGL window.
            state['dpi']=dpi
            old_width,old_height=window.winfo_width(),window.winfo_height()
            if initial and (old_width<=1 or old_height<=1):
                import re
                size=re.match(r'(\d+)x(\d+)',window.geometry())
                if size and int(size[1])>1 and int(size[2])>1:old_width,old_height=map(int,size.groups())
                else:old_width,old_height=window.winfo_reqwidth(),window.winfo_reqheight()
            # Do not scale coordinates twice: resize from logical initial size,
            # then keep current dimensions when Windows/Tk handles a DPI move.
            if initial:
                sw,sh=window.winfo_screenwidth(),window.winfo_screenheight()
                window.geometry(f'{min(round(old_width*dpi/96),round(sw*.94))}x{min(round(old_height*dpi/96),round(sh*.9))}')
                mw,mh=window.minsize();window.minsize(min(round(mw*dpi/96),round(sw*.9)),min(round(mh*dpi/96),round(sh*.85)))
        stack=[window]
        while stack:
            w=stack.pop()
            if w!=window and w.winfo_toplevel()!=window:continue
            try:
                self._apply_widget(w,dpi);stack.extend(w.winfo_children())
            except Exception:continue
        if old!=dpi:
            window.event_generate('<<DpiChanged>>',when='tail')

    def _poll(self):
        if not self.root.winfo_exists():return
        self._ticks+=1
        for key,state in list(self.windows.items()):
            window=state['window']
            if not window.winfo_exists():self.windows.pop(key,None);continue
            if state['dpi']!=window_dpi(window) or self._ticks%4==0:
                self._apply_window(window,initial=state['dpi'] is None)
        if self._ticks%4==0:
            for key,record in list(self.records.items()):
                if not record['widget'].winfo_exists():
                    self.records.pop(key,None);self.fonts.pop(key,None)
        self._timer=self.root.after(250,self._poll)


def watch_window(window):
    root=window._root()
    manager=getattr(root,'dpi_manager',None)
    if manager:manager.watch(window)
