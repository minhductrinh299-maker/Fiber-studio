"""Project-owned reference objects, async import/material preparation and Outliner."""
from copy import deepcopy
from pathlib import Path
from queue import Queue,Empty
import json
import math
import tkinter as tk
from tkinter import ttk,filedialog,messagebox,simpledialog
import numpy as np
from .cards import HairCard,ribbon_mesh
from .scene_import import import_scene,decode_texture
from .surface_snap import SurfaceBVH
from .number_slider import NumberSlider
from .engine_v2.scheduler import LatestScheduler
from .engine_v2.cache import ByteLRU


def signature(record):
    return (record['id'],json.dumps(record['material'],sort_keys=True),record.get('_geometry_version',()),record.get('_pose_revision',0))


class ObjectWorkspace:
    def __init__(self,app):
        self.app=app;self.queue=Queue();self.scheduler=LatestScheduler(workers=1)
        app.project._object_workspace=self
        self.prepared=ByteLRU(256*1024**2);self.bvhs=ByteLRU(128*1024**2)
        self.pending={};self.failed={};self.delivered={};self.requests=set();self.window=None;self.revision=0;self.closed=False
        self.project=app.project
        self.last_objects=None;self.poll_job=app.after(80,self.poll)
        self.pending_bvh=set()
        self.pose_revision=0;self.poses={};self.joint_poses={};self.sessions={};self.pose_request=0;self.pose_published=0;self.requested_joints={}

    def show(self,editor=None):
        if self.window is None or not self.window.winfo_exists():self.window=Outliner(self,editor)
        else:self.window.editor=editor or self.window.editor;self.window.refresh();self.window.lift()

    def changed(self,refresh=True):
        self.revision+=1
        if refresh and self.window and self.window.winfo_exists():self.window.refresh()
        card=self.app.card_window
        if card and card.winfo_exists():card._render_soon(0)
        studio=self.app.render_window
        if studio and studio.winfo_exists():
            if studio.renderer:
                studio.renderer.invalidate_history('scene objects changed')
                if getattr(studio.renderer,'_bound_pose_revision',None)!=self.pose_revision:
                    studio.renderer._bound_pose_revision=self.pose_revision
                    if any(c.get('attachment') or any(m.get('op') in ('bind','attach') for m in c.get('modifiers',[])) for c in self.app.project.cards):
                        studio.renderer.load_cards(self.app.project.cards,self.app._atlas.layout.placements,self.app._atlas.layout.size)
            studio._frame_later(0)

    def poll(self):
        if self.closed:return
        if self.project is not self.app.project:
            self.project=self.app.project;self.pending.clear();self.failed.clear()
            self.app.project._object_workspace=self
            self.delivered.clear();self.requests.clear()
            self.pending_bvh.clear()
            self.poses={};self.joint_poses={};self.pose_revision+=1
            self.prepared=ByteLRU(256*1024**2);self.bvhs=ByteLRU(128*1024**2)
        try:
            while True:
                kind,project,data,error=self.queue.get_nowait()
                if project is not self.app.project:continue
                if error:
                    if kind=='prepared' and data is not None:
                        key,sig=data
                        if self.pending.get(key)==sig:self.pending.pop(key,None)
                        self.failed[key]=sig
                    if kind=='pose':
                        if data!=self.pose_request:continue
                        self.pose_published=self.pose_request
                        if self.window and self.window.winfo_exists():self.window.playing=False
                    if kind=='bvh' and data is not None:self.pending_bvh.discard(data)
                    if self.window and self.window.winfo_exists():self.window.status.set(error)
                    continue
                if kind=='import':
                    self.app._history();self.app.project.objects=[*self.app.project.objects,*data]
                    self.app.modified=True;self.changed()
                    if self.window and self.window.winfo_exists():
                        warnings=sorted({note for record in data for note in record.get('warnings',[])})
                        self.window.status.set(f'Imported {len(data)} mesh/material objects. '+(' · '.join(warnings) if warnings else 'Select model and Frame Mesh to inspect.'))
                elif kind=='prepared':
                    key,record,prepared=data
                    if self.pending.get(key)==prepared['signature']:self.pending.pop(key,None)
                    current=next((o for o in self.evaluated_objects() if o['id']==key),None)
                    if current and signature(current)==prepared['signature']:
                        self.prepared.put(key,prepared);self.changed(False)
                        self.delivered[key]=prepared['signature'];self.requests.discard(key)
                        if self.window and self.window.winfo_exists() and prepared['missing']:
                            self.window.status.set('Missing textures: '+', '.join(prepared['missing'])+' · use map buttons to relink.')
                elif kind=='snap':
                    editor,target,snapshots,shaped=data
                    if not editor.winfo_exists():continue
                    if not any(o is target for o in self.app.project.objects):continue
                    if any(editor._card_lookup.get(cid) is None or editor._card_lookup[cid].to_dict()!=source
                           for cid,source in snapshots.items()):
                        if self.window and self.window.winfo_exists():self.window.status.set('Cards changed while snapping; result discarded.')
                        continue
                    if not shaped:
                        if self.window and self.window.winfo_exists():self.window.status.set('Snap complete · no roots/vertices needed moving within the distance limit.')
                        continue
                    editor._history()
                    replacements={c.id:c for c in shaped}
                    editor.cards=[replacements.get(c.id,c) for c in editor.cards]
                    editor._save_cards();editor._refresh_tree();editor._render_soon(0)
                    if self.window and self.window.winfo_exists():self.window.status.set(f'Snapped {len(shaped)} cards')
                elif kind=='bvh':
                    key,bvh,target=data;self.pending_bvh.discard(key)
                    if any(o is target for o in self.app.project.objects):self.bvhs.put(key,bvh);self.changed()
                elif kind=='pose':
                    request,source_objects,poses,joints,time_range=data
                    if request!=self.pose_request:continue
                    if source_objects is not self.app.project.objects:
                        self.pose_published=request;continue
                    self.poses=poses;self.joint_poses=joints;self.pose_revision+=1;self.pose_published=request;self.changed(False)
                    if self.window and self.window.winfo_exists():
                        self.window.time_scale.configure(from_=time_range[0],to=max(time_range[0]+.001,time_range[1]))
        except Empty:pass
        objects=self.app.project.objects
        if objects is not self.last_objects:
            self.last_objects=objects;self.pose_revision+=1;self.changed()
            from .kernel.scene import kernel
            kernel(self.app.project).synchronize()
        for record in self.evaluated_objects():
            if not record.get('visible',True):continue
            key=record['id'];sig=signature(record);prepared=self.prepared.get(key)
            if prepared and prepared['signature']==sig:continue
            if self.delivered.get(key)==sig and key not in self.requests:continue
            if self.failed.get(key)==sig:continue
            if self.pending.get(key)==sig:continue
            if len(self.pending)>=2:break
            self.pending[key]=sig;project=self.app.project
            previous_prepared=prepared
            def prepare(token,record=record,project=project,key=key,sig=sig,previous=previous_prepared):
                try:
                    faces=np.asarray(record['triangles'],np.int32)
                    vertices=np.asarray(record['vertices'],np.float32)
                    normals=np.asarray(record['normals'],np.float32)
                    uv=np.asarray(record['uv'],np.float32)
                    data=np.ascontiguousarray(np.column_stack((vertices,normals,uv))[faces.reshape(-1)],np.float32)
                    images={};missing=[]
                    for channel,path in record['material'].get('maps',{}).items():
                        if token.is_set():return
                        if channel not in ('color','normal','roughness','alpha','specular','metallic','ao','emission'):continue
                        if previous and previous['signature'][1]==sig[1] and channel in previous['images']:
                            images[channel]=previous['images'][channel]
                        elif Path(path).is_file():
                            try:images[channel]=decode_texture(path)
                            except Exception as ex:missing.append(f'{path} ({ex})')
                        else:missing.append(path)
                    cost=data.nbytes+sum(image.width*image.height*4*4//3 for image in images.values())
                    if data.nbytes+sum(image.width*image.height*4 for image in images.values())>240*1024**2:
                        raise ValueError('Model preparation exceeds 240 MiB; split mesh or use smaller textures')
                    prepared=dict(data=data,images=images,signature=sig,missing=missing,cost=cost)
                    if not token.is_set():self.queue.put(('prepared',project,(key,record,prepared),None))
                except Exception as ex:self.queue.put(('prepared',project,(key,sig),f'Mesh prepare: {ex}'))
            self.scheduler.submit('prepare:'+key,prepare,priority=5)
        self.poll_job=self.app.after(16,self.poll)

    def evaluated_objects(self):
        stamp=(id(self.app.project),id(self.app.project.objects),self.pose_revision)
        if getattr(self,'_evaluated_stamp',None)==stamp:return self._evaluated_objects
        from .kernel.attachments import topology_signature
        result=[]
        for obj in self.app.project.objects:
            posed=obj['id'] in self.poses
            vertices=self.poses[obj['id']][:,:3] if posed else np.asarray(obj['vertices'],np.float32)
            normals=self.poses[obj['id']][:,3:6] if posed else np.asarray(obj['normals'],np.float32)
            faces=np.asarray(obj['triangles'],np.int32)
            result.append({**obj,'vertices':vertices,'normals':normals,'triangles':faces,
                           '_pose_revision':self.pose_revision if posed else 0,
                           '_geometry_version':(id(obj['vertices']),id(obj['normals']),id(obj['triangles'])),
                           '_topology_signature':topology_signature(vertices,faces)})
        self._evaluated_stamp=stamp;self._evaluated_objects=result
        return result

    def request_joint(self,object_id,name,seconds=0.):
        if not name:raise ValueError('Enter a joint path/name')
        self.requested_joints[object_id,name]=True
        self.evaluate_time(seconds)

    def evaluate_time(self,seconds):
        if not math.isfinite(seconds):raise ValueError('Invalid animation time')
        self.pose_request+=1;request=self.pose_request;project=self.app.project
        objects=project.objects;cards=project.cards;extra_joints=tuple(self.requested_joints)
        def work(token):
            try:
                from .fbx_reader import AnimationSession
                poses={};joint_poses={};time_range=(0.,1.)
                sources={o.get('animation_source') for o in objects if o.get('animation_source')}
                for path in sources:
                    if token.is_set():return
                    if path not in self.sessions:
                        while len(self.sessions)>=2:self.sessions.pop(next(iter(self.sessions))).close()
                        self.sessions[path]=AnimationSession(path)
                    ids={o['id'] for o in objects if o.get('animation_source')==path}
                    joints={name for oid,name in extra_joints if oid in ids}|{c['attachment'].get('joint') for c in cards
                            if c.get('attachment') and c['attachment'].get('kind')=='joint' and c['attachment'].get('object_id') in ids}-{None,''}
                    meshes,joint_matrices,time_range=self.sessions[path].frame(seconds,joints)
                    for obj in objects:
                        if obj.get('animation_source')!=path:continue
                        part=obj.get('source_part',0)
                        if part not in meshes:raise ValueError('Animation mesh part no longer exists')
                        if len(meshes[part])!=len(obj['vertices']):raise ValueError('Animation topology changed; remap required')
                        poses[obj['id']]=meshes[part]
                        for name,matrix in joint_matrices.items():joint_poses[obj['id'],name]=matrix
                if not token.is_set():self.queue.put(('pose',project,(request,objects,poses,joint_poses,time_range),None))
            except Exception as error:
                if not token.is_set():self.queue.put(('pose',project,request,str(error)))
            finally:
                if self.closed:
                    for session in self.sessions.values():session.close()
                    self.sessions.clear()
        self.scheduler.submit('animation-pose',work,priority=-3)

    def import_file(self,parent):
        path=filedialog.askopenfilename(parent=parent,title='Import model',filetypes=[('3D model','*.obj *.fbx')])
        if not path:return
        project=self.app.project
        if self.window:self.window.status.set('Importing model in background…')
        def work(token):
            try:
                records=import_scene(path)
                if not token.is_set():self.queue.put(('import',project,records,None))
            except Exception as ex:self.queue.put(('import',project,None,str(ex)))
        self.scheduler.submit('import',work,priority=0)

    def require(self,key):
        self.requests.add(key)

    def live_snap(self,editor,card):
        target_id=getattr(editor,'snap_mesh_id',None)
        target=next((o for o in self.app.project.objects if o['id']==target_id and o.get('visible',True)),None)
        if target is None:return
        key=(target_id,tuple(target.get('position',[0,0,0])),target.get('scale',1))
        bvh=self.bvhs.get(key)
        if bvh is None:
            if key not in self.pending_bvh and len(self.pending_bvh)<2:
                self.pending_bvh.add(key);project=self.app.project
                def prepare(token):
                    try:
                        bvh=SurfaceBVH(target)
                        if not token.is_set():self.queue.put(('bvh',project,(key,bvh,target),None))
                    except Exception as ex:self.queue.put(('bvh',project,key,str(ex)))
                self.scheduler.submit('live-bvh:'+str(key),prepare,priority=-2)
            return
        hit=bvh.nearest(card.root,getattr(editor,'snap_max_distance',float('inf')))
        if hit is not None:
            position,normal=hit;card.root=(position+normal*getattr(editor,'snap_offset',.002)).tolist()

    def snap(self,editor,target_id,conform,offset,max_distance):
        target=next((o for o in self.app.project.objects if o['id']==target_id and o.get('visible',True)),None)
        if target is None:raise ValueError('Choose a visible mesh as Snap Target')
        cards=editor._selection()
        if not cards:raise ValueError('Select unlocked cards in the Card Editor')
        snapshots={c.id:c.to_dict() for c in cards};project=self.app.project
        def work(token):
            try:
                key=(target_id,tuple(target.get('position',[0,0,0])),target.get('scale',1))
                bvh=self.bvhs.get(key)
                if bvh is None:bvh=SurfaceBVH(target);self.bvhs.put(key,bvh)
                output=[]
                for source in snapshots.values():
                    if token.is_set():return
                    card=HairCard.from_dict(source);changed=False
                    if conform:
                        vertices,_,_,_=ribbon_mesh(card)
                        for i,point in enumerate(vertices):
                            if i<card.width_segments+1 and card.locked_root:continue
                            hit=bvh.nearest(point,max_distance)
                            if hit is None:continue
                            pos,normal=hit;key=f'{i//(card.width_segments+1)}:{i%(card.width_segments+1)}'
                            delta=pos+normal*offset-point
                            card.vertex_offsets[key]=(np.asarray(card.vertex_offsets.get(key,[0,0,0]))+delta).tolist()
                            changed=True
                    else:
                        hit=bvh.nearest(card.root,max_distance)
                        if hit is not None:
                            pos,normal=hit;root=pos+normal*offset
                            changed=bool(np.linalg.norm(root-card.root)>1e-8)
                            card.root=root.tolist()
                    if changed:card.sanitize();output.append(card)
                if not token.is_set():self.queue.put(('snap',project,(editor,target,snapshots,output),None))
            except Exception as ex:self.queue.put(('snap',project,None,f'Snap: {ex}'))
        self.scheduler.submit('snap',work,priority=-1)

    def close(self):
        self.closed=True;self.scheduler.close();self.app.after_cancel(self.poll_job)
        for thread in self.scheduler.threads:thread.join(timeout=.5)
        if not any(thread.is_alive() for thread in self.scheduler.threads):
            for session in self.sessions.values():session.close()
            self.sessions.clear()


def workspace(app):
    if getattr(app,'object_workspace',None) is None:app.object_workspace=ObjectWorkspace(app)
    return app.object_workspace


class Outliner(tk.Toplevel):
    def __init__(self,owner,editor=None):
        super().__init__(owner.app);self.owner=owner;self.editor=editor
        self.title('Scene Outliner · Import & Surface Snap');self.geometry('650x720')
        self.status=tk.StringVar(value='OBJ / FBX native import · no Blender required')
        bar=ttk.Frame(self,padding=8);bar.pack(fill='x')
        ttk.Button(bar,text='Import OBJ / FBX',command=lambda:owner.import_file(self)).pack(side='left')
        ttk.Button(bar,text='Refresh',command=self.refresh).pack(side='left',padx=4)
        ttk.Button(bar,text='Frame Mesh',command=self.frame_mesh).pack(side='left',padx=4)
        tree_frame=ttk.Frame(self);tree_frame.pack(fill='both',expand=True,padx=8)
        self.tree=ttk.Treeview(tree_frame,columns=('visible','locked','type'),selectmode='extended')
        for key,label,width in [('visible','Visible',65),('locked','Locked',65),('type','Type',80)]:
            self.tree.heading(key,text=label);self.tree.column(key,width=width,stretch=False)
        self.tree.heading('#0',text='Object');self.tree.pack(side='left',fill='both',expand=True)
        scrollbar=ttk.Scrollbar(tree_frame,orient='vertical',command=self.tree.yview)
        scrollbar.pack(side='right',fill='y');self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.bind('<Double-1>',self.double_click)
        self.tree.bind('<<TreeviewSelect>>',self.select_cards)
        buttons=ttk.Frame(self,padding=8);buttons.pack(fill='x')
        for title,key,value in [('Show','visible',True),('Hide','visible',False),('Lock','locked',True),('Unlock','locked',False)]:
            ttk.Button(buttons,text=title,command=lambda k=key,v=value:self.edit(k,v)).pack(side='left',padx=2)
        ttk.Button(buttons,text='Rename',command=self.rename).pack(side='left',padx=2)
        ttk.Button(buttons,text='Delete',command=self.delete).pack(side='left',padx=2)
        maps=ttk.LabelFrame(self,text='Model material maps',padding=8);maps.pack(fill='x',padx=8,pady=4)
        for index,(title,channel) in enumerate([('Base Color','color'),('Normal','normal'),('Roughness','roughness'),('Alpha','alpha'),
                                              ('Specular','specular'),('Metallic','metallic'),('AO','ao'),('Emission','emission')]):
            ttk.Button(maps,text=title,command=lambda c=channel:self.assign_map(c)).grid(row=index//4,column=index%4,sticky='ew',padx=2,pady=2)
            maps.columnconfigure(index%4,weight=1)
        transform=ttk.LabelFrame(self,text='Selected models · absolute transform',padding=8);transform.pack(fill='x',padx=8,pady=4)
        self.position=[tk.StringVar(value='0') for _ in range(3)];self.scale=tk.StringVar(value='1')
        for name,var in zip(('X','Y','Z','Scale'),[*self.position,self.scale]):
            ttk.Label(transform,text=name).pack(side='left');ttk.Entry(transform,textvariable=var,width=7).pack(side='left',padx=2)
        ttk.Button(transform,text='Apply',command=self.transform).pack(side='left',padx=4)
        snap=ttk.LabelFrame(self,text='Surface Snap · Card Editor selection',padding=8);snap.pack(fill='x',padx=8,pady=5)
        self.target=tk.StringVar();self.target_box=ttk.Combobox(snap,textvariable=self.target,state='readonly')
        self.target_box.pack(fill='x')
        self.live=tk.BooleanVar(value=False)
        ttk.Checkbutton(snap,text='Live Root Snap while moving cards',variable=self.live,command=self.set_live).pack(anchor='w',pady=3)
        self.target_box.bind('<<ComboboxSelected>>',lambda e:self.set_live())
        self.offset=tk.StringVar(value='.002');self.maximum=tk.StringVar(value='0')
        row=ttk.Frame(snap);row.pack(fill='x',pady=4)
        for name,var in [('Offset',self.offset),('Max distance · 0=unlimited',self.maximum)]:
            ttk.Label(row,text=name).pack(side='left');ttk.Entry(row,textvariable=var,width=8).pack(side='left',padx=4)
        ttk.Button(row,text='Snap Roots',command=lambda:self.snap(False)).pack(side='left',padx=2)
        ttk.Button(row,text='Conform Surface',command=lambda:self.snap(True)).pack(side='left',padx=2)
        animation=ttk.LabelFrame(self,text='FBX Animation · deforming surface',padding=8);animation.pack(fill='x',padx=8)
        self.playing=False;self.animation_time=tk.DoubleVar(value=0.)
        self.time_scale=NumberSlider(animation,variable=self.animation_time,from_=0,to=10,step=0.05,height=22,
                                     command=lambda value:self.owner.evaluate_time(float(value)))
        self.time_scale.pack(fill='x',pady=3)
        ttk.Button(animation,text='Enable Selected FBX Sources',command=self.enable_animation).pack(side='left')
        ttk.Button(animation,text='Play / Pause',command=self.toggle_play).pack(side='left',padx=4)
        ttk.Button(animation,text='Rest Pose',command=self.rest_pose).pack(side='left',padx=4)
        ttk.Label(self,textvariable=self.status,wraplength=620).pack(fill='x',padx=8,pady=8)
        self.refresh()

    def refresh(self):
        selected=set(self.tree.selection());self.tree.delete(*self.tree.get_children())
        self.tree.insert('','end',iid='models',text='Imported Models',open=True)
        self.tree.insert('','end',iid='cards',text='Hair Cards',open=True)
        for parent,records in [('models',self.owner.app.project.objects),('cards',self.owner.app.project.cards)]:
            for record in records:
                self.tree.insert(parent,'end',iid=parent+':'+record['id'],text=record['name'],
                    values=('On' if record.get('visible',True) else 'Off','Yes' if record.get('locked',False) else 'No',
                            'Mesh' if parent=='models' else 'Card'))
        self.tree.selection_set([key for key in selected if self.tree.exists(key)])
        previous=getattr(self,'targets',{}).get(self.target.get())
        self.targets={f'{o["name"]} · {o["id"][:6]}':o['id'] for o in self.owner.app.project.objects if o.get('visible',True)}
        self.target_box.configure(values=list(self.targets))
        self.target.set(next((label for label,key in self.targets.items() if key==previous),next(iter(self.targets),'')))

    def selected_ids(self,kind):return {key.split(':',1)[1] for key in self.tree.selection() if key.startswith(kind+':')}

    def select_cards(self,event=None):
        models=self.selected_ids('models')
        model=next((o for o in self.owner.app.project.objects if o['id'] in models),None)
        if model is not None:
            for var,value in zip(self.position,model.get('position',[0,0,0])):var.set(f'{value:.6g}')
            self.scale.set(f'{model.get("scale",1):.6g}')
        editor=self.editor
        if editor and editor.winfo_exists():
            ids=self.selected_ids('cards')
            if ids:editor.selected=ids;editor._sync_tree();editor._sync_inspector();editor._render_soon(0)

    def frame_mesh(self):
        ids=self.selected_ids('models')
        records=[o for o in self.owner.app.project.objects if o.get('visible',True) and (not ids or o['id'] in ids)]
        if not records:return
        lo=[];hi=[]
        for record in records:
            vertices=np.asarray(record['vertices'],float)*record.get('scale',1)+record.get('position',[0,0,0])
            lo.append(vertices.min(axis=0));hi.append(vertices.max(axis=0))
        low=np.min(lo,axis=0);high=np.max(hi,axis=0);center=(low+high)*.5
        distance=max(.01,float(np.linalg.norm(high-low))*.5/math.sin(math.radians(15))*1.2)
        editor=self.editor or self.owner.app.card_window
        if editor and editor.winfo_exists():
            editor.camera_target=list(center);editor.distance=distance;editor._render_soon(0)
        else:
            studio=self.owner.app.render_window
            if studio and studio.winfo_exists() and studio.renderer:
                studio.renderer.target[:]=center;studio.renderer.distance=distance;studio._frame_later(0)

    def double_click(self,event):
        item=self.tree.identify_row(event.y);column=self.tree.identify_column(event.x)
        if ':' not in item or column not in ('#1','#2'):return
        self.tree.selection_set(item)
        key='visible' if column=='#1' else 'locked'
        kind,id=item.split(':',1)
        records=self.owner.app.project.objects if kind=='models' else self.owner.app.project.cards
        value=next(o.get(key,key=='visible') for o in records if o['id']==id)
        self.edit(key,not value)

    def commit(self,models,cards):
        app=self.owner.app;app._history();app.project.objects=models;app.project.cards=cards;app.modified=True
        from .kernel.scene import kernel
        kernel(app.project).synchronize()
        app._notify_card_editor();self.owner.changed()

    def edit(self,key,value):
        app=self.owner.app
        def replace(records,kind):
            ids=self.selected_ids(kind)
            return [{**o,key:value} if o['id'] in ids else o for o in records]
        self.commit(replace(app.project.objects,'models'),replace(app.project.cards,'cards'))

    def rename(self):
        selected=self.tree.selection()
        if len(selected)!=1 or ':' not in selected[0]:return
        kind,id=selected[0].split(':',1);app=self.owner.app
        source=app.project.objects if kind=='models' else app.project.cards
        obj=next(o for o in source if o['id']==id)
        if obj.get('locked'):self.status.set('Unlock the object before editing.');return
        name=simpledialog.askstring('Rename object','Name',initialvalue=obj['name'],parent=self)
        if not name:return
        records=[{**o,'name':name} if o['id']==id else o for o in source]
        self.commit(records if kind=='models' else app.project.objects,records if kind=='cards' else app.project.cards)

    def delete(self):
        app=self.owner.app
        def keep(records,kind):
            ids=self.selected_ids(kind)
            return [o for o in records if o['id'] not in ids or o.get('locked',False)]
        self.commit(keep(app.project.objects,'models'),keep(app.project.cards,'cards'))

    def assign_map(self,channel):
        ids=self.selected_ids('models');app=self.owner.app
        if not ids:self.status.set('Select imported mesh objects first.');return
        path=filedialog.askopenfilename(parent=self,title=f'Assign {channel} texture',filetypes=[('Texture','*.png *.jpg *.jpeg *.tif *.tiff *.tga *.bmp'),('All files','*.*')])
        if not path:return
        records=[]
        for obj in app.project.objects:
            if obj['id'] in ids and not obj.get('locked'):
                material={**obj['material'],'maps':{**obj['material'].get('maps',{}),channel:str(Path(path).resolve())}}
                obj={**obj,'material':material}
            records.append(obj)
        self.commit(records,app.project.cards)

    def transform(self):
        try:
            position=list(map(lambda v:float(v.get()),self.position));scale=float(self.scale.get())
            if not all(math.isfinite(x) for x in [*position,scale]) or scale<=0:raise ValueError()
        except ValueError:self.status.set('Use finite position and positive scale.');return
        ids=self.selected_ids('models');app=self.owner.app
        records=[{**o,'position':position,'scale':scale} if o['id'] in ids and not o.get('locked') else o for o in app.project.objects]
        self.commit(records,app.project.cards)

    def snap(self,conform):
        editor=self.editor or self.owner.app.card_window
        if editor is None or not editor.winfo_exists():self.status.set('Open Card Editor and select cards first.');return
        try:
            offset=float(self.offset.get());maximum=float(self.maximum.get())
            if not math.isfinite(offset) or not math.isfinite(maximum) or maximum<0:raise ValueError('Use finite offset and nonnegative distance')
            self.owner.snap(editor,self.targets.get(self.target.get()),conform,offset,maximum or float('inf'))
            self.status.set('Snapping in background…')
        except ValueError as ex:self.status.set(str(ex))

    def set_live(self):
        editor=self.editor or self.owner.app.card_window
        if editor is None or not editor.winfo_exists():self.live.set(False);return
        try:
            offset=float(self.offset.get());maximum=float(self.maximum.get())
            if not math.isfinite(offset) or not math.isfinite(maximum) or maximum<0:raise ValueError()
        except ValueError:self.live.set(False);self.status.set('Invalid snap offset/distance');return
        editor.snap_mesh_id=self.targets.get(self.target.get()) if self.live.get() else None
        editor.snap_offset=offset;editor.snap_max_distance=maximum or float('inf')

    def enable_animation(self):
        ids=self.selected_ids('models');app=self.owner.app;records=[]
        for obj in app.project.objects:
            if obj['id'] in ids and not obj.get('locked'):
                source=obj.get('source','')
                if not Path(source).is_file() or Path(source).suffix.lower()!='.fbx':
                    source=filedialog.askopenfilename(parent=self,title='Choose original animated FBX source',filetypes=[('FBX','*.fbx')])
                if not source:return
                obj={**obj,'animation_source':source}
            records.append(obj)
        self.commit(records,app.project.cards);self.owner.evaluate_time(self.animation_time.get())

    def toggle_play(self):
        self.playing=not self.playing
        if self.playing:self.play_step()

    def play_step(self):
        if not self.winfo_exists() or not self.playing:return
        if self.owner.pose_published==self.owner.pose_request:
            value=self.animation_time.get()+1/30
            a,b=float(self.time_scale.cget('from')),float(self.time_scale.cget('to'))
            value=a if value>b else value
            self.animation_time.set(value);self.owner.evaluate_time(value)
        self.after(33,self.play_step)

    def rest_pose(self):
        self.playing=False;self.owner.pose_request+=1;self.owner.pose_published=self.owner.pose_request
        self.owner.poses={};self.owner.joint_poses={};self.owner.pose_revision+=1;self.owner.changed()
