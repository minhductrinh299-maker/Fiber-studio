"""Stable deterministic multi-page tile atlas with incremental dirty-region updates and UDIM support."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import re
from PIL import Image
import json
from .model import Project, Tile, MAP_NAMES
from .raster import RenderResult


def udim_to_uv_tile(udim: int) -> tuple[int, int]:
    """Convert standard UDIM identifier (1001-based) to integer (u_col, v_row) tile coordinates.

    In standard UDIM:
    UDIM = 1001 + u + 10 * v (where u in [0..9] and v >= 0).
    """
    offset = max(0, int(udim) - 1001)
    return offset % 10, offset // 10


def uv_tile_to_udim(u: int, v: int) -> int:
    """Convert integer (u_col, v_row) tile coordinates to standard UDIM identifier."""
    return 1001 + int(u) + 10 * int(v)


def page_to_udim(page: int) -> int:
    """Map contiguous page index to standard UDIM identifier."""
    return 1001 + max(0, int(page))


def udim_to_page(udim: int) -> int:
    """Map standard UDIM identifier to 0-based page index."""
    return max(0, int(udim) - 1001)


@dataclass(frozen=True)
class Placement:
    page: int
    x: int
    y: int
    width: int
    height: int
    gutter: int
    rotation: float = 0.0
    udim: int = 1001

    def __post_init__(self):
        # Keep page and udim synchronized
        if self.udim == 1001 and self.page > 0:
            object.__setattr__(self, "udim", 1001 + self.page)
        elif self.udim != 1001 and self.page == 0:
            object.__setattr__(self, "page", max(0, self.udim - 1001))

    def to_dict(self, atlas_size: int) -> dict:
        u_tile, v_tile = udim_to_uv_tile(self.udim)
        u_min = u_tile + self.x / atlas_size
        u_max = u_tile + (self.x + self.width) / atlas_size
        v_min = v_tile + (1.0 - (self.y + self.height) / atlas_size)
        v_max = v_tile + (1.0 - self.y / atlas_size)
        d = {
            "page": self.page,
            "udim": self.udim,
            "rect_px": [self.x, self.y, self.width, self.height],
            "uv_scale": [self.width / atlas_size, self.height / atlas_size],
            "uv_offset": [self.x / atlas_size, self.y / atlas_size],
            "udim_tile": [u_tile, v_tile],
            "udim_uv_rect": [float(u_min), float(v_min), float(u_max), float(v_max)],
            "note": "UV origin is top-left for image pixel data; convert V for OpenGL conventions"
        }
        if abs(self.rotation % 360.0) > 1e-4:
            d["rotation"] = float(self.rotation % 360.0)
        return d


class AtlasLayout:
    def __init__(self, project: Project):
        self.size = project.atlas_size
        self.gutter = project.padding
        self.placements: dict[str, Placement] = {}
        self.pages = 0
        self.udims: list[int] = []
        self._layout(project.tiles, project.metadata.get("tile_placements"), project.metadata.get("active_udims"))

    def page_to_udim(self, page: int) -> int:
        return 1001 + max(0, int(page))

    def udim_to_page(self, udim: int) -> int:
        return max(0, int(udim) - 1001)

    def get_tiles_in_udim(self, udim: int) -> list[str]:
        return [tid for tid, p in self.placements.items() if p.udim == udim]

    def _layout(self, tiles: list[Tile], manual_placements: dict[str, dict] | None = None, active_udims: list[int] | None = None):
        known_udims: set[int] = set(active_udims or [])
        if not known_udims:
            known_udims.add(1001)

        # Harvest any explicit UDIMs or pages in custom placements
        if manual_placements:
            for custom in manual_placements.values():
                if isinstance(custom, dict):
                    if "udim" in custom:
                        known_udims.add(int(custom["udim"]))
                    elif "page" in custom:
                        known_udims.add(1001 + int(custom["page"]))

        # Partition tiles into explicit coordinates, per-UDIM unplaced, and general unplaced
        unplaced_per_udim: dict[int, list[Tile]] = {}
        general_unplaced: list[Tile] = []

        for tile in tiles:
            custom = manual_placements.get(tile.id) if manual_placements else None
            if custom and isinstance(custom, dict) and "x" in custom and "y" in custom:
                cudim = int(custom.get("udim", 1001 + int(custom.get("page", 0))))
                cpage = cudim - 1001
                cx = int(custom["x"])
                cy = int(custom["y"])
                rot = float(custom.get("rotation", 0.0)) % 360.0
                if "width" in custom and "height" in custom:
                    cw = int(custom["width"])
                    ch = int(custom["height"])
                elif abs(rot - 90.0) < 1e-4 or abs(rot - 270.0) < 1e-4:
                    cw, ch = tile.height, tile.width
                else:
                    cw, ch = tile.width, tile.height
                cw = max(16, min(self.size - 2 * self.gutter, cw))
                ch = max(16, min(self.size - 2 * self.gutter, ch))
                cx = max(self.gutter, min(self.size - cw - self.gutter, cx))
                cy = max(self.gutter, min(self.size - ch - self.gutter, cy))
                self.placements[tile.id] = Placement(cpage, cx, cy, cw, ch, self.gutter, rot, cudim)
                known_udims.add(cudim)
            elif custom and isinstance(custom, dict) and ("udim" in custom or "page" in custom):
                cudim = int(custom.get("udim", 1001 + int(custom.get("page", 0))))
                known_udims.add(cudim)
                unplaced_per_udim.setdefault(cudim, []).append(tile)
            else:
                general_unplaced.append(tile)

        # Pack unplaced tiles for specific UDIMs
        for udim, u_tiles in unplaced_per_udim.items():
            u_tiles.sort(key=lambda t: (-t.height, -t.width, t.id))
            x, y, row_h = self.gutter, self.gutter, 0
            page = udim - 1001
            for tile in u_tiles:
                w, h = tile.width + 2 * self.gutter, tile.height + 2 * self.gutter
                if w > self.size or h > self.size:
                    raise ValueError(f"Tile {tile.name} ({tile.width}x{tile.height}) too large for {self.size}px atlas")
                if x + tile.width + self.gutter > self.size:
                    x = self.gutter
                    y += row_h
                    row_h = 0
                if y + tile.height + self.gutter > self.size:
                    y = max(self.gutter, self.size - tile.height - self.gutter)
                self.placements[tile.id] = Placement(page, x, y, tile.width, tile.height, self.gutter, 0.0, udim)
                x += tile.width + self.gutter
                row_h = max(row_h, tile.height + self.gutter)

        # Pack general unplaced tiles across available UDIMs starting from 1001
        if general_unplaced:
            general_unplaced.sort(key=lambda t: (-t.height, -t.width, t.id))
            current_udim = 1001
            page = current_udim - 1001
            x, y, row_h = self.gutter, self.gutter, 0
            for tile in general_unplaced:
                w, h = tile.width + 2 * self.gutter, tile.height + 2 * self.gutter
                if w > self.size or h > self.size:
                    raise ValueError(f"Tile {tile.name} ({tile.width}x{tile.height}) too large for {self.size}px atlas")
                if x + tile.width + self.gutter > self.size:
                    x = self.gutter
                    y += row_h
                    row_h = 0
                if y + tile.height + self.gutter > self.size:
                    current_udim += 1
                    page = current_udim - 1001
                    x, y, row_h = self.gutter, self.gutter, 0
                self.placements[tile.id] = Placement(page, x, y, tile.width, tile.height, self.gutter, 0.0, current_udim)
                known_udims.add(current_udim)
                x += tile.width + self.gutter
                row_h = max(row_h, tile.height + self.gutter)

        self.udims = sorted(known_udims)
        max_page = max([p.page for p in self.placements.values()] + [u - 1001 for u in self.udims] + [0])
        self.pages = max_page + 1


class AtlasCache:
    def __init__(self,project: Project):
        self.layout=AtlasLayout(project)
        self._pages:dict[tuple[str,int],Image.Image]={}
        self._tile_version:dict[str,tuple[int,int,int]]={}
        self._channel_versions={}
        self.changed_regions:list[tuple[str,int,tuple[int,int,int,int]]]=[]

    def _page(self,map_name:str,index:int) -> Image.Image:
        if getattr(self,'_cancel',lambda:False)():raise RuntimeError('Export cancelled')
        key=(map_name,index)
        if key not in self._pages and any(self.layout.placements.get(tid) is not None and self.layout.placements[tid].page==index and map_name in descriptor.channels for tid,descriptor in getattr(self,'_gpu_tiles',{}).items()):
            from .fiberbake_x.atlas import compose_page
            self._pages[key]=compose_page(self,map_name,index)
        if key not in self._pages:
            mode="RGBA" if map_name=="color" else ("L" if map_name in ("alpha","depth","ao","roughness","specular","anisotropy","transmission","scatter","iridescence") else "RGB")
            bg=tuple([0]*4) if mode=="RGBA" else (255 if map_name=="ao" else (0 if mode=="L" else (0,0,0)))
            self._pages[key]=Image.new(mode,(self.layout.size,self.layout.size),bg)
        return self._pages[key]

    def update_tile(self, result: RenderResult) -> int:
        """Update the tile only, and record exactly which atlas subrects changed."""
        placement=self.layout.placements.get(result.tile_id)
        if placement is None: raise KeyError(result.tile_id)
        version=(result.revision,result.width,result.height)
        updated=0
        for map_name,im in result.maps.items():
            signature=result.metadata.get('channel_versions',{}).get(map_name,version)
            ckey=(result.tile_id,map_name)
            if self._channel_versions.get(ckey)==signature:continue
            page=self._page(map_name,placement.page)
            rects=result.metadata.get('dirty_regions',{}).get(map_name,[])
            base=result.metadata.get('base_channel_versions',{}).get(map_name)
            # Regions are relative to a particular accepted channel version.
            # If a worker result was dropped or resized, fall back to a full tile.
            rot=float(getattr(placement,'rotation',0.0))%360.0
            partial=(abs(rot)<1e-4 and base is not None and self._channel_versions.get(ckey)==base and
                     im.size==(placement.width,placement.height) and rects and
                     sum((r-l)*(b-t) for l,t,r,b in rects)<placement.width*placement.height*.6 and
                     all(l>0 and t>0 and r<placement.width and b<placement.height for l,t,r,b in rects))
            if partial:
                for l,t,r,b in rects:
                    page.paste(im.crop((l,t,r,b)),(placement.x+l,placement.y+t))
                    self.changed_regions.append((map_name,placement.page,
                        (placement.x+l,placement.y+t,placement.x+r,placement.y+b)))
                self._channel_versions[ckey]=signature
                updated+=1
                continue
            if abs(rot)>=1e-4:
                if abs(rot-90.0)<1e-4:
                    im=im.transpose(Image.Transpose.ROTATE_90)
                elif abs(rot-180.0)<1e-4:
                    im=im.transpose(Image.Transpose.ROTATE_180)
                elif abs(rot-270.0)<1e-4:
                    im=im.transpose(Image.Transpose.ROTATE_270)
                else:
                    im=im.rotate(rot,expand=False,resample=Image.Resampling.BILINEAR)
            if im.size!=(placement.width,placement.height):
                im=im.resize((placement.width,placement.height),Image.Resampling.NEAREST if map_name in ('id','cluster_id','material_id') else Image.Resampling.BILINEAR)
            # Remove stale padding before new image is written.
            pad=placement.gutter
            lx,ly=placement.x,placement.y
            region=(lx-pad,ly-pad,lx+placement.width+pad,ly+placement.height+pad)
            if map_name=="ao": bg=255
            elif page.mode=="RGBA":bg=(0,0,0,0)
            elif page.mode=="RGB":bg=(0,0,0)
            else:bg=0
            page.paste(Image.new(page.mode,(region[2]-region[0],region[3]-region[1]),bg),region[:2])
            page.paste(im,(lx,ly))
            # Expand nearest tile border into gutter for mip/filter isolation;
            # padding is NOT part of any card's UV rectangle.
            if pad:
                page.paste(im.crop((0,0,1,placement.height)).resize((pad,placement.height)),(lx-pad,ly))
                page.paste(im.crop((placement.width-1,0,placement.width,placement.height)).resize((pad,placement.height)),(lx+placement.width,ly))
                page.paste(im.crop((0,0,placement.width,1)).resize((placement.width,pad)),(lx,ly-pad))
                page.paste(im.crop((0,placement.height-1,placement.width,placement.height)).resize((placement.width,pad)),(lx,ly+placement.height))
                for px,py,sx,sy in [ (lx-pad,ly-pad,0,0), (lx+placement.width,ly-pad,placement.width-1,0),
                                      (lx-pad,ly+placement.height,0,placement.height-1),
                                      (lx+placement.width,ly+placement.height,placement.width-1,placement.height-1)]:
                    page.paste(Image.new(page.mode,(pad,pad),im.getpixel((sx,sy))),(px,py))
            self.changed_regions.append((map_name,placement.page,region))
            self._channel_versions[ckey]=signature
            updated+=1
        self._tile_version[result.tile_id]=version
        return updated

    def staged_tile(self,result):
        """Worker-side copy-on-write pages, atomically published as one revision.

        Readers retain an immutable previous page set. Only changed channel pages
        are copied; no full atlas composition is performed on the Tk thread.
        """
        if result.metadata.get('gpu_descriptor') is not None:
            from .fiberbake_x.atlas import stage
            return stage(self,result)
        staged=object.__new__(AtlasCache)
        staged._gpu_tiles=dict(getattr(self,'_gpu_tiles',{}));staged._gpu_tiles.pop(result.tile_id,None)
        staged._cpu_pages=dict(getattr(self,'_cpu_pages',{}))
        staged.layout=self.layout
        staged._pages=self._pages.copy()
        staged._tile_version=self._tile_version.copy()
        staged._channel_versions=self._channel_versions.copy()
        staged.changed_regions=[]
        placement=self.layout.placements.get(result.tile_id)
        if placement is None:return staged
        version=(result.revision,result.width,result.height)
        for channel in result.maps:
            sig=result.metadata.get('channel_versions',{}).get(channel,version)
            key=(channel,placement.page)
            if self._channel_versions.get((result.tile_id,channel))!=sig and key in staged._pages:
                staged._pages[key]=staged._pages[key].copy()
        staged.update_tile(result)
        for channel in result.maps:
            if placement is not None and (channel,placement.page) in staged._pages:staged._cpu_pages[channel,placement.page]=staged._pages[channel,placement.page]
        return staged

    def relocated(self,layout,cancel=lambda:False,order=None):
        """Reuse tile bodies and rebuild only affected pages, never source fibers."""
        descriptors=getattr(self,'_gpu_tiles',{})
        if descriptors and set(self._tile_version)<=set(descriptors):
            target=object.__new__(AtlasCache);target.layout=layout;target._pages={};target._cpu_pages={}
            target._gpu_tiles={tid:value for tid,value in descriptors.items() if tid in layout.placements}
            target._tile_version={tid:version for tid,version in self._tile_version.items() if tid in layout.placements}
            target._channel_versions={key:version for key,version in self._channel_versions.items() if key[0] in layout.placements};target.changed_regions=[]
            return target,set(layout.placements)-set(target._gpu_tiles)
        target=object.__new__(AtlasCache);target._gpu_tiles=dict(descriptors);target._cpu_pages=dict(getattr(self,'_cpu_pages',{}));target.layout=layout;target._pages=self._pages.copy();target._tile_version=self._tile_version.copy();target._channel_versions=self._channel_versions.copy();target.changed_regions=list(self.changed_regions)
        old=self.layout.placements;new=layout.placements;changed={tid for tid in set(old)|set(new) if old.get(tid)!=new.get(tid)}
        if self.layout.size!=layout.size:
            target._pages={};target._tile_version={};target._channel_versions={};return target,set(new)
        invalid={tid for tid in changed if tid not in old or tid not in new or (old[tid].width,old[tid].height,old[tid].rotation)!=(new[tid].width,new[tid].height,new[tid].rotation)}
        # Padded gutters overlap normally; only overlapping BODY pixels lose source.
        for tid in changed:
            if tid not in old:continue
            a=old[tid]
            for other,p in old.items():
                if other!=tid and p.page==a.page and a.x<p.x+p.width and a.x+a.width>p.x and a.y<p.y+p.height and a.y+a.height>p.y:invalid.update((tid,other))
        pages={p.page for tid in changed for p in (old.get(tid),new.get(tid)) if p is not None}
        target._pages={key:image for key,image in target._pages.items() if key[1] not in pages}
        ordered=list(order or new);ordered.extend(tid for tid in new if tid not in set(ordered))
        for tid in ordered:
            p=new.get(tid);source_p=old.get(tid)
            if p is None or source_p is None or p.page not in pages or tid in invalid:continue
            for (tile_id,channel),version in self._channel_versions.items():
                if tile_id!=tid:continue
                if cancel():raise RuntimeError('Atlas relocation cancelled')
                source=self._pages.get((channel,source_p.page)) or getattr(self,'_cpu_pages',{}).get((channel,source_p.page))
                if source is None:continue
                image=source.crop((source_p.x,source_p.y,source_p.x+source_p.width,source_p.y+source_p.height))
                page=target._page(channel,p.page);x,y,w,h,pad=p.x,p.y,p.width,p.height,p.gutter
                area=(x-pad,y-pad,x+w+pad,y+h+pad);bg=255 if channel=='ao' else (0 if page.mode=='L' else (0,)*len(page.getbands()))
                page.paste(bg,area);page.paste(image,(x,y))
                if pad:
                    page.paste(image.crop((0,0,1,h)).resize((pad,h)),(x-pad,y));page.paste(image.crop((w-1,0,w,h)).resize((pad,h)),(x+w,y))
                    page.paste(image.crop((0,0,w,1)).resize((w,pad)),(x,y-pad));page.paste(image.crop((0,h-1,w,h)).resize((w,pad)),(x,y+h))
                    for px,py,sx,sy in ((x-pad,y-pad,0,0),(x+w,y-pad,w-1,0),(x-pad,y+h,0,h-1),(x+w,y+h,w-1,h-1)):page.paste(Image.new(page.mode,(pad,pad),image.getpixel((sx,sy))),(px,py))
                target.changed_regions.append((channel,p.page,area))
        for tid in invalid:
            target._tile_version.pop(tid,None)
            for key in list(target._channel_versions):
                if key[0]==tid:target._channel_versions.pop(key,None)
        used={p.page for p in new.values()};target._pages={key:image for key,image in target._pages.items() if key[1] in used}
        return target,invalid

    def get_page(self,name:str,page:int=0) -> Image.Image:
        return self._page(name,page)

    def get_udim_page(self, name: str, udim: int) -> Image.Image:
        return self._page(name, self.layout.udim_to_page(udim))

    def write(self, out_dir: str | Path, project: Project, names=MAP_NAMES, mode: str = "udim") -> list[Path]:
        dest = Path(out_dir)
        dest.mkdir(parents=True, exist_ok=True)
        paths = []
        udims = getattr(self.layout, "udims", None) or [1001 + p for p in range(self.layout.pages)]
        if not udims:
            udims = [1001]

        if mode == "texture_set":
            ts_meta = {}
            for udim in udims:
                page = self.layout.udim_to_page(udim)
                ts_folder = dest / f"TextureSet_{udim}"
                ts_folder.mkdir(parents=True, exist_ok=True)
                maps_dict = {}
                for name in names:
                    fn = f"{name}.png"
                    p_file = ts_folder / fn
                    self._page(name, page).save(p_file, optimize=True)
                    paths.append(p_file)
                    maps_dict[name] = f"TextureSet_{udim}/{fn}"
                tiles_in_udim = [
                    {"tile_id": tid, "name": project.find(tid).name if project.find(tid) else tid, **p.to_dict(self.layout.size)}
                    for tid, p in self.layout.placements.items() if getattr(p, "udim", 1001 + p.page) == udim
                ]
                ts_meta[f"TextureSet_{udim}"] = {
                    "udim": udim,
                    "material": f"Fiber_TextureSet_{udim}",
                    "maps": maps_dict,
                    "tiles": tiles_in_udim,
                }
            manifest_path = dest / "FSD_TextureSets_manifest.json"
            manifest_data = {
                "generator": "Fiber Strand Designer",
                "format": "texture_set",
                "atlas_size": self.layout.size,
                "padding_px": self.layout.gutter,
                "udims": udims,
                "texture_sets": ts_meta,
            }
            manifest_path.write_text(json.dumps(manifest_data, ensure_ascii=False, indent=2), encoding="utf-8")
            paths.append(manifest_path)
        else:
            for udim in udims:
                page = self.layout.udim_to_page(udim)
                for name in names:
                    fn_udim = f"FSD_Atlas_{name}.{udim}.png"
                    path_udim = dest / fn_udim
                    self._page(name, page).save(path_udim, optimize=True)
                    paths.append(path_udim)
                    fn_legacy = f"FSD_Atlas_{page:02d}_{name}.png"
                    if fn_legacy != fn_udim:
                        path_leg = dest / fn_legacy
                        self._page(name, page).save(path_leg, optimize=True)
                        paths.append(path_leg)

        metadata = {
            "generator": "Fiber Strand Designer",
            "format": mode,
            "atlas_size": self.layout.size,
            "padding_px": self.layout.gutter,
            "pages": self.layout.pages,
            "udims": udims,
            "maps": list(names),
            "tiles": {
                tile.id: {"name": tile.name, "kind": tile.kind, **self.layout.placements[tile.id].to_dict(self.layout.size)}
                for tile in project.tiles if tile.id in self.layout.placements
            },
        }
        path_manifest = dest / "FSD_Atlas_manifest.json"
        path_manifest.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
        paths.append(path_manifest)
        return paths


def write_tile_maps(folder:str|Path,tile:Tile,result:RenderResult) -> list[Path]:
    """Optional independent tile cache files for downstream texture consumers."""
    safe=re.sub(r"[^a-zA-Z0-9_-]+","_",tile.name).strip("_")[:40] or "Tile"
    dest=Path(folder)/"Tiles"/f"{tile.id}_{safe}"
    dest.mkdir(parents=True,exist_ok=True)
    paths=[]
    for name,im in result.maps.items():
        path=dest/f"{name}.png";im.save(path,optimize=True);paths.append(path)
    info={"tile_id":tile.id,"name":tile.name,"kind":tile.kind,
          "width":result.width,"height":result.height,"revision":result.revision,
          "generated_strands":len(result.strands),"maps":list(result.maps)}
    info['engine']=result.metadata.get('engine','legacy')
    info['source_versions']=result.metadata.get('source_versions',{})
    info['id_table']=result.metadata.get('id_table',{})
    info['representation']=result.metadata.get('note','')
    path=dest/"tile_manifest.json"
    path.write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding="utf-8")
    paths.append(path)
    return paths
