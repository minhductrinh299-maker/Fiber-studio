"""Opaque model pass shared by Card Editor and Render Studio GL contexts."""
from pathlib import Path
import ctypes as C
import numpy as np
from PIL import Image
from .rendercore.glapi import *

VERT='''#version 330 core
layout(location=0) in vec3 position;
layout(location=1) in vec3 normal;
layout(location=2) in vec2 uv;
uniform mat4 mvp;
uniform vec3 offset;
uniform float scale;
uniform mat4 uLightMVP;
out vec4 vLightClip;
out vec3 N;out vec3 P;out vec2 UV;
void main(){P=position*scale+offset;N=normal;UV=uv;gl_Position=mvp*vec4(P,1);vLightClip=uLightMVP*vec4(P,1);}
'''
FRAG='''#version 330 core
in vec3 N;in vec3 P;in vec2 UV;out vec4 color;
uniform sampler2D albedo;uniform sampler2D normalMap;uniform sampler2D roughMap;
uniform sampler2D alphaMap;uniform sampler2D specMap;
uniform sampler2D metalMap;uniform sampler2D aoMap;uniform sampler2D emissionMap;
uniform int hasMetal;uniform int hasAO;uniform int hasEmission;
uniform int hasColor;uniform int hasNormal;uniform int hasRough;uniform int hasAlpha;uniform int hasSpec;
uniform vec3 base;uniform float roughness;uniform vec3 eye;uniform vec3 light;
uniform vec3 keyColor;uniform vec3 fillColor;uniform vec3 ambientColor;
in vec4 vLightClip;
uniform sampler2D uShadowDensity,uShadowDensityFar;
uniform int uShadowEnabled,uShadowFast;
uniform float uShadowStrength,uShadowBias,uLightSize,uShadowKnots[9];
// FSD_DEEP_SHADOW_INCLUDE
// FSD_SURFACE_OPTICS_INCLUDE
void main(){
 vec4 pigment=hasColor!=0?texture(albedo,UV):vec4(1);
 float alpha=pigment.a*(hasAlpha!=0?texture(alphaMap,UV).r:1.);
 if(alpha<.5)discard;
 vec3 n=normalize(N);if(!gl_FrontFacing)n=-n;
 if(hasNormal!=0){
  vec3 dp1=dFdx(P),dp2=dFdy(P);vec2 du1=dFdx(UV),du2=dFdy(UV);
  float determinant=du1.x*du2.y-du1.y*du2.x;
  if(abs(determinant)>1e-9){
   vec3 t=normalize((dp1*du2.y-dp2*du1.y)/determinant);
   vec3 b=normalize((-dp1*du2.x+dp2*du1.x)/determinant);
   n=normalize(mat3(t,b,n)*(texture(normalMap,UV).xyz*2.-1.));
  }
 }
 vec3 l=normalize(light),v=normalize(eye-P),h=normalize(v+l);
 vec3 fillL=normalize(vec3(-l.x*0.85,max(0.20,l.y*0.45),-l.z*0.85));
 float r=clamp(hasRough!=0?texture(roughMap,UV).r:roughness,0.06,0.98);
 float spec=hasSpec!=0?texture(specMap,UV).r:.28;
 float metal=clamp(hasMetal!=0?texture(metalMap,UV).r:0.,0.,1.);
 float ao=hasAO!=0?texture(aoMap,UV).r:1.;
 vec3 albedoLin=base*pigment.rgb;
 float ndlWrap=pow(clamp((dot(n,l)+0.18)/1.18,0.,1.),1.08);
 float ndFill=max(0.,dot(n,fillL));
 float hemi=clamp(0.48+0.42*n.y,0.18,0.96);
 vec3 diffuse=albedoLin*(1.-metal)*(ambientColor*ao*hemi+keyColor*fsdVisibility(vLightClip)*0.85*ndlWrap+fillColor*0.58*ndFill*ao);
 // GGX specular + Schlick Fresnel + subtle rim grazing reflection
 float a=r*r;float a2=a*a;
 float ndh=max(0.,dot(n,h));float ndv=max(0.001,dot(n,v));float ndl=max(0.001,dot(n,l));
 float denom=ndh*ndh*(a2-1.)+1.;
 float D=a2/max(0.001,3.14159*denom*denom);
 float k=(r+1.)*(r+1.)*0.125;
 float G=(ndv/(ndv*(1.-k)+k))*(ndl/(ndl*(1.-k)+k));
 vec3 F0=mix(vec3(0.04*spec*2.),albedoLin,metal);
 vec3 F=F0+(1.-F0)*pow(1.-max(0.,dot(v,h)),5.);
 vec3 reflection=keyColor*fsdVisibility(vLightClip)*(D*G*F)/(4.*ndv*ndl+0.001)*ndl*0.85;
 float rimFresnel=pow(1.-ndv,4.)*(1.-r*0.7);
 reflection+=(ambientColor*0.18+fillColor*0.16)*F0*rimFresnel*ao;
 vec3 emission=hasEmission!=0?texture(emissionMap,UV).rgb:vec3(0.);
 color=vec4(diffuse+reflection+emission,1.);
 if(uPhysical!=0){
  F0=mix(vec3(.04),albedoLin,metal);
  float pdf;
  vec3 direct=sarea(n,v,l,albedoLin,metal,r,F0)*keyColor*fsdVisibility(vLightClip);
  direct+=seval(n,v,fillL,albedoLin,metal,r,F0,pdf)*fillColor;
  color=vec4(direct+senvironment(n,v,albedoLin,metal,r,F0)*ao+emission,1.);
 }
}'''


FRAG=FRAG.replace('// FSD_DEEP_SHADOW_INCLUDE',
                  (Path(__file__).parent/'rendercore/shaders/deep_shadow.glsl').read_text(encoding='utf-8')).replace(
                  '// FSD_SURFACE_OPTICS_INCLUDE',
                  (Path(__file__).parent/'rendercore/shaders/surface_optics.glsl').read_text(encoding='utf-8'))

SHADOW_FRAG='''#version 330 core
in vec2 UV;uniform sampler2D albedo,alphaMap;uniform int hasColor,hasAlpha;
void main(){float a=hasColor!=0?texture(albedo,UV).a:1.;if(hasAlpha!=0)a*=texture(alphaMap,UV).r;if(a<.5)discard;}
'''


class ReferenceRenderer:
    def __init__(self,gl):
        self.gl=gl
        self.program=gl.program(VERT,FRAG);self.resources={};self.size=None
        self.shadow_fbo=self.shadow_depth=0;self.shadow_resolution=0
        self.shadow_program=gl.program(VERT,SHADOW_FRAG)
        self.project=None
        self.pending=False
        self.fbo=self.color=self.depth=0
        self.history=[];self.history_fbo=0;self.history_size=None
        self.history_index=0;self.history_count=0;self.history_key=None;self.display_color=0

    def history_targets(self,width,height):
        if self.history_size==(width,height):return
        self.release_history();g=self.gl
        self.history_fbo=g.name('Framebuffers')
        for _ in range(2):
            texture=g.name('Textures');self.history.append(texture)
            g.glBindTexture(GL_TEXTURE_2D,texture)
            g.glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA32F,width,height,0,GL_RGBA,GL_FLOAT,None)
            for p,v in ((GL_TEXTURE_MIN_FILTER,GL_LINEAR),(GL_TEXTURE_MAG_FILTER,GL_LINEAR),(GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE),(GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE)):g.glTexParameteri(GL_TEXTURE_2D,p,v)
        g.glBindFramebuffer(GL_FRAMEBUFFER,self.history_fbo)
        g.glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,self.history[0],0)
        g.glDrawBuffer(GL_COLOR_ATTACHMENT0)
        if g.glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE:raise RuntimeError('Surface history framebuffer incomplete')
        self.history_size=(width,height);self.history_count=0;self.history_key=None

    def release_history(self):
        g=self.gl
        for texture in self.history:
            v=U(texture);g.glDeleteTextures(1,C.byref(v))
        if self.history_fbo:v=U(self.history_fbo);g.glDeleteFramebuffers(1,C.byref(v))
        self.history=[];self.history_fbo=0;self.history_size=None;self.display_color=0

    def delete_resource(self,resource):
        g=self.gl
        for kind,ids in [('Buffers',[resource['vbo']]),('VertexArrays',[resource['vao']]),('Textures',list(resource['textures'].values()))]:
            for name in ids:value=U(name);getattr(g,'glDelete'+kind)(1,C.byref(value))

    def targets(self,width,height):
        if self.size==(width,height):return
        g=self.gl
        g.glActiveTexture(GL_TEXTURE0)
        for kind,ids in [('Framebuffers',[self.fbo]),('Textures',[self.color,self.depth])]:
            for name in ids:
                if name:value=U(name);getattr(g,'glDelete'+kind)(1,C.byref(value))
        self.fbo=g.name('Framebuffers');self.color=g.name('Textures');self.depth=g.name('Textures')
        g.glBindFramebuffer(GL_FRAMEBUFFER,self.fbo)
        for texture,internal,fmt,attachment in ((self.color,GL_RGBA32F,GL_RGBA,GL_COLOR_ATTACHMENT0),
                                               (self.depth,GL_DEPTH_COMPONENT24,GL_DEPTH_COMPONENT,GL_DEPTH_ATTACHMENT)):
            g.glBindTexture(GL_TEXTURE_2D,texture)
            g.glTexImage2D(GL_TEXTURE_2D,0,internal,width,height,0,fmt,GL_FLOAT,None)
            for p,v in ((GL_TEXTURE_MIN_FILTER,GL_NEAREST),(GL_TEXTURE_MAG_FILTER,GL_NEAREST),
                        (GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE),(GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE)):
                g.glTexParameteri(GL_TEXTURE_2D,p,v)
            g.glFramebufferTexture2D(GL_FRAMEBUFFER,attachment,GL_TEXTURE_2D,texture,0)
        g.glDrawBuffer(GL_COLOR_ATTACHMENT0)
        if g.glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE:raise RuntimeError('Model framebuffer incomplete')
        self.size=(width,height)

    def upload(self,prepared):
        g=self.gl;vao=g.name('VertexArrays');vbo=g.name('Buffers');data=prepared['data']
        g.glActiveTexture(GL_TEXTURE0)
        resource=dict(vao=vao,vbo=vbo,count=len(data),textures={},signature=prepared['signature'],cost=prepared['cost'])
        try:
            g.glBindVertexArray(vao);g.glBindBuffer(GL_ARRAY_BUFFER,vbo)
            g.glBufferData(GL_ARRAY_BUFFER,data.nbytes,V(data.ctypes.data),GL_STATIC_DRAW)
            for location,count,offset in ((0,3,0),(1,3,12),(2,2,24)):
                g.glEnableVertexAttribArray(location);g.glVertexAttribPointer(location,count,GL_FLOAT,GL_FALSE,32,V(offset))
            for channel,image in prepared['images'].items():
                name=g.name('Textures');resource['textures'][channel]=name
                g.glBindTexture(GL_TEXTURE_2D,name)
                payload=image.transpose(Image.Transpose.FLIP_TOP_BOTTOM).tobytes()
                g.glTexImage2D(GL_TEXTURE_2D,0,0x8C43 if channel in ('color','emission') else GL_RGBA8,
                               image.width,image.height,0,GL_RGBA,GL_UNSIGNED_BYTE,C.c_char_p(payload))
                g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR)
                g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR)
                g.glGenerateMipmap(GL_TEXTURE_2D)
            return resource
        except Exception:
            self.delete_resource(resource);raise

    def render(self,workspace,mvp,eye,light,width,height,material,prepare_only=False):
        p=self.shadow_program if prepare_only else self.program
        g=self.gl;objects=workspace.evaluated_objects()
        if self.project is not workspace.app.project:
            for resource in self.resources.values():self.delete_resource(resource)
            self.resources={};self.project=workspace.app.project
        live={o['id'] for o in objects if o.get('visible',True)}
        for key in set(self.resources)-live:self.delete_resource(self.resources.pop(key))
        self.targets(width,height)
        g.glBindFramebuffer(GL_FRAMEBUFFER,self.fbo);g.glViewport(0,0,width,height)
        g.glDisable(GL_BLEND);g.glEnable(GL_DEPTH_TEST);g.glDepthFunc(GL_LESS)
        g.glDisable(GL_CULL_FACE);g.glClearDepth(1.)
        g.glClearBufferfv(GL_COLOR,0,(F*4)(0,0,0,0));g.glClear(GL_DEPTH_BUFFER_BIT)
        g.glUseProgram(p)
        matrix=np.ascontiguousarray(mvp,dtype=np.float32)
        g.glUniformMatrix4fv(g.glGetUniformLocation(p,b'mvp'),1,GL_TRUE,matrix.ctypes.data_as(C.POINTER(F)))
        g.uniform(p,'eye',tuple(eye));g.uniform(p,'light',tuple(light))
        g.uniform(p,'keyColor',tuple(np.asarray(material.key_color)*material.light_intensity))
        g.uniform(p,'fillColor',tuple(np.asarray(material.fill_color)*material.fill_intensity))
        g.uniform(p,'ambientColor',tuple(np.asarray(material.ambient_color)*material.ambient_intensity))
        uploaded=False;visible=False;self.pending=False
        for obj in objects:
            if not obj.get('visible',True):continue
            prepared=workspace.prepared.get(obj['id'])
            resource=self.resources.get(obj['id'])
            if resource is None and prepared is None:workspace.require(obj['id'])
            if prepared and resource is None and uploaded:self.pending=True
            if prepared and resource is not None and resource['signature']!=prepared['signature'] and uploaded:self.pending=True
            if prepared and not uploaded and (resource is None or resource['signature']!=prepared['signature']):
                if sum(r['cost'] for key,r in self.resources.items() if key!=obj['id'])+prepared['cost']>384*1024**2:
                    if workspace.window and workspace.window.winfo_exists():
                        workspace.window.status.set('Model GPU budget 384 MiB exceeded; hide unused models or use smaller textures.')
                    if resource is None:continue
                else:
                    if resource and resource['signature'][1]==prepared['signature'][1] and resource['count']==len(prepared['data']):
                        data=prepared['data'];g.glBindBuffer(GL_ARRAY_BUFFER,resource['vbo'])
                        g.glBufferData(GL_ARRAY_BUFFER,data.nbytes,None,GL_DYNAMIC_DRAW)
                        g.glBufferSubData(GL_ARRAY_BUFFER,0,data.nbytes,V(data.ctypes.data))
                        resource['signature']=prepared['signature']
                    else:
                        replacement=self.upload(prepared)
                        if resource:self.delete_resource(resource)
                        resource=self.resources[obj['id']]=replacement
                    uploaded=True
                    g.glUseProgram(p)
            if resource is None:continue
            visible=True;mat=obj['material']
            g.uniform(p,'offset',tuple(obj.get('position',[0.,0.,0.])))
            g.uniform(p,'scale',float(obj.get('scale',1.)))
            # Material base color is stored as display/sRGB values.
            base=np.asarray(mat.get('color',[.5,.5,.5]),float)
            base=np.where(base<=.04045,base/12.92,((base+.055)/1.055)**2.4)
            g.uniform(p,'base',tuple(base));g.uniform(p,'roughness',float(mat.get('roughness',.55)))
            for unit,(channel,sampler,flag) in enumerate((('color','albedo','hasColor'),('normal','normalMap','hasNormal'),
                ('roughness','roughMap','hasRough'),('alpha','alphaMap','hasAlpha'),('specular','specMap','hasSpec'),
                ('metallic','metalMap','hasMetal'),('ao','aoMap','hasAO'),('emission','emissionMap','hasEmission'))):
                g.glActiveTexture(GL_TEXTURE0+unit);g.glBindTexture(GL_TEXTURE_2D,resource['textures'].get(channel,0))
                g.uniform(p,sampler,unit);g.uniform(p,flag,int(channel in resource['textures']))
            g.glBindVertexArray(resource['vao']);g.glDrawArrays(GL_TRIANGLES,0,resource['count'])
        g.glDisable(GL_DEPTH_TEST);g.glBindFramebuffer(GL_FRAMEBUFFER,0)
        return visible

    def render_shadow(self,workspace,mvp,resolution):
        g=self.gl
        if self.shadow_resolution!=resolution:
            for kind,name in (('Textures',self.shadow_depth),('Framebuffers',self.shadow_fbo)):
                if name:v=U(name);getattr(g,'glDelete'+kind)(1,C.byref(v))
            self.shadow_depth=g.name('Textures');self.shadow_fbo=g.name('Framebuffers')
            g.glBindTexture(GL_TEXTURE_2D,self.shadow_depth)
            g.glTexImage2D(GL_TEXTURE_2D,0,GL_DEPTH_COMPONENT24,resolution,resolution,0,GL_DEPTH_COMPONENT,GL_UNSIGNED_INT,None)
            for par,val in ((GL_TEXTURE_MIN_FILTER,GL_NEAREST),(GL_TEXTURE_MAG_FILTER,GL_NEAREST),(GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE),(GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE)):g.glTexParameteri(GL_TEXTURE_2D,par,val)
            g.glBindFramebuffer(GL_FRAMEBUFFER,self.shadow_fbo)
            g.glFramebufferTexture2D(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_TEXTURE_2D,self.shadow_depth,0)
            g.glDrawBuffer(GL_NONE);g.glReadBuffer(GL_NONE)
            if g.glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE:raise RuntimeError('Opaque shadow framebuffer incomplete')
            self.shadow_resolution=resolution
        g.glBindFramebuffer(GL_FRAMEBUFFER,self.shadow_fbo);g.glViewport(0,0,resolution,resolution)
        g.glDisable(GL_BLEND);g.glDisable(GL_CULL_FACE);g.glEnable(GL_DEPTH_TEST);g.glDepthFunc(GL_LESS)
        g.glClearDepth(1.);g.glClear(GL_DEPTH_BUFFER_BIT);g.glUseProgram(self.shadow_program)
        matrix=np.ascontiguousarray(mvp,np.float32)
        g.glUniformMatrix4fv(g.glGetUniformLocation(self.shadow_program,b'mvp'),1,GL_TRUE,matrix.ctypes.data_as(C.POINTER(F)))
        for obj in workspace.evaluated_objects():
            resource=self.resources.get(obj['id'])
            if not resource or not obj.get('visible',True):continue
            g.uniform(self.shadow_program,'offset',tuple(obj.get('position',[0,0,0])));g.uniform(self.shadow_program,'scale',float(obj.get('scale',1.)))
            for unit,(channel,sampler,flag) in enumerate((('color','albedo','hasColor'),('alpha','alphaMap','hasAlpha'))):
                g.glActiveTexture(GL_TEXTURE0+unit);g.glBindTexture(GL_TEXTURE_2D,resource['textures'].get(channel,0))
                g.uniform(self.shadow_program,sampler,unit);g.uniform(self.shadow_program,flag,int(channel in resource['textures']))
            g.glBindVertexArray(resource['vao']);g.glDrawArrays(GL_TRIANGLES,0,resource['count'])
        g.glDisable(GL_DEPTH_TEST);g.glBindFramebuffer(GL_FRAMEBUFFER,0)

    def close(self):
        g=self.gl
        self.release_history()
        for resource in self.resources.values():self.delete_resource(resource)
        for kind,names in [('Framebuffers',[self.fbo,self.shadow_fbo]),('Textures',[self.color,self.depth,self.shadow_depth]),('Program',[self.program,self.shadow_program])]:
            for name in names:
                if not name:continue
                if kind=='Program':g.glDeleteProgram(name)
                else:value=U(name);getattr(g,'glDelete'+kind)(1,C.byref(value))
