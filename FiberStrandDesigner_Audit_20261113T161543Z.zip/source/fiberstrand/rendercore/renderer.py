"""OpenGL 3.3 GPU hair-card renderer for FSD V4.

R0/R1 prototype: weighted blended multi-layer OIT, flow-oriented fiber lighting,
normal/roughness maps, art-directable angle iridescence, tile-region upload,
float tile-local coverage mips, linear AA resolve and stationary temporal samples.
The render backend is replaceable; this is NOT the D3D12 production implementation.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
from pathlib import Path
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
import ctypes as C
import json
import os
import math
import time
import numpy as np
from PIL import Image
from ..cards import HairCard,ribbon_mesh
from .context import EGLContext,WGLContext
from .glapi import *
from .coverage import TileRect,atlas_mip_chain,max_safe_level
from .sampling import mip_bytes,prepare_tile
from .quality import MODES,ALIASES,render_size,jitter,halton

SHADERS=Path(__file__).parent/'shaders'
CHANNELS=('color','alpha','normal','flow','roughness')

@dataclass
class HairMaterial:
    shading_mode:str="Physical"
    artistic_optics:bool=False
    cuticle_tilt:float=2.
    longitudinal_roughness:float=.3
    azimuthal_roughness:float=.5
    ior:float=1.55
    absorption:float=.6
    environment_path:str=""
    environment_strength:float=.5
    environment_rotation:float=0.
    roughness:float=.40
    specular:float=.67
    secondary:float=.28
    anisotropy:float=.85
    sheen:float=.22
    backlight:float=.20
    iridescence:float=.0
    alpha_gain:float=1.0
    exposure:float=0.0
    light_azimuth:float=40.0
    light_elevation:float=54.0
    light_intensity:float=1.0
    fill_intensity:float=.20
    ambient_intensity:float=.13
    key_color:tuple[float,float,float]=(1.,.965,.92)
    fill_color:tuple[float,float,float]=(.70,.82,1.)
    ambient_color:tuple[float,float,float]=(1.,1.,1.)
    light_size:float=89.33  # full angular source extent, degrees [0, 360]
    key_target:tuple[float,float,float]|None=None
    rim_intensity:float=.65
    rim_color:tuple[float,float,float]=(.55,.72,1.)
    rim_azimuth:float=-140.
    rim_elevation:float=32.
    rim_width:float=.45
    bloom:float=.08
    bloom_threshold:float=.8
    bloom_radius:float=8.
    chroma:float=0.
    desaturate:float=0.
    vignette:float=.12
    noise:float=0.
    noise_size:float=1.
    shadow_strength:float=.45
    scatter_strength:float=.28
    debug:int=0
    checker:bool=False
    alpha_cutoff:float=.5  # diagnostic only; blended beauty never thresholds alpha

@dataclass
class RenderInfo:
    backend:str
    gpu_renderer:str
    gl_version:str
    cards:int=0
    triangles:int=0
    batches:int=0
    atlas_uploads:int=0
    regions_uploaded:int=0
    render_ms:float=0.0
    transparency:str='Weighted Blended OIT'
    peel_passes:int=0
    peel_memory_mib:float=0.0
    gpu_ms:float=-1.0
    quality_policy:str="manual"
    shadow_memory_mib:float=0.0
    coverage_mip_levels:int=0
    render_scale:float=1.
    internal_size:tuple=(0,0)
    physical_size:tuple=(0,0)
    aa_status:str=''
    history_count:int=0
    history_limit:int=1
    history_reason:str='first frame'
    target_memory_mib:float=0.
    tile_memory_mib:float=0.
    texture_upload_ms:float=0.
    cpu_p95_ms:float=0.
    cpu_p99_ms:float=0.
    gpu_p95_ms:float=-1.
    gpu_p99_ms:float=-1.
    allocations:int=0
    oit_gpu_ms:float=-1.
    aa_gpu_ms:float=-1.
    shadow_gpu_ms:float=-1.
    memory_budget_mib:float=0.
    memory_usage_mib:float=0.
    memory_source:str='conservative cap'
    target_budget_mib:float=1024.


def perspective(fov,aspect,near=.02,far=300.):
    f=1./math.tan(fov*.5)
    return np.array([[f/aspect,0,0,0],[0,f,0,0],[0,0,(far+near)/(near-far),(2*far*near)/(near-far)],
                     [0,0,-1,0]],np.float32)

def orthographic(left,right,bottom,top,near,far):
    return np.array([[2/(right-left),0,0,-(right+left)/(right-left)],
                     [0,2/(top-bottom),0,-(top+bottom)/(top-bottom)],
                     [0,0,-2/(far-near),-(far+near)/(far-near)],
                     [0,0,0,1]],dtype=np.float32)

def look_at(eye,target,up=(0.,1.,0.)):
    eye=np.asarray(eye,np.float32);target=np.asarray(target,np.float32)
    forward=target-eye;forward/=max(np.linalg.norm(forward),1e-8)
    right=np.cross(forward,np.asarray(up,np.float32));right/=max(np.linalg.norm(right),1e-8)
    u=np.cross(right,forward)
    view=np.eye(4,dtype=np.float32)
    view[0,:3]=right;view[1,:3]=u;view[2,:3]=-forward
    view[:3,3]=-view[:3,:3]@eye
    return view


def _as_card(item):
    return item if isinstance(item,HairCard) else HairCard.from_dict(item)

class GPUHairRenderer:
    """Owns GPU device for one preview viewport; use only from owning thread."""
    def __init__(self,width=900,height=570,hwnd=None,async_sampling=False,native_owner="tk"):
        self.width=max(32,int(width));self.height=max(32,int(height))
        self.display_width,self.display_height=self.width,self.height
        self.quality_mode='Lookdev';self.scale_override=None;self.aa_method='Temporal'
        self.interacting=False;self._history_key=None;self._history_count=0;self._history_index=0
        self._post_textures=[];self._post_fbos=[];self._reference=0;self._reference_key=None
        self._previous_mvp=np.eye(4,dtype=np.float32)
        self._previous_card_vertices={};self._motion_geometry_pending=False
        self._geometry_revision=0;self._atlas_revision=0
        self._tile_textures={};self._tile_regions={};self._dirty_tiles=set()
        self._tile_memory={};self._cpu_samples=[];self._gpu_samples=[]
        self._sampling_worker=ThreadPoolExecutor(max_workers=1,thread_name_prefix='coverage-mips') if async_sampling else None
        self._sampling_jobs={}
        self._target_allocations=0;self._oit_samples=1
        self._fiberbake_device=None;self._gpu_sampling_miss=set()
        if hwnd is not None:
            from ..fiberbake_x.service import peek_device
            candidate=peek_device()
            try:
                self.context=WGLContext(hwnd,self.width,self.height,install_tk_paint_hook=native_owner=="tk",share_with=candidate.context if candidate else None)
                self._fiberbake_device=candidate
            except Exception:
                if candidate is None:raise
                self.context=WGLContext(hwnd,self.width,self.height,install_tk_paint_hook=native_owner=="tk")
        else:self.context=EGLContext(self.width,self.height)
        self.context.activate()
        self.gl=GL(self.context)
        self.material=HairMaterial()
        self.yaw=0.0;self.pitch=.1;self.distance=4.1;self.target=np.array([0.,.48,0.],np.float32)
        self._atlas_size=0
        self._tile_rects=[]
        self._atlas_sources={}
        self._mip_limit=0
        self._shadow_texture=0
        self._shadow_fbo=0
        self._shadow_resolution=1024
        self._page_textures={}
        self._batches={}
        self._programs=[]
        self._images={}
        self._closed=False
        self.transparency_mode='weighted'
        self._quality_counter=0
        self._gpu_ema_ms=0.0
        self._gpu_queries=[]
        self._pass_queries=[];self._pass_frame=0
        self._gpu_query_frame=0
        self.peel_layers=2
        self._peel_colors=[];self._peel_depths=[];self._peel_fbo=0
        self._layer_targets=[];self._layer_history_index=0
        self._sample_serial=0;self._resolved_layers=[]
        self._card_numeric_ids={}
        self.up_axis='Y-Up'
        self.show_hud=False
        self.show_axis_gizmo=False
        self.hud_lines=()
        self.hud_dpr=1.0
        self._overlay_hud=None
        try:self._init_gpu()
        except Exception:
            if self._sampling_worker:self._sampling_worker.shutdown(wait=False,cancel_futures=True)
            self.context.close();self._closed=True
            raise
        self.info=RenderInfo('WGL direct window' if hwnd is not None else 'EGL offscreen',self.gl.renderer,self.gl.version)
        n=I();self.gl.glGetIntegerv(GL_MAX_TEXTURE_SIZE,C.byref(n));self._max_texture_size=max(32,n.value)
        self.gl.glGetIntegerv(GL_MAX_COLOR_TEXTURE_SAMPLES,C.byref(n));self._max_samples=n.value
        self._anisotropy=1.
        self.gl.glGetIntegerv(GL_NUM_EXTENSIONS,C.byref(n))
        extensions={(self.gl.glGetStringi(GL_EXTENSIONS,i) or b'').decode() for i in range(n.value)}
        self.extensions=extensions
        if 'GL_EXT_texture_filter_anisotropic' in extensions or 'GL_ARB_texture_filter_anisotropic' in extensions:
            value=F();self.gl.glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT,C.byref(value))
            self._anisotropy=min(8.,value.value)
        self._configure_resolution()

    def _init_gpu(self):
        g=self.gl
        hair_source=(SHADERS/'hair.frag').read_text(encoding='utf-8').replace('// FSD_DEEP_SHADOW_INCLUDE',(SHADERS/'deep_shadow.glsl').read_text(encoding='utf-8')).replace('// FSD_HAIR_OPTICS_INCLUDE',(SHADERS/'hair_optics.glsl').read_text(encoding='utf-8'))
        vert=(SHADERS/'hair.vert').read_text()
        self.hq_available=os.environ.get('FSD_RENDER_LEGACY','0')!='1'
        self.backend_fallback=''
        if self.hq_available:
            try:
                self.hair_program=g.program(vert,hair_source)
                self.peel_program=g.program(vert,hair_source.replace('#version 330 core','#version 330 core\n#define FSD_PEEL_PASS 1',1))
            except RuntimeError as error:
                if getattr(self,'hair_program',0):g.glDeleteProgram(self.hair_program);self.hair_program=0
                self.hq_available=False;self.backend_fallback='HQ shader rejected by driver: '+str(error)
        if not self.hq_available:
            hair_source=(SHADERS/'hair_legacy.frag').read_text(encoding='utf-8')
            self.hair_program=g.program(vert,hair_source)
            self.peel_program=g.program(vert,hair_source.replace('#version 330 core','#version 330 core\n#define FSD_PEEL_PASS 1',1))
            if not self.backend_fallback:self.backend_fallback='Legacy backend explicitly selected'
        self.shadow_program=g.program(vert,(SHADERS/'shadow_density.frag').read_text())
        self.composite_program=g.program((SHADERS/'composite.vert').read_text(),(SHADERS/'composite.frag').read_text())
        self.hybrid_composite_program=g.program((SHADERS/'composite.vert').read_text(),(SHADERS/'composite_hybrid.frag').read_text())
        self.msaa_composite_program=g.program((SHADERS/'composite.vert').read_text(),
            (SHADERS/'composite.frag').read_text().replace('#version 330 core','#version 330 core\n#define FSD_MSAA 1',1))
        self.temporal_program=g.program((SHADERS/'composite.vert').read_text(),(SHADERS/'temporal.frag').read_text())
        self.present_program=g.program((SHADERS/'composite.vert').read_text(),(SHADERS/'present.frag').read_text())
        self.motion_program=g.program(vert,(SHADERS/'motion.frag').read_text())
        self.layer_temporal_program=g.program((SHADERS/'composite.vert').read_text(),(SHADERS/'layer_temporal.frag').read_text())
        self._programs=[self.hair_program,self.peel_program,self.shadow_program,self.composite_program,self.hybrid_composite_program]
        self._programs += [self.msaa_composite_program,self.temporal_program,self.present_program,self.motion_program,self.layer_temporal_program]
        self.fullscreen_vao=g.name('VertexArrays')
        self._allocate_targets(self.width,self.height)
        if all(g.available(n) for n in ('glGenQueries','glDeleteQueries','glBeginQuery','glEndQuery',
                                        'glGetQueryObjectuiv','glGetQueryObjectui64v')):
            self._gpu_queries=[g.name('Queries') for _ in range(3)]
            self._pass_queries=[[g.name('Queries') for _ in range(4)] for _ in range(3)]
        g.glPixelStorei(GL_UNPACK_ALIGNMENT,1)
        g.glEnable(GL_MULTISAMPLE);g.glDisable(GL_SAMPLE_ALPHA_TO_COVERAGE)

    def _ensure_shadow_target(self):
        if self._shadow_texture:return
        g=self.gl
        self._shadow_texture=g.name('Textures');self._shadow_texture_far=g.name('Textures')
        self._shadow_fbo=g.name('Framebuffers');g.glBindFramebuffer(GL_FRAMEBUFFER,self._shadow_fbo)
        for index,name in enumerate((self._shadow_texture,self._shadow_texture_far)):
            g.glBindTexture(GL_TEXTURE_2D,name)
            for par,val in ((GL_TEXTURE_MIN_FILTER,GL_LINEAR),(GL_TEXTURE_MAG_FILTER,GL_LINEAR),(GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE),(GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE)):g.glTexParameteri(GL_TEXTURE_2D,par,val)
            g.glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA16F,self._shadow_resolution,self._shadow_resolution,0,GL_RGBA,GL_FLOAT,None)
            g.glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0+index,GL_TEXTURE_2D,name,0)
        g.glDrawBuffers(2,(U*2)(GL_COLOR_ATTACHMENT0,GL_COLOR_ATTACHMENT1))
        if g.glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE:
            raise RuntimeError('FiberShadow framebuffer incomplete')
        g.glBindFramebuffer(GL_FRAMEBUFFER,0)

    def _render_shadow(self,light_mvp):
        if self.material.shadow_strength<=0 or not (self._batches or getattr(self,'_groups',{})):
            return False
        self._ensure_shadow_target()
        cacheable=True # geometry/atlas/light key also tracks editor root changes
        shadow_key=(self._geometry_revision,self._atlas_revision,light_mvp.tobytes(),
                    float(self.material.alpha_gain),self._shadow_resolution)
        if cacheable and getattr(self,'_shadow_cache_key',None)==shadow_key:return True
        g=self.gl
        g.glBindFramebuffer(GL_FRAMEBUFFER,self._shadow_fbo)
        g.glViewport(0,0,self._shadow_resolution,self._shadow_resolution)
        g.glDisable(GL_DEPTH_TEST);g.glDisable(GL_CULL_FACE)
        g.glClearBufferfv(GL_COLOR,0,(F*4)(0,0,0,0));g.glClearBufferfv(GL_COLOR,1,(F*4)(0,0,0,0))
        g.glEnable(GL_BLEND);g.glBlendFunc(GL_ONE,GL_ONE)
        g.glUseProgram(self.shadow_program)
        g.uniform(self.shadow_program,'uRoots',7);g.uniform(self.shadow_program,'uUseRoots',0)
        matrix=np.ascontiguousarray(light_mvp,dtype=np.float32)
        g.glUniformMatrix4fv(g.glGetUniformLocation(self.shadow_program,b'uMVP'),1,GL_TRUE,
                             matrix.ctypes.data_as(C.POINTER(F)))
        g.uniform(self.shadow_program,'uAlphaGain',float(self.material.alpha_gain))
        for i,v in enumerate(getattr(self,'_shadow_knots',np.linspace(0.,1.,9))):g.uniform(self.shadow_program,f'uShadowKnots[{i}]',float(v))
        g.uniform(self.shadow_program,'uColor',0)
        g.uniform(self.shadow_program,'uAlpha',1)
        self._draw_shadow_geometry()
        g.glDisable(GL_BLEND)
        g.glBindFramebuffer(GL_FRAMEBUFFER,0)
        if cacheable:self._shadow_cache_key=shadow_key
        return True

    def _draw_shadow_geometry(self):
        g=self.gl
        for key,(vao,_,count) in self._batches.items():
            if not all((ch,key) in self._tile_textures for ch in ('color','alpha')):continue
            for unit,ch in enumerate(('color','alpha')):
                g.glActiveTexture(GL_TEXTURE0+unit)
                g.glBindTexture(GL_TEXTURE_2D,self._tile_textures[ch,key])
            g.glBindVertexArray(vao);g.glDrawArrays(GL_TRIANGLES,0,count)

    def _make_render_target(self,internal,fmt):
        g=self.gl;name=g.name('Textures')
        if internal==GL_RGBA16F and self.quality_mode=='Capture':internal=GL_RGBA32F
        g.glBindTexture(GL_TEXTURE_2D,name)
        g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR)
        g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR)
        g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE)
        g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE)
        g.glTexImage2D(GL_TEXTURE_2D,0,internal,self.width,self.height,0,fmt,GL_FLOAT,None)
        return name

    def _allocate_targets(self,width,height):
        g=self.gl
        self._release_peel_targets()
        if getattr(self,'fbo',0):
            for name in (self.accum,self.reveal):
                v=U(name);g.glDeleteTextures(1,C.byref(v))
            v=U(self.fbo);g.glDeleteFramebuffers(1,C.byref(v))
        self.width,self.height=max(32,int(width)),max(32,int(height))
        self.accum=self._make_oit_target(GL_RGBA32F,GL_RGBA)
        self.reveal=self._make_oit_target(GL_R16F,GL_RED)
        self.fbo=g.name('Framebuffers')
        g.glBindFramebuffer(GL_FRAMEBUFFER,self.fbo)
        target=GL_TEXTURE_2D_MULTISAMPLE if self._oit_samples>1 else GL_TEXTURE_2D
        g.glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,target,self.accum,0)
        g.glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT1,target,self.reveal,0)
        attachments=(U*2)(GL_COLOR_ATTACHMENT0,GL_COLOR_ATTACHMENT1)
        g.glDrawBuffers(2,attachments)
        status=g.glCheckFramebufferStatus(GL_FRAMEBUFFER)
        if status!=GL_FRAMEBUFFER_COMPLETE:
            raise RuntimeError(f'Weighted transparency framebuffer incomplete: 0x{status:x}')
        g.glBindFramebuffer(GL_FRAMEBUFFER,0)
        self._allocate_post_targets()
        self._target_allocations+=1

    def _make_oit_target(self,internal,fmt):
        if self._oit_samples==1:return self._make_render_target(internal,fmt)
        g=self.gl;name=g.name('Textures');g.glBindTexture(GL_TEXTURE_2D_MULTISAMPLE,name)
        g.glTexImage2DMultisample(GL_TEXTURE_2D_MULTISAMPLE,self._oit_samples,internal,self.width,self.height,GL_TRUE)
        return name

    def _release_post_targets(self):
        g=self.gl
        for n in self._post_textures:
            obj=U(n);g.glDeleteTextures(1,C.byref(obj))
        for n in self._post_fbos:
            obj=U(n);g.glDeleteFramebuffers(1,C.byref(obj))
        self._post_textures=[];self._post_fbos=[]

    def _allocate_post_targets(self):
        self._release_post_targets();g=self.gl
        # Current linear premultiplied color, two history ping-pong images, motion.
        for _ in range(4):
            tex=self._make_render_target(GL_RGBA16F,GL_RGBA)
            fbo=g.name('Framebuffers');self._post_textures.append(tex);self._post_fbos.append(fbo)
            g.glBindFramebuffer(GL_FRAMEBUFFER,fbo)
            g.glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,tex,0)
            g.glDrawBuffer(GL_COLOR_ATTACHMENT0)
            if g.glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE:
                raise RuntimeError('Sampling/temporal framebuffer incomplete')
            g.glClearBufferfv(GL_COLOR,0,(F*4)(0,0,0,0))
        depth=g.name('Textures');self._post_textures.append(depth)
        g.glBindTexture(GL_TEXTURE_2D,depth)
        g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST)
        g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST)
        g.glTexImage2D(GL_TEXTURE_2D,0,GL_DEPTH_COMPONENT24,self.width,self.height,0,GL_DEPTH_COMPONENT,GL_UNSIGNED_INT,None)
        g.glFramebufferTexture2D(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_TEXTURE_2D,depth,0)
        if g.glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE:
            raise RuntimeError('Motion framebuffer incomplete')
        g.glBindFramebuffer(GL_FRAMEBUFFER,0)
        self.invalidate_history('framebuffer resized')

    def invalidate_history(self,reason='scene changed'):
        self._history_key=None;self._history_count=0
        if hasattr(self,'info'):self.info.history_reason=reason

    def set_quality(self,mode='Live',scale=None,aa='Temporal'):
        self.context.activate()
        mode=ALIASES.get(mode,mode)
        if mode not in MODES:raise ValueError('Unknown quality mode')
        if aa not in ('Off','Spatial','Temporal','MSAA4'):raise ValueError('Unknown AA mode')
        if scale is not None and float(scale) not in (1.,1.5,2.):raise ValueError('Unknown render scale')
        previous=(self.quality_mode,self.transparency_mode,self.peel_layers,self.scale_override,self.aa_method)
        self.quality_mode=mode
        policy=MODES[mode]
        self.transparency_mode='weighted' if policy.layers==0 else 'hybrid'
        if policy.layers and self.peel_layers!=policy.layers:
            self.peel_layers=policy.layers;self._release_peel_targets()
        self.scale_override=None if scale is None else float(scale);self.aa_method=aa
        self.invalidate_history('sampling changed')
        try:self._configure_resolution()
        except Exception:
            self.quality_mode,self.transparency_mode,self.peel_layers,self.scale_override,self.aa_method=previous
            self._release_peel_targets()
            self._configure_resolution()
            raise

    def set_interaction(self,active):
        if self.interacting==bool(active):return
        self.interacting=bool(active)
        self.invalidate_history('interaction' if active else 'settling')
        # Keep allocated resolution stable while dragging; rebuilding every
        # target on each mouse press/release creates avoidable driver stalls.
        self.info.history_limit=1 if active or self.aa_method!='Temporal' else MODES[self.quality_mode].history

    def _target_budget_mib(self):
        now=time.monotonic()
        if now-getattr(self,'_memory_check_time',-100.)>2.:
            from .device import query_video_memory
            self._memory_check_time=now
            try:self._memory_snapshot=query_video_memory(self.gl.renderer)
            except (OSError,ValueError):self._memory_snapshot=None
        snapshot=getattr(self,'_memory_snapshot',None)
        own_targets=self.info.target_memory_mib or self.width*self.height*120/1024**2
        budget=1024.
        if snapshot and snapshot['budget_mib']>0:
            cap=min(3072.,snapshot['budget_mib']*.85)
            budget=min(1024.,max(64.,cap-snapshot['usage_mib']+own_targets-256.))
            self.info.memory_budget_mib=snapshot['budget_mib'];self.info.memory_usage_mib=snapshot['usage_mib']
            self.info.memory_source=snapshot['source']
        elif 'GL_NVX_gpu_memory_info' in getattr(self,'extensions',set()):
            available=I();self.gl.glGetIntegerv(0x9049,C.byref(available))
            if available.value>0:budget=min(1024.,max(64.,available.value/1024*.6+own_targets))
            self.info.memory_source='GL driver available memory / conservative cap'
        self.info.target_budget_mib=budget
        return budget

    def _configure_resolution(self):
        if not hasattr(self,'info'):return
        selected=MODES[self.quality_mode]
        requested=self.scale_override or selected.scale
        layers=self.peel_layers if self.transparency_mode!='weighted' else 0
        self.quality_fallback=''
        budget=self._target_budget_mib()
        bpp=lambda k:(160+128*k) if self.quality_mode=='Capture' else (120+88*k)
        while layers>1 and self.display_width*self.display_height*bpp(layers)>budget*1024**2:
            layers//=2
        if layers and self.display_width*self.display_height*bpp(layers)>budget*1024**2:
            self.quality_fallback='VRAM target cap: ordered layers unavailable; Weighted OIT'
            layers=0;self.transparency_mode='weighted';self._release_peel_targets()
        if self.transparency_mode!='weighted' and layers!=self.peel_layers:
            self.quality_fallback=f'VRAM target cap: {self.peel_layers} → {layers} layers'
            self.peel_layers=layers;self._release_peel_targets()
        samples=1;status=self.aa_method
        if self.aa_method=='Off':requested=1.
        if self.aa_method=='MSAA4':
            if self.transparency_mode=='weighted' and self._max_samples>=4:
                samples=4;status='4x MSAA / Weighted OIT (A2C disabled)'
            else:
                requested=2.
                status='4x MSAA unavailable in this path; spatial 2x requested'
        try:
            w,h,scale,memory=render_size(self.display_width,self.display_height,requested,layers,
                                        budget_mib=budget/(2 if samples==4 else 1),max_texture_size=self._max_texture_size,hq_float32=self.quality_mode=='Capture')
        except MemoryError:
            if samples!=4:raise
            samples=1;requested=1.
            status='MSAA target budget exceeded; native-resolution spatial fallback'
            w,h,scale,memory=render_size(self.display_width,self.display_height,1.,layers,
                                        budget_mib=budget,max_texture_size=self._max_texture_size,hq_float32=self.quality_mode=='Capture')
        if self.aa_method=='MSAA4' and samples==1 and scale<1.99:
            status+=f' / memory limited to {scale:.2f}x'
        precision=self.quality_mode=='Capture'
        changed=(w,h,samples)!=(self.width,self.height,self._oit_samples) or precision!=getattr(self,'_target_float32',False)
        self._oit_samples=samples
        if changed:
            self.context.activate()
            try:self._allocate_targets(w,h)
            except RuntimeError:
                if samples==1:raise
                # Format-specific MSAA support can be below the advertised
                # global sample limit. Rebuild a valid spatial OIT path.
                for _ in range(8):
                    if self.gl.glGetError()==0:break
                samples=1;self._oit_samples=1;requested=2.
                w,h,scale,memory=render_size(self.display_width,self.display_height,2.,layers,
                                            budget_mib=budget,max_texture_size=self._max_texture_size,hq_float32=self.quality_mode=='Capture')
                self._allocate_targets(w,h)
                status='MSAA framebuffer unavailable; spatial fallback'
        self._target_float32=precision
        self.info.render_scale=scale;self.info.internal_size=(w,h)
        self.info.physical_size=(self.display_width,self.display_height)
        self.info.target_memory_mib=memory*(2 if samples==4 else 1)
        self.info.aa_status=status
        if scale+1e-3<requested:self.info.aa_status+=f' / bounded to {scale:.2f}x by target budget'
        self.info.history_limit=1 if self.interacting or self.aa_method!='Temporal' else selected.history

    def _scene_key(self):
        return (round(self.yaw,8),round(self.pitch,8),round(self.distance,8),tuple(map(float,self.target)),
                tuple(asdict(self.material).items()),self._geometry_revision,self._atlas_revision,
                self.transparency_mode,self.peel_layers,getattr(self,'_auto_effective',None),self.display_width,self.display_height,
                getattr(getattr(self,'object_workspace',None),'revision',0))

    def pin_reference(self):
        """Explicit user capture only; no readback in the interactive frame loop."""
        im=self.capture();g=self.gl
        if not self._reference:self._reference=g.name('Textures')
        g.glBindTexture(GL_TEXTURE_2D,self._reference)
        for p,v in ((GL_TEXTURE_MIN_FILTER,GL_LINEAR),(GL_TEXTURE_MAG_FILTER,GL_LINEAR),
                    (GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE),(GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE)):
            g.glTexParameteri(GL_TEXTURE_2D,p,v)
        payload=im.transpose(Image.Transpose.FLIP_TOP_BOTTOM).tobytes()
        g.glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,im.width,im.height,0,GL_RGBA,GL_UNSIGNED_BYTE,C.c_char_p(payload))
        self._reference_key=self._scene_key()

    def clear_reference(self):self._reference_key=None

    def _release_peel_targets(self):
        if not hasattr(self,'gl'):return
        g=self.gl
        for layer in getattr(self,'_layer_targets',[]):
            for tex in layer.values():
                obj=U(tex);g.glDeleteTextures(1,C.byref(obj))
        self._layer_targets=[];self._resolved_layers=[]
        for tex in self._peel_colors+self._peel_depths:
            obj=U(tex);g.glDeleteTextures(1,C.byref(obj))
        if self._peel_fbo:
            obj=U(self._peel_fbo);g.glDeleteFramebuffers(1,C.byref(obj))
        self._peel_colors=[];self._peel_depths=[];self._peel_fbo=0

    def _ensure_peel_targets(self):
        if self._peel_fbo and len(self._peel_colors)==self.peel_layers:return
        if self._peel_fbo:self._release_peel_targets()
        g=self.gl
        # Allocate exactly K color layers, not four for every hybrid mode.
        self._peel_colors=[self._make_render_target(GL_RGBA16F,GL_RGBA) for _ in range(self.peel_layers)]
        self._layer_targets=[]
        for _ in range(self.peel_layers):
            layer={}
            for name in ('motion','meta','history0','history1','oldmeta0','oldmeta1'):
                layer[name]=self._make_render_target(GL_RGBA32F if 'meta' in name else GL_RGBA16F,GL_RGBA)
            self._layer_targets.append(layer)
        self._layer_history_index=0
        for _ in range(2):
            tex=g.name('Textures');g.glBindTexture(GL_TEXTURE_2D,tex)
            g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST)
            g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST)
            g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE)
            g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE)
            g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_COMPARE_MODE,GL_NONE)
            g.glTexImage2D(GL_TEXTURE_2D,0,GL_DEPTH_COMPONENT24,self.width,self.height,0,
                           GL_DEPTH_COMPONENT,GL_UNSIGNED_INT,None)
            self._peel_depths.append(tex)
        self._peel_fbo=g.name('Framebuffers')
        g.glBindFramebuffer(GL_FRAMEBUFFER,self._peel_fbo)
        g.glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,self._peel_colors[0],0)
        g.glFramebufferTexture2D(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_TEXTURE_2D,self._peel_depths[0],0)
        g.glDrawBuffer(GL_COLOR_ATTACHMENT0)
        status=g.glCheckFramebufferStatus(GL_FRAMEBUFFER)
        g.glBindFramebuffer(GL_FRAMEBUFFER,0)
        if status!=GL_FRAMEBUFFER_COMPLETE:
            self._release_peel_targets()
            raise RuntimeError(f'Hybrid depth-peel framebuffer incomplete: 0x{status:x}')

    def set_transparency(self,mode='weighted',layers=2):
        """Weighted fast path or bounded-cost ordered front layers + weighted tail.

        Peeling is a GPU multi-pass *reference-quality* prototype. It is NOT a
        production D3D12 K-buffer or memory-adaptive tile allocation scheme.
        """
        if mode not in ('weighted','hybrid','auto'):raise ValueError('Unknown transparency mode')
        if int(layers) not in (1,2,4,8):raise ValueError('Peel layers must be 1, 2, 4 or 8')
        old_layers=self.peel_layers
        self.transparency_mode=mode;self.peel_layers=int(layers)
        if self._peel_fbo and (mode=='weighted' or old_layers!=self.peel_layers):
            self.context.activate();self._release_peel_targets()
        self.info.transparency=('Weighted Blended OIT' if mode=='weighted' else f'Ordered {layers}-layer + weighted tail')
        self.info.quality_policy='adaptive' if mode=='auto' else 'manual' 
        self.invalidate_history('transparency changed');self._configure_resolution()

    def resize(self,width,height):
        width,height=int(width),int(height)
        if width<=0 or height<=0:return
        if (width,height)==(self.display_width,self.display_height):return
        self.context.activate()
        if hasattr(self.context,'resize'):self.context.resize(width,height)
        self.display_width,self.display_height=width,height
        self.invalidate_history('physical viewport resized');self._configure_resolution()

    @staticmethod
    def _blank(channel,size):
        if channel=='color':return Image.new('RGBA',(size,size),(220,189,151,255))
        if channel=='alpha':return Image.new('L',(size,size),255)
        if channel=='normal':return Image.new('RGB',(size,size),(128,128,255))
        if channel=='flow':return Image.new('RGB',(size,size),(128,255,128))
        if channel=='roughness':return Image.new('L',(size,size),110)
        raise ValueError(channel)

    def _release_tile_textures(self):
        for name in self._tile_textures.values():
            obj=U(name);self.gl.glDeleteTextures(1,C.byref(obj))
        self._tile_textures={};self._tile_memory={}
        self._tile_level_shapes={}

    def _upload_tile(self,key,prepared=None):
        from ..fiberbake_x.sampling import SamplingPacket
        if isinstance(prepared,SamplingPacket):return self._upload_tile_gpu(key,prepared)
        if prepared is None and self._fiberbake_device is not None:
            self._gpu_sampling_miss.add(key);self._dirty_tiles.add(key);return
        page,_=key;r=self._tile_regions[key];g=self.gl
        cost=mip_bytes(r.width,r.height)
        if sum(self._tile_memory.values())-self._tile_memory.get(key,0)+cost>768*1024**2:
            raise MemoryError('Tile sampling residency exceeds 768 MiB; reduce resident atlas pages')
        box=(r.x,r.y,r.x+r.width,r.y+r.height)
        if prepared is None:
            alpha=self._source_page('alpha',page).crop(box)
            prepared=prepare_tile({ch:self._source_page(ch,page).crop(box) for ch in CHANNELS},alpha)
        levels=1
        for channel in CHANNELS:
            mips=prepared[channel];levels=max(levels,len(mips))
            slot=(channel,key)
            name=self._tile_textures.get(slot)
            fresh=name is None
            if name is None:name=g.name('Textures');self._tile_textures[slot]=name
            g.glBindTexture(GL_TEXTURE_2D,name)
            fmt=GL_RGBA if channel=='color' else GL_RGB if channel in ('normal','flow') else GL_RED
            internal=GL_RGBA16F if channel=='color' else GL_RGB16F if fmt==GL_RGB else GL_R16F
            for level,array in enumerate(mips):
                data=np.ascontiguousarray(array[::-1])
                shapes=getattr(self,'_tile_level_shapes',None)
                if shapes is None:self._tile_level_shapes=shapes={}
                shape_key=(channel,key,level)
                if not fresh and shapes.get(shape_key)==data.shape:
                    g.glTexSubImage2D(GL_TEXTURE_2D,level,0,0,data.shape[1],data.shape[0],fmt,GL_FLOAT,V(data.ctypes.data))
                else:
                    g.glTexImage2D(GL_TEXTURE_2D,level,internal,data.shape[1],data.shape[0],0,fmt,GL_FLOAT,V(data.ctypes.data))
                    shapes[shape_key]=data.shape
            for p,v in ((GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR),(GL_TEXTURE_MAG_FILTER,GL_LINEAR),
                        (GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE),(GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE),
                        (GL_TEXTURE_MAX_LEVEL,len(mips)-1)):
                g.glTexParameteri(GL_TEXTURE_2D,p,v)
            if self._anisotropy>1:g.glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAX_ANISOTROPY_EXT,self._anisotropy)
        self._tile_memory[key]=cost
        self.info.tile_memory_mib=sum(self._tile_memory.values())/1024**2
        self.info.coverage_mip_levels=max(self.info.coverage_mip_levels,levels)
        self._shadow_cache_key=None

    def _upload_tile_gpu(self,key,packet):
        """GPU -> GPU transfer of complete tile mips, with no card geometry work."""
        g=self.gl;result=packet.result;new={};cost=mip_bytes(*result.size,bytes_per_pixel=40)
        if sum(self._tile_memory.values())-self._tile_memory.get(key,0)+cost>768*1024**2:
            packet.close();self._gpu_sampling_miss.add(key);self._dirty_tiles.add(key);return
        prototype=getattr(C,'WINFUNCTYPE',C.CFUNCTYPE)
        copy=prototype(None,U,U,I,I,I,I,U,U,I,I,I,I,I,I,I)(self.context.get_proc('glCopyImageSubData'))
        try:
            stamps=result.metrics.get('channel_stamps',{})
            seen=getattr(self,'_gpu_tile_channel_versions',None)
            if seen is None:self._gpu_tile_channel_versions=seen={}
            shapes=getattr(self,'_gpu_tile_shapes',None)
            if shapes is None:self._gpu_tile_shapes=shapes={}
            for ch,source in result.textures.items():
                if seen.get((ch,key))==stamps.get(ch) and (ch,key) in self._tile_textures:continue
                old=self._tile_textures.get((ch,key));shape=(result.size,packet.levels)
                incremental=old is not None and shapes.get((ch,key))==shape and seen.get((ch,key))==result.metrics.get('base_stamps',{}).get(ch)
                target=old if incremental else g.name('Textures')
                if not incremental:new[ch]=target
                g.glBindTexture(GL_TEXTURE_2D,target)
                for p,v in ((GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR),(GL_TEXTURE_MAG_FILTER,GL_LINEAR),(GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE),(GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE),(GL_TEXTURE_MAX_LEVEL,packet.levels-1)):g.glTexParameteri(GL_TEXTURE_2D,p,v)
                regions=result.metrics.get('mip_regions',{}).get(ch,())
                for level in range(packet.levels):
                    width=max(1,result.size[0]>>level);height=max(1,result.size[1]>>level)
                    if not incremental:g.glTexImage2D(GL_TEXTURE_2D,level,GL_RGBA16F,width,height,0,GL_RGBA,GL_FLOAT,None)
                    rectangles=regions[level] if incremental and level<len(regions) else [(0,0,width,height)]
                    for x0,y0,x1,y1 in rectangles:
                        if x1>x0 and y1>y0:copy(source,GL_TEXTURE_2D,level,x0,height-y1,0,target,GL_TEXTURE_2D,level,x0,height-y1,0,x1-x0,y1-y0,1)
                shapes[ch,key]=shape;seen[ch,key]=stamps.get(ch)
            for ch,target in new.items():
                previous=self._tile_textures.get((ch,key));self._tile_textures[ch,key]=target
                if previous:value=U(previous);g.glDeleteTextures(1,C.byref(value))
            for ch in new:seen[ch,key]=stamps.get(ch)
            self._tile_memory[key]=cost;self._atlas_revision+=1;self._id_key=None;self.invalidate_history('FiberBake X GPU tile mips')
            self.info.tile_memory_mib=sum(self._tile_memory.values())/1024**2
            fence=g.glFenceSync(GL_SYNC_GPU_COMMANDS_COMPLETE,0);g.glFlush();packet.close(fence)
        except Exception:
            for target in new.values():value=U(target);g.glDeleteTextures(1,C.byref(value))
            packet.close();self._gpu_sampling_miss.add(key);self._dirty_tiles.add(key)

    def _source_page(self,channel,page):
        source=self._atlas_sources.get((channel,page))
        if source is None:
            source=self._blank(channel,self._atlas_size)
            self._atlas_sources[(channel,page)]=source
        return source

    def flush_tile_updates(self):
        if not self._dirty_tiles and not self._sampling_jobs:return
        self.context.activate()
        start=time.perf_counter()
        completed=False
        bounded=type(self) is GPUHairRenderer
        for key,future in list(self._sampling_jobs.items()):
            if not future.done():continue
            del self._sampling_jobs[key]
            if key in self._tile_regions and key not in self._dirty_tiles:
                try:prepared=future.result()
                except Exception:prepared=None
                self._upload_tile(key,prepared);completed=True
                if bounded:break
        submitted=0
        for key in list(self._dirty_tiles):
            bound=getattr(self,"_bound_atlas_cache",None)
            if bound is not None and key[1] not in bound._tile_version:
                self._dirty_tiles.discard(key);continue
            if self._sampling_worker and len(self._sampling_jobs)>=2:break
            if key in self._sampling_jobs:continue
            if key in self._tile_regions:
                if self._sampling_worker:
                    page,_=key;r=self._tile_regions[key];box=(r.x,r.y,r.x+r.width,r.y+r.height)
                    cache=getattr(self,'_atlas_cache',None) or getattr(self,'_bound_atlas_cache',None)
                    if self._fiberbake_device is not None and cache is not None and key not in self._gpu_sampling_miss:
                        from ..fiberbake_x.sampling import request_sampling
                        placement=cache.layout.placements.get(key[1])
                        expected={ch:cache._channel_versions.get((key[1],ch)) for ch in CHANNELS}
                        self._sampling_jobs[key]=request_sampling(self._fiberbake_device,key[1],expected,(r.width,r.height),placement.rotation if placement else 0)
                        self._dirty_tiles.discard(key);submitted+=1
                        continue
                    descriptor=getattr(cache,'_gpu_tiles',{}).get(key[1]) if cache is not None else None
                    if descriptor is not None:
                        placement=cache.layout.placements[key[1]]
                        def cpu_mips(descriptor=descriptor,placement=placement):
                            from ..fiberbake_x.atlas import compatibility_tile
                            images=compatibility_tile(descriptor,placement,CHANNELS)
                            return prepare_tile(images,images['alpha'])
                        self._sampling_jobs[key]=self._sampling_worker.submit(cpu_mips);self._dirty_tiles.discard(key);submitted+=1
                        continue
                    images={ch:self._source_page(ch,page).crop(box) for ch in CHANNELS}
                    alpha=images['alpha']
                    self._sampling_jobs[key]=self._sampling_worker.submit(prepare_tile,images,alpha)
                    submitted+=1
                else:self._upload_tile(key);completed=True
            self._dirty_tiles.discard(key)
            if bounded and (submitted or completed):break
        if completed:self.invalidate_history('tile sampling uploaded')
        self.info.texture_upload_ms=(time.perf_counter()-start)*1000

    @property
    def sampling_pending(self):return bool(self._dirty_tiles or self._sampling_jobs or getattr(self,'_env_future',None))

    def update_sampling_region(self,channel,page,rect,image):
        """Live Studio path: update CPU source and queue tile-local float mips.

        No synchronous legacy atlas mip construction/upload. The original
        update_atlas_region/read_atlas debug contract remains available.
        """
        if channel not in CHANNELS:raise ValueError(channel)
        x0,y0,x1,y1=map(int,rect)
        if not 0<=x0<x1<=self._atlas_size or not 0<=y0<y1<=self._atlas_size:
            raise ValueError('Tile sampling region outside atlas')
        self._source_page(channel,int(page)).paste(image.crop((x0,y0,x1,y1)),(x0,y0))
        for key,r in self._tile_regions.items():
            if key[0]==int(page) and r.x<x1 and r.x+r.width>x0 and r.y<y1 and r.y+r.height>y0:
                self._dirty_tiles.add(key)
        self._atlas_revision+=1
        self.invalidate_history('live tile source changed')

    def load_atlas_images(self,images:dict[tuple[str,int],Image.Image],atlas_size:int,tile_rects=None):
        """Replace currently bound atlas textures; no CPU fiber geometry required.

        images uses keys (channel,page). PNG top-left rows are flipped for GL UV.
        """
        self.context.activate();g=self.gl
        self._bound_atlas_cache=None
        for future in self._sampling_jobs.values():future.cancel()
        self._sampling_jobs={}
        self._release_tile_textures();self._dirty_tiles.update(self._tile_regions)
        self._atlas_revision+=1;self.invalidate_history('atlas replaced')
        old=self._page_textures
        self._page_textures={};self._atlas_size=int(atlas_size)
        self._tile_rects=list(tile_rects or [])
        self._mip_limit=min((max_safe_level(r.padding,self._atlas_size) for r in self._tile_rects),default=0)
        images=dict(images)
        for page in {p for _,p in images}:
            if ('alpha',page) not in images and ('color',page) in images:
                # Explicit Alpha Map is authoritative. RGBA alpha is only the
                # fallback when a separate alpha channel was not supplied.
                images[('alpha',page)]=images[('color',page)].convert('RGBA').getchannel('A')
        self._atlas_sources={k:v.copy() for k,v in images.items()}
        self.info.coverage_mip_levels=self._mip_limit+1
        pages=sorted({page for _,page in images}) or [0]
        for page in pages:
            for channel in CHANNELS:
                im=images.get((channel,page))
                if im is None:im=self._blank(channel,self._atlas_size)
                self._atlas_sources[(channel,page)]=im.copy()
                im=im.convert('RGBA') if channel=='color' else im.convert('RGB' if channel in ('normal','flow') else 'L')
                if im.size!=(self._atlas_size,self._atlas_size):
                    raise ValueError(f'Atlas {channel}/{page}: size {im.size} != {self._atlas_size}')
                name=g.name('Textures');g.glBindTexture(GL_TEXTURE_2D,name)
                fmt=GL_RGBA if channel=='color' else (GL_RGB if channel in ('normal','flow') else GL_RED)
                al=self._source_page('alpha',page)
                mips=atlas_mip_chain(im,al,self._tile_rects,channel,page,self._mip_limit) if self._tile_rects else [im]
                for level,pic in enumerate(mips):
                    payload=pic.transpose(Image.Transpose.FLIP_TOP_BOTTOM).tobytes()
                    g.glTexImage2D(GL_TEXTURE_2D,level,GL_RGBA8 if channel=='color' else (GL_RGB if fmt==GL_RGB else GL_R8),
                                   pic.width,pic.height,0,fmt,GL_UNSIGNED_BYTE,C.c_char_p(payload))
                for param,v in [(GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR),(GL_TEXTURE_MAG_FILTER,GL_LINEAR),
                                (GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE),(GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE)]:
                    g.glTexParameteri(GL_TEXTURE_2D,param,v)
                if self._tile_rects:
                    g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAX_LEVEL,self._mip_limit)
                else:g.glGenerateMipmap(GL_TEXTURE_2D)
                self._page_textures[(channel,page)]=name
        for name in old.values():
            obj=U(name);g.glDeleteTextures(1,C.byref(obj))
        self.info.atlas_uploads+=len(self._page_textures)

    def update_atlas_region(self,channel,page,rect,image:Image.Image):
        """Update one atlas subrect via glTexSubImage2D; leaves other tiles intact.

        rect uses top-left (x0,y0,x1,y1) and includes atlas padding.
        """
        self.context.activate();g=self.gl
        tex=self._page_textures.get((channel,int(page)))
        if tex is None:raise KeyError(f'Atlas texture not resident: {channel}/{page}')
        x0,y0,x1,y1=map(int,rect)
        if not 0<=x0<x1<=self._atlas_size or not 0<=y0<y1<=self._atlas_size:
            raise ValueError('GPU tile upload region outside atlas')
        crop=image.crop((x0,y0,x1,y1))
        fmt=GL_RGBA if channel=='color' else(GL_RGB if channel in ('normal','flow') else GL_RED)
        crop=crop.convert('RGBA' if fmt==GL_RGBA else('RGB' if fmt==GL_RGB else 'L'))
        payload=crop.transpose(Image.Transpose.FLIP_TOP_BOTTOM).tobytes()
        g.glBindTexture(GL_TEXTURE_2D,tex)
        g.glTexSubImage2D(GL_TEXTURE_2D,0,x0,self._atlas_size-y1,x1-x0,y1-y0,fmt,GL_UNSIGNED_BYTE,C.c_char_p(payload))
        if self._tile_rects:
            src=self._atlas_sources.get((channel,int(page)))
            if src is None:src=image.copy()
            else:src.paste(crop,(x0,y0))
            self._atlas_sources[(channel,int(page))]=src
            alpha=self._atlas_sources.get(('alpha',int(page)))
            if alpha is None:alpha=self._blank('alpha',self._atlas_size)
            if channel=='alpha':alpha=src
            # Recalculate only the affected tile's footprint on each mip level.
            affected=[r for r in self._tile_rects if r.page==int(page)
                      and r.x < x1 and r.x+r.width > x0
                      and r.y < y1 and r.y+r.height > y0]
            for r in affected:
                one=atlas_mip_chain(src,alpha,[r],channel,int(page),self._mip_limit)
                for level,pic in enumerate(one[1:],start=1):
                    scale=1<<level
                    lx=int(math.ceil(max(0,r.x-r.padding)/scale))
                    ly=int(math.ceil(max(0,r.y-r.padding)/scale))
                    hx=int(math.floor(min(self._atlas_size,r.x+r.width+r.padding)/scale))
                    hy=int(math.floor(min(self._atlas_size,r.y+r.height+r.padding)/scale))
                    if hx<=lx or hy<=ly:continue
                    sub=pic.crop((lx,ly,hx,hy)).convert(crop.mode)
                    pl=sub.transpose(Image.Transpose.FLIP_TOP_BOTTOM).tobytes()
                    g.glTexSubImage2D(GL_TEXTURE_2D,level,lx,pic.height-hy,
                                      hx-lx,hy-ly,fmt,GL_UNSIGNED_BYTE,C.c_char_p(pl))
        else:
            g.glGenerateMipmap(GL_TEXTURE_2D)
        self.info.regions_uploaded+=1
        # Float tile-local mips depend on alpha for color, normal and roughness.
        # Queue one upload per affected tile, coalesced across all changed maps.
        self._source_page(channel,int(page)).paste(crop,(x0,y0))
        for key,r in self._tile_regions.items():
            if key[0]==int(page) and r.x<x1 and r.x+r.width>x0 and r.y<y1 and r.y+r.height>y0:
                self._dirty_tiles.add(key)
        self._atlas_revision+=1;self.invalidate_history('tile content changed')

    def read_atlas(self,channel,page=0,level=0):
        """Debug readback of one resident texture to verify subregion updates.

        Slow by design; never called during normal interactive rendering.
        """
        self.context.activate();g=self.gl
        tex=self._page_textures[(channel,page)]
        if level<0 or (self._tile_rects and level>self._mip_limit):raise ValueError('mipmap level outside resident range')
        channels=4 if channel=='color' else (3 if channel in ('normal','flow') else 1)
        fmt={4:GL_RGBA,3:GL_RGB,1:GL_RED}[channels]
        g.glBindTexture(GL_TEXTURE_2D,tex)
        g.glPixelStorei(0x0D05,1) # PACK_ALIGNMENT
        size=max(1,self._atlas_size//(1<<level))
        raw=C.create_string_buffer(size*size*channels)
        g.glGetTexImage(GL_TEXTURE_2D,level,fmt,GL_UNSIGNED_BYTE,C.cast(raw,V))
        im=Image.frombytes({4:'RGBA',3:'RGB',1:'L'}[channels],(size,size),raw.raw)
        return im.transpose(Image.Transpose.FLIP_TOP_BOTTOM)

    def load_atlas_directory(self,path):
        directory=Path(path)
        manifest=json.loads((directory/'FSD_Atlas_manifest.json').read_text('utf-8'))
        images={}
        for page in range(manifest['pages']):
            for channel in CHANNELS:
                f=directory/f'FSD_Atlas_{page:02d}_{channel}.png'
                if f.exists():images[(channel,page)]=Image.open(f).copy()
        rects=[TileRect(int(t.get('page',0)),*map(int,t['rect_px']),int(manifest.get('padding_px',0)))
               for t in manifest.get('tiles',{}).values()]
        self.load_atlas_images(images,int(manifest['atlas_size']),tile_rects=rects)
        return manifest

    def load_atlas_cache(self,cache):
        # Cache pages are immutable copy-on-write snapshots. Bind references and
        # invalidate only changed tile sampling, without full-page GPU uploads.
        previous=getattr(self,'_bound_atlas_cache',None)
        if previous is cache:return
        layout_changed=previous is None or previous.layout is not cache.layout
        self.context.activate()
        if layout_changed:
            for future in self._sampling_jobs.values():future.cancel()
            self._sampling_jobs={}
            self._release_tile_textures()
            self._dirty_tiles.clear()
        self._atlas_size=cache.layout.size
        self._atlas_sources={key:image for key,image in cache._pages.items() if key[0] in CHANNELS}
        for tid,placement in cache.layout.placements.items():
            if tid not in cache._tile_version:continue
            changed=layout_changed or any(previous._channel_versions.get((tid,ch))!=cache._channel_versions.get((tid,ch)) for ch in CHANNELS)
            if changed:
                key=(placement.page,tid)
                future=self._sampling_jobs.pop(key,None)
                if future:future.cancel()
                self._dirty_tiles.add(key)
        self._bound_atlas_cache=cache
        self._atlas_revision+=1
        self.invalidate_history('atlas tile sources changed')

    def load_cards(self,cards,placements,atlas_size):
        """Cards are independent from raster; changes only re-upload geometry.
        placements: TileID -> Placement or manifest object with rect_px, page.
        """
        self.context.activate();g=self.gl
        from ..editor_scene import geometry_signature
        from ..kernel.operations import effective_tile_id
        from ..kernel.binding import resolved_card
        owner=getattr(self,'object_workspace',None)
        objects=owner.evaluated_objects() if owner else []
        cache=getattr(self,'_card_draw_cache',{});next_cache={};batches=defaultdict(list)
        regions={};previous_vertices={};total=0;triangles=0;changed_geometry=False
        for item in cards:
            card=_as_card(item)
            if owner and card.attachment:card=resolved_card(card,objects,owner.joint_poses)
            if not card.visible:continue
            tile_id=effective_tile_id(card);p=placements.get(tile_id)
            if p is None:continue
            if hasattr(p,'x'):x,y,w,h=p.x,p.y,p.width,p.height;page=p.page
            else:x,y,w,h=p['rect_px'];page=int(p.get('page',0))
            key=(page,tile_id);regions[key]=TileRect(page,int(x),int(y),int(w),int(h),0)
            if card.id not in self._card_numeric_ids:
                numeric_id=len(self._card_numeric_ids)
                if numeric_id>=16777215:raise MemoryError('Card identity space exhausted; reopen the view')
                self._card_numeric_ids[card.id]=numeric_id
            signature=(geometry_signature(card),tuple(card.root));old=cache.get(card.id)
            changed=old is None or old['signature']!=signature
            if changed:
                verts,uv,faces,center=ribbon_mesh(card)
                tangent=np.gradient(center.astype(np.float64),axis=0)
                tangent/=np.maximum(np.linalg.norm(tangent,axis=1,keepdims=True),1e-8)
                norms=np.zeros_like(verts)
                face_normals=np.cross(verts[faces[:,1]]-verts[faces[:,0]],verts[faces[:,2]]-verts[faces[:,0]])
                face_normals/=np.maximum(np.linalg.norm(face_normals,axis=1,keepdims=True),1e-8)
                for corner in range(3):np.add.at(norms,faces[:,corner],face_normals)
                norms/=np.maximum(np.linalg.norm(norms,axis=1,keepdims=True),1e-8)
                tangents=np.repeat(tangent.astype(np.float32),card.width_segments+1,axis=0)
                previous=old['vertices'] if old and old['vertices'].shape==verts.shape else verts
                interleaved=np.column_stack((verts,uv[:,0],1.-uv[:,1],tangents,norms,previous,np.full(len(verts),self._card_numeric_ids[card.id]))).astype(np.float32)
                data=np.ascontiguousarray(interleaved[faces.reshape(-1)])
                entry=dict(signature=signature,data=data,vertices=verts,triangles=len(faces),settle=old is not None)
                changed_geometry=True
            else:
                entry=old
                if entry.get('settle'):
                    data=entry['data'].copy();data[:,11:14]=data[:,:3]
                    entry={**entry,'data':data,'settle':False};changed=True
            next_cache[card.id]=entry;previous_vertices[card.id]=entry['vertices']
            batches[key].append((card.id,entry['data'],changed))
            total+=1;triangles+=entry['triangles']
        old_batches=self._batches;new_batches={};layouts={};uploaded=0
        old_layouts=getattr(self,'_card_batch_layouts',{})
        for key,chunks in batches.items():
            layout=tuple((cid,len(data)) for cid,data,_ in chunks);layouts[key]=layout
            existing=old_batches.get(key)
            if existing and old_layouts.get(key)==layout:
                vao,vbo,count=existing;g.glBindBuffer(GL_ARRAY_BUFFER,vbo);offset=0
                for cid,data,changed in chunks:
                    if changed:
                        g.glBufferSubData(GL_ARRAY_BUFFER,offset,data.nbytes,C.c_void_p(data.ctypes.data));uploaded+=data.nbytes
                    offset+=data.nbytes
                new_batches[key]=existing
            else:
                data=np.ascontiguousarray(np.concatenate([chunk[1] for chunk in chunks]),dtype=np.float32)
                vao,vbo=(existing[:2] if existing else (g.name('VertexArrays'),g.name('Buffers')))
                g.glBindVertexArray(vao);g.glBindBuffer(GL_ARRAY_BUFFER,vbo)
                g.glBufferData(GL_ARRAY_BUFFER,data.nbytes,C.c_void_p(data.ctypes.data),GL_DYNAMIC_DRAW);uploaded+=data.nbytes
                for location,count,offset in [(0,3,0),(1,2,12),(2,3,20),(3,3,32),(4,3,44),(5,1,56)]:
                    g.glEnableVertexAttribArray(location)
                    g.glVertexAttribPointer(location,count,GL_FLOAT,GL_FALSE,60,C.c_void_p(offset))
                new_batches[key]=(vao,vbo,len(data));changed_geometry=True
        for key,(vao,vbo,_) in old_batches.items():
            if key not in new_batches:
                for fn,val in [(g.glDeleteBuffers,vbo),(g.glDeleteVertexArrays,vao)]:
                    obj=U(val);fn(1,C.byref(obj))
                changed_geometry=True
        self._batches=new_batches;self._card_draw_cache=next_cache;self._card_batch_layouts=layouts
        self.last_geometry_upload_bytes=uploaded
        self.info.cards=total;self.info.triangles=triangles;self.info.batches=len(self._batches)
        for key in set(self._tile_regions)-set(regions):
            for ch in CHANNELS:
                name=self._tile_textures.pop((ch,key),0)
                if name:obj=U(name);g.glDeleteTextures(1,C.byref(obj))
            self._tile_memory.pop(key,None)
        for key,r in regions.items():
            if self._tile_regions.get(key)!=r or ('color',key) not in self._tile_textures:self._dirty_tiles.add(key)
        self._tile_regions=regions;self._previous_card_vertices=previous_vertices
        if changed_geometry:
            self._motion_geometry_pending=True;self._geometry_revision+=1
            self.invalidate_history('geometry changed')
        self.flush_tile_updates()

    def _environment(self,program):
        from .render_service import load_environment as load
        path=self.material.environment_path;g=self.gl
        if getattr(self,'_env_path',None)!=path:
            future=getattr(self,'_env_future',None)
            if future:future.cancel()
            self._env_path=path;self._env_sh=None;self._env_data=None;self.environment_error=""
            if self._sampling_worker:self._env_future=self._sampling_worker.submit(load,path)
            else:self._env_future=None;self._env_data=load(path)
        future=getattr(self,'_env_future',None)
        if future and future.done():
            try:self._env_data=future.result()
            except Exception as error:self.environment_error=str(error)
            self._env_future=None
        data=getattr(self,'_env_data',None)
        if data is not None:
            pixels,self._env_sh,pdf,cdf=data;self._env_data=None
            if not getattr(self,'_env_tex',0):self._env_tex=g.name('Textures')
            g.glActiveTexture(GL_TEXTURE0+10);g.glBindTexture(GL_TEXTURE_2D,self._env_tex)
            g.glTexImage2D(GL_TEXTURE_2D,0,0x881B,pixels.shape[1],pixels.shape[0],0,0x1907,GL_FLOAT,C.c_void_p(pixels.ctypes.data))
            g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,0x2703);g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR)
            g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,0x2901);g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);g.glGenerateMipmap(GL_TEXTURE_2D)
            for unit,field,values in ((12,'_env_pdf',pdf),(13,'_env_cdf',cdf)):
                if not getattr(self,field,0):setattr(self,field,g.name('Textures'))
                g.glActiveTexture(GL_TEXTURE0+unit);g.glBindTexture(GL_TEXTURE_2D,getattr(self,field))
                g.glTexImage2D(GL_TEXTURE_2D,0,0x822E,values.shape[1],values.shape[0],0,GL_RED,GL_FLOAT,C.c_void_p(values.ctypes.data))
                for par,val in ((GL_TEXTURE_MIN_FILTER,GL_NEAREST),(GL_TEXTURE_MAG_FILTER,GL_NEAREST),(GL_TEXTURE_WRAP_S,0x2901),(GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE)):g.glTexParameteri(GL_TEXTURE_2D,par,val)
            self._env_levels=float(math.floor(math.log2(max(pixels.shape[:2]))));self.invalidate_history('environment ready')
        enabled=getattr(self,'_env_sh',None) is not None
        g.uniform(program,'uEnvironmentEnabled',int(enabled));g.uniform(program,'uEnvironment',10)
        g.uniform(program,'uEnvironmentStrength',float(self.material.environment_strength));g.uniform(program,'uEnvironmentRotation',math.radians(self.material.environment_rotation))
        g.uniform(program,'uEnvironmentLevels',float(getattr(self,'_env_levels',0)))
        if enabled:
            for unit,field,uniform in ((12,'_env_pdf','uEnvPDF'),(13,'_env_cdf','uEnvDistribution')):
                g.glActiveTexture(GL_TEXTURE0+unit);g.glBindTexture(GL_TEXTURE_2D,getattr(self,field));g.uniform(program,uniform,unit)
            g.glActiveTexture(GL_TEXTURE0+10);g.glBindTexture(GL_TEXTURE_2D,self._env_tex)
            for i,value in enumerate(self._env_sh):g.uniform(program,'uSH['+str(i)+']',value)

    def _bind_hair_uniforms(self,mvp,eye,program=None,previous_depth=None,light_mvp=None,shadow_enabled=False):
        g=self.gl;p=program or self.hair_program
        g.glUseProgram(p)
        g.uniform(p,'uRoots',7);g.uniform(p,'uUseRoots',0)
        loc=g.glGetUniformLocation(p,b'uMVP')
        matrix=np.ascontiguousarray(mvp,dtype=np.float32)
        g.glUniformMatrix4fv(loc,1,GL_TRUE,matrix.ctypes.data_as(C.POINTER(F)))
        loc=g.glGetUniformLocation(p,b'uPreviousMVP')
        if loc>=0:
            previous=np.ascontiguousarray(self._previous_mvp,dtype=np.float32)
            g.glUniformMatrix4fv(loc,1,GL_TRUE,previous.ctypes.data_as(C.POINTER(F)))
        g.uniform(p,'uGeometryMoved',int(self._motion_geometry_pending))
        if light_mvp is not None:
            loc=g.glGetUniformLocation(p,b'uLightMVP')
            lm=np.ascontiguousarray(light_mvp,dtype=np.float32)
            if loc>=0:g.glUniformMatrix4fv(loc,1,GL_TRUE,lm.ctypes.data_as(C.POINTER(F)))
        g.uniform(p,'uShadowEnabled',int(shadow_enabled))
        g.uniform(p,'uMeshShadowEnabled',int(getattr(self,'_mesh_shadow_enabled',False)))
        g.uniform(p,'uMeshShadow',14)
        if getattr(self,'_mesh_shadow_enabled',False):
            g.glActiveTexture(GL_TEXTURE0+14);g.glBindTexture(GL_TEXTURE_2D,self._object_renderer.shadow_depth)
        g.uniform(p,'uShadowStrength',float(self.material.shadow_strength))
        g.uniform(p,'uScatterStrength',float(self.material.scatter_strength))
        if self._shadow_texture:
            g.glActiveTexture(GL_TEXTURE0+6)
            g.glBindTexture(GL_TEXTURE_2D,self._shadow_texture)
            g.uniform(p,'uShadowDensity',6)
            g.glActiveTexture(GL_TEXTURE0+11);g.glBindTexture(GL_TEXTURE_2D,getattr(self,'_shadow_texture_far',0));g.uniform(p,'uShadowDensityFar',11)
        g.uniform(p,'uShadowFast',0)
        g.uniform(p,'uShadowBias',float(getattr(self,'_shadow_bias',.007)))
        for i,v in enumerate(getattr(self,'_shadow_knots',np.linspace(0.,1.,9))):g.uniform(p,f'uShadowKnots[{i}]',float(v))
        self._environment(p)
        m=self.material
        policy=MODES[self.quality_mode]
        stable=self.quality_mode!='Capture' or self.interacting or self.info.history_limit<=1 or (p==self.hair_program and getattr(self,'_effective_mode_for_frame','weighted')=='hybrid')
        g.uniform(p,'uStableSampling',int(stable))
        g.uniform(p,'uFiberOffset',float((halton(self._history_count+1,2)*2.-1.)*.9999))
        for name,value in {'uPhysical':int(m.shading_mode=='Physical'),'uArtistic':int(m.artistic_optics),'uLightSamples':policy.light_samples,'uEnvSamples':policy.environment_samples,'uSampleIndex':0 if stable else self._history_count}.items():g.uniform(p,name,value)
        g.uniform(p,'uCuticleTilt',float(m.cuticle_tilt))
        for name,value in [('uLongRough',m.longitudinal_roughness),('uAzimRough',m.azimuthal_roughness),('uIOR',m.ior),('uAbsorption',m.absorption)]:g.uniform(p,name,float(value))
        az=math.radians(m.light_azimuth);el=math.radians(m.light_elevation)
        ld=(math.sin(az)*math.cos(el),math.sin(el),math.cos(az)*math.cos(el))
        for name,value in {
            'uLightDir':ld,'uViewPos':tuple(eye),
            'uLightIntensity':float(m.light_intensity),
            'uFillIntensity':float(m.fill_intensity),
            'uAmbientIntensity':float(m.ambient_intensity),
            'uKeyColor':tuple(m.key_color),'uFillColor':tuple(m.fill_color),'uAmbientColor':tuple(m.ambient_color),
            'uLightSize':float(m.light_size),
            'uOpaqueDepth':8,'uHasOpaque':int(getattr(self,'_has_objects',False)),
            'uUseKeyPosition':int(m.key_target is not None),
            'uKeyPosition':tuple(np.asarray(m.key_target if m.key_target is not None else self.target)+np.asarray(ld)*5.5),
            'uRimIntensity':float(m.rim_intensity),'uRimColor':tuple(m.rim_color),
            'uRimDir':(math.sin(math.radians(m.rim_azimuth))*math.cos(math.radians(m.rim_elevation)),
                       math.sin(math.radians(m.rim_elevation)),
                       math.cos(math.radians(m.rim_azimuth))*math.cos(math.radians(m.rim_elevation))),
            'uRimWidth':float(m.rim_width),
            'uRoughness':float(m.roughness),'uSpecular':float(m.specular),
            'uSecondary':float(m.secondary),'uSheen':float(m.sheen),'uBacklight':float(m.backlight),
            'uIridescence':float(m.iridescence),'uAnisotropy':float(m.anisotropy),
            'uAlphaGain':float(m.alpha_gain),'uExposure':float(m.exposure),'uDebug':int(m.debug),
            'uAlphaCutoff':float(m.alpha_cutoff),
        }.items():g.uniform(p,name,value)
        g.uniform(p,'uDepthReject',1 if previous_depth is not None else 0)
        if previous_depth is not None:
            g.glActiveTexture(GL_TEXTURE0+5);g.glBindTexture(GL_TEXTURE_2D,previous_depth)
            g.uniform(p,'uPrevDepth',5)
        for unit,ch in enumerate(CHANNELS):g.uniform(p,{'color':'uColor','alpha':'uAlpha','normal':'uNormalTex',
                                                             'flow':'uFlow','roughness':'uRoughnessTex'}[ch],unit)
        return p

    def _draw_hair(self,mvp,eye,program=None,previous_depth=None,light_mvp=None,shadow_enabled=False):
        g=self.gl
        p=self._bind_hair_uniforms(mvp,eye,program,previous_depth,light_mvp,shadow_enabled)
        for key,(vao,_,count) in self._batches.items():
            if not all((ch,key) in self._tile_textures for ch in CHANNELS):continue
            r=self._tile_regions[key]
            g.uniform(p,'uMaxMip',float(math.floor(math.log2(max(r.width,r.height)))))
            for unit,ch in enumerate(CHANNELS):
                g.glActiveTexture(GL_TEXTURE0+unit)
                g.glBindTexture(GL_TEXTURE_2D,self._tile_textures[(ch,key)])
            g.glBindVertexArray(vao);g.glDrawArrays(GL_TRIANGLES,0,count)

    def _weighted_pass(self,mvp,eye,depth_threshold=None,light_mvp=None,shadow_enabled=False):
        g=self.gl
        g.glBindFramebuffer(GL_FRAMEBUFFER,self.fbo)
        g.glViewport(0,0,self.width,self.height)
        g.glDisable(GL_DEPTH_TEST);g.glDisable(GL_CULL_FACE)
        g.glClearBufferfv(GL_COLOR,0,(F*4)(0,0,0,0))
        g.glClearBufferfv(GL_COLOR,1,(F*4)(0,0,0,0))
        g.glEnable(GL_BLEND)
        attachments=(U*2)(GL_COLOR_ATTACHMENT0,GL_COLOR_ATTACHMENT1)
        g.glDrawBuffers(2,attachments)
        if all(g.available(x) for x in ('glBlendFunci','glEnablei','glDisablei')):
            g.glEnablei(GL_BLEND,0);g.glEnablei(GL_BLEND,1)
            g.glBlendFunci(0,GL_ONE,GL_ONE)
            g.glBlendFunci(1,GL_ONE,GL_ONE)
            self._draw_hair(mvp,eye,previous_depth=depth_threshold,light_mvp=light_mvp,shadow_enabled=shadow_enabled)
            g.glDisablei(GL_BLEND,0);g.glDisablei(GL_BLEND,1)
        else:
            # GL 3.3 fallback maintains fragment output-to-attachment mapping.
            g.glDrawBuffers(2,(U*2)(GL_COLOR_ATTACHMENT0,GL_NONE))
            g.glBlendFunc(GL_ONE,GL_ONE)
            self._draw_hair(mvp,eye,previous_depth=depth_threshold,light_mvp=light_mvp,shadow_enabled=shadow_enabled)
            g.glDrawBuffers(2,(U*2)(GL_NONE,GL_COLOR_ATTACHMENT1))
            g.glBlendFunc(GL_ONE,GL_ONE)
            self._draw_hair(mvp,eye,previous_depth=depth_threshold,light_mvp=light_mvp,shadow_enabled=shadow_enabled)
        g.glDisable(GL_BLEND)

    def _front_peel_passes(self,mvp,eye,light_mvp=None,shadow_enabled=False):
        """Peel exact nearest 1/2/4 layers, sorted implicitly by depth testing.

        Unlike a K-buffer this repeats hair draw calls per layer; intended as
        a correctness/quality option and test oracle for future native OIT.
        """
        g=self.gl
        self._ensure_peel_targets()
        g.glBindFramebuffer(GL_FRAMEBUFFER,self._peel_fbo)
        g.glViewport(0,0,self.width,self.height)
        g.glDisable(GL_BLEND);g.glDisable(GL_CULL_FACE)
        g.glEnable(GL_DEPTH_TEST);g.glDepthFunc(GL_LESS)
        g.glClearDepth(1.0)
        for i in range(self.peel_layers):
            layer=self._layer_targets[i]
            depth=self._peel_depths[i%2]
            previous=None if i==0 else self._peel_depths[(i-1)%2]
            g.glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,self._peel_colors[i],0)
            g.glFramebufferTexture2D(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_TEXTURE_2D,depth,0)
            for attachment,field in ((1,'motion'),(2,'meta')):g.glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0+attachment,GL_TEXTURE_2D,layer[field],0)
            g.glDrawBuffers(3,(U*3)(GL_COLOR_ATTACHMENT0,GL_COLOR_ATTACHMENT1,GL_COLOR_ATTACHMENT0+2))
            for attachment in range(3):g.glClearBufferfv(GL_COLOR,attachment,(F*4)(0,0,0,0))
            g.glClear(GL_DEPTH_BUFFER_BIT)
            self._draw_hair(mvp,eye,program=self.peel_program,previous_depth=previous,light_mvp=light_mvp,shadow_enabled=shadow_enabled)
        g.glDisable(GL_DEPTH_TEST)
        return self._peel_depths[(self.peel_layers-1)%2]

    def _resolve_layer_history(self):
        """Independent motion/identity/depth rejection for every ordered layer.

        Tail remains current-frame weighted OIT. Reordered layers reject history;
        they do not inherit the velocity or radiance of another card.
        """
        if not self.hq_available:self._resolved_layers=list(self._peel_colors);return
        g=self.gl;src=self._layer_history_index;dst=1-src
        self._resolved_layers=[]
        for i,layer in enumerate(self._layer_targets):
            g.glBindFramebuffer(GL_FRAMEBUFFER,self._peel_fbo)
            # Detach depth while resolving; source depth textures remain sampled.
            g.glFramebufferTexture2D(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_TEXTURE_2D,0,0)
            g.glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,layer[f'history{dst}'],0)
            g.glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT1,GL_TEXTURE_2D,layer[f'oldmeta{dst}'],0)
            g.glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0+2,GL_TEXTURE_2D,0,0)
            g.glDrawBuffers(2,(U*2)(GL_COLOR_ATTACHMENT0,GL_COLOR_ATTACHMENT1))
            g.glUseProgram(self.layer_temporal_program)
            bindings=((self._peel_colors[i],'uCurrent'),(layer[f'history{src}'],'uHistory'),
                      (layer['motion'],'uMotion'),(layer['meta'],'uMeta'),(layer[f'oldmeta{src}'],'uOldMeta'))
            for unit,(tex,name) in enumerate(bindings):
                g.glActiveTexture(GL_TEXTURE0+unit);g.glBindTexture(GL_TEXTURE_2D,tex);g.uniform(self.layer_temporal_program,name,unit)
            weight=self._history_count/(self._history_count+1) if self.info.history_limit>1 else 0.
            g.uniform(self.layer_temporal_program,'uWeight',float(weight))
            g.uniform(self.layer_temporal_program,'uMoving',int(self._moving_history))
            g.glBindVertexArray(self.fullscreen_vao);g.glDrawArrays(GL_TRIANGLES,0,3)
            self._resolved_layers.append(layer[f'history{dst}'])
        self._layer_history_index=dst

    def _shadow_points(self):
        return [v for v in self._previous_card_vertices.values() if len(v)]

    def _fit_shadow(self,direction,target):
        """Scene-fitted light projection and nonuniform density-depth knots.

        Vertex-depth quantiles concentrate the eight extinction intervals around
        occupied geometry. This is bounded deep-opacity approximation, not ray GI.
        """
        owner=getattr(self,'object_workspace',None)
        key=(self._geometry_revision,tuple(direction),tuple(target),getattr(owner,'revision',0))
        if getattr(self,'_shadow_fit_key',None)==key:return self._fitted_light_mvp
        chunks=self._shadow_points()
        if owner:
            for obj in owner.evaluated_objects():
                if obj.get('visible',True):
                    verts=np.asarray(obj.get('vertices',[]),np.float32).reshape(-1,3)*obj.get('scale',1.)+np.asarray(obj.get('position',[0,0,0]),np.float32)
                    if len(verts):chunks.append(verts)
        points=np.concatenate(chunks) if chunks else np.array([[-1,-1,-1],[1,1,1]],np.float32)
        center=(points.min(axis=0)+points.max(axis=0))*.5
        radius=max(.01,float(np.linalg.norm(points.max(axis=0)-points.min(axis=0)))*.5)
        d=np.asarray(direction,np.float32);eye=center+d*(radius*2+.01)
        up=(1,0,0) if abs(float(d[1]))>.98 else (0,1,0)
        view=look_at(eye,center,up);q=points@view[:3,:3].T+view[:3,3]
        pad=radius*.04+.0001;lo=q.min(axis=0)-pad;hi=q.max(axis=0)+pad
        mvp=orthographic(lo[0],hi[0],lo[1],hi[1],max(.00001,-hi[2]),max(.00002,-lo[2]))@view
        z=(points@mvp[2,:3]+mvp[2,3])*.5+.5
        knots=np.quantile(z,np.linspace(0,1,9));knots[0]=0.;knots[-1]=1.
        # Avoid zero-width intervals on planar or repeated vertices.
        knots=.9*knots+.1*np.linspace(0.,1.,9)
        if not self.hq_available:knots=np.linspace(0.,1.,9)
        self._shadow_knots=knots;self._shadow_bias=max(.0001,1.5/self._shadow_resolution)
        self._shadow_fit_key=key;self._fitted_light_mvp=mvp
        return mvp

    def _adaptive_transparency(self):
        """Frame-level budget policy; NOT per-pixel adaptive K-buffer.

        Never changes material/texture source. Uses GPU timer EMA when present.
        Degrades with hysteresis; falls back to 2 ordered layers without timers.
        """
        if self._gpu_ema_ms<=0:return 'hybrid',2
        if self._gpu_ema_ms>24:return 'weighted',0
        if self._gpu_ema_ms>17:return 'hybrid',1
        if self._gpu_ema_ms<11:return 'hybrid',4
        return 'hybrid',2

    def _effective_transparency(self):
        if self.transparency_mode!='auto':return self.transparency_mode
        if self._quality_counter%8==0:
            desired,count=self._adaptive_transparency()
            if desired=='hybrid' and count!=self.peel_layers:
                self.peel_layers=count;self._release_peel_targets()
            self._auto_effective=desired
        self._quality_counter+=1
        return getattr(self,'_auto_effective','hybrid')

    def _pass_stamp(self,index):
        if self._pass_queries:
            self.gl.glQueryCounter(self._pass_queries[self._pass_frame%3][index],GL_TIMESTAMP)

    def _pass_timer_begin(self):
        if not self._pass_queries:return
        g=self.gl;queries=self._pass_queries[self._pass_frame%3]
        if self._pass_frame>=3:
            ready=U();g.glGetQueryObjectuiv(queries[-1],GL_QUERY_RESULT_AVAILABLE,C.byref(ready))
            if ready.value:
                values=[]
                for q in queries:
                    v=C.c_uint64();g.glGetQueryObjectui64v(q,GL_QUERY_RESULT,C.byref(v));values.append(v.value)
                spans=[(values[i+1]-values[i])*1e-6 for i in range(3)]
                if all(0<=s<=1000 for s in spans):
                    self.info.shadow_gpu_ms,self.info.oit_gpu_ms,self.info.aa_gpu_ms=spans
        self._pass_stamp(0)

    def _timer_begin(self):
        g=self.gl
        self._pass_timer_begin()
        if not self._gpu_queries:return
        idx=self._gpu_query_frame%len(self._gpu_queries)
        if self._gpu_query_frame>=len(self._gpu_queries):
            available=U(0)
            g.glGetQueryObjectuiv(self._gpu_queries[idx],GL_QUERY_RESULT_AVAILABLE,C.byref(available))
            if available.value:
                nanos=C.c_uint64(0)
                g.glGetQueryObjectui64v(self._gpu_queries[idx],GL_QUERY_RESULT,C.byref(nanos))
                value=nanos.value*1e-6
                # On some fresh Mesa/driver contexts the first query can
                # report a disjoint/invalid interval. Ignore implausible
                # samples rather than destroying adaptive quality decisions.
                if 0.001<=value<=1000.0:
                    self.info.gpu_ms=value
                    self._gpu_samples=(self._gpu_samples+[value])[-240:]
                    self.info.gpu_p95_ms=float(np.percentile(self._gpu_samples,95))
                    self.info.gpu_p99_ms=float(np.percentile(self._gpu_samples,99))
                    self._gpu_ema_ms=value if self._gpu_ema_ms<=0 else .83*self._gpu_ema_ms+.17*value
        g.glBeginQuery(GL_TIME_ELAPSED,self._gpu_queries[idx])

    def _timer_end(self):
        self._pass_stamp(3);self._pass_frame+=1
        if self._gpu_queries:
            self.gl.glEndQuery(GL_TIME_ELAPSED)
            self._gpu_query_frame+=1

    def projection_matrix(self,aspect):
        return perspective(math.radians(44),aspect,
                           max(1e-7,self.distance*.001),max(300.,self.distance*10))

    def before_present(self):
        """Optional GPU editor overlays, on the context owner before SwapBuffers."""
        if not (self.show_hud or self.show_axis_gizmo):
            return
        if self._overlay_hud is None:
            from .hud import ViewportOverlayRenderer
            self._overlay_hud = ViewportOverlayRenderer(self.gl)
        dpr = max(1.0, float(getattr(self, 'hud_dpr', 1.0)))
        if self.show_axis_gizmo:
            rot = self.yaw
            pitch = max(-1.4, min(1.4, self.pitch))
            eye = (
                float(self.target[0] + self.distance * math.sin(rot) * math.cos(pitch)),
                float(self.target[1] + self.distance * math.sin(pitch)),
                float(self.target[2] + self.distance * math.cos(rot) * math.cos(pitch)),
            )
            view_rot = look_at(eye, self.target)[:3, :3]
            self._overlay_hud.draw_axis_gizmo(self.display_width, self.display_height, dpr, view_rot, self.up_axis)
        if self.show_hud and self.hud_lines:
            self._overlay_hud.draw_hud(self.display_width, self.display_height, dpr, self.hud_lines)

    def _render_objects(self,mvp,eye,light_mvp=None,shadow_enabled=False,prepare_only=False):
        owner=getattr(self,'object_workspace',None)
        self._has_objects=False
        if owner is None or not any(o.get('visible',True) for o in owner.app.project.objects):return
        if not hasattr(self,'_object_renderer'):
            from ..reference_renderer import ReferenceRenderer
            self._object_renderer=ReferenceRenderer(self.gl)
        az=math.radians(self.material.light_azimuth);el=math.radians(self.material.light_elevation)
        light=(math.sin(az)*math.cos(el),math.sin(el),math.cos(az)*math.cos(el))
        self.gl.glUseProgram(self._object_renderer.program)
        p=self._object_renderer.program;g=self.gl
        self._environment(p)
        for name,value in {'uShadowDensity':15,'uShadowDensityFar':11,'uMeshShadow':14,
                           'uShadowEnabled':int(shadow_enabled),'uMeshShadowEnabled':int(getattr(self,'_mesh_shadow_enabled',False) and light_mvp is not None),
                           'uShadowStrength':float(self.material.shadow_strength),'uShadowFast':0,
                           'uShadowBias':float(getattr(self,'_shadow_bias',.001)),'uLightSize':float(self.material.light_size),
                           'uPhysical':int(self.hq_available and self.material.shading_mode=='Physical'),'uEnvSamples':MODES[self.quality_mode].environment_samples,
                           'uLightSamples':MODES[self.quality_mode].light_samples,
                           'uSampleIndex':0 if self.interacting or self.info.history_limit<=1 else self._history_count}.items():g.uniform(p,name,value)
        for i,v in enumerate(getattr(self,'_shadow_knots',np.linspace(0,1,9))):g.uniform(p,f'uShadowKnots[{i}]',float(v))
        if light_mvp is not None:
            matrix=np.ascontiguousarray(light_mvp,np.float32)
            g.glUniformMatrix4fv(g.glGetUniformLocation(p,b'uLightMVP'),1,GL_TRUE,matrix.ctypes.data_as(C.POINTER(F)))
            for unit,texture in ((15,self._shadow_texture),(11,getattr(self,'_shadow_texture_far',0)),(14,getattr(self._object_renderer,'shadow_depth',0))):
                g.glActiveTexture(GL_TEXTURE0+unit);g.glBindTexture(GL_TEXTURE_2D,texture)
        self._has_objects=self._object_renderer.render(owner,mvp,eye,light,self.width,self.height,self.material,prepare_only=prepare_only)
        self.gl.glActiveTexture(GL_TEXTURE0+8)
        self.gl.glBindTexture(GL_TEXTURE_2D,self._object_renderer.depth)
        self.gl.glActiveTexture(GL_TEXTURE0+9)
        self.gl.glBindTexture(GL_TEXTURE_2D,self._object_renderer.color)

    def _resolve_surface_history(self):
        if not getattr(self,'_has_objects',False):return
        obj=self._object_renderer;g=self.gl;obj.history_targets(self.width,self.height)
        key=(self._scene_key(),tuple((k,repr(v['signature'])) for k,v in obj.resources.items()),getattr(self,'_env_path',None))
        if obj.history_key!=key or self._history_count==0:obj.history_count=0;obj.history_key=key
        src=obj.history_index;dst=1-src
        g.glBindFramebuffer(GL_FRAMEBUFFER,obj.history_fbo)
        g.glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,obj.history[dst],0)
        g.glViewport(0,0,self.width,self.height);g.glUseProgram(self.temporal_program)
        for unit,texture,name in ((0,obj.color,'uCurrent'),(1,obj.history[src],'uHistory')):
            g.glActiveTexture(GL_TEXTURE0+unit);g.glBindTexture(GL_TEXTURE_2D,texture);g.uniform(self.temporal_program,name,unit)
        g.uniform(self.temporal_program,'uReproject',0)
        count=obj.history_count if not self.interacting else 0
        g.uniform(self.temporal_program,'uHistoryWeight',float(count/(count+1)))
        g.glBindVertexArray(self.fullscreen_vao);g.glDrawArrays(GL_TRIANGLES,0,3)
        obj.history_index=dst;obj.history_count=min(self.info.history_limit,count+1);obj.display_color=obj.history[dst]
        g.glActiveTexture(GL_TEXTURE0+9);g.glBindTexture(GL_TEXTURE_2D,obj.display_color)

    def render(self):
        if self._closed:return
        self.context.activate();g=self.gl
        t0=time.perf_counter()
        self.flush_tile_updates()
        self._timer_begin()
        self._sample_serial+=1
        effective=self._effective_transparency()
        self._effective_mode_for_frame=effective
        aspect=self.width/max(1,self.height)
        rot=self.yaw;pitch=max(-1.4,min(1.4,self.pitch))
        eye=(float(self.target[0]+self.distance*math.sin(rot)*math.cos(pitch)),
             float(self.target[1]+self.distance*math.sin(pitch)),
             float(self.target[2]+self.distance*math.cos(rot)*math.cos(pitch)))
        mvp=self.projection_matrix(aspect)@look_at(eye,self.target)
        base_mvp=mvp.copy()
        scene_key=self._scene_key()
        key=(scene_key,self.width,self.height,self.aa_method,self.quality_mode,self.interacting)
        safe_key=(self.width,self.height,self._geometry_revision,self._atlas_revision,repr(asdict(self.material)),self.aa_method,self.quality_mode,self.transparency_mode,self.peel_layers,self._oit_samples,getattr(self,'_auto_effective',''),getattr(getattr(self,'object_workspace',None),'revision',0))
        self._moving_history=key!=self._history_key and getattr(self,'_temporal_safe_key',None)==safe_key and self._history_count>0
        self._temporal_safe_key=safe_key
        if key!=self._history_key:
            if self._history_key is not None:self.info.history_reason='camera/material/scene changed'
            self._history_count=min(1,self.info.history_limit-1) if self._moving_history else 0;self._history_key=key
        if self.info.history_limit>1 and effective!='hybrid':
            jx,jy=jitter(min(self._history_count,self.info.history_limit-1))
            mvp[0,:]+=2*jx/self.width*mvp[3,:]
            mvp[1,:]+=2*jy/self.height*mvp[3,:]
        self._render_objects(mvp,eye,prepare_only=True)
        light_dir=(math.sin(math.radians(self.material.light_azimuth))*math.cos(math.radians(self.material.light_elevation)),
                   math.sin(math.radians(self.material.light_elevation)),
                   math.cos(math.radians(self.material.light_azimuth))*math.cos(math.radians(self.material.light_elevation)))
        light_target=self.material.key_target if self.material.key_target is not None else self.target
        light_mvp=self._fit_shadow(light_dir,light_target)
        shadow_enabled=self._render_shadow(light_mvp)
        self._mesh_shadow_enabled=False
        if getattr(self,'_has_objects',False):
            self._object_renderer.render_shadow(self.object_workspace,light_mvp,self._shadow_resolution)
            self._mesh_shadow_enabled=True
            self._render_objects(mvp,eye,light_mvp,shadow_enabled)
        self._resolve_surface_history()
        self._pass_stamp(1)
        hybrid=effective=='hybrid' and self.material.debug!=10
        if hybrid:
            final_front_depth=self._front_peel_passes(mvp,eye,light_mvp,shadow_enabled)
            self._resolve_layer_history()
            self._weighted_pass(mvp,eye,depth_threshold=final_front_depth,light_mvp=light_mvp,shadow_enabled=shadow_enabled)
        else:
            self._weighted_pass(mvp,eye,light_mvp=light_mvp,shadow_enabled=shadow_enabled)
        self._pass_stamp(2)
        # Composite to a linear premultiplied image BEFORE AA/display encoding.
        g.glBindFramebuffer(GL_FRAMEBUFFER,self._post_fbos[0])
        g.glViewport(0,0,self.width,self.height)
        composite=self.hybrid_composite_program if hybrid else self.msaa_composite_program if self._oit_samples>1 else self.composite_program
        g.glUseProgram(composite)
        for unit,tex,uni in [(0,self.accum,'uAccum'),(1,self.reveal,'uReveal')]:
            g.glActiveTexture(GL_TEXTURE0+unit)
            g.glBindTexture(GL_TEXTURE_2D_MULTISAMPLE if self._oit_samples>1 else GL_TEXTURE_2D,tex)
            g.uniform(composite,uni,unit)
        if hybrid:
            g.uniform(composite,'uLayerCount',self.peel_layers)
            for i,tex in enumerate(self._resolved_layers or self._peel_colors):
                g.glActiveTexture(GL_TEXTURE0+2+i);g.glBindTexture(GL_TEXTURE_2D,tex)
                g.uniform(composite,f'uPeel{i}',2+i)
        g.uniform(composite,'uExposure',float(self.material.exposure))
        g.uniform(composite,'uBackground',int(self.material.checker))
        g.uniform(composite,'uSamples',int(self._oit_samples));g.uniform(composite,'uDebug',int(self.material.debug))
        g.glBindVertexArray(self.fullscreen_vao);g.glDrawArrays(GL_TRIANGLES,0,3)
        if self.material.debug==14 or self._moving_history:
            g.glBindFramebuffer(GL_FRAMEBUFFER,self._post_fbos[3])
            g.glClearBufferfv(GL_COLOR,0,(F*4)(0,0,0,0));g.glClearDepth(1.);g.glClear(GL_DEPTH_BUFFER_BIT)
            g.glEnable(GL_DEPTH_TEST);g.glDepthFunc(GL_LESS)
            if self._history_count==0:self._previous_mvp=base_mvp.copy()
            self._draw_hair(base_mvp,eye,program=self.motion_program)
            g.glDisable(GL_DEPTH_TEST);self._motion_initialized=True
        self._previous_mvp=mvp.copy() if hybrid else base_mvp.copy();self._motion_geometry_pending=False
        if hybrid or self._history_count<self.info.history_limit:
            dst=1+(1-self._history_index);src=1+self._history_index
            g.glBindFramebuffer(GL_FRAMEBUFFER,self._post_fbos[dst]);g.glUseProgram(self.temporal_program)
            for unit,tex,uniform in ((0,self._post_textures[0],'uCurrent'),(1,self._post_textures[src],'uHistory')):
                g.glActiveTexture(GL_TEXTURE0+unit);g.glBindTexture(GL_TEXTURE_2D,tex);g.uniform(self.temporal_program,uniform,unit)
            g.glActiveTexture(GL_TEXTURE0+2);g.glBindTexture(GL_TEXTURE_2D,self._post_textures[3]);g.uniform(self.temporal_program,'uMotion',2)
            g.uniform(self.temporal_program,'uReproject',int(self._moving_history))
            weight=min(.65,self._history_count/(self._history_count+1)) if self._moving_history else self._history_count/(self._history_count+1)
            # Layer histories already accumulate hair. The weighted tail has no
            # trustworthy per-fragment motion and remains current-frame only.
            g.uniform(self.temporal_program,'uHistoryWeight',0. if hybrid and self.hq_available else float(weight))
            g.glBindVertexArray(self.fullscreen_vao);g.glDrawArrays(GL_TRIANGLES,0,3)
            self._history_index=dst-1;self._history_count=min(self.info.history_limit,self._history_count+1)
        g.glBindFramebuffer(GL_FRAMEBUFFER,getattr(self,'_capture_fbo',0))
        g.glViewport(0,0,self.display_width,self.display_height);g.glUseProgram(self.present_program)
        for unit,tex,uniform in ((0,self._post_textures[1+self._history_index],'uImage'),
                                  (1,self._reference,'uReference'),(2,self._post_textures[3],'uMotion')):
            g.glActiveTexture(GL_TEXTURE0+unit);g.glBindTexture(GL_TEXTURE_2D,tex);g.uniform(self.present_program,uniform,unit)
        for uniform,value in {
            'uPhysicalSize':(self.display_width,self.display_height),'uInternalSize':(self.width,self.height),
            'uExposure':float(self.material.exposure),'uBackground':int(self.material.checker),
            'uCompare':int(bool(self._reference and self._reference_key==scene_key)),
            'uDebug':int(self.material.debug),'uHistoryProgress':float(self._history_count/self.info.history_limit),
            'uTransparent':int(bool(getattr(self,'_capture_fbo',0))),
            'uSurfaceColor':9,'uHasSurface':int(getattr(self,'_has_objects',False)),
            'uBloom':float(self.material.bloom),'uBloomThreshold':float(self.material.bloom_threshold),
            'uBloomRadius':float(self.material.bloom_radius),'uChroma':float(self.material.chroma),
            'uDesaturate':float(self.material.desaturate),'uVignette':float(self.material.vignette),
            'uNoise':float(self.material.noise),'uNoiseSize':float(self.material.noise_size),
        }.items():g.uniform(self.present_program,uniform,value)
        if getattr(self,'_has_objects',False):
            g.glActiveTexture(GL_TEXTURE0+9)
            g.glBindTexture(GL_TEXTURE_2D,self._object_renderer.display_color or self._object_renderer.color)
        g.uniform(self.present_program,'uGrid',int(getattr(self,'show_grid',False)))
        g.uniform(self.present_program,'uZUp',int(getattr(self,'up_axis','Y-Up')=='Z-Up'))
        if getattr(self,'show_grid',False):
            inverse=np.ascontiguousarray(np.linalg.inv(base_mvp),dtype=np.float32)
            g.glUniformMatrix4fv(g.glGetUniformLocation(self.present_program,b'uInverseMVP'),1,GL_TRUE,inverse.ctypes.data_as(C.POINTER(F)))
            g.uniform(self.present_program,'uEye',tuple(eye))
        g.glBindVertexArray(self.fullscreen_vao);g.glDrawArrays(GL_TRIANGLES,0,3)
        if not getattr(self,'_capture_fbo',0):self.before_present()
        self._timer_end()
        if self.context.direct and not getattr(self,'_capture_fbo',0):self.context.present()
        self.info.shadow_memory_mib=(self._shadow_resolution**2*16)/(1024*1024) if self._shadow_texture else 0.0
        if getattr(self,'_mesh_shadow_enabled',False):self.info.shadow_memory_mib+=self._shadow_resolution**2*4/1024**2
        self.info.peel_passes=self.peel_layers if hybrid else 0
        # Approximate texture payload only (excludes alignment/driver overhead).
        layer_bytes=112 if self.quality_mode=='Capture' else 80
        self.info.peel_memory_mib=(self.width*self.height*(layer_bytes*len(self._peel_colors)+4*len(self._peel_depths)))/(1024.*1024.)
        self.info.transparency=('Weighted Blended OIT' if not hybrid else
                                f'Ordered {self.peel_layers}-layer + weighted tail')
        if self.transparency_mode=='auto':self.info.transparency='Auto · '+self.info.transparency
        # CPU wall-clock of this call, including Present if direct; not GPU time.
        self.info.render_ms=(time.perf_counter()-t0)*1000
        self.info.history_count=self._history_count
        self._cpu_samples=(self._cpu_samples+[self.info.render_ms])[-240:]
        self.info.cpu_p95_ms=float(np.percentile(self._cpu_samples,95));self.info.cpu_p99_ms=float(np.percentile(self._cpu_samples,99))
        self.info.allocations=self._target_allocations

    def release_inactive(self):
        """Release expensive view-private HQ history when a workspace is hidden."""
        self.context.activate();g=self.gl
        self._release_peel_targets()
        if hasattr(self,'_object_renderer'):self._object_renderer.release_history()
        for field in ('_shadow_texture','_shadow_texture_far'):
            texture=getattr(self,field,0)
            if texture:v=U(texture);g.glDeleteTextures(1,C.byref(v));setattr(self,field,0)
        if self._shadow_fbo:v=U(self._shadow_fbo);g.glDeleteFramebuffers(1,C.byref(v));self._shadow_fbo=0
        self._shadow_cache_key=None;self.info.peel_memory_mib=0.;self.info.shadow_memory_mib=0.
        self.invalidate_history('inactive view histories released')

    def capture_transparent(self):
        """Render postprocessed straight RGBA to an offscreen attachment, no checker."""
        self.context.activate();g=self.gl
        fbo=g.name('Framebuffers');texture=g.name('Textures')
        try:
            w,h=self.display_width,self.display_height
            g.glBindTexture(GL_TEXTURE_2D,texture)
            g.glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,w,h,0,GL_RGBA,GL_UNSIGNED_BYTE,None)
            g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR)
            g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR)
            g.glBindFramebuffer(GL_FRAMEBUFFER,fbo)
            g.glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,texture,0)
            g.glDrawBuffer(GL_COLOR_ATTACHMENT0)
            if g.glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE:
                raise RuntimeError('Transparent capture framebuffer incomplete')
            self._capture_fbo=fbo
            self.render()
            g.glBindFramebuffer(GL_FRAMEBUFFER,fbo);g.glReadBuffer(GL_COLOR_ATTACHMENT0)
            data=C.create_string_buffer(w*h*4)
            g.glReadPixels(0,0,w,h,GL_RGBA,GL_UNSIGNED_BYTE,C.cast(data,V))
            return Image.frombytes('RGBA',(w,h),data.raw).transpose(Image.Transpose.FLIP_TOP_BOTTOM)
        finally:
            self._capture_fbo=0;g.glBindFramebuffer(GL_FRAMEBUFFER,0)
            for kind,name in (('Textures',texture),('Framebuffers',fbo)):
                value=U(name);getattr(g,'glDelete'+kind)(1,C.byref(value))

    def capture_linear(self):
        """Read converged scene-linear premultiplied RGBA at internal resolution."""
        self.context.activate();g=self.gl
        def read(texture):
            data=np.empty((self.height,self.width,4),np.float32)
            g.glBindTexture(GL_TEXTURE_2D,texture)
            g.glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,V(data.ctypes.data))
            return data
        hair=read(self._post_textures[1+self._history_index])
        if getattr(self,'_has_objects',False):
            surface=read(self._object_renderer.display_color or self._object_renderer.color);hair+=surface*(1.-hair[:,:,3:4])
        return np.ascontiguousarray(hair[::-1])

    def capture(self):
        """Read final GPU color only for screenshots/headless tests, not direct Windows viewport."""
        g=self.gl;self.context.activate()
        g.glBindFramebuffer(GL_FRAMEBUFFER,0)
        w,h=self.display_width,self.display_height
        data=C.create_string_buffer(w*h*4)
        if self.context.direct:g.glReadBuffer(GL_FRONT)
        g.glReadPixels(0,0,w,h,GL_RGBA,GL_UNSIGNED_BYTE,C.cast(data,V))
        # Do not use gpu readback in Windows interactive frame loop.
        return Image.frombytes('RGBA',(w,h),data.raw).transpose(Image.Transpose.FLIP_TOP_BOTTOM)

    def close(self):
        if self._closed:return
        self.context.activate();g=self.gl
        if getattr(self,'_shadow_texture_far',0):
            obj=U(self._shadow_texture_far);g.glDeleteTextures(1,C.byref(obj));self._shadow_texture_far=0
        for field in ('_env_pdf','_env_cdf'):
            if getattr(self,field,0):
                obj=U(getattr(self,field));g.glDeleteTextures(1,C.byref(obj));setattr(self,field,0)
        if getattr(self,'_env_tex',0):
            obj=U(self._env_tex);g.glDeleteTextures(1,C.byref(obj));self._env_tex=0
        if hasattr(self,'_object_renderer'):self._object_renderer.close()
        if getattr(self,'_overlay_hud',None) is not None:
            self._overlay_hud.close()
            self._overlay_hud=None
        if self._sampling_worker:self._sampling_worker.shutdown(wait=False,cancel_futures=True)
        self._sampling_jobs={}
        for vao,vbo,_ in self._batches.values():
            obj=U(vbo);g.glDeleteBuffers(1,C.byref(obj))
            obj=U(vao);g.glDeleteVertexArrays(1,C.byref(obj))
        self._release_peel_targets()
        self._release_post_targets();self._release_tile_textures()
        for group in self._pass_queries:
            for n in group:
                obj=U(n);g.glDeleteQueries(1,C.byref(obj))
        self._pass_queries=[]
        if self._reference:
            obj=U(self._reference);g.glDeleteTextures(1,C.byref(obj))
        if self._gpu_queries:
            for n in self._gpu_queries:
                obj=U(n);g.glDeleteQueries(1,C.byref(obj))
            self._gpu_queries=[]
        if self._shadow_texture:
            obj=U(self._shadow_texture);g.glDeleteTextures(1,C.byref(obj))
            obj=U(self._shadow_fbo);g.glDeleteFramebuffers(1,C.byref(obj))
        for name in list(self._page_textures.values())+[self.accum,self.reveal]:
            obj=U(name);g.glDeleteTextures(1,C.byref(obj))
        obj=U(self.fbo);g.glDeleteFramebuffers(1,C.byref(obj))
        obj=U(self.fullscreen_vao);g.glDeleteVertexArrays(1,C.byref(obj))
        for name in self._programs:g.glDeleteProgram(name)
        self.context.close();self._closed=True
