"""Render Studio GPU preview for Tk-based Fiber Strand Designer V4.

Windows: WGL paints directly into Tk native child window, no frame readback.
Linux: EGL reference capture displays in Tk, useful for non-Windows testing.
Material edits never call Fiber Generator or Tile Rasterizer.
"""
from __future__ import annotations
from ..ui_theme import color as ui_color
from ..navigation import MayaNavigation, HELP, dolly_factor, pan_target
from ..dpi import watch_window,viewport_metrics,window_dpi,pixels
from dataclasses import asdict
import sys
import json
import math
import time
import tkinter as tk
from tkinter import ttk,filedialog,messagebox,colorchooser
from pathlib import Path
from PIL import ImageTk
from .renderer import GPUHairRenderer,HairMaterial
from .settings import material_from_project,store_material
from .device import enumerate_dxgi_adapters,gpu_mismatch
from .lighting import LightDrag,SHIFT_MASK,normalize_azimuth,clamp_elevation
from .lighting import light_color_from_srgb,light_color_hex
from ..gpu_bootstrap import launch_status
from ..cards import HairCard
from ..number_slider import NumberSlider
import numpy as np

BG=ui_color('background');PANEL=ui_color('panel');ACCENT=ui_color('selection');FG=ui_color('text');MUTED='#9faab7'
ASSET_ROOT=Path(__file__).parent.parent.parent/'samples'/'rendercore'

GROUPS=[
    ('Hair Reflection',[('cuticle_tilt','Cuticle Tilt · °',-10,10),('longitudinal_roughness','Longitudinal Roughness',.03,1),('azimuthal_roughness','Azimuthal Roughness',.03,1),('ior','Fiber IOR',1.01,2),('absorption','Pigment Absorption',0,3),('roughness','Roughness',0.02,1),('specular','Primary Specular',0,2),
                        ('secondary','Secondary Specular',0,1.5),('anisotropy','Anisotropy',0,1),
                        ('sheen','Sheen',0,1)]),
    ('Scattering / Optics',[('backlight','Backlight',0,1),('iridescence','Iridescence',0,1),
                            ('alpha_gain','Coverage Gain',0.1,2),
                            ('alpha_cutoff','Diagnostic Alpha Cutoff',0,1),
                            ('scatter_strength','Fiber Scattering',0,1),
                            ('shadow_strength','Self Shadow',0,1)]),
    ('Environment IBL',[('environment_strength','Environment Intensity',0,3),('environment_rotation','Environment Rotation',-180,180)]),
    ('Studio Lighting',[('light_intensity','Key Intensity',0.1,3),('fill_intensity','Fill Intensity',0,2),
                        ('ambient_intensity','Ambient Light',0,1.5),('light_size','Key Source Angle · °',0,360),
                        ('exposure','Exposure',-2,3)]),
    ('Rim Light',[('rim_intensity','Rim Intensity',0,3),('rim_azimuth','Rim Azimuth',-180,180),
                  ('rim_elevation','Rim Elevation',-85,85),('rim_width','Rim Softness',0,1)]),
    ('Post Effects',[('bloom','Bloom',0,2),('bloom_threshold','Bloom Threshold',0,3),
                     ('bloom_radius','Bloom Radius · px',1,32),('chroma','Chroma · px',0,12),
                     ('desaturate','Desaturate',0,1),('vignette','Vignette',0,1),
                     ('noise','Noise / Film Grain',0,1),('noise_size','Grain Size · px',1,8)]),
]
DEBUG_MODES=[('Rendered',0),('Alpha Coverage',1),('Normal',2),('Fiber Direction',3),
             ('Roughness',4),('Specular',5),('Iridescence',6),('Self Shadow',7),
             ('Original Alpha',8),('Effective Coverage',9),('Transparency Overdraw',10),
             ('Mipmap Level',11),('Alpha Cutoff',12),('Silhouette',13),
             ('Motion Vectors',14),('Temporal History',15),('Ordered Layer Overflow',16)]
LIGHT_COLOR_FIELDS={'light_intensity':'key_color','fill_intensity':'fill_color',
                    'ambient_intensity':'ambient_color','rim_intensity':'rim_color'}


def slider_value(text,minimum,maximum):
    """Parse only on commit, so partial numeric input remains editable."""
    value=float(str(text).strip().replace(',','.'))
    if not math.isfinite(value):raise ValueError('Value must be finite')
    return max(float(minimum),min(float(maximum),value))

from ..workspace_frame import WorkspaceFrame


class RenderStudio(WorkspaceFrame):
    def __init__(self,parent_or_app,app=None):
        self.app=app if app is not None else parent_or_app
        super().__init__(parent_or_app,bg=BG)
        self.title('FIBER STRAND DESIGNER  |  FIBER COVERAGE / HIGH-DPI')
        self.geometry('1290x790');self.minsize(940,590)
        self.configure(bg=BG)
        settings=getattr(app,'app_settings',None)
        topmost=settings.render_studio_topmost if settings else True
        self.attributes('-topmost',topmost)
        self.renderer=None
        self._photo=None
        self._render_after=None
        self._tick_after=None
        self._sweep=False
        self._drag=None
        self._light_drag=None
        self._last_size=(0,0)
        self._atlas_marker=0
        self._last_project_marker=0
        self._project_cache=None;self._project_cards_ref=None
        self.material=material_from_project(self.app.project)
        self._material_project=self.app.project
        self._capture_job=None;self._capture_after=None
        self.sliders={}
        self.values={}
        self.value_entries={}
        self.param_limits={field:(lo,hi) for _,fields in GROUPS for field,_,lo,hi in fields}
        self._syncing_slider=False
        self._building_controls=True
        self.light_color_buttons={}
        self._make_ui()
        self._building_controls=False
        watch_window(self)
        self.bind('<<DpiChanged>>',lambda e:self._frame_later(0))
        self.update_idletasks()
        try:
            hwnd=self.stage.winfo_id() if sys.platform=='win32' else None
            metrics=viewport_metrics(self.stage)
            width=max(64,metrics.physical_width);height=max(64,metrics.physical_height)
            self.renderer=GPUHairRenderer(width,height,hwnd=hwnd,async_sampling=True)
            from ..object_workspace import workspace
            self.renderer.object_workspace=workspace(self.app)
            self.renderer.material=self.material
            self.renderer.set_transparency('auto',2)
            self._set_sampling()
            self.status.set(f'{self.renderer.info.backend} | {self.renderer.info.gpu_renderer} | GL {self.renderer.info.gl_version}')
            self._load_demo_or_current()
            self._gpu_warning=self._detect_gpu_warning()
            self._frame_later(0)
            self._tick_after=self.after(110,self._tick)
        except Exception as ex:
            self.status.set('GPU renderer unavailable: '+str(ex))
            messagebox.showerror('GPU Render Studio',f'Không khởi tạo được GPU renderer:\n{ex}',parent=self)
        self.protocol('WM_DELETE_WINDOW',self._close)

    def load_environment(self):
        path=filedialog.askopenfilename(parent=self,title='Lat-long environment',filetypes=[('Environment','*.hdr *.png *.jpg *.jpeg *.tif *.tiff')])
        if path:self.set_environment(path)

    def set_environment(self,path):
        self.material.environment_path=path
        if self.renderer:self.renderer.invalidate_history('environment source changed')
        self._frame_later(0)

    def _make_ui(self):
        top=ttk.Frame(self,padding=(12,7));top.pack(side='top',fill='x')
        ttk.Label(top,text='GPU RENDER STUDIO',font=('Segoe UI Semibold',12)).pack(side='left',padx=(2,12))
        tk.Label(top,text='RENDERCORE HQ  ·  Lookdev',fg=ui_color('cyan'),bg=ui_color('background'),font=('Segoe UI Semibold',9)).pack(side='left')
        ttk.Button(top,text='Hide Controls [Tab]',style='TButton',command=self._toggle_controls).pack(side='right',padx=3)
        ttk.Button(top,text='Capture PNG / EXR',style='Primary.TButton',command=self.capture).pack(side='right',padx=3)
        ttk.Button(top,text='HDRI Environment',style='TButton',command=self.load_environment).pack(side='right',padx=3)
        ttk.Button(top,text='Studio Env',style='TButton',command=lambda:self.set_environment('')).pack(side='right',padx=3)
        center=ttk.Frame(self);center.pack(fill='both',expand=True,padx=10,pady=5)
        view=ttk.Frame(center);controls=ttk.Frame(center,style='Panel.TFrame',width=315)
        view.place(relx=0,rely=0,relwidth=.8,relheight=1.)
        controls.place(relx=.8,rely=0,relwidth=.2,relheight=1.)
        self.viewport_panel=view
        self.paned=center
        self.controls_panel=controls
        self.controls_visible=True
        ttk.Style(self).configure('Studio.TNotebook.Tab',padding=(10,7))
        self.control_tabs=ttk.Notebook(controls,style='Studio.TNotebook')
        self.control_tabs.pack(fill='both',expand=True)
        self.tab_bodies={}
        for title in ('Material','Optics','Lighting','Post','View','Tools'):
            self.tab_bodies[title]=self._control_page(title)
        ttk.Label(self.tab_bodies['Tools'],text='Workflow source tile').pack(anchor='w',padx=8,pady=(8,2))
        self.workflow_tile=tk.StringVar()
        ttk.Button(self.tab_bodies['Tools'],text='Outliner / Import Models',
                   command=self._open_object_outliner).pack(fill='x',padx=8,pady=4)
        ttk.Button(self.tab_bodies['Tools'],text='Load Atlas Folder',command=self.load_atlas_folder).pack(fill='x',padx=8,pady=3)
        ttk.Button(self.tab_bodies['Tools'],text='Load Sample Demo',command=self.load_demo).pack(fill='x',padx=8,pady=3)
        self.workflow_tile_box=ttk.Combobox(self.tab_bodies['Tools'],textvariable=self.workflow_tile,
                                           state='readonly',postcommand=self._refresh_workflow_tiles)
        self.workflow_tile_box.pack(fill='x',padx=8,pady=4)
        self._refresh_workflow_tiles()
        bar=ttk.Frame(view,padding=(6,5));bar.pack(fill='x')
        ttk.Label(bar,text='GPU HAIR MATERIAL PREVIEW',font=('Segoe UI Semibold',10)).pack(side='left')
        self.debug_var=tk.StringVar(value='Rendered')
        options=[a for a,_ in DEBUG_MODES]
        cmb=ttk.Combobox(bar,textvariable=self.debug_var,values=options,width=19,state='readonly')
        cmb.pack(side='right');cmb.bind('<<ComboboxSelected>>',self._set_debug)
        self.oit_var=tk.StringVar(value='Auto · GPU Budget')
        oit=ttk.Combobox(bar,textvariable=self.oit_var,width=21,state='readonly',
                         values=['Auto · GPU Budget','Weighted · Fast','Hybrid · 2 Layers','Hybrid · 4 Layers','Hybrid · 8 Layers'])
        oit.pack(side='right',padx=(3,10));oit.bind('<<ComboboxSelected>>',self._set_oit)
        sampling=ttk.Frame(self.tab_bodies['View'],padding=(6,4));sampling.pack(fill='x')
        saved=self.app.project.metadata.get('rendercore',{}).get('quality','Lookdev')
        self.quality_var=tk.StringVar(value=saved if saved in ('Edit','Lookdev','Capture') else 'Lookdev')
        self.scale_var=tk.StringVar(value='Auto')
        self.aa_var=tk.StringVar(value='Temporal')
        for label,var,values,width in (
            ('Quality',self.quality_var,['Edit','Lookdev','Capture'],12),
            ('Scale',self.scale_var,['Auto','1x','1.5x','2x'],6),
            ('AA',self.aa_var,['Off','Spatial','Temporal','MSAA4'],10)):
            row=ttk.Frame(sampling);row.pack(fill='x',pady=5)
            ttk.Label(row,text=label).pack(side='left',padx=(5,2))
            combo=ttk.Combobox(row,textvariable=var,values=values,state='readonly',width=width)
            combo.pack(side='right');combo.bind('<<ComboboxSelected>>',self._set_sampling)
            if hasattr(self.app,'ui_registry'):self.app.ui_registry.register('workspace.render.quality.'+label.lower(),combo)
        self.shading_var=tk.StringVar(value=self.material.shading_mode)
        ttk.Label(self.tab_bodies['Material'],text='Shading model').pack(anchor='w',padx=12,pady=(10,2))
        model=ttk.Combobox(self.tab_bodies['Material'],textvariable=self.shading_var,values=['Physical','Legacy'],state='readonly')
        model.pack(fill='x',padx=12,pady=3);model.bind('<<ComboboxSelected>>',self._set_model)
        if hasattr(self.app,'ui_registry'):self.app.ui_registry.register('workspace.render.shading_model',model)
        self.artistic_var=tk.BooleanVar(value=self.material.artistic_optics)
        ttk.Checkbutton(self.tab_bodies['Material'],text='Artistic specular / sheen / iridescence',variable=self.artistic_var,command=self._set_model).pack(anchor='w',padx=12,pady=3)
        ttk.Label(self.tab_bodies['Material'],text='Physical: roughness, IOR, pigment and cuticle. Legacy gains apply in Legacy or Artistic mode.',wraplength=240).pack(fill='x',padx=12,pady=4)
        self.capture_samples=tk.IntVar(value=256)
        ttk.Label(sampling,text='Capture samples').pack(anchor='w',padx=5,pady=(10,2))
        ttk.Spinbox(sampling,from_=1,to=4096,textvariable=self.capture_samples,width=8).pack(fill='x',padx=5)
        ttk.Button(sampling,text='Cancel Capture',command=self.cancel_capture).pack(fill='x',pady=3)
        ttk.Button(sampling,text='Pin Before',command=self._pin_before).pack(fill='x',pady=3)
        ttk.Button(sampling,text='Clear Compare',command=self._clear_compare).pack(fill='x',pady=3)
        self.stage_wrap=tk.Frame(view,bg=ui_color('viewport'))
        self.stage_wrap.pack(fill='both',expand=True,padx=4,pady=(0,4))
        self.stage=tk.Frame(self.stage_wrap,bg=ui_color('viewport'),bd=0,highlightthickness=0,takefocus=1)
        self.stage.pack(fill='both',expand=True)
        self.preview_label=tk.Label(self.stage,bd=0,highlightthickness=0,bg=ui_color('viewport'))
        # On Windows the HWND itself is the OpenGL surface, no Tk image overlay.
        if sys.platform!='win32':self.preview_label.pack(fill='both',expand=True)
        self.stage.bind('<Configure>',self._resize)
        for widget in [self.stage,self.preview_label]:
            widget.bind('<Enter>',lambda e:self.stage.focus_set(),add='+')
            widget._navigation=MayaNavigation(widget,self._nav_orbit,self._nav_pan,self._nav_dolly,
                                              on_start=self._begin_navigation,on_end=self._end_navigation)
            widget.bind('<ButtonPress-3>',self._light_down)
            widget.bind('<B3-Motion>',self._light_move)
            widget.bind('<ButtonRelease-3>',self._light_up)
            widget.bind('<MouseWheel>',self._wheel)
            widget.bind('<Button-4>',lambda e:self._zoom(.90))
            widget.bind('<Button-5>',lambda e:self._zoom(1.10))
            for button in (1,3):
                widget.bind(f'<Control-ButtonPress-{button}>',self._radius_down)
                widget.bind(f'<Control-B{button}-Motion>',self._radius_move)
                widget.bind(f'<Control-ButtonRelease-{button}>',self._radius_up)
            widget.bind('<B1-Motion>',self._radius_move,add='+')
            widget.bind('<ButtonRelease-1>',self._radius_up,add='+')
        controlrow=ttk.Frame(self.tab_bodies['Tools'],padding=6);controlrow.pack(fill='x')
        ttk.Button(controlrow,text='Frame All  [F]',command=self.frame_all).pack(fill='x',pady=3)
        ttk.Button(controlrow,text='Light Sweep',command=self._toggle_sweep).pack(fill='x',pady=3)
        ttk.Button(controlrow,text='Reset Light',command=self.reset_light).pack(fill='x',pady=3)
        settings=getattr(self.app,'app_settings',None)
        self.topmost_var=tk.BooleanVar(value=settings.render_studio_topmost if settings else True)
        ttk.Checkbutton(controlrow,text='Always On Top',variable=self.topmost_var,
                        command=self._toggle_topmost).pack(anchor='w',pady=4)
        self.checker=tk.BooleanVar(value=False)
        ttk.Checkbutton(controlrow,text='Checker Background',variable=self.checker,command=self._change_checker).pack(anchor='w',pady=4)
        ttk.Label(self.tab_bodies['Tools'],text=HELP+'  ·  Shift + RMB: rotate light',wraplength=270,foreground=MUTED).pack(anchor='w',padx=12,pady=(0,3))
        self.light_guide=tk.StringVar(value='')
        tk.Label(self.tab_bodies['Lighting'],textvariable=self.light_guide,bg=PANEL,fg=ACCENT,
                 wraplength=270,justify='left',font=('Segoe UI Semibold',9)).pack(anchor='w',padx=12,pady=(0,6))
        self._refresh_light_guide()
        for w in (self, self.stage, self.preview_label):
            w.bind('<KeyPress-f>',lambda e:self.frame_all())
            w.bind('<KeyPress-F>',lambda e:self.frame_all())
            w.bind('<Escape>',lambda e:self._cancel_interactions())
            w.bind('<Tab>',self._toggle_controls_key)
        self.bind('<FocusOut>',lambda e:self._cancel_light_drag())
        self.bind('<FocusOut>',lambda e:self._cancel_radius_drag(),add='+')
        self.slider_area=self.tab_bodies['Material']
        ttk.Style(self).map('Numeric.TEntry',fieldbackground=[('invalid','#4c2928')],
                           foreground=[('invalid','#ffb6aa')])
        for group,fields in GROUPS:
            inner=self.tab_bodies[{'Hair Reflection':'Material','Scattering / Optics':'Optics',
                                   'Environment IBL':'Lighting','Studio Lighting':'Lighting','Rim Light':'Lighting','Post Effects':'Post'}[group]]
            tk.Label(inner,text=group.upper(),bg=PANEL,fg=ACCENT,font=('Segoe UI Semibold',9)).pack(anchor='w',padx=12,pady=(11,4))
            for field,label,lo,hi in fields:
                row=ttk.Frame(inner,style='Panel.TFrame');row.pack(fill='x',padx=12,pady=3)
                color_field=LIGHT_COLOR_FIELDS.get(field)
                if color_field:self._make_light_color(row,color_field)
                ttk.Label(row,text=label,style='Panel.TLabel').pack(side='left')
                val_num=float(getattr(self.material,field))
                value=tk.StringVar(value=f'{val_num:.6g}')
                self.param_limits[field]=(lo,hi)
                step=1.0 if 'rim_azimuth' in field or 'rim_elevation' in field or 'light_size' in field else 0.01
                scale=NumberSlider(row,from_=lo,to=hi,step=step,width=155,height=22,
                                   command=lambda x,f=field:self._set_param(f,x))
                scale.pack(side='right',fill='x',expand=True)
                self.sliders[field]=scale;self.values[field]=value;self.value_entries[field]=scale
                if hasattr(self.app,'ui_registry'):self.app.ui_registry.register('workspace.render.parameter.'+field,scale)
                self._set_slider(field,val_num)
        if sys.platform=='win32':
            ttk.Button(top,text='GPU Info',command=self._open_gpu_settings).pack(side='right',padx=3)
        self.status=tk.StringVar(value='Starting GPU Renderer...')
        footer=ttk.Frame(self,padding=(12,7));footer.pack(fill='x')
        ttk.Label(footer,textvariable=self.status,foreground=MUTED).pack(anchor='w')
        self.render_summary=tk.StringVar(value='')
        ttk.Label(footer,textvariable=self.render_summary,foreground=MUTED).pack(anchor='w')
        self.details=tk.StringVar(value='')
        stats=self._control_page('Stats')
        self._stats_page=stats.master.master
        details_label=ttk.Label(stats,textvariable=self.details,foreground=MUTED,justify='left')
        details_label.pack(anchor='w',fill='x')
        stats.bind('<Configure>',lambda e:details_label.configure(wraplength=max(100,e.width-24)))
        self._last_details_time=0.
        self.after(200,lambda:self._sash_setup(center))

    def _control_page(self,title):
        page=ttk.Frame(self.control_tabs)
        self.control_tabs.add(page,text=title)
        canvas=tk.Canvas(page,bg=PANEL,bd=0,highlightthickness=0)
        canvas.pack(side='left',fill='both',expand=True)
        scroll=ttk.Scrollbar(page,orient='vertical',command=canvas.yview)
        scroll.pack(side='right',fill='y');canvas.configure(yscrollcommand=scroll.set)
        body=ttk.Frame(canvas,style='Panel.TFrame')
        window=canvas.create_window((0,0),window=body,anchor='nw')
        body.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure(window,width=e.width))
        return body

    def _toggle_controls_key(self,event):
        if isinstance(event.widget,(ttk.Entry,ttk.Combobox,tk.Entry)):return
        self._toggle_controls()
        return 'break'

    def _handle_global_key(self, event):
        if isinstance(getattr(event, 'widget', None), (ttk.Entry, ttk.Combobox, tk.Entry, tk.Spinbox, tk.Text)):
            return None
        k = event.keysym.lower() if getattr(event, 'keysym', None) else ''
        if k == 'f':
            self.frame_all()
            return 'break'
        elif k == 'escape':
            self.cancel_capture()
            self._cancel_interactions()
            return 'break'
        elif k == 'tab':
            return self._toggle_controls_key(event)
        return None

    def _toggle_controls(self):
        self.controls_visible=not self.controls_visible
        self._restore_controls_width()
        self._frame_later(0)

    def _restore_controls_width(self):
        # Fixed relative layout: no sash or user-adjustable width.
        if not self.winfo_exists():return
        if self.controls_visible:
            self.viewport_panel.place(relx=0,rely=0,relwidth=.8,relheight=1.)
            self.controls_panel.place(relx=.8,rely=0,relwidth=.2,relheight=1.)
        else:
            self.controls_panel.place_forget()
            self.viewport_panel.place(relx=0,rely=0,relwidth=1.,relheight=1.)

    def _detect_gpu_warning(self):
        try:
            adapters=enumerate_dxgi_adapters()
            mismatch=gpu_mismatch(self.renderer.info.gpu_renderer,adapters)
            policy=launch_status()
            if mismatch:
                requested='đã yêu cầu High Performance tự động' if policy.get('requested') else 'yêu cầu tự động chưa được áp dụng'
                self.status.set(f'GPU thực tế: {self.renderer.info.gpu_renderer} | Card rời: {mismatch.name} | {requested}; Windows/driver chưa chuyển context.')
                return mismatch
            if policy.get('requested'):
                self.status.set(f'Auto GPU · đang render: {self.renderer.info.gpu_renderer}')
            elif policy.get('reason'):
                self.status.set(f'GPU thực tế: {self.renderer.info.gpu_renderer} | Auto GPU: {policy["reason"]}')
        except Exception as exc:
            # Never stop the renderer if the operating system's GPU probe fails.
            self.status.set(f'{self.renderer.info.gpu_renderer} | GPU discovery: {exc}')
        return None

    def _open_gpu_settings(self):
        try:
            actual=self.renderer.info.gpu_renderer if self.renderer else 'Chưa tạo render context'
            adapters=enumerate_dxgi_adapters()
            available='\n'.join(f'• {a.name} — {a.dedicated_mb} MiB VRAM' for a in adapters if not a.software)
            policy=launch_status()
            mode='Đã tự yêu cầu High Performance' if policy.get('requested') else 'Dùng lựa chọn hiện có của Windows'
            reason=('\nChi tiết: '+policy['reason']) if policy.get('reason') else ''
            messagebox.showinfo('GPU Info',f'GPU thực sự đang render:\n{actual}\n\n{mode}{reason}\n\nGPU phát hiện:\n{available or "Không đọc được danh sách adapter"}',parent=self)
        except Exception as exc:
            messagebox.showinfo('GPU Info',str(exc),parent=self)

    def _sash_setup(self,center):
        self._restore_controls_width()

    def _refresh_value(self,field):
        if field in self.values:
            x=getattr(self.material,field)
            self.values[field].set(f'{float(x):.6g}')

    def _make_light_color(self,parent,field):
        button=tk.Button(parent,command=lambda f=field:self._choose_light_color(f),relief='flat',
                         width=3,height=1,padx=2,pady=1,cursor='hand2',takefocus=True)
        button.pack(side='right',padx=(7,0))
        self.light_color_buttons[field]=button
        self._refresh_light_color(field)

    def _refresh_light_color(self,field):
        color=light_color_hex(getattr(self.material,field))
        rgb=tuple(int(color[i:i+2],16) for i in (1,3,5))
        text='#101010' if sum(c*w for c,w in zip(rgb,(.2126,.7152,.0722)))>140 else '#ffffff'
        self.light_color_buttons[field].configure(text='',background=color,
                                                  activebackground=color,foreground=text,activeforeground=text)

    def _choose_light_color(self,field):
        rgb,_=colorchooser.askcolor(parent=self,initialcolor=light_color_hex(getattr(self.material,field)),
                                    title={'key_color':'Key Light Color','fill_color':'Fill Light Color',
                                           'ambient_color':'Ambient Light Color','rim_color':'Rim Light Color'}[field])
        if rgb is None:return
        setattr(self.material,field,light_color_from_srgb(rgb))
        self._refresh_light_color(field)
        if self.renderer:self.renderer.invalidate_history('light color changed')
        self._frame_later(0)

    def _set_param(self,field,text):
        if self._building_controls or self._syncing_slider:return
        try:value=slider_value(text,*self.param_limits[field])
        except (ValueError,TypeError):return
        setattr(self.material,field,value)
        self._refresh_value(field)
        self._frame_later(10)

    def _set_slider(self,field,value):
        self._syncing_slider=True
        try:
            if hasattr(self.sliders.get(field), 'set'):
                self.sliders[field].set(value, notify=False)
        finally:self._syncing_slider=False

    def _commit_value(self,field):
        try:value=slider_value(self.values[field].get(),*self.param_limits[field])
        except (ValueError,TypeError):
            self.value_entries[field].state(['invalid'])
            return 'break'
        changed=float(getattr(self.material,field))!=value
        setattr(self.material,field,value)
        self._set_slider(field,value)
        self._refresh_value(field)
        self.value_entries[field].state(['!invalid'])
        if changed:self._frame_later(0)
        return 'break'

    def _restore_value(self,field):
        self._refresh_value(field)
        self.value_entries[field].state(['!invalid'])
        return 'break'

    def _set_model(self,event=None):
        self.material.shading_mode=self.shading_var.get()
        self.material.artistic_optics=self.artistic_var.get()
        if self.renderer:self.renderer.invalidate_history('shading model changed')
        self._frame_later(0)

    def _set_debug(self,event=None):
        self.material.debug=dict(DEBUG_MODES)[self.debug_var.get()]
        self._frame_later(0)
    def _set_sampling(self,event=None):
        if self.renderer is None:return
        scale=None if self.scale_var.get()=='Auto' else float(self.scale_var.get().rstrip('x'))
        try:
            self.renderer.set_quality(self.quality_var.get(),scale,self.aa_var.get())
            self.oit_var.set('Weighted · Fast' if self.renderer.transparency_mode=='weighted' else f'Hybrid · {self.renderer.peel_layers} Layers')
            self._frame_later(0)
        except Exception as exc:self.status.set('Sampling: '+str(exc))
    def _pin_before(self):
        if self.renderer is None:return
        try:
            self.renderer.clear_reference();self.renderer.render();self.renderer.pin_reference()
            self.status.set('Compare: left = pinned sampling, right = current. Camera/light/scene edits invalidate the reference.')
            self._frame_later(0)
        except Exception as exc:self.status.set('Compare: '+str(exc))
    def _clear_compare(self):
        if self.renderer:self.renderer.clear_reference();self._frame_later(0)
    def _begin_navigation(self):
        self._cancel_interactions()
        if self.renderer:self.renderer.set_interaction(True)
    def _end_navigation(self):
        if self.renderer:self.renderer.set_interaction(False)
        self._frame_later(0)
    def _set_oit(self,event=None):
        if self.renderer is None:return
        value=self.oit_var.get()
        if value=='Weighted · Fast':self.renderer.set_transparency('weighted')
        elif value=='Hybrid · 2 Layers':self.renderer.set_transparency('hybrid',2)
        elif value=='Hybrid · 4 Layers':self.renderer.set_transparency('hybrid',4)
        elif value=='Hybrid · 8 Layers':self.renderer.set_transparency('hybrid',8)
        else:self.renderer.set_transparency('auto',2)
        self._frame_later(0)

    def _change_checker(self):
        self.material.checker=self.checker.get()
        self._frame_later(0)

    def _load_demo_or_current(self):
        self.sync_project()
        for tile in self.app.project.tiles:
            result=self.app._results.get(tile.id)
            if result is None or result.revision!=tile.revision:self.app._submit_preview(tile,show_status=False)

    def _can_continue_project(self):
        if self._atlas_marker<0:
            self.status.set('External/sample atlas has no editable project source. Sync Project to continue project workflows.')
            return False
        return True

    def _refresh_workflow_tiles(self):
        selected=getattr(self,'_workflow_tiles',{}).get(self.workflow_tile.get(),self.app.current_id)
        self._workflow_tiles={f'{i+1:02d} · {t.name}':t.id for i,t in enumerate(self.app.project.tiles)}
        self.workflow_tile_box.configure(values=list(self._workflow_tiles))
        self.workflow_tile.set(next((name for name,tid in self._workflow_tiles.items() if tid==selected),''))

    def _open_object_outliner(self):
        from ..object_workspace import workspace
        workspace(self.app).show()

    def _workflow_context(self):
        return self._workflow_tiles.get(self.workflow_tile.get(),self.app.current_id),None

    @staticmethod
    def _demo_cards(manifest):
        ids=list(manifest.get('tiles',{}))
        cards=[]
        for i in range(30):
            if not ids:break
            tile=ids[min(len(ids)-1,i//8)]
            card=HairCard.create(tile,f'Preview {i}',root=[(i-14.5)*.062,0.,(i%7)*-.025])
            card.length=.80+((i*7)%9)*.055
            card.width=.14+(i%4)*.013
            card.bend=(i-15)*.008
            card.yaw=(i-15)*.030
            card.tilt=(i-15)*.004
            cards.append(card)
        return cards

    def load_demo(self):
        if self.renderer is None:return
        try:
            manifest=self.renderer.load_atlas_directory(ASSET_ROOT)
            self.renderer.load_cards(self._demo_cards(manifest),manifest['tiles'],manifest['atlas_size'])
            self._atlas_marker=-1
            self.status.set('Demo atlas | GPU shader live | '+self.renderer.info.gpu_renderer)
            self._frame_later(0)
        except Exception as ex:
            messagebox.showerror('Demo Atlas',str(ex),parent=self)

    def load_atlas_folder(self):
        if self.renderer is None:return
        folder=filedialog.askdirectory(parent=self,title='Choose exported atlas folder (FSD_Atlas_manifest.json)')
        if not folder:return
        try:
            manifest=self.renderer.load_atlas_directory(folder)
            self.renderer.load_cards(self._demo_cards(manifest),manifest['tiles'],manifest['atlas_size'])
            self._atlas_marker=-1
            self.status.set('Atlas: '+Path(folder).name+' | '+self.renderer.info.gpu_renderer)
            self._frame_later(0)
        except Exception as ex:messagebox.showerror('Load Atlas',str(ex),parent=self)

    def sync_project(self):
        if self.renderer is None:return
        try:
            cache=self.app._atlas
            if self._project_cache is not cache or self._atlas_marker<0:
                self.renderer.load_atlas_cache(cache)
                self._project_cache=cache
            cards=self.app.project.cards
            if not cards:
                cards=[HairCard.create(t.id,root=[i*.35,0,0]) for i,t in enumerate(self.app.project.tiles)]
            self.renderer.load_cards(cards,cache.layout.placements,cache.layout.size)
            self._project_cards_ref=self.app.project.cards
            self._atlas_marker=len(cache.changed_regions)
            self.status.set('Live FSD Project | '+self.renderer.info.gpu_renderer)
            self._frame_later(0)
        except Exception as ex:messagebox.showerror('Sync Project',str(ex),parent=self)

    def _tick(self):
        if not self.winfo_exists() or self.renderer is None:return
        if self.renderer.sampling_pending:
            try:
                self.renderer.flush_tile_updates();self._frame_later(0)
            except Exception as exc:self.status.set('Tile sampling: '+str(exc))
        if self._atlas_marker>=0:
            try:
                cache=self.app._atlas
                if self._project_cache is not cache:
                    previous=self._project_cache
                    if previous is not None and previous.layout is cache.layout:
                        # Worker snapshots retain the layout but replace page sets.
                        # Diff versions, not just the latest changed_regions: the
                        # 100ms poll can skip several published snapshots.
                        for (tile_id,ch),version in cache._channel_versions.items():
                            if ch not in ('color','alpha','normal','flow','roughness'):continue
                            if previous._channel_versions.get((tile_id,ch))==version:continue
                            p=cache.layout.placements.get(tile_id)
                            if p is None:continue
                            rect=(p.x-p.gutter,p.y-p.gutter,
                                  p.x+p.width+p.gutter,p.y+p.height+p.gutter)
                            self.renderer.update_sampling_region(ch,p.page,rect,cache.get_page(ch,p.page))
                        self._project_cache=cache
                        self._atlas_marker=len(cache.changed_regions)
                        self._frame_later(0)
                    else:self.sync_project()
                if self._project_cards_ref is not self.app.project.cards:
                    # Card Editor commits a new list. Upload geometry only;
                    # material/light edits do not touch either source list.
                    self.renderer.load_cards(self.app.project.cards,cache.layout.placements,cache.layout.size)
                    self._project_cards_ref=self.app.project.cards
                    self._frame_later(0)
                updates=cache.changed_regions
                if self._atlas_marker>len(updates):self._atlas_marker=0
                if self._atlas_marker<len(updates):
                    for ch,page,rect in updates[self._atlas_marker:]:
                        if ch in ('color','alpha','normal','flow','roughness'):
                            self.renderer.update_sampling_region(ch,page,rect,cache.get_page(ch,page))
                    self._atlas_marker=len(updates)
                    self._frame_later(0)
            except Exception as ex:
                self.status.set('Atlas sync: '+str(ex))
                self._atlas_marker=-1
        self._tick_after=self.after(100,self._tick)

    def _resize(self,event):
        if self.renderer is None:return
        size=(max(64,event.width),max(64,event.height))
        if size!=self._last_size:
            self._last_size=size;self._frame_later(130)

    def _frame_later(self,delay=18):
        if self.renderer is None:return
        # Coalesce input into the already scheduled frame. Repeated mouse
        # events must not keep pushing its deadline into the future.
        if self._render_after is not None:return
        self._render_after=self.after(min(16,max(0,int(delay))),self._render)

    def _toggle_topmost(self):
        val=bool(self.topmost_var.get())
        self.attributes('-topmost',val)
        settings=getattr(self.app,'app_settings',None)
        if settings is not None:
            settings.render_studio_topmost=val
            settings.save()

    def _render(self):
        self._render_after=None
        if self.renderer is None or not self.winfo_exists() or self._capture_job:return
        try:
            if self._sweep:
                now=time.perf_counter()
                dt=min(.1,max(0.,now-getattr(self,'_sweep_clock',now)))
                self._sweep_clock=now
                self.material.light_azimuth=(self.material.light_azimuth+24.*dt+180)%360-180
                self._refresh_light_guide()
            metrics=viewport_metrics(self.stage)
            size=(max(64,metrics.physical_width),max(64,metrics.physical_height))
            if size!=(self.renderer.display_width,self.renderer.display_height):self.renderer.resize(*size)
            self.renderer.show_hud=False
            self.renderer.show_axis_gizmo=False
            self.renderer.show_grid=False
            self.renderer.hud_lines=()
            if self._material_project is not self.app.project:
                self._material_project=self.app.project;self.material=material_from_project(self.app.project)
                self.renderer.material=self.material;self.shading_var.set(self.material.shading_mode);self.artistic_var.set(self.material.artistic_optics)
                for field in self.sliders:self._set_slider(field,float(getattr(self.material,field)))
                for field in self.light_color_buttons:self._refresh_light_color(field)
            store_material(self.app.project,self.material,self.renderer.quality_mode)
            self.renderer.render()
            if not self.renderer.context.direct:
                image=self.renderer.capture().convert('RGB')
                self._photo=ImageTk.PhotoImage(image)
                self.preview_label.configure(image=self._photo)
            info=self.renderer.info
            actual=self.material.shading_mode if self.renderer.hq_available else 'Legacy backend fallback · see Stats'
            self.render_summary.set(f'{self.renderer.quality_mode} · {actual} · {info.peel_passes} ordered layers · samples {info.history_count}/{info.history_limit} · {info.render_scale:.2f}x · {self.renderer.quality_fallback}')
            now=time.perf_counter()
            if self.controls_visible and self.control_tabs.select()==str(self._stats_page) and now-self._last_details_time>=.25:
                self._last_details_time=now
                self.details.set(
                    f'{info.cards} cards · {info.triangles} tris · {info.transparency} · {info.aa_status} · {info.render_scale:.2f}x · '
                    f'{size[0]}×{size[1]} physical → {info.internal_size[0]}×{info.internal_size[1]} internal · DPR {metrics.dpr:.2f}\n'
                    f'CPU {info.render_ms:.1f} ms (P95/99 {info.cpu_p95_ms:.1f}/{info.cpu_p99_ms:.1f}) · '
                    f'GPU {info.gpu_ms:.1f} ms (P95/99 {info.gpu_p95_ms:.1f}/{info.gpu_p99_ms:.1f}) · '
                    f'OIT {info.oit_gpu_ms:.1f} / AA+display {info.aa_gpu_ms:.1f} ms · '
                    f'history {info.history_count}/{info.history_limit} · tile {info.tile_memory_mib:.0f} MiB · targets ≤{info.target_memory_mib:.0f} MiB estimated · '
                    f'upload {info.texture_upload_ms:.1f} ms CPU · allocations {info.allocations}\n'
                    f'{self.material.shading_mode} · {self.renderer.quality_mode} · {getattr(self.renderer,"quality_fallback","")}\n'
                    f'{info.memory_source}: budget {info.memory_budget_mib:.0f} / process {info.memory_usage_mib:.0f} MiB · target cap {info.target_budget_mib:.0f} MiB\n'
                    f'{self.renderer.backend_fallback}\n'
                    f'Environment: {getattr(self.renderer,"environment_error","") or "ready / preparing"}')
            if self._sweep or self.renderer.sampling_pending or getattr(getattr(self.renderer,'_object_renderer',None),'pending',False) or (info.history_count<info.history_limit and not self.renderer.interacting):self._frame_later(16)
        except Exception as ex:
            self.status.set('GPU render error: '+str(ex))

    def _nav_orbit(self,dx,dy):
        if self.renderer:
            self.renderer.yaw-=dx*.009
            self.renderer.pitch=max(-1.25,min(1.25,self.renderer.pitch+dy*.008))
            self._frame_later(0)
    def _nav_pan(self,dx,dy):
        if self.renderer:
            r=self.renderer
            r.target[:]=pan_target(r.target,r.yaw,r.pitch,r.distance,self.stage.winfo_height(),dx,dy,math.radians(44))
            self._frame_later(0)
    def _nav_dolly(self,dx,dy):self._zoom(dolly_factor(dx))

    def _refresh_light_guide(self):
        if hasattr(self,'light_guide'):
            self.light_guide.set(f'KEY LIGHT · Azimuth {self.material.light_azimuth:+.0f}° · Elevation {self.material.light_elevation:+.0f}° · Source angle {self.material.light_size:.1f}°\nShift + RMB: direction · Ctrl + LMB/RMB horizontal: source angle')

    def _light_down(self,event):
        if not self.renderer or not (event.state & SHIFT_MASK):return
        self._pick_light_target(event)
        self._stop_sweep()  # manual gesture takes priority over automatic Light Sweep
        if hasattr(self.renderer,'set_interaction'):self.renderer.set_interaction(True)
        self._light_drag=LightDrag(event.x,event.y,self.material.light_azimuth,self.material.light_elevation,
                                   sensitivity=.42/(window_dpi(self.stage)/96.))
        self.stage.focus_set()
        return 'break'

    def _pick_light_target(self,event):
        # Once per gesture: intersect card mesh, without a synchronous GPU readback.
        from .renderer import look_at
        r=self.renderer
        target=np.asarray(r.target,dtype=np.float64)
        eye=target+r.distance*np.array([math.sin(r.yaw)*math.cos(r.pitch),math.sin(r.pitch),
                                       math.cos(r.yaw)*math.cos(r.pitch)])
        w,h=max(1,self.stage.winfo_width()),max(1,self.stage.winfo_height())
        inverse=np.linalg.inv(r.projection_matrix(w/h)@look_at(eye,target))
        clip=np.array([2*event.x/w-1,1-2*event.y/h,1.,1.])
        point=inverse@clip;point=point[:3]/point[3]
        direction=point-eye;direction/=max(np.linalg.norm(direction),1e-12)
        nearest=float('inf')
        for vertices in r._previous_card_vertices.values():
            if len(vertices)<4:continue
            rows=np.arange(0,len(vertices)-2,2)
            indices=np.concatenate((np.stack((rows,rows+1,rows+2),1),
                                    np.stack((rows+1,rows+3,rows+2),1)))
            tri=vertices[indices].astype(np.float64)
            a=tri[:,1]-tri[:,0];b=tri[:,2]-tri[:,0]
            p=np.cross(direction,b);det=np.sum(a*p,axis=1)
            valid=np.abs(det)>1e-10
            inv=np.divide(1.,det,out=np.zeros_like(det),where=valid)
            offset=eye-tri[:,0];u=np.sum(offset*p,axis=1)*inv
            q=np.cross(offset,a);v=q@direction*inv
            distance=np.sum(b*q,axis=1)*inv
            hit=valid&(u>=0)&(v>=0)&(u+v<=1)&(distance>0)
            if np.any(hit):nearest=min(nearest,float(distance[hit].min()))
        if not math.isfinite(nearest):
            # Empty space: camera-facing plane through the orbit pivot.
            normal=target-eye;normal/=max(np.linalg.norm(normal),1e-12)
            denominator=float(np.dot(direction,normal))
            if abs(denominator)<1e-8:return
            nearest=float(np.dot(target-eye,normal)/denominator)
        if nearest>0:
            r.material.key_target=tuple(map(float,eye+direction*nearest))
            r.invalidate_history('key light target picked')

    def _light_move(self,event):
        if getattr(self,'_radius_drag',None) is not None:return self._radius_move(event)
        if self._light_drag is None or self.renderer is None:return
        self.material.light_azimuth,self.material.light_elevation=self._light_drag.update(event.x,event.y)
        self._refresh_light_guide()
        self._frame_later(0)
        return 'break'

    def _light_up(self,event):
        if getattr(self,'_radius_drag',None) is not None:return self._radius_up(event)
        if self._light_drag is None:return
        self._light_move(event)
        self._light_drag=None
        if hasattr(self.renderer,'set_interaction'):self.renderer.set_interaction(False)
        return 'break'

    def _cancel_light_drag(self):
        if self._light_drag is not None and self.renderer is not None and hasattr(self.renderer,'set_interaction'):
            self.renderer.set_interaction(False)
        self._light_drag=None
    def _cancel_interactions(self):
        self._stop_sweep()
        self._cancel_light_drag()
        self._cancel_radius_drag()
        self._drag=None

    def _radius_down(self,event):
        if self.renderer is None:return
        self._cancel_interactions()
        self._radius_drag=(event.x_root,self.material.light_size,window_dpi(self.stage)/96.)
        self.renderer.set_interaction(True)
        return 'break'

    def _radius_move(self,event):
        drag=getattr(self,'_radius_drag',None)
        if drag is None or self.renderer is None:return
        x,radius,dpi=drag
        self.material.light_size=max(0.,min(360.,radius+(event.x_root-x)*.6/max(dpi,.1)))
        self._set_slider('light_size',self.material.light_size)
        self._refresh_value('light_size')
        self._refresh_light_guide()
        self._frame_later(0)
        return 'break'

    def _radius_up(self,event):
        if getattr(self,'_radius_drag',None) is None:return
        self._radius_move(event)
        self._cancel_radius_drag()
        return 'break'

    def _cancel_radius_drag(self):
        if getattr(self,'_radius_drag',None) is not None:
            self._radius_drag=None
            if self.renderer:self.renderer.set_interaction(False)
            self._frame_later(0)

    def reset_light(self):
        self._stop_sweep()
        self._cancel_light_drag()
        self.material.light_azimuth=40.0
        self.material.key_target=None
        self.material.light_elevation=54.0
        self._refresh_light_guide()
        self._frame_later(0)

    def _wheel(self,event):self._zoom(.90 if event.delta>0 else 1.10)
    def _zoom(self,factor):
        if self.renderer:
            distance=self.renderer.distance*float(factor)
            if not math.isfinite(distance) or distance<=0:return
            self.renderer.distance=max(1e-5,distance)
            self._frame_later(0)
    def frame_all(self):
        if self.renderer:
            self.renderer.yaw=0;self.renderer.pitch=.1
            raw_cards=self.app.project.cards if getattr(self,'app',None) and getattr(self.app,'project',None) else []
            cards=[]
            for c in raw_cards:
                if isinstance(c,dict):
                    if c.get('visible',True) and not c.get('hidden',False):cards.append(c.get('root',[0.,0.,0.]))
                else:
                    if getattr(c,'visible',True) and not getattr(c,'hidden',False):cards.append(getattr(c,'root',[0.,0.,0.]))
            if cards:
                arr=np.array(cards,dtype=np.float32)
                spread=np.max(arr,axis=0)-np.min(arr,axis=0)
                self.renderer.target[:]=list(np.mean(arr,axis=0)+[0.,.5,0.])
                self.renderer.distance=float(max(spread[0],spread[1],spread[2],1.)*3.2)
            else:
                self.renderer.distance=4.1
                self.renderer.target[:]=[0.,.48,0.]
            self._frame_later(0)
    def _toggle_sweep(self):
        self._cancel_light_drag()
        self._sweep=not self._sweep
        self._sweep_clock=time.perf_counter()
        self._frame_later(0)
    def _stop_sweep(self):self._sweep=False
    def capture(self):
        if self.renderer is None or self._capture_job:return
        dest=filedialog.asksaveasfilename(parent=self,defaultextension='.png',filetypes=[('PNG display image','*.png'),('OpenEXR linear RGBA','*.exr')])
        if not dest:return
        try:
            samples=max(1,min(4096,int(self.capture_samples.get())))
            r=self.renderer
            previous=(r.quality_mode,r.scale_override,r.aa_method,r.transparency_mode,r.peel_layers)
            self._capture_job={'dest':dest,'samples':samples,'done':0,'previous':previous,'scene':None,'project':self.app.project}
            r.set_interaction(False);r.set_quality('Capture',None,'Temporal')
            r.info.history_limit=samples
            r.invalidate_history('capture start')
            self._capture_job['scene']=r._scene_key()
            self._stop_sweep();self._capture_after=self.after(1,self._capture_step)
        except Exception as error:
            self.cancel_capture();messagebox.showerror('Capture',str(error),parent=self)

    def _capture_step(self):
        self._capture_after=None;job=self._capture_job
        if not job:return
        try:
            r=self.renderer
            if job['project'] is not self.app.project or r._scene_key()!=job['scene']:
                self.cancel_capture();self.status.set('Capture canceled: scene changed.');return
            r.render()
            if r.sampling_pending:
                self.status.set('Capture: preparing environment / texture assets…')
                self._capture_after=self.after(30,self._capture_step);return
            if getattr(r,'environment_error',''):raise ValueError(r.environment_error)
            job['done']=r.info.history_count
            self.status.set(f"Capture {job['done']}/{job['samples']} · {r.width}×{r.height} · {r.info.peel_passes} front layers · Cancel Capture to stop")
            if job['done']<job['samples']:
                self._capture_after=self.after(1,self._capture_step);return
            dest=job['dest'];linear=Path(dest).suffix.lower()=='.exr'
            metadata={'gpu':r.info.gpu_renderer,'backend':r.info.backend,'material':asdict(self.material),
                      'quality':r.quality_mode,'sampling':asdict(r.info),'samples':job['done'],
                      'color_space':'linear Rec.709 D65' if linear else 'sRGB / FSD Filmic',
                      'alpha':'premultiplied' if linear else 'straight',
                      'fallback':getattr(r,'quality_fallback',''),'renderer':'RenderCore HQ / GL3.3 depth peeling',
                      'backend_fallback':r.backend_fallback,'hq_shader_active':r.hq_available,
                      'limitations':'Weighted tail has no temporal history; deep opacity and area-shadow visibility remain approximations.'}
            if linear:
                from .exr import write_linear
                write_linear(dest,r.capture_linear())
            else:
                # Always use offscreen capture: checker/grid/viewport overlays excluded.
                r.capture_transparent().save(dest)
            Path(dest).with_suffix('.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
            self.cancel_capture();self.status.set('Saved capture: '+dest)
        except Exception as error:
            self.cancel_capture();messagebox.showerror('Capture',str(error),parent=self)

    def cancel_capture(self):
        if self._capture_after:
            self.after_cancel(self._capture_after);self._capture_after=None
        job=self._capture_job;self._capture_job=None
        if job and self.renderer:
            mode,scale,aa,oit,layers=job['previous']
            self.renderer.set_quality(mode,scale,aa);self.renderer.set_transparency(oit,layers)
            self.status.set('Capture canceled / viewport restored.')
            self._frame_later(0)

    def pause(self):
        self.cancel_capture()
        if self._material_project is self.app.project:store_material(self.app.project,self.material,self.quality_var.get())
        if self.renderer:self.renderer.release_inactive()
        if self._sweep:self._stop_sweep()
        if self._tick_after:
            try:self.after_cancel(self._tick_after)
            except tk.TclError:pass
            self._tick_after=None
        if self._render_after:
            try:self.after_cancel(self._render_after)
            except tk.TclError:pass
            self._render_after=None

    def resume(self):
        if self._tick_after is None:
            self._tick_after=self.after(100,self._tick)
        self.sync_project()
        self._frame_later(0)

    def _close(self):
        self.pause()
        if self.renderer:
            try:self.renderer.close()
            except Exception:pass
        self.app.render_window=None
        self.destroy()
