#version 330 core
in vec2 vUV;
layout(location=0) out vec4 oColor;
layout(location=1) out vec4 oMeta;
uniform sampler2D uCurrent,uHistory,uMotion,uMeta,uOldMeta;
uniform float uWeight;
uniform int uMoving;
void main(){
 ivec2 sz=textureSize(uCurrent,0),p=clamp(ivec2(gl_FragCoord.xy),ivec2(0),sz-1);
 vec4 cur=texelFetch(uCurrent,p,0),meta=texelFetch(uMeta,p,0),motion=texelFetch(uMotion,p,0);oMeta=meta;oColor=cur;
 if(uWeight<=0.||cur.a<.002||meta.y<.5)return;
 vec2 uv=(vec2(p)+.5)/vec2(sz)-motion.xy;
 if(any(lessThan(uv,vec2(0)))||any(greaterThanEqual(uv,vec2(1))))return;
 ivec2 prev=clamp(ivec2(uv*vec2(sz)),ivec2(0),sz-1);
 vec4 oldMeta=texelFetch(uOldMeta,prev,0),old=texelFetch(uHistory,prev,0);
 // Layer reorder/occlusion rejects history rather than borrowing front motion.
 if(abs(meta.y-oldMeta.y)>.25||abs(motion.z-oldMeta.x)>.00035||length(vec2(mod(meta.z,1024.),floor(meta.z/1024.))-vec2(mod(oldMeta.z,1024.),floor(oldMeta.z/1024.)))>61.||abs(old.a-cur.a)>.12)return;
 float count=max(0.,oldMeta.w);
 float weight=min(uWeight,count/(count+1.));
 oMeta.w=min(4096.,count+1.);
 if(uMoving!=0){
  vec4 lo=cur,hi=cur;for(int y=-1;y<=1;y++)for(int x=-1;x<=1;x++){vec4 q=texelFetch(uCurrent,clamp(p+ivec2(x,y),ivec2(0),sz-1),0);lo=min(lo,q);hi=max(hi,q);}
  old=clamp(old,lo,hi);weight=min(weight,.8)*exp(-length(motion.xy)*20.);
 }
 oColor=mix(cur,old,weight);
}
