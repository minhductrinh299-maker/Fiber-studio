#version 330 core
in vec2 vUV;
out vec4 outColor;
uniform sampler2D uImage;
uniform sampler2D uReference;
uniform sampler2D uMotion;
uniform sampler2D uSurfaceColor;
uniform int uHasSurface;
uniform vec2 uPhysicalSize;
uniform vec2 uInternalSize;
uniform float uExposure;
uniform int uBackground;
uniform int uCompare;
uniform int uDebug;
uniform float uHistoryProgress;
uniform int uGrid;
uniform int uZUp;
uniform int uTransparent;
uniform float uBloom;
uniform float uBloomThreshold;
uniform float uBloomRadius;
uniform float uChroma;
uniform float uDesaturate;
uniform float uVignette;
uniform float uNoise;
uniform float uNoiseSize;
uniform mat4 uInverseMVP;
uniform vec3 uEye;
vec3 srgb(vec3 c){
    return mix(c*12.92,1.055*pow(max(c,vec3(0)),vec3(1./2.4))-.055,greaterThan(c,vec3(.0031308)));
}
vec4 resolve(){
    if(all(lessThanEqual(uInternalSize/uPhysicalSize,vec2(1.001))))return texture(uImage,vUV);
    // Integrate subpixel samples in premultiplied linear space. RGB and
    // coverage use exactly the same positive kernel; no straight-alpha halo
    // and no global FXAA/blur pass across one-pixel fiber silhouettes.
    vec2 d=.25/uPhysicalSize;
    return (texture(uImage,vUV+vec2(-d.x,-d.y))+texture(uImage,vUV+vec2(d.x,-d.y))+
            texture(uImage,vUV+vec2(-d.x,d.y))+texture(uImage,vUV+vec2(d.x,d.y)))*.25;
}
vec4 sceneSample(vec2 uv){
    vec4 hair=texture(uImage,uv);
    if(uHasSurface!=0){
        vec4 surface=texture(uSurfaceColor,uv);
        return hair+surface*(1.-hair.a);
    }
    return hair;
}
vec3 acesFilmic(vec3 x){
    vec3 u=max(x,vec3(0.))*0.72;
    return clamp((u*(2.51*u+0.03))/(u*(2.43*u+0.59)+0.14),0.,1.);
}
void main(){
    vec4 c=resolve();c.a=clamp(c.a,0.,1.);
    if(uHasSurface!=0){
        vec4 surface=texture(uSurfaceColor,vUV);
        c.rgb+=surface.rgb*(1.-c.a);
        c.a+=surface.a*(1.-c.a);
    }
    if(uDebug==0){
        if(uChroma>0.){
            vec2 shift=(vUV-.5)*uChroma*2./uPhysicalSize;
            vec4 r=sceneSample(vUV+shift),b=sceneSample(vUV-shift);
            c.rgb=vec3(r.r,c.g,b.b);
            c.a=max(c.a,max(r.a,b.a));
        }
        if(uBloom>0.){
            vec3 glow=vec3(0.);float halo=0.;
            float knee=max(0.15,uBloomThreshold*0.35);
            for(int i=0;i<16;i++){
                float angle=float(i)*2.39996323;
                float rNorm=sqrt((float(i)+.5)/16.);
                vec2 offset=vec2(cos(angle),sin(angle))*rNorm*uBloomRadius/uPhysicalSize;
                vec4 tap=sceneSample(vUV+offset);
                vec3 colTap=tap.rgb/max(tap.a,1e-6);
                float lum=dot(colTap,vec3(.2126,.7152,.0722));
                float rq=clamp(lum-uBloomThreshold+knee,0.,2.*knee);
                rq=(rq*rq)/(4.*knee);
                float bright=max(rq,max(0.,lum-uBloomThreshold))/max(lum,1e-5);
                float ringWeight=mix(1.15,0.45,rNorm)/16.;
                glow+=tap.rgb*bright*ringWeight;
                halo+=tap.a*bright*ringWeight;
            }
            c.rgb+=glow*uBloom*1.12;
            c.a=clamp(c.a+(1.-c.a)*halo*uBloom,0.,1.);
        }
        float gray=dot(c.rgb,vec3(.2126,.7152,.0722));
        c.rgb=mix(c.rgb,vec3(gray),uDesaturate);
        c.rgb*=1.-uVignette*smoothstep(.15,.75,length(vUV-.5));
    }
    vec3 bg=mix(vec3(.009,.013,.020),vec3(.032,.043,.062),vUV.y);
    bg*=1.-.26*pow(length(vUV-vec2(.5)),1.65);
    if(uBackground==1){
        vec2 cell=floor(gl_FragCoord.xy/24.);
        bg=mix(vec3(.18),vec3(.27),mod(cell.x+cell.y,2.));
    }
    if(uGrid!=0 && uTransparent==0){
        vec4 farClip=uInverseMVP*vec4(vUV*2.-1.,1.,1.);
        vec3 direction=normalize(farClip.xyz/farClip.w-uEye);
        float t=-uEye.y/(abs(direction.y)>.00001?direction.y:.00001);
        vec3 world=uEye+direction*max(t,0.);
        vec2 coord=world.xz*2.;
        vec2 widths=max(fwidth(coord),vec2(.00001));
        vec2 distanceToLine=abs(fract(coord-.5)-.5)/widths;
        float line=(1.-min(min(distanceToLine.x,distanceToLine.y),1.))*exp(-max(t,0.)*.075);
        if(t>0.){
            bg=mix(bg,vec3(.25,.29,.34),line*.16);
            float xAxis=1.-clamp(abs(world.z)/max(fwidth(world.z),.00001),0.,1.);
            float zAxis=1.-clamp(abs(world.x)/max(fwidth(world.x),.00001),0.,1.);
            // Near the horizon derivatives cover a broad world-space area:
            // suppress unresolved axes instead of blending them into purple.
            float axisFade=exp(-t*.075)*(1.-smoothstep(.05,.5,max(fwidth(world.x),fwidth(world.z))));
            bg=mix(bg,vec3(.45,.08,.06),xAxis*.25*axisFade);
            vec3 depthAxisColor = uZUp != 0 ? vec3(.08,.42,.12) : vec3(.06,.16,.5);
            bg=mix(bg,depthAxisColor,zAxis*.25*axisFade);
        }
    }
    vec3 light=max(vec3(0.),(uTransparent!=0?c.rgb/max(c.a,1e-7):c.rgb+bg*(1.-c.a))*exp2(uExposure));
    vec3 mapped=(uDebug==17 || uDebug==18)?light:(uDebug==0)?acesFilmic(light):(light/(1.+light));
    vec3 display=srgb(mapped);
    if(uDebug==0 && uTransparent==0){
        // Sub-LSB screen dither prevents 8-bit dark-studio gradient banding.
        float dither=fract(sin(dot(gl_FragCoord.xy,vec2(12.9898,78.233)))*43758.5453)-.5;
        display=clamp(display+vec3(dither*(1.0/255.0)),0.,1.);
    }
    if(uDebug==0 && uNoise>0.){
        // Stationary monochrome grain after tone mapping: no temporal crawl,
        // no extra history reset/frames; preserve transparent capture alpha.
        vec2 cell=floor(gl_FragCoord.xy/max(1.,uNoiseSize));
        float grain=fract(sin(dot(cell,vec2(127.1,311.7)))*43758.5453)-.5;
        float luminance=dot(display,vec3(.2126,.7152,.0722));
        float amplitude=uNoise*.22*sqrt(max(.02,luminance*(1.-luminance)));
        float coverage=uTransparent!=0?1.:c.a;
        display=clamp(display+vec3(grain*amplitude*coverage),0.,1.);
    }
    if(uDebug==8 || uDebug==9 || uDebug==13)display=vec3(c.a);
    if(uDebug==12)display=vec3(c.a>0.?c.r/max(c.a,1e-7):0.);
    if(uDebug==14){
        vec4 m=texture(uMotion,vUV);
        display=m.a>0.?clamp(vec3(.5+m.xy*32.,.5),0.,1.):vec3(0.);
    }
    if(uDebug==15)display=mix(vec3(.8,.12,.06),vec3(.1,.8,.3),uHistoryProgress);
    if(uCompare==1 && uTransparent==0 && vUV.x<.5)display=texture(uReference,vUV).rgb;
    if(uCompare==1 && uTransparent==0 && abs(vUV.x-.5)<1./uPhysicalSize.x)display=vec3(1.,.65,.2);
    outColor=vec4(uTransparent!=0 && c.a<1e-7?vec3(0.):display,uTransparent!=0?c.a:1.);
}
