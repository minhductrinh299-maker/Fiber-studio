// Shared hair -> hair/mesh and opaque mesh -> hair/mesh key visibility.
uniform sampler2D uMeshShadow;
uniform int uMeshShadowEnabled;
float fsdVisibility(vec4 clip){
 if(uShadowStrength<=0. || (uShadowEnabled==0 && uMeshShadowEnabled==0))return 1.;
 vec3 p=clip.xyz/max(abs(clip.w),1e-8)*.5+.5;p.z-=uShadowBias;
 if(any(lessThan(p,vec3(0)))||any(greaterThan(p,vec3(1))))return 1.;
 vec2 stepUV=1./vec2(textureSize(uShadowDensity,0));
 if(uShadowEnabled==0)stepUV=1./vec2(textureSize(uMeshShadow,0));
 float radius=.75+sin(radians(clamp(uLightSize,0.,360.))*.25)*5.5;
 vec4 nearW,farW;
 for(int i=0;i<4;i++){nearW[i]=clamp((p.z-uShadowKnots[i])/max(1e-6,uShadowKnots[i+1]-uShadowKnots[i]),0.,1.);farW[i]=clamp((p.z-uShadowKnots[i+4])/max(1e-6,uShadowKnots[i+5]-uShadowKnots[i+4]),0.,1.);}
 float sum=0.,norm=0.;
 for(int y=-2;y<=2;y++)for(int x=-2;x<=2;x++){
  if(uShadowFast!=0 && (abs(x)>1||abs(y)>1))continue;
  vec2 uv=p.xy+vec2(x,y)*stepUV*radius;float w=exp(-.5*float(x*x+y*y)),tau=0.;
  if(uShadowEnabled!=0)tau=dot(texture(uShadowDensity,uv),nearW)+dot(texture(uShadowDensityFar,uv),farW);
  float visible=uMeshShadowEnabled!=0?step(p.z,texture(uMeshShadow,uv).r):1.;
  sum+=exp(-min(tau,20.))*visible*w;norm+=w;
 }
 return mix(1.,sum/max(norm,1e-8),clamp(uShadowStrength,0.,1.));
}
