// Chiang/PBRT v3 normalized hair scattering. See vendor/pbrt/LICENSE.txt.
// Projected response, integrated in solid angle; do NOT multiply by N.L.
const float HP=3.14159265359;
uniform int uPhysical,uArtistic,uLightSamples,uEnvSamples,uSampleIndex;
uniform float uCuticleTilt,uFiberOffset;
uniform int uStableSampling;
uniform sampler2D uEnvPDF,uEnvDistribution;
float hLongitudinal;
float hrand(inout uint s){s=s*1664525u+1013904223u;uint t=s;t^=t>>16;t*=2246822519u;t^=t>>13;return (float(t>>8)+.5)/16777216.;}
float hlogI0(float x){
 if(x>12.)return x+.5*(-log(2.*HP)-log(x)+1./(8.*x));
 float term=1.,sum=1.;for(int i=1;i<10;i++){term*=x*x/(4.*float(i*i));sum+=term;}return log(sum);
}
float hmp(float si,float ci,float so,float co,float v){
 float a=ci*co/v,b=si*so/v;
 if(v<=.1)return exp(clamp(hlogI0(a)-b-1./v+log(1./v),-85.,80.));
 return exp(-b+hlogI0(a))/(v*(exp(1./v)-exp(-1./v)));
}
float hnp(float dp,float s){float x=mod(dp+HP,2.*HP)-HP,e=exp(-abs(x)/s);return e/(s*(1.+e)*(1.+e)*(1.-2./(1.+exp(min(80.,HP/s)))));}
vec3 hsigma(vec3 base){
 // Source RGB is the painted card pigment, not measured fiber reflectance.
 // Beer-Lambert attenuation over a unit-radius cylinder diameter (length 2).
 // Keep Fresnel R untinted; TT/TRT retain source pigment instead of bleaching it.
 return -.5*log(clamp(base,vec3(.0001),vec3(1.)))*max(0.,uAbsorption);}
void hsetup(vec3 wo,vec3 sigma,float h,out vec4 vari,out float s,out float gt,out float go,out vec3 ap[4]){
 float bm=clamp(hLongitudinal,.03,1.),bn=clamp(uAzimRough,.03,1.);
 float v=pow(.726*bm+.812*bm*bm+3.7*pow(bm,20.),2.);vari=vec4(v,.25*v,4.*v,4.*v);
 s=sqrt(HP/8.)*(.265*bn+1.194*bn*bn+5.372*pow(bn,22.));
 float so=clamp(wo.x,-.999999,.999999),co=sqrt(1.-so*so),eta=max(1.001,uIOR);
 gt=asin(clamp(h*co/sqrt(eta*eta-so*so),-.99999,.99999));go=asin(h);
 float ct=sqrt(1.-pow(so/eta,2.)),c=co*sqrt(1.-h*h),cost=sqrt(1.-(1.-c*c)/(eta*eta));
 float rp=(eta*c-cost)/(eta*c+cost),rs=(c-eta*cost)/(c+eta*cost),f=.5*(rp*rp+rs*rs);
 vec3 tr=exp(-sigma*(2.*cos(gt)/ct));ap[0]=vec3(f);ap[1]=(1.-f)*(1.-f)*tr;ap[2]=ap[1]*tr*f;ap[3]=ap[2]*tr*f/max(vec3(1e-8),1.-tr*f);
}
void hrotate(float so,int p,out float sp,out float cp){float a=radians(uCuticleTilt)*(p==0?-2.:p==1?1.:p==2?4.:0.);float co=sqrt(max(0.,1.-so*so));sp=so*cos(a)+co*sin(a);cp=abs(co*cos(a)-so*sin(a));}
vec3 heval(vec3 wo,vec3 wi,vec3 sigma,float h,out float pdf){
 vec4 vari;float s,gt,go;vec3 ap[4];hsetup(wo,sigma,h,vari,s,gt,go,ap);
 vec4 aw=vec4(dot(ap[0],vec3(.2126,.7152,.0722)),dot(ap[1],vec3(.2126,.7152,.0722)),dot(ap[2],vec3(.2126,.7152,.0722)),dot(ap[3],vec3(.2126,.7152,.0722)));aw/=max(dot(aw,vec4(1)),1e-12);
 float dp=atan(wi.z,wi.y)-atan(wo.z,wo.y),ci=sqrt(max(0.,1.-wi.x*wi.x));vec3 response=vec3(0);pdf=0.;
 for(int p=0;p<4;p++){float sp,cp;hrotate(wo.x,p,sp,cp);float n=p<3?hnp(dp-(2.*float(p)*gt-2.*go+float(p)*HP),s):1./(2.*HP);float q=hmp(wi.x,ci,sp,cp,vari[p])*n;response+=ap[p]*q;pdf+=aw[p]*q;}return response;
}
vec3 hsample(vec3 wo,vec3 sigma,float h,inout uint rng){
 vec4 vari;float s,gt,go;vec3 ap[4];hsetup(wo,sigma,h,vari,s,gt,go,ap);
 vec4 aw=vec4(dot(ap[0],vec3(.2126,.7152,.0722)),dot(ap[1],vec3(.2126,.7152,.0722)),dot(ap[2],vec3(.2126,.7152,.0722)),dot(ap[3],vec3(.2126,.7152,.0722)));aw/=max(dot(aw,vec4(1)),1e-12);
 float u=hrand(rng);int p=3;for(int i=0;i<3;i++){if(u<aw[i]){p=i;break;}u-=aw[i];}
 float sp,cp;hrotate(wo.x,p,sp,cp);float r=max(1e-6,hrand(rng));float c=clamp(1.+vari[p]*log(r+(1.-r)*exp(-2./vari[p])),-1.,1.);
 float si=clamp(-c*sp+sqrt(max(0.,1.-c*c))*cos(2.*HP*hrand(rng))*cp,-.999999,.999999);
 float up=hrand(rng),dphi;
 if(p==3)dphi=2.*HP*up;
 else{float lo=1./(1.+exp(min(80.,HP/s)));float t=clamp(lo+up*(1.-2.*lo),1e-7,1.-1e-7);dphi=s*log(t/(1.-t))+2.*float(p)*gt-2.*go+float(p)*HP;}
 float phi=atan(wo.z,wo.y)+dphi,ci=sqrt(1.-si*si);return vec3(si,ci*cos(phi),ci*sin(phi));
}
vec3 hlocal(vec3 d,vec3 t,vec3 b,vec3 n){return vec3(dot(d,t),dot(d,b),dot(d,n));}
vec3 hunrotate(vec3 d){float c=cos(uEnvironmentRotation),s=sin(uEnvironmentRotation);return vec3(c*d.x+s*d.z,d.y,-s*d.x+c*d.z);}
vec2 huv(vec3 d){return vec2(fract(atan(d.z,d.x)/(2.*HP)),acos(clamp(d.y,-1.,1.))/HP);}
vec4 henvsample(inout uint rng,out vec3 li){
 ivec2 sz=textureSize(uEnvDistribution,0);int lo=0,hi=sz.x*sz.y-1;float u=hrand(rng);
 for(int j=0;j<20;j++){if(lo<hi){int mid=(lo+hi)/2;float c=texelFetch(uEnvDistribution,ivec2(mid%sz.x,mid/sz.x),0).r;if(c<u)lo=mid+1;else hi=mid;}}
 ivec2 cell=ivec2(lo%sz.x,lo/sz.x);float phi=2.*HP*(float(cell.x)+hrand(rng))/float(sz.x);
 float cy=mix(cos(HP*float(cell.y)/float(sz.y)),cos(HP*float(cell.y+1)/float(sz.y)),hrand(rng));
 float sy=sqrt(max(0.,1.-cy*cy));li=texelFetch(uEnvironment,cell,0).rgb;return vec4(sy*cos(phi),cy,sy*sin(phi),texelFetch(uEnvPDF,cell,0).r);
}
vec3 harea(vec3 wo,vec3 axis,vec3 t,vec3 b,vec3 n,vec3 sigma,float h,float angle,int count,inout uint rng){
 vec3 x=normalize(abs(axis.y)<.99?cross(axis,vec3(0,1,0)):cross(axis,vec3(1,0,0))),y=cross(axis,x),sum=vec3(0);float cap=cos(radians(clamp(angle,0.,360.))*.5);
 for(int i=0;i<8;i++){if(i>=count)break;float z=mix(1.,cap,hrand(rng)),phi=2.*HP*hrand(rng);vec3 l=axis*z+sqrt(max(0.,1.-z*z))*(x*cos(phi)+y*sin(phi));float pdf;sum+=heval(wo,hlocal(l,t,b,n),sigma,h,pdf);}
 // Light intensity is integrated source strength, constant as angle changes.
 return sum/float(max(1,count));
}
vec3 hlightingAt(vec3 t,vec3 b,vec3 n,vec3 v,vec3 l,vec3 fill,vec3 base,float trans,float fiberH,uint sequence){
 hLongitudinal=clamp(uLongRough*clamp(texture(uRoughnessTex,vUV).r*2.,.25,2.),.03,1.);
 uint rng=sequence*26699u+911u;
 float h=fiberH;vec3 sigma=hsigma(base),wo=hlocal(v,t,b,n);
 vec3 result=harea(wo,l,t,b,n,sigma,h,uLightSize,uLightSamples,rng)*max(uKeyColor,vec3(0))*max(0.,uLightIntensity)*trans;
 float q;result+=heval(wo,hlocal(fill,t,b,n),sigma,h,q)*max(uFillColor,vec3(0))*max(0.,uFillIntensity);
 result+=heval(wo,hlocal(normalize(uRimDir),t,b,n),sigma,h,q)*max(uRimColor,vec3(0))*max(0.,uRimIntensity);
 vec3 ibl=vec3(0);
 for(int i=0;i<8;i++){
  if(i>=uEnvSamples)break;
  // Solid-angle HDRI importance estimator. BSDF proposal is not used here.
  if(uEnvironmentEnabled!=0 && uEnvironmentStrength>0.){
   vec3 li;vec4 sampleD=henvsample(rng,li);
   vec3 d=hunrotate(sampleD.xyz);vec3 f=heval(wo,hlocal(d,t,b,n),sigma,h,q);ibl+=f*li/max(sampleD.w,1e-12);

  }
  // Uniform ambient radiance sampled using the hair distribution.
  
 }
 vec4 vari;float ls,gt,go;vec3 ap[4];hsetup(wo,sigma,h,vari,ls,gt,go,ap);
 result+=(ap[0]+ap[1]+ap[2]+ap[3])*max(uAmbientColor,vec3(0))*max(0.,uAmbientIntensity);
 return result+ibl*(uEnvironmentStrength/float(max(1,uEnvSamples)));
}

vec3 hlighting(vec3 t,vec3 b,vec3 n,vec3 v,vec3 l,vec3 fill,vec3 base,float trans){
 if(uStableSampling==0)return hlightingAt(t,b,n,v,l,fill,base,trans,uFiberOffset,uint(uSampleIndex));
 // Three-node Gauss integration over cylinder offset. Stable lookdev samples
 // are independent of redraw count; Capture retains progressive integration.
 vec3 a=hlightingAt(t,b,n,v,l,fill,base,trans,-.7745966692,3u);
 vec3 c=hlightingAt(t,b,n,v,l,fill,base,trans,0.,7u);
 vec3 d=hlightingAt(t,b,n,v,l,fill,base,trans,.7745966692,11u);
 return (a+d)*(5./18.)+c*(4./9.);
}
