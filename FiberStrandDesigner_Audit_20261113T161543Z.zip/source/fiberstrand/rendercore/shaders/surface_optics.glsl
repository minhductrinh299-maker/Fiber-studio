// Linear dielectric/metal GGX. Environment integration uses balance MIS with
// a cosine/GGX BSDF mixture and solid-angle weighted HDRI importance sampling.
uniform sampler2D uEnvironment,uEnvPDF,uEnvDistribution;
uniform int uEnvironmentEnabled,uEnvSamples,uLightSamples,uSampleIndex,uPhysical;
uniform float uEnvironmentStrength,uEnvironmentRotation;
const float SP=3.14159265359;
float srand(inout uint s){s=s*1664525u+1013904223u;uint t=s;t^=t>>16;t*=2246822519u;t^=t>>13;return (float(t>>8)+.5)/16777216.;}
vec3 srotate(vec3 d,float angle){float c=cos(angle),s=sin(angle);return vec3(c*d.x-s*d.z,d.y,s*d.x+c*d.z);}
vec2 suv(vec3 d){return vec2(fract(atan(d.z,d.x)/(2.*SP)),acos(clamp(d.y,-1.,1.))/SP);}
float sg1(float c,float a2){return 2.*c/max(1e-8,c+sqrt(a2+(1.-a2)*c*c));}
vec3 seval(vec3 n,vec3 v,vec3 l,vec3 pigment,float metal,float r,vec3 f0,out float pdf){
 float nv=max(1e-6,dot(n,v)),nl=max(0.,dot(n,l));pdf=0.;if(nl<=0.)return vec3(0);
 vec3 halfV=v+l;if(dot(halfV,halfV)<1e-12)return vec3(0);vec3 h=normalize(halfV);
 float nh=max(0.,dot(n,h)),vh=max(1e-6,dot(v,h)),a2=pow(r,4.),den=nh*nh*(a2-1.)+1.;
 float d=a2/max(1e-12,SP*den*den),g=sg1(nv,a2)*sg1(nl,a2);
 vec3 f=f0+(1.-f0)*pow(1.-vh,5.);pdf=.5*nl/SP+.5*d*nh/(4.*vh);
 return ((1.-f)*(1.-metal)*pigment/SP+d*g*f/(4.*nv*nl))*nl;
}
vec3 ssample(vec3 n,vec3 v,float rough,inout uint rng){
 vec3 b=normalize(abs(n.y)<.99?cross(n,vec3(0,1,0)):cross(n,vec3(1,0,0))),t=cross(b,n);
 float u=srand(rng),phi=2.*SP*srand(rng);
 if(srand(rng)<.5){float z=sqrt(1.-u);return b*(sqrt(u)*cos(phi))+t*(sqrt(u)*sin(phi))+n*z;}
 float z=sqrt((1.-u)/(1.+(pow(rough,4.)-1.)*u));vec3 h=b*(sqrt(1.-z*z)*cos(phi))+t*(sqrt(1.-z*z)*sin(phi))+n*z;return reflect(-v,h);
}
vec3 senvironment(vec3 n,vec3 v,vec3 pigment,float metal,float rough,vec3 f0){
 uint rng=uint(uSampleIndex)*26699u+271u;
 vec3 sum=vec3(0);ivec2 sz=textureSize(uEnvDistribution,0);
 for(int i=0;i<8;i++){
  if(i>=uEnvSamples)break;
  float pdf;vec3 d=ssample(n,v,rough,rng);vec3 f=seval(n,v,d,pigment,metal,rough,f0,pdf);
  sum+=f/max(pdf,1e-12)*ambientColor;
  if(uEnvironmentEnabled==0||uEnvironmentStrength<=0.)continue;
  vec2 uv=suv(srotate(d,uEnvironmentRotation));float ep=texture(uEnvPDF,uv).r;
  ivec2 cell=clamp(ivec2(uv*vec2(sz)),ivec2(0),sz-1);
  sum+=f*texelFetch(uEnvironment,cell,0).rgb*(uEnvironmentStrength/max(pdf+ep,1e-12));
  int lo=0,hi=sz.x*sz.y-1;float u=srand(rng);
  for(int j=0;j<20;j++){if(lo<hi){int mid=(lo+hi)/2;float c=texelFetch(uEnvDistribution,ivec2(mid%sz.x,mid/sz.x),0).r;if(c<u)lo=mid+1;else hi=mid;}}
  cell=ivec2(lo%sz.x,lo/sz.x);float phi=2.*SP*(float(cell.x)+srand(rng))/float(sz.x),z=mix(cos(SP*float(cell.y)/float(sz.y)),cos(SP*float(cell.y+1)/float(sz.y)),srand(rng));
  d=srotate(vec3(sqrt(1.-z*z)*cos(phi),z,sqrt(1.-z*z)*sin(phi)),-uEnvironmentRotation);
  f=seval(n,v,d,pigment,metal,rough,f0,pdf);ep=texelFetch(uEnvPDF,cell,0).r;
  sum+=f*texelFetch(uEnvironment,cell,0).rgb*(uEnvironmentStrength/max(pdf+ep,1e-12));
 }
 return sum/float(max(1,uEnvSamples));
}
vec3 sarea(vec3 n,vec3 v,vec3 axis,vec3 pigment,float metal,float rough,vec3 f0){
 uint rng=uint(uSampleIndex)*26699u+313u;
 vec3 b=normalize(abs(axis.y)<.99?cross(axis,vec3(0,1,0)):cross(axis,vec3(1,0,0))),t=cross(axis,b),sum=vec3(0);
 float cap=cos(radians(clamp(uLightSize,0.,360.))*.5);
 for(int i=0;i<8;i++){if(i>=uLightSamples)break;float z=mix(1.,cap,srand(rng)),phi=2.*SP*srand(rng);vec3 d=axis*z+sqrt(1.-z*z)*(b*cos(phi)+t*sin(phi));float pdf;sum+=seval(n,v,d,pigment,metal,rough,f0,pdf);}
 return sum/float(max(1,uLightSamples));
}
