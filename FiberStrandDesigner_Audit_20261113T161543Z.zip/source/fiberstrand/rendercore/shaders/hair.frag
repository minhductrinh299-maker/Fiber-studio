#version 330 core
in vec2 vUV;
in vec3 vWorldPos;
in vec3 vTangent;
in vec3 vNormal;
in vec4 vLightClip;
in vec4 vCurrentClip,vPreviousClip;
flat in uint vCardID;
#ifdef FSD_PEEL_PASS
layout(location=0) out vec4 oLayer;
layout(location=1) out vec4 oLayerMotion;
layout(location=2) out vec4 oLayerMeta;
#else
layout(location=0) out vec4 oAccum;
layout(location=1) out vec4 oReveal;
#endif
uniform sampler2D uPrevDepth;
uniform sampler2D uOpaqueDepth;
uniform int uHasOpaque;
uniform sampler2D uShadowDensity;
uniform sampler2D uShadowDensityFar;
uniform int uShadowFast;
uniform float uShadowStrength;
uniform float uScatterStrength;
uniform float uShadowKnots[9];
uniform float uShadowBias;
uniform int uShadowEnabled;
uniform int uDepthReject;
uniform sampler2D uColor;
uniform sampler2D uAlpha;
uniform sampler2D uNormalTex;
uniform sampler2D uFlow;
uniform sampler2D uRoughnessTex;
uniform vec3 uLightDir;
uniform vec3 uKeyPosition;
uniform int uUseKeyPosition;
uniform vec3 uViewPos;
uniform float uLightIntensity;
uniform float uFillIntensity;
uniform float uAmbientIntensity;
uniform vec3 uKeyColor;
uniform vec3 uFillColor;
uniform vec3 uAmbientColor;
uniform float uLightSize;
// Full angular extent in degrees. Smooth monotonic spread through 360 degrees;
// no clamp plateau above 180 and no tangent singularity at a hemisphere.
float sourceSpread(){return sin(radians(clamp(uLightSize,0.,360.))*.25);}
uniform vec3 uRimDir;
uniform vec3 uRimColor;
uniform float uRimIntensity;
uniform float uRimWidth;
uniform float uRoughness;
uniform float uSpecular;
uniform float uSecondary;
uniform float uSheen;
uniform float uBacklight;
uniform float uIridescence;
uniform float uAnisotropy;
uniform float uAlphaGain;
uniform int uDebug;
uniform float uAlphaCutoff;
uniform float uMaxMip;
uniform float uLongRough,uAzimRough,uIOR,uAbsorption;
uniform sampler2D uEnvironment;
uniform int uEnvironmentEnabled;
uniform float uEnvironmentStrength,uEnvironmentRotation,uEnvironmentLevels;
uniform vec3 uSH[9];
vec3 envDirection(vec3 d){float c=cos(uEnvironmentRotation),s=sin(uEnvironmentRotation);return vec3(c*d.x-s*d.z,d.y,s*d.x+c*d.z);}
vec3 envSample(vec3 d,float rough){d=envDirection(normalize(d));return textureLod(uEnvironment,vec2(atan(d.z,d.x)/6.2831853,acos(clamp(d.y,-1.,1.))/3.14159265),rough*uEnvironmentLevels).rgb;}
vec3 envDiffuse(vec3 n){n=envDirection(n);float x=n.x,y=n.y,z=n.z;return max(vec3(0),uSH[0]*.282095+uSH[1]*(.488603*y)+uSH[2]*(.488603*z)+uSH[3]*(.488603*x)+uSH[4]*(1.092548*x*y)+uSH[5]*(1.092548*y*z)+uSH[6]*(.315392*(3.*z*z-1.))+uSH[7]*(1.092548*x*z)+uSH[8]*(.546274*(x*x-y*y)));}
const float EPS=0.0001;
vec2 safeN2(vec2 v,vec2 fallback){float n=length(v);return (n>EPS)?v/n:fallback;}
vec3 safeN(vec3 v,vec3 fallback){float n=length(v);return (n>EPS)?v/n:fallback;}
// FSD_DEEP_SHADOW_INCLUDE
// FSD_HAIR_OPTICS_INCLUDE
vec3 decodeSRGB(vec3 c) {
    vec3 a=c/12.92;
    vec3 b=pow(max((c+0.055)/1.055,vec3(0)),vec3(2.4));
    return mix(a,b,greaterThan(c,vec3(0.04045)));
}
// Four-bin light-space optical density with 9-tap soft PCF. Approximate
// transmittance integrated across card layers, responsive to key angular size.
float shadowTransmittance(){return fsdVisibility(vLightClip);}
// Longitudinal fiber lobe (Marschner M). Maximum occurs where H makes the
// requested cuticle tilt angle offset against tangent T.
float fiberLobe(vec3 T,vec3 H,float offset,float width) {
    float longitudinal=asin(clamp(dot(T,H),-0.9999,0.9999));
    float u=(longitudinal-offset)/max(0.024,width);
    return exp(-0.5*u*u);
}
void main(){
    if(uHasOpaque!=0 && gl_FragCoord.z>texelFetch(uOpaqueDepth,ivec2(gl_FragCoord.xy),0).r+1e-7)discard;
    if(uDepthReject!=0){
        float previous=texelFetch(uPrevDepth,ivec2(gl_FragCoord.xy),0).r;
        if(gl_FragCoord.z<=previous+0.0000001) discard;
    }
    vec4 col=texture(uColor,vUV);
    // Tile color is LINEAR PREMULTIPLIED, with the authoritative Alpha Map
    // in its A channel. Filtering therefore does not pull black into edges.
    float cov=clamp(texture(uAlpha,vUV).r*uAlphaGain,0.0,1.0);
    float original=textureLod(uAlpha,vUV,0.).r;
    if(uDebug==8)cov=clamp(original*uAlphaGain,0.,1.);
#ifdef FSD_PEEL_PASS
    if(cov<=0.002) discard;
#else
    if(uDebug!=10 && cov<=0.0005) discard;
#endif
    vec3 surfaceN=safeN(vNormal,vec3(0.,0.,1.));
    vec3 geoT=safeN(vTangent,vec3(0.,1.,0.));
    // Flow is encoded in the 2-D basis of the mesh card. Project the
    // tangent back onto the transformed card plane after card deformation.
    geoT=safeN(geoT-surfaceN*dot(geoT,surfaceN),geoT);
    vec3 B=safeN(cross(geoT,surfaceN),vec3(1.,0.,0.));
    vec2 flow=texture(uFlow,vUV).xy*2.0-1.0;
    // Raster maps encode image X right, image Y down. Geometry root->tip
    // tangent points up the card, so image Y maps to -geoT, not +geoT.
    vec3 T=safeN(B*flow.x - geoT*flow.y,geoT);
    T=safeN(T-surfaceN*dot(T,surfaceN),geoT);
    vec3 perpB=safeN(cross(T,surfaceN),B);

    // Nyquist-safe distance-aware micro-strand relief and cuticle sparkle.
    vec2 uvFlow=safeN2(flow,vec2(0.,-1.));
    vec2 uvPerp=vec2(-uvFlow.y,uvFlow.x);
    float strandCoord=dot(vUV,uvPerp)*175.0+dot(vUV,uvFlow)*5.0;
    float cuticleCoord=dot(vUV,uvFlow)*96.0;
    float pxStrandRate=max(length(dFdx(strandCoord)),length(dFdy(strandCoord)));
    float pxCuticleRate=max(length(dFdx(cuticleCoord)),length(dFdy(cuticleCoord)));
    float detailFade=1.0-smoothstep(0.55,1.85,pxStrandRate);
    float cuticleFade=1.0-smoothstep(0.55,1.85,pxCuticleRate);
    float filamentWave=sin(strandCoord)*0.70+sin(strandCoord*1.93+1.13)*0.30;
    float cuticleWave=sin(cuticleCoord+strandCoord*0.20)*cuticleFade;

    vec3 mapN=texture(uNormalTex,vUV).xyz*2.0-1.0;
    vec3 N=safeN(surfaceN*max(0.10,mapN.z)
                 +B*(mapN.x+0.042*filamentWave*detailFade)
                 -geoT*(mapN.y-0.022*cuticleWave),surfaceN);
    vec3 V=safeN(uViewPos-vWorldPos,vec3(0.,0.,1.));
    if(dot(N,V)<0.)N=-N;
    vec3 L=safeN(uLightDir,vec3(.3,.65,1.));
    if(uUseKeyPosition!=0)L=safeN(uKeyPosition-vWorldPos,L);
    vec3 fillDir=safeN(vec3(-L.x*0.88,max(0.18,L.y*0.42),-L.z*0.88),vec3(-.4,.5,-.6));
    vec3 H=safeN(V+L,V);
    float spread=sourceSpread();
    float wrap=.12+spread*.48;
    float ndl=pow(clamp((dot(N,L)+wrap)/(1.+wrap),0.,1.),1.12);
    ndl=mix(ndl,.5,pow(spread,4.));
    float ndFill=pow(clamp((dot(N,fillDir)+0.25)/1.25,0.0,1.0),1.05);
    float ndv=clamp(dot(N,V),0.0,1.0);

    float baseRough=clamp(mix(texture(uRoughnessTex,vUV).r,uRoughness,.70),.05,.96);
    float rough=clamp(baseRough+0.030*cuticleWave,.05,.96);
    float microGlint=mix(1.0,0.92+0.16*(0.5+0.5*sin(strandCoord*0.79+0.4)),detailFade);

    // Azimuthal frame perpendicular to hair tangent T.
    vec3 pL=safeN(L-T*dot(T,L),perpB);
    vec3 pV=safeN(V-T*dot(T,V),perpB);
    float cosPhi=clamp(dot(pL,pV),-1.0,1.0);
    float cosHalfPhi=sqrt(clamp(0.5+0.5*cosPhi,0.0,1.0));

    vec3 base=col.a>1e-5?max(col.rgb,vec3(0.))/col.a:vec3(0.);
    vec3 safeBase=max(base,vec3(0.004));
    float maxChan=max(0.02,max(safeBase.r,max(safeBase.g,safeBase.b)));
    vec3 chromaBoost=safeBase/maxChan;
    vec3 cortexTint=pow(safeBase,vec3(0.54))*mix(vec3(1.0),chromaBoost,0.36);

    // Marschner-inspired R (primary cuticle) and TRT (secondary cortical glint).
    float sigmaR=mix(.038,.44,mix(rough*rough,uLongRough*uLongRough,.65))+spread*.13;
    float lobeR=fiberLobe(T,H,-0.068,sigmaR);
    float azimR=pow(max(cosHalfPhi,.001),mix(12.,.4,uAzimRough));
    float lobeTRT=fiberLobe(T,H,0.118,sigmaR*1.95+0.022);
    float azimTRT=0.32+0.68*pow(clamp(0.5-0.35*cosPhi,0.0,1.0),1.35);

    // Normalized GGX fallback for low-anisotropy materials.
    float alpha2=rough*rough*rough*rough;
    float ndh=max(0.,dot(N,H));
    float ggxDen=ndh*ndh*(alpha2-1.0)+1.0;
    float normalHighlight=clamp(alpha2/max(0.002,3.14159*ggxDen*ggxDen),0.0,6.0)*0.48;

    float primary=mix(normalHighlight,lobeR*azimR,uAnisotropy)*uSpecular*microGlint;
    float secondary=lobeTRT*azimTRT*(0.85+0.30*microGlint)*uSecondary;
    float f0=pow((uIOR-1.)/(uIOR+1.),2.);
    float fresnel=f0+(1.-f0)*pow(1.-max(0.,dot(V,H)),5.);
    vec3 sigmaA=-log(max(base,vec3(.01)))*max(uAbsorption,0.);
    vec3 transmission=exp(-sigmaA);
    float visibility=clamp(0.16+0.84*pow(ndl,.32),0.0,1.0);

    vec3 keyColor=max(uKeyColor,vec3(0.))*max(0.,uLightIntensity);
    vec3 fillColor=max(uFillColor,vec3(0.))*max(0.,uFillIntensity);
    vec3 ambColor=max(uAmbientColor,vec3(0.))*max(0.,uAmbientIntensity);
    float hemi=clamp(.46+.44*N.y,0.16,.98);
    vec3 domeDiff=mix(vec3(0.55,0.52,0.50),vec3(1.06,1.08,1.12),smoothstep(-0.35,0.85,N.y))*hemi;

    float transmittance=shadowTransmittance();
    vec3 shadowTint=mix(vec3(transmittance),
                        pow(max(vec3(transmittance),vec3(1e-4)),mix(vec3(1.0),vec3(0.75,0.90,1.08),clamp(uScatterStrength,0.,1.))),
                        0.65);
    shadowTint=mix(vec3(transmittance),shadowTint,clamp(base*1.5,vec3(0.),vec3(1.)));

    vec3 shaded=base*(1.-fresnel)*(keyColor*shadowTint*(.025+.90*ndl)
                       + fillColor*(.06+.74*ndFill)
                       + ambColor*domeDiff);

    // Studio softbox reflection weighted strictly by active ambient + fill sources.
    vec3 bentN=safeN(N-T*dot(N,T)*0.58,N);
    vec3 reflV=reflect(-V,bentN);
    float softbox=smoothstep(0.15,0.82,reflV.y)*mix(0.75,0.15,rough);
    float grazingV=pow(1.0-ndv,3.0);
    shaded+=(ambColor*0.36+fillColor*0.24)*softbox*(0.12+0.88*grazingV)*mix(cortexTint,vec3(1.0),0.55)*clamp(uSpecular,0.0,1.5);

    // Forward transmission TT and multi-scattering bundle luminance.
    float forwardAzim=pow(clamp(0.5-0.5*cosPhi,0.0,1.0),1.8);
    float longTT=fiberLobe(T,safeN(L+V,V),0.032,sigmaR*1.45+0.09);
    float back=max(0.,dot(-N,L))*0.55+forwardAzim*longTT*0.78;
    shaded+=transmission*pow(1.-fresnel,2.)*keyColor*back*uBacklight*(0.35+0.65*transmittance)*0.68;

    float phase=pow(max(0.0,dot(-L,V)),2.0);
    float penumbra=mix(transmittance,pow(max(transmittance,1e-4),0.42),0.65);
    vec3 scatterAlbedo=mix(base,max(base,cortexTint*0.85),0.45);
    shaded+=scatterAlbedo*(1.-transmission)*keyColor*uScatterStrength*(.14+.86*(0.65*phase+0.35*forwardAzim))*(.35+.65*penumbra)*.56;

    vec3 specR=keyColor*(primary*visibility*fresnel*1.18);
    vec3 specTRT=keyColor*transmission*transmission*fresnel*pow(1.-fresnel,2.)*(secondary*(0.35+0.65*visibility)*(0.35+0.65*fresnel)*0.92);
    vec3 spec=specR+specTRT;
    float rim=pow(1.-ndv,2.8);
    vec3 sheen=mix(base,cortexTint,0.35)*(keyColor*.38+fillColor*.24)*uSheen*rim;
    shaded+=spec*mix(.65,1.0,transmittance)+sheen;

    // Independent artistic rim kicker oriented by fiber tangent and edge normal.
    vec3 rimL=safeN(uRimDir,vec3(-.4,.5,-1.));
    float edge=pow(clamp(1.-abs(dot(N,V)),0.,1.),mix(6.,1.3,uRimWidth));
    float rimFacing=smoothstep(-.3,.7,dot(N,rimL));
    float rimFiber=fiberLobe(T,safeN(V+rimL,V),-0.04,sigmaR*1.55+0.03);
    shaded+=max(uRimColor,vec3(0.))*max(0.,uRimIntensity)*
            mix(vec3(.60),cortexTint*.85+vec3(.25),.45)*edge*(.22+.78*rimFacing)*(.45+.75*rimFiber);

    // Pearlescent spectral thin-film interference shift across grazing view/light angles.
    float opticalAngle=clamp(1.-abs(dot(N,V))*.68-abs(dot(N,L))*.17,0.,1.);
    float iridPhase=opticalAngle*0.95+0.08*abs(dot(T,V));
    vec3 iricolor=vec3(0.50)+vec3(0.42)*cos(6.2831853*(iridPhase+vec3(0.28,0.56,0.84)));
    float optical=uIridescence*(.28+.72*pow(max(0.,dot(N,H)),.65));
    shaded+=iricolor*optical*(keyColor*.58+fillColor*.18)*(0.25+0.75*visibility);
    if(uEnvironmentEnabled!=0){
        float envF=f0+(1.-f0)*pow(1.-ndv,5.);
        vec3 reflection=envSample(reflect(-V,N),rough);
        shaded+=uEnvironmentStrength*(base*(1.-envF)*envDiffuse(N)+reflection*envF*clamp(uSpecular,0.,1.));
    }
    if(uPhysical!=0 && uDebug==0){
        vec3 frameN=safeN(N-T*dot(N,T),surfaceN);
        vec3 frameB=safeN(cross(frameN,T),perpB);
        vec3 physical=hlighting(T,frameB,frameN,V,L,fillDir,base,transmittance);
        // Legacy gains remain an explicit artistic layer, never BSDF energy.
        shaded=physical+(uArtistic!=0?max(vec3(0),spec+sheen+iricolor*optical):vec3(0));
    }
    if(uDebug==17)shaded=base;
    if(uDebug==18){float z=1./max(gl_FragCoord.w,1e-8);shaded=vec3(z/(1.+z));}
    if(uDebug==1)shaded=vec3(cov);
    if(uDebug==2)shaded=N*.5+.5;
    if(uDebug==3)shaded=T*.5+.5;
    if(uDebug==4)shaded=vec3(rough);
    if(uDebug==5)shaded=vec3(primary+secondary);
    if(uDebug==6)shaded=vec3(optical);
    if(uDebug==7)shaded=vec3(transmittance);
    if(uDebug==8)shaded=vec3(original);
    if(uDebug==9)shaded=vec3(cov);
    vec2 ts=vec2(textureSize(uAlpha,0));
    float mip=clamp(log2(max(max(length(dFdx(vUV)*ts),length(dFdy(vUV)*ts)),1.)),0.,uMaxMip);
    if(uDebug==11)shaded=mix(vec3(.08,.3,1.),vec3(1.,.15,.04),mip/max(1.,uMaxMip));
    if(uDebug==12)shaded=vec3(step(uAlphaCutoff,cov));
    if(uDebug==13)shaded=vec3(1.);
#ifdef FSD_PEEL_PASS
    oLayer=vec4(shaded*cov,cov);
    vec3 now=vCurrentClip.xyz/max(abs(vCurrentClip.w),1e-8);
    vec3 before=vPreviousClip.xyz/max(abs(vPreviousClip.w),1e-8);
    oLayerMotion=vec4((now.xy-before.xy)*.5,before.z*.5+.5,cov);
    // Float32 identity is exact up to 2^24; renderer bounds card IDs.
    vec3 mn=N/(abs(N.x)+abs(N.y)+abs(N.z));
    vec2 oct=mn.z>=0.?mn.xy:(1.-abs(mn.yx))*sign(mn.xy+vec2(1e-8));
    vec2 encodedNormal=floor(clamp(oct*.5+.5,0.,1.)*1023.+.5);
    oLayerMeta=vec4(gl_FragCoord.z,float(vCardID)+1.,encodedNormal.x+encodedNormal.y*1024.,1.);
#else
    // Accumulate optical depth instead of multiplying half-float revealage.
    // Linear view-depth weighting separates front hair highlights cleanly from
    // deeper layers in Weighted Blended OIT without FP16 overflow.
    float viewZ=1.0/max(gl_FragCoord.w,1e-4);
    float depthWeight=clamp(14.0/(0.04+pow(viewZ*0.25,3.8)),0.04,36.0);
    float weight=depthWeight*(0.20+0.80*cov);
    oAccum=vec4(shaded*cov*weight,cov*weight);
    float tau=cov<.01?cov*(1.+cov*(.5+cov/3.)):-log(max(1.-cov,1e-8));
    oReveal=vec4(tau);
    if(uDebug==10)oAccum=vec4(1.,0.,0.,1.); // additive actual fragment count
#endif
}
