#version 330 core
out vec4 outColor;
uniform vec3 uColor;
uniform int uPoints;
void main(){
    float a=1.;
    if(uPoints!=0){
        float radius=length(gl_PointCoord-vec2(.5));
        a=1.-smoothstep(.5-fwidth(radius),.5,radius);
        if(a<=0.)discard;
    }
    outColor=vec4(uColor,a);
}
