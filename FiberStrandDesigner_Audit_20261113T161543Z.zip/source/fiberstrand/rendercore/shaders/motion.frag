#version 330 core
in vec2 vUV;
in vec4 vCurrentClip;
in vec4 vPreviousClip;
layout(location=0) out vec4 oMotion;
uniform sampler2D uAlpha;
uniform float uAlphaGain;
void main(){
    float a=clamp(texture(uAlpha,vUV).r*uAlphaGain,0.,1.);
    if(a<=0.)discard;
    vec2 current=vCurrentClip.xy/max(abs(vCurrentClip.w),1e-6);
    vec2 previous=vPreviousClip.xy/max(abs(vPreviousClip.w),1e-6);
    // Nearest visible card surface. This is NOT multilayer optical flow.
    oMotion=vec4((current-previous)*.5,gl_FragCoord.z,a);
}
