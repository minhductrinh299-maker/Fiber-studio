#version 330 core
in vec2 vUV;
flat in uint vCardID;
layout(location=0) out uint outID;
uniform sampler2D uAlpha;
void main(){
    // Selection threshold only, never the beauty shader's coverage policy.
    if(texture(uAlpha,vUV).r<.025)discard;
    outID=(vCardID<<9u)|(uint(gl_PrimitiveID)&511u);
}
