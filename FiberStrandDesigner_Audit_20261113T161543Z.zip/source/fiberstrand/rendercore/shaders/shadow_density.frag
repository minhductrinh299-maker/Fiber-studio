#version 330 core
in vec2 vUV;
layout(location=0) out vec4 oDensity;
layout(location=1) out vec4 oDensityFar;
uniform sampler2D uColor;
uniform sampler2D uAlpha;
uniform float uAlphaGain;
uniform float uShadowKnots[9];
void main() {
    vec4 col=texture(uColor,vUV);
    float a=clamp(texture(uAlpha,vUV).r*uAlphaGain,0.0,0.98);
    if (a<=0.0) discard;
    float extinction=a<.01?a*(1.+a*(.5+a/3.)):min(4.0,-log(max(0.02,1.0-a)));
    int bin=7;for(int i=0;i<8;i++){if(gl_FragCoord.z<uShadowKnots[i+1]){bin=i;break;}}
    oDensity=vec4(0.0);oDensityFar=vec4(0.0);
    if(bin<4)oDensity[bin]=extinction;else oDensityFar[bin-4]=extinction;
}
