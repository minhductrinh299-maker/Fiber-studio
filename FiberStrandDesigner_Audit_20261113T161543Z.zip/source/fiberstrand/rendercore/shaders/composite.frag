#version 330 core
in vec2 vUV;
out vec4 outColor;
#ifdef FSD_MSAA
uniform sampler2DMS uAccum;
uniform sampler2DMS uReveal;
#else
uniform sampler2D uAccum;
uniform sampler2D uReveal;
#endif
uniform int uSamples;
uniform int uDebug;
uniform float uExposure;
uniform int uBackground;
vec3 srgb(vec3 x){
    vec3 a=1.055*pow(max(x,vec3(0.)),vec3(1./2.4))-.055;
    vec3 b=x*12.92;
    return mix(b,a,greaterThan(x,vec3(.0031308)));
}
void main(){
    vec2 uv=clamp(vUV,0.0,1.0);
    vec4 sum=vec4(0.);
    int count=max(1,uSamples);
    for(int i=0;i<count;++i){
#ifdef FSD_MSAA
        vec4 acc=texelFetch(uAccum,ivec2(gl_FragCoord.xy),i);
        float r=exp(-max(texelFetch(uReveal,ivec2(gl_FragCoord.xy),i).r,0.));
#else
        vec4 acc=texture(uAccum,uv);
        float r=exp(-max(texture(uReveal,uv).r,0.));
#endif
        float alpha=1.-r;
        vec3 avg=acc.rgb/max(acc.a,.0000001);
        vec4 s=vec4(avg*alpha,alpha);
        if(uDebug==10){float h=clamp(log2(1.+acc.r)/5.,0.,1.);s=vec4(h,h*h,1.-h,1.);}
        sum+=s;
    }
    // Resolve composited samples, never averaged revealage/accumulation.
    outColor=sum/float(count);
}
