#version 330 core
layout(location=0) in vec3 aPos;
layout(location=1) in vec2 aUV;
layout(location=2) in vec3 aTangent;
layout(location=3) in vec3 aNormal;
layout(location=4) in vec3 aPreviousPos;
layout(location=5) in float aCardID;
uniform mat4 uMVP;
uniform mat4 uPreviousMVP;
uniform int uGeometryMoved;
uniform samplerBuffer uRoots;
uniform int uUseRoots;
uniform mat4 uLightMVP;
out vec4 vLightClip;
out vec2 vUV;
out vec3 vWorldPos;
out vec3 vTangent;
out vec3 vNormal;
out vec4 vCurrentClip;
out vec4 vPreviousClip;
flat out uint vCardID;
void main(){
    vec3 root=uUseRoots!=0?texelFetch(uRoots,int(aCardID+.5)).xyz:vec3(0.);
    vec3 world=aPos+root;
    gl_Position = uMVP * vec4(world,1.0);
    vCurrentClip=gl_Position;
    vPreviousClip=uPreviousMVP*vec4((uGeometryMoved!=0?aPreviousPos:aPos)+root,1.);
    vCardID=uint(aCardID+.5);
    vWorldPos = world;
    vLightClip = uLightMVP * vec4(world,1.0);
    vUV = aUV;
    vTangent = normalize(aTangent);
    vNormal = normalize(aNormal);
}
