#version 330 core
in vec2 vUV;
out vec4 outColor;
uniform sampler2D uAccum;
uniform sampler2D uReveal;
uniform sampler2D uPeel0;
uniform sampler2D uPeel1;
uniform sampler2D uPeel2;
uniform sampler2D uPeel3;
uniform sampler2D uPeel4;
uniform sampler2D uPeel5;
uniform sampler2D uPeel6;
uniform sampler2D uPeel7;
uniform int uLayerCount;
uniform int uDebug;
uniform float uExposure;
uniform int uBackground;
vec3 srgb(vec3 x){
    vec3 a=1.055*pow(max(x,vec3(0.)),vec3(1./2.4))-.055;
    vec3 b=x*12.92;
    return mix(b,a,greaterThan(x,vec3(.0031308)));
}
void main(){
    vec2 uv=clamp(vUV,0.0,1.0);
    vec4 acc=texture(uAccum,uv);
    float r=exp(-max(texture(uReveal,uv).r,0.));
    float alpha=1.-r;
    if(uDebug==16){outColor=vec4(alpha,1.-alpha,0.,1.);return;}
    vec3 avg=acc.rgb/max(acc.a,.0000001);
    vec3 light=avg*alpha;
    float remaining=r;
    // Each peeled texture contains premultiplied linear RGB and its true alpha.
    // Resolve far to near; layers with no fragments are transparent.
    if(uLayerCount>7){vec4 s=texture(uPeel7,uv);light=s.rgb+light*(1.-s.a);remaining*=1.-s.a;}
    if(uLayerCount>6){vec4 s=texture(uPeel6,uv);light=s.rgb+light*(1.-s.a);remaining*=1.-s.a;}
    if(uLayerCount>5){vec4 s=texture(uPeel5,uv);light=s.rgb+light*(1.-s.a);remaining*=1.-s.a;}
    if(uLayerCount>4){vec4 s=texture(uPeel4,uv);light=s.rgb+light*(1.-s.a);remaining*=1.-s.a;}
    if (uLayerCount>3) {vec4 s=texture(uPeel3,uv);light=s.rgb+light*(1.0-s.a);remaining*=1.-s.a;}
    if (uLayerCount>2) {vec4 s=texture(uPeel2,uv);light=s.rgb+light*(1.0-s.a);remaining*=1.-s.a;}
    if (uLayerCount>1) {vec4 s=texture(uPeel1,uv);light=s.rgb+light*(1.0-s.a);remaining*=1.-s.a;}
    if (uLayerCount>0) {vec4 s=texture(uPeel0,uv);light=s.rgb+light*(1.0-s.a);remaining*=1.-s.a;}
    outColor=vec4(light,1.-remaining);
}
