#version 330 core
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aOther;
layout(location=5) in float aCardID;
uniform mat4 uMVP;
uniform vec2 uSize;
uniform int uScreen;
uniform float uPointSize;
uniform int uCenterPairs;
uniform samplerBuffer uRoots;
uniform int uUseRoots;
void main(){
    vec3 p=uCenterPairs!=0?(aPos+aOther)*.5:aPos;
    if(uUseRoots!=0 && uScreen==0)p+=texelFetch(uRoots,int(aCardID+.5)).xyz;
    gl_Position=uScreen!=0?vec4(p.x/uSize.x*2.-1.,1.-p.y/uSize.y*2.,0.,1.):uMVP*vec4(p,1.);
    gl_PointSize=uPointSize;
}
