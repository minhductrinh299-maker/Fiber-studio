#version 330 core
in vec2 vUV;
out vec4 outColor;
uniform sampler2D uCurrent,uHistory,uMotion;
uniform float uHistoryWeight;
uniform int uReproject;
void main(){
 ivec2 size=textureSize(uCurrent,0);ivec2 p=clamp(ivec2(gl_FragCoord.xy),ivec2(0),size-1);
 vec4 current=texelFetch(uCurrent,p,0);
 if(uHistoryWeight<=0.){outColor=current;return;}
 vec2 uv=(vec2(p)+.5)/vec2(size);float weight=uHistoryWeight;
 if(uReproject!=0){
  vec4 motion=texelFetch(uMotion,p,0);uv-=motion.xy;
  // Velocity represents nearest layer, so reject partial/multilayer silhouettes.
  if(any(lessThan(uv,vec2(0)))||any(greaterThan(uv,vec2(1)))||current.a<.92||motion.a<.92){outColor=current;return;}
  weight*=exp(-length(motion.xy)*40.);
 }
 vec4 old=texture(uHistory,uv);vec4 low=current,high=current;
 for(int y=-1;y<=1;y++)for(int x=-1;x<=1;x++){
  vec4 q=texelFetch(uCurrent,clamp(p+ivec2(x,y),ivec2(0),size-1),0);low=min(low,q);high=max(high,q);
 }
 if(uReproject!=0){weight*=1.-smoothstep(.02,.15,abs(old.a-current.a));old=clamp(old,low,high);}
 outColor=mix(current,old,weight);
}
