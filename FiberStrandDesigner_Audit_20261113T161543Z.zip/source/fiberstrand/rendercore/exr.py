"""Dependency-free, uncompressed single-part float32 scanline OpenEXR writer.

Layout: https://openexr.com/en/latest/OpenEXRFileLayout.html
Working primaries are linear sRGB/Rec.709 D65, alpha premultiplied.
No tone curve, exposure, checker, bloom or grain is baked into these pixels.
"""
import os
import struct
import tempfile
from pathlib import Path
import numpy as np

def write_linear(path,rgba):
    pixels=np.asarray(rgba,dtype='<f4')
    if pixels.ndim!=3 or pixels.shape[2]!=4:raise ValueError('Expected H×W×4 linear RGBA')
    if not np.isfinite(pixels).all():raise ValueError('Cannot export nonfinite radiance')
    h,w=pixels.shape[:2]
    if w<1 or h<1:raise ValueError('Empty capture')
    def attr(name,typ,value):return name.encode()+b'\0'+typ.encode()+b'\0'+struct.pack('<i',len(value))+value
    channels=b''.join(name.encode()+b'\0'+struct.pack('<iB3xii',2,0,1,1) for name in ('A','B','G','R'))+b'\0'
    box=struct.pack('<4i',0,0,w-1,h-1)
    header=struct.pack('<II',20000630,2)
    for name,typ,value in (
        ('channels','chlist',channels),('compression','compression',b'\0'),
        ('dataWindow','box2i',box),('displayWindow','box2i',box),('lineOrder','lineOrder',b'\0'),
        ('pixelAspectRatio','float',struct.pack('<f',1.)),('screenWindowCenter','v2f',struct.pack('<2f',0.,0.)),
        ('screenWindowWidth','float',struct.pack('<f',1.)),
        ('chromaticities','chromaticities',struct.pack('<8f',.64,.33,.30,.60,.15,.06,.3127,.3290)),
        ('fsdAlpha','string',b'premultiplied'),('fsdColorSpace','string',b'linear Rec.709 D65'),
        ('software','string',b'Fiber Strand Designer RenderCore HQ')):header+=attr(name,typ,value)
    header+=b'\0'
    start=len(header)+h*8;stride=w*16+8
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='.fsd_exr_',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(header)
            f.write(b''.join(struct.pack('<Q',start+y*stride) for y in range(h)))
            for y in range(h):
                f.write(struct.pack('<ii',y,w*16))
                for channel in (3,2,1,0):f.write(np.ascontiguousarray(pixels[y,:,channel],dtype='<f4').tobytes())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.remove(tmp)
