"""FSD RenderCore R0 GPU prototype.

Actual GPU shader execution (OpenGL 3.3), not the final D3D12 backend.
"""
from .renderer import GPUHairRenderer, HairMaterial, RenderInfo
__all__=['GPUHairRenderer','HairMaterial','RenderInfo']
