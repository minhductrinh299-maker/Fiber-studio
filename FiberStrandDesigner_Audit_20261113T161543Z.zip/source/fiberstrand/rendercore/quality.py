"""Explicit sampling policies and conservative GPU allocation planning."""
from dataclasses import dataclass
import math


@dataclass(frozen=True)
class Quality:
    scale:float
    history:int
    light_samples:int=1
    environment_samples:int=1
    layers:int=0


PRESETS={'Edit':Quality(1.,1,1,1,0),
         'Lookdev':Quality(1.,32,4,2,4),
         'Capture':Quality(1.5,256,8,8,8)}
# Source/API compatibility with saved settings and embedded views.
ALIASES={'Interactive':'Edit','Live':'Lookdev','Inspect':'Capture'}
MODES={**PRESETS,**{name:PRESETS[target] for name,target in ALIASES.items()}}


def render_size(width,height,scale,layers=4,budget_mib=384,max_texture_size=8192,hq_float32=False):
    """Bound all viewport targets, including temporal/motion/resolve allocations.

    This is a resource estimate, not DXGI total VRAM usage. Never changes shader,
    source textures or geometry. A reduced scale is reported to the user.
    """
    width=max(32,int(width));height=max(32,int(height))
    if scale not in (1.,1.5,2.):raise ValueError('Render scale must be 1, 1.5 or 2')
    # OIT accum/reveal + peel/depth + linear current/history + motion/depth.
    # Layer color, motion, identity/depth, color/meta double history and resolve.
    bpp=(160+128*layers) if hq_float32 else (120+88*layers)
    pixels=budget_mib*1024**2/bpp
    allowed=min(scale,math.sqrt(pixels/(width*height)),max_texture_size/width,max_texture_size/height)
    # Never silently downscale below the physical viewport.
    if allowed<1:
        raise MemoryError('Physical viewport exceeds the configured render-target budget')
    w=max(32,round(width*allowed));h=max(32,round(height*allowed))
    return w,h,w/width, w*h*bpp/(1024**2)


def halton(index,base):
    value=0.;fraction=1.
    while index:
        fraction/=base;value+=fraction*(index%base);index//=base
    return value


def jitter(index):
    return halton(index%4096+1,2)-.5,halton(index%4096+1,3)-.5
