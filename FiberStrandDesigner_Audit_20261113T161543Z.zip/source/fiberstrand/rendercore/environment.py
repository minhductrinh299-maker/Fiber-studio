"""Linear HDR environment input and diffuse SH9; no scene/GPU mutation."""
import math,re
from pathlib import Path
import numpy as np
from PIL import Image

def importance(pixels):
    """Exact texel solid-angle PDF and flattened inverse-search CDF.

    A small uniform mixture keeps all directions in the MIS support, including
    zero-radiance texels. The shader samples uniformly in cos(theta) per cell.
    """
    h,w=pixels.shape[:2]
    edges=np.arange(h+1,dtype=np.float64)*math.pi/h
    omega=(np.cos(edges[:-1])-np.cos(edges[1:]))[:,None]*(2*math.pi/w)
    luminance=np.einsum('hwc,c->hw',pixels,[.2126,.7152,.0722])
    energy=float(np.sum(luminance*omega))
    pdf=.98*luminance/max(energy,1e-20)+.02/(4*math.pi) if energy>0 else np.full((h,w),1/(4*math.pi))
    mass=pdf*omega;mass/=mass.sum()
    cdf=np.cumsum(mass.ravel(),dtype=np.float64);cdf[-1]=1.
    return np.ascontiguousarray(pdf,np.float32),np.ascontiguousarray(cdf.reshape(h,w),np.float32)

def load(path=''):
    if not path:
        h,w=128,256;y,x=np.mgrid[:h,:w];v=y/h;u=x/w
        pixels=np.zeros((h,w,3),np.float32)+.035
        pixels+=np.exp(-((u-.2)/.055)**2-((v-.30)/.10)**2)[...,None]*np.array([12,10,8])
        pixels+=np.exp(-((u-.72)/.12)**2-((v-.4)/.17)**2)[...,None]*np.array([2,3,5])
        pixels+=((v>.5)*.06)[...,None]
        # Built-in studio is a balanced lookdev rig; user HDRIs retain radiance.
        pixels*=.125
    elif Path(path).suffix.lower()=='.hdr':
        with open(path,'rb') as f:
            if not f.readline().startswith((b'#?RADIANCE',b'#?RGBE')):raise ValueError('Unsupported HDR header')
            while f.readline().strip():pass
            match=re.fullmatch(rb'-Y (\d+) \+X (\d+)\s*',f.readline())
            if not match:raise ValueError('HDR orientation must be -Y +X')
            h,w=map(int,match.groups())
            if w*h>16000000:raise ValueError('HDR exceeds 16 million pixels')
            rgbe=np.empty((h,w,4),np.uint8)
            for row in range(h):
                head=f.read(4)
                if len(head)!=4:raise ValueError('Truncated HDR')
                if head[:2]!=b'\x02\x02':
                    raw=head+f.read(w*4-4)
                    if len(raw)!=w*4:raise ValueError('Truncated HDR pixels')
                    rgbe[row]=np.frombuffer(raw,np.uint8).reshape(w,4);continue
                if int.from_bytes(head[2:],'big')!=w:raise ValueError('HDR scanline width mismatch')
                channels=np.empty((4,w),np.uint8)
                for c in range(4):
                    pos=0
                    while pos<w:
                        code=f.read(1)
                        if not code:raise ValueError('Truncated HDR RLE')
                        code=code[0];count=code-128 if code>128 else code
                        if count==0 or pos+count>w:raise ValueError('Invalid HDR RLE')
                        data=f.read(1 if code>128 else count)
                        if len(data)!=(1 if code>128 else count):raise ValueError('Truncated HDR run')
                        channels[c,pos:pos+count]=data[0] if code>128 else np.frombuffer(data,np.uint8);pos+=count
                rgbe[row]=channels.T
            pixels=rgbe[:,:,:3].astype(np.float32)*np.exp2(rgbe[:,:,3].astype(np.float32)-136)[...,None]
    else:
        with Image.open(path) as image:
            if image.mode in ('F','I','I;16','I;16B','I;16L'):
                raise ValueError('Float / high-bit TIFF environments require explicit color management; use Radiance HDR or an sRGB PNG/JPEG')
            if image.width*image.height>16000000:raise ValueError('Environment exceeds 16 million pixels')
            if image.info.get('icc_profile'):
                import io
                from PIL import ImageCms
                try:
                    profile=ImageCms.ImageCmsProfile(io.BytesIO(image.info['icc_profile']))
                    converted=ImageCms.profileToProfile(image,profile,ImageCms.createProfile('sRGB'),outputMode='RGB')
                except Exception as error:raise ValueError('Cannot convert environment ICC profile to sRGB: '+str(error)) from error
            else:converted=image.convert('RGB')
            pixels=np.asarray(converted,np.float32)/255
        pixels=np.where(pixels<=.04045,pixels/12.92,((pixels+.055)/1.055)**2.4)
    if not np.isfinite(pixels).all():raise ValueError('Nonfinite environment radiance')
    pixels=np.maximum(pixels,0).astype(np.float32)
    h,w=pixels.shape[:2];ratio=min(1.,1024/w,512/h)
    if ratio<1:
        size=(max(1,round(w*ratio)),max(1,round(h*ratio)))
        edges=np.linspace(0.,math.pi,h+1)
        weights=np.broadcast_to((np.cos(edges[:-1])-np.cos(edges[1:]))[:,None],(h,w)).astype(np.float32)
        denominator=np.asarray(Image.fromarray(weights).resize(size,Image.Resampling.BOX))
        energy=np.sum(pixels*weights[:,:,None],axis=(0,1),dtype=np.float64)/w
        pixels=np.stack([np.asarray(Image.fromarray(pixels[:,:,c]*weights).resize(size,Image.Resampling.BOX))/np.maximum(denominator,1e-20) for c in range(3)],-1)
        e2=np.linspace(0.,math.pi,size[1]+1);w2=(np.cos(e2[:-1])-np.cos(e2[1:]))[:,None,None]
        new_energy=np.sum(pixels*w2,axis=(0,1))/size[0]
        pixels*=np.divide(energy,new_energy,out=np.ones(3),where=new_energy>1e-20).astype(np.float32)
    pixels=np.ascontiguousarray(pixels,np.float32)
    h,w=pixels.shape[:2];theta=(np.arange(h)+.5)*math.pi/h;phi=(np.arange(w)+.5)*2*math.pi/w
    x=np.sin(theta)[:,None]*np.cos(phi);y=np.broadcast_to(np.cos(theta)[:,None],(h,w));z=np.sin(theta)[:,None]*np.sin(phi)
    basis=np.stack([np.ones_like(x)*.282095,.488603*y,.488603*z,.488603*x,1.092548*x*y,1.092548*y*z,.315392*(3*z*z-1),1.092548*x*z,.546274*(x*x-y*y)],-1)
    weights=np.sin(theta)[:,None]*(math.pi/h)*(2*math.pi/w)
    sh=np.einsum('hwc,hwk,hw->kc',pixels,basis,np.broadcast_to(weights,(h,w)))*np.array([1,2/3,2/3,2/3,1/4,1/4,1/4,1/4,1/4])[:,None]
    return pixels,sh.astype(np.float32)
