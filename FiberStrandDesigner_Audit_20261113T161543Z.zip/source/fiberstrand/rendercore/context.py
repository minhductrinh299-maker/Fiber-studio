"""OpenGL 3.3 context backends with zero third-party GL runtime dependencies.

WGL: direct native swapchain in a Tk Frame HWND (Windows / NVIDIA, AMD, Intel).
EGL: headless pbuffer (Linux build/test and GPU reference capture).
The RHI surface is intentionally isolated for later native D3D12 replacement.
"""
from __future__ import annotations
import ctypes as C
import ctypes.util
import os
import sys

class ContextError(RuntimeError):
    pass

class EGLContext:
    """Offscreen OpenGL context; uses Mesa surfaceless if available."""
    def __init__(self, width=800, height=550):
        if sys.platform == 'win32':
            raise ContextError('EGL backend is Linux-only in this distribution')
        self.width, self.height = int(width), int(height)
        name=ctypes_util_find('EGL')
        if not name: raise ContextError('libEGL is unavailable')
        e=self.lib=C.CDLL(name)
        self._fn('eglGetProcAddress',C.c_void_p,C.c_char_p)
        proc=e.eglGetProcAddress(b'eglGetPlatformDisplayEXT')
        if proc:
            getplat=C.CFUNCTYPE(C.c_void_p,C.c_uint,C.c_void_p,C.c_void_p)(proc)
            self.display=getplat(0x31DD,None,None)  # EGL_PLATFORM_SURFACELESS_MESA
        else:
            self._fn('eglGetDisplay',C.c_void_p,C.c_void_p)
            self.display=e.eglGetDisplay(None)
        if not self.display: raise ContextError('Unable to obtain EGL display')
        self._fn('eglInitialize',C.c_uint,C.c_void_p,C.POINTER(C.c_int),C.POINTER(C.c_int))
        major,minor=C.c_int(),C.c_int()
        if not e.eglInitialize(self.display,C.byref(major),C.byref(minor)):
            raise ContextError('eglInitialize failed')
        self._fn('eglBindAPI',C.c_uint,C.c_uint)
        if not e.eglBindAPI(0x30A2): raise ContextError('EGL OpenGL API unavailable')
        self._fn('eglChooseConfig',C.c_uint,C.c_void_p,C.POINTER(C.c_int),C.POINTER(C.c_void_p),C.c_int,C.POINTER(C.c_int))
        attr=(C.c_int*15)(0x3024,8,0x3023,8,0x3022,8,0x3021,8,0x3033,1,0x3040,8,0x3038)
        config=C.c_void_p();count=C.c_int()
        if not e.eglChooseConfig(self.display,attr,C.byref(config),1,C.byref(count)) or count.value==0:
            raise ContextError('EGL cannot allocate OpenGL pbuffer config')
        self.config=config
        self._fn('eglCreatePbufferSurface',C.c_void_p,C.c_void_p,C.c_void_p,C.POINTER(C.c_int))
        pb=(C.c_int*5)(0x3057,max(8,self.width),0x3056,max(8,self.height),0x3038)
        self.surface=e.eglCreatePbufferSurface(self.display,config,pb)
        if not self.surface: raise ContextError('EGL pbuffer creation failed')
        self._fn('eglCreateContext',C.c_void_p,C.c_void_p,C.c_void_p,C.c_void_p,C.POINTER(C.c_int))
        for ver in [(3,3),(3,0)]:
            ctxattr=(C.c_int*5)(0x3098,ver[0],0x30FB,ver[1],0x3038)
            self.context=e.eglCreateContext(self.display,config,None,ctxattr)
            if self.context: break
        if not self.context: raise ContextError('OpenGL 3.x EGL context creation failed')
        self._fn('eglMakeCurrent',C.c_uint,C.c_void_p,C.c_void_p,C.c_void_p,C.c_void_p)
        self.activate()
        self._fn('eglDestroyContext',C.c_uint,C.c_void_p,C.c_void_p)
        self._fn('eglDestroySurface',C.c_uint,C.c_void_p,C.c_void_p)
        self._fn('eglTerminate',C.c_uint,C.c_void_p)
        self.direct=False
        self.gl_lib=C.CDLL(ctypes_util_find('GL'))
        self._destroyed=False

    def _fn(self,name,restype,*args):
        fn=getattr(self.lib,name);fn.restype=restype;fn.argtypes=list(args)
        return fn
    def activate(self):
        if not self.lib.eglMakeCurrent(self.display,self.surface,self.surface,self.context):
            raise ContextError('eglMakeCurrent failed')
    def resize(self,width,height):
        width,height=int(width),int(height)
        if (width,height)==(self.width,self.height):return
        self.lib.eglMakeCurrent(self.display,None,None,None)
        self.lib.eglDestroySurface(self.display,self.surface)
        attrs=(C.c_int*5)(0x3057,max(8,width),0x3056,max(8,height),0x3038)
        self.surface=self.lib.eglCreatePbufferSurface(self.display,self.config,attrs)
        if not self.surface:raise ContextError('Failed to resize EGL pbuffer')
        self.width,self.height=width,height
        self.activate()

    def get_proc(self,name):
        try: return C.cast(getattr(self.gl_lib,name),C.c_void_p).value
        except AttributeError: return self.lib.eglGetProcAddress(name.encode('ascii'))
    def present(self): pass
    def close(self):
        if self._destroyed:return
        self.lib.eglMakeCurrent(self.display,None,None,None)
        self.lib.eglDestroyContext(self.display,self.context)
        self.lib.eglDestroySurface(self.display,self.surface)
        self.lib.eglTerminate(self.display)
        self._destroyed=True

class WGLContext:
    """Hardware-backed direct GL rendering to an existing Tk Windows HWND."""
    def __init__(self, hwnd:int,width:int=800,height:int=550,install_tk_paint_hook=True,share_with=None):
        if sys.platform!='win32':raise ContextError('WGL requires Windows')
        import threading
        self._owner_thread=threading.get_ident()
        self.width,self.height=width,height
        self.user=C.WinDLL('user32',use_last_error=True)
        self.gdi=C.WinDLL('gdi32',use_last_error=True)
        self.gl_lib=C.WinDLL('opengl32',use_last_error=True)
        self.user.GetDC.argtypes=[C.c_void_p];self.user.GetDC.restype=C.c_void_p
        self.user.ReleaseDC.argtypes=[C.c_void_p,C.c_void_p];self.user.ReleaseDC.restype=C.c_int
        self.gdi.ChoosePixelFormat.argtypes=[C.c_void_p,C.c_void_p];self.gdi.ChoosePixelFormat.restype=C.c_int
        self.gdi.GetPixelFormat.argtypes=[C.c_void_p];self.gdi.GetPixelFormat.restype=C.c_int
        self.gdi.SetPixelFormat.argtypes=[C.c_void_p,C.c_int,C.c_void_p];self.gdi.SetPixelFormat.restype=C.c_int
        self.gdi.SwapBuffers.argtypes=[C.c_void_p];self.gdi.SwapBuffers.restype=C.c_int
        self.gl_lib.wglCreateContext.argtypes=[C.c_void_p];self.gl_lib.wglCreateContext.restype=C.c_void_p
        self.gl_lib.wglMakeCurrent.argtypes=[C.c_void_p,C.c_void_p];self.gl_lib.wglMakeCurrent.restype=C.c_int
        self.gl_lib.wglDeleteContext.argtypes=[C.c_void_p];self.gl_lib.wglDeleteContext.restype=C.c_int
        self.gl_lib.wglGetProcAddress.argtypes=[C.c_char_p];self.gl_lib.wglGetProcAddress.restype=C.c_void_p
        self.hwnd=C.c_void_p(int(hwnd))
        self.hdc=self.user.GetDC(self.hwnd)
        if not self.hdc:raise ContextError('GetDC failed for render viewport')
        class PFD(C.Structure):
            _fields_=[('nSize',C.c_ushort),('nVersion',C.c_ushort),('dwFlags',C.c_uint32),
                      ('iPixelType',C.c_ubyte),('cColorBits',C.c_ubyte),('cRedBits',C.c_ubyte),
                      ('cRedShift',C.c_ubyte),('cGreenBits',C.c_ubyte),('cGreenShift',C.c_ubyte),
                      ('cBlueBits',C.c_ubyte),('cBlueShift',C.c_ubyte),('cAlphaBits',C.c_ubyte),
                      ('cAlphaShift',C.c_ubyte),('cAccumBits',C.c_ubyte),('cAccumRedBits',C.c_ubyte),
                      ('cAccumGreenBits',C.c_ubyte),('cAccumBlueBits',C.c_ubyte),('cAccumAlphaBits',C.c_ubyte),
                      ('cDepthBits',C.c_ubyte),('cStencilBits',C.c_ubyte),('cAuxBuffers',C.c_ubyte),
                      ('iLayerType',C.c_ubyte),('bReserved',C.c_ubyte),('dwLayerMask',C.c_uint32),
                      ('dwVisibleMask',C.c_uint32),('dwDamageMask',C.c_uint32)]
        pfd=PFD();pfd.nSize=C.sizeof(PFD);pfd.nVersion=1
        pfd.dwFlags=0x00000004|0x00000020|0x00000001 # DRAW_TO_WINDOW | SUPPORT_OPENGL | DOUBLEBUFFER
        pfd.iPixelType=0;pfd.cColorBits=32;pfd.cAlphaBits=8;pfd.cDepthBits=24;pfd.iLayerType=0
        fmt=self.gdi.GetPixelFormat(self.hdc)
        configured=bool(fmt)
        if not configured:fmt=self.gdi.ChoosePixelFormat(self.hdc,C.byref(pfd))
        if not fmt or (not configured and not self.gdi.SetPixelFormat(self.hdc,fmt,C.byref(pfd))):
            self.user.ReleaseDC(self.hwnd,self.hdc)
            raise ContextError('OpenGL pixel format unavailable; try a native GPU driver')
        self.context=self.gl_lib.wglCreateContext(self.hdc)
        if not self.context:
            self.user.ReleaseDC(self.hwnd,self.hdc)
            raise ContextError('wglCreateContext failed')
        if share_with is not None:
            share=self.gl_lib.wglShareLists
            share.argtypes=[C.c_void_p,C.c_void_p];share.restype=C.c_int
            if not share(share_with.context,self.context):
                self.gl_lib.wglDeleteContext(self.context);self.user.ReleaseDC(self.hwnd,self.hdc)
                raise ContextError('wglShareLists failed; GPU handles must not cross unshared contexts')
        self.activate()
        self._install_vsync()
        self._old_wndproc=None
        self._wndproc_ref=None
        if install_tk_paint_hook:self._install_wndproc()
        self.direct=True
        self._destroyed=False
    def _install_vsync(self):
        raw=self.get_proc('wglSwapIntervalEXT')
        if raw:
            try:
                swap_interval=C.WINFUNCTYPE(C.c_int,C.c_int)(raw)
                # Windowed DWM on Windows is already tear-free; swap_interval(1)
                # blocks the single-threaded Tk UI loop for 16-33ms per SwapBuffers.
                swap_interval(0)
            except Exception:
                pass
    def _install_wndproc(self):
        """Suppress GDI WM_ERASEBKGND/WM_PAINT on the Tk child HWND so WGL never flashes white."""
        try:
            from ctypes import wintypes
            LRESULT=C.c_ssize_t
            get_ptr=getattr(self.user,'GetWindowLongPtrW',self.user.GetWindowLongW)
            set_ptr=getattr(self.user,'SetWindowLongPtrW',self.user.SetWindowLongW)
            get_ptr.restype=C.c_void_p
            get_ptr.argtypes=[wintypes.HWND,C.c_int]
            set_ptr.restype=C.c_void_p
            set_ptr.argtypes=[wintypes.HWND,C.c_int,C.c_void_p]
            self.user.CallWindowProcW.restype=LRESULT
            self.user.CallWindowProcW.argtypes=[C.c_void_p,wintypes.HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM]
            self.user.ValidateRect.restype=wintypes.BOOL
            self.user.ValidateRect.argtypes=[wintypes.HWND,C.c_void_p]
            self.user.IsWindow.restype=wintypes.BOOL
            self.user.IsWindow.argtypes=[wintypes.HWND]
            WNDPROC=C.WINFUNCTYPE(LRESULT,wintypes.HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM)
            old_proc=get_ptr(self.hwnd,-4)
            if not old_proc:
                return
            self._old_wndproc=old_proc
            user=self.user
            def _wndproc(hwnd,msg,wparam,lparam):
                if msg==0x0014: # WM_ERASEBKGND
                    return 1
                if msg==0x000F: # WM_PAINT
                    user.ValidateRect(hwnd,None)
                    return 0
                if msg==0x0082: # WM_NCDESTROY
                    if self._old_wndproc and user.IsWindow(hwnd):
                        set_ptr(hwnd,-4,self._old_wndproc)
                        self._old_wndproc=None
                return user.CallWindowProcW(old_proc,hwnd,msg,wparam,lparam)
            self._wndproc_ref=WNDPROC(_wndproc)
            set_ptr(self.hwnd,-4,C.cast(self._wndproc_ref,C.c_void_p))
        except Exception:
            self._old_wndproc=None
            self._wndproc_ref=None
    def _restore_wndproc(self):
        if self._old_wndproc:
            try:
                if self.user.IsWindow(self.hwnd):
                    set_ptr=getattr(self.user,'SetWindowLongPtrW',self.user.SetWindowLongW)
                    set_ptr(self.hwnd,-4,self._old_wndproc)
            except Exception:
                pass
            self._old_wndproc=None
        self._wndproc_ref=None
    def activate(self):
        import threading
        if threading.get_ident()!=self._owner_thread:raise ContextError('WGL context called from a non-owning thread')
        if not self.gl_lib.wglMakeCurrent(self.hdc,self.context):
            raise ContextError('wglMakeCurrent failed')
    def get_proc(self,name):
        raw=self.gl_lib.wglGetProcAddress(name.encode('ascii'))
        if raw not in (None,0,1,2,3,0xFFFFFFFF,0xFFFFFFFFFFFFFFFF):return raw
        try:return C.cast(getattr(self.gl_lib,name),C.c_void_p).value
        except AttributeError:return None
    def present(self):self.gdi.SwapBuffers(self.hdc)
    def close(self):
        if self._destroyed:return
        self._restore_wndproc()
        self.gl_lib.wglMakeCurrent(None,None)
        self.gl_lib.wglDeleteContext(self.context)
        self.user.ReleaseDC(self.hwnd,self.hdc)
        self._destroyed=True

def ctypes_util_find(name):
    return ctypes.util.find_library(name)
