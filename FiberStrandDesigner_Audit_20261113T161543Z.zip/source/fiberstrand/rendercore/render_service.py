"""Process-wide CPU asset service. Never stores or calls a GL context.

Each viewport uploads immutable prepared assets to its own owner-thread context.
The bounded cache coalesces identical HDRI preparation across Studio/map views.
"""
from collections import OrderedDict
from pathlib import Path
from threading import RLock
import hashlib
from .environment import load,importance

_LOCK=RLock()
_CACHE=OrderedDict()
_LIMIT=128*1024**2

def load_environment(path=''):
    p=Path(path) if path else None
    stamp=(str(p.resolve()),p.stat().st_mtime_ns,p.stat().st_size) if p else ('studio-hdr-v2',)
    with _LOCK:
        if stamp in _CACHE:
            _CACHE.move_to_end(stamp);return _CACHE[stamp][0]
        pixels,sh=load(path);pdf,cdf=importance(pixels)
        result=(pixels,sh,pdf,cdf)
        for a in result:a.flags.writeable=False
        size=sum(a.nbytes for a in result)
        while _CACHE and sum(v[1] for v in _CACHE.values())+size>_LIMIT:_CACHE.popitem(last=False)
        _CACHE[stamp]=(result,size)
        return result

def environment_asset_id(path):
    if not path:return 'studio-hdr-v2'
    digest=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):digest.update(block)
    return digest.hexdigest()
