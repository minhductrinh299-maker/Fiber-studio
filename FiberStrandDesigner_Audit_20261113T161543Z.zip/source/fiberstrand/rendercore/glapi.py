"""Minimal GL 3.3 symbol loader, independent of PyOpenGL/moderngl.
Version queried at runtime; intended for application-controlled GL contexts.
"""
from __future__ import annotations
import ctypes as C
import sys

U=C.c_uint; I=C.c_int; F=C.c_float; S=C.c_int; V=C.c_void_p; B=C.c_ubyte
P=C.POINTER

GL_FALSE=0;GL_TRUE=1;GL_NONE=0;GL_FRONT=0x0404;GL_BACK=0x0405
GL_VERSION=0x1F02;GL_RENDERER=0x1F01
GL_VERTEX_SHADER=0x8B31;GL_FRAGMENT_SHADER=0x8B30;GL_COMPILE_STATUS=0x8B81;GL_LINK_STATUS=0x8B82
GL_INFO_LOG_LENGTH=0x8B84;GL_ARRAY_BUFFER=0x8892;GL_STATIC_DRAW=0x88E4;GL_DYNAMIC_DRAW=0x88E8
GL_FLOAT=0x1406;GL_TRIANGLES=0x0004;GL_RGBA=0x1908;GL_RGB=0x1907;GL_RED=0x1903;GL_UNSIGNED_BYTE=0x1401
GL_RGBA8=0x8058;GL_R8=0x8229;GL_RGBA16F=0x881A;GL_R16F=0x822D;GL_TEXTURE_2D=0x0DE1
GL_RGB16F=0x881B;GL_MAX_TEXTURE_SIZE=0x0D33
GL_NUM_EXTENSIONS=0x821D;GL_EXTENSIONS=0x1F03
GL_TEXTURE_MAX_ANISOTROPY_EXT=0x84FE;GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT=0x84FF
GL_TEXTURE_2D_MULTISAMPLE=0x9100;GL_MAX_COLOR_TEXTURE_SAMPLES=0x910E
GL_TEXTURE_MAX_LEVEL=0x813D;GL_TEXTURE0=0x84C0;GL_TEXTURE_MIN_FILTER=0x2801;GL_TEXTURE_MAG_FILTER=0x2800
GL_LINEAR=0x2601;GL_NEAREST=0x2600;GL_LINEAR_MIPMAP_LINEAR=0x2703;GL_TEXTURE_WRAP_S=0x2802
GL_TEXTURE_WRAP_T=0x2803;GL_CLAMP_TO_EDGE=0x812F;GL_UNPACK_ALIGNMENT=0x0CF5
GL_FRAMEBUFFER=0x8D40;GL_COLOR_ATTACHMENT0=0x8CE0;GL_COLOR_ATTACHMENT1=0x8CE1
GL_FRAMEBUFFER_COMPLETE=0x8CD5;GL_BLEND=0x0BE2;GL_ONE=1;GL_ZERO=0;GL_ONE_MINUS_SRC_COLOR=0x0301
GL_DEPTH_TEST=0x0B71;GL_CULL_FACE=0x0B44;GL_SRC_ALPHA=0x0302;GL_ONE_MINUS_SRC_ALPHA=0x0303
GL_COLOR=0x1800;GL_SCISSOR_TEST=0x0C11
GL_COLOR_BUFFER_BIT=0x00004000; GL_DEPTH_BUFFER_BIT=0x00000100
GL_DEPTH_ATTACHMENT=0x8D00; GL_DEPTH_COMPONENT=0x1902; GL_DEPTH_COMPONENT24=0x81A6
GL_TIME_ELAPSED=0x88BF;GL_QUERY_RESULT=0x8866;GL_QUERY_RESULT_AVAILABLE=0x8867
GL_TIMESTAMP=0x8E28;GL_MULTISAMPLE=0x809D;GL_SAMPLE_ALPHA_TO_COVERAGE=0x809E
GL_UNSIGNED_INT=0x1405; GL_LESS=0x0201; GL_TEXTURE_COMPARE_MODE=0x884C
GL_ELEMENT_ARRAY_BUFFER=0x8893;GL_PIXEL_PACK_BUFFER=0x88EB;GL_STREAM_READ=0x88E1
GL_R32UI=0x8236;GL_RED_INTEGER=0x8D94;GL_MAP_READ_BIT=0x0001
GL_SYNC_GPU_COMMANDS_COMPLETE=0x9117;GL_ALREADY_SIGNALED=0x911A;GL_CONDITION_SATISFIED=0x911C
GL_SYNC_FLUSH_COMMANDS_BIT=1;GL_POINTS=0;GL_LINE_LOOP=2
GL_WAIT_FAILED=0x911D
GL_FRONT_AND_BACK=0x0408;GL_LINE=0x1B01;GL_FILL=0x1B02
GL_PROGRAM_POINT_SIZE=0x8642;GL_ALIASED_LINE_WIDTH_RANGE=0x846E
GL_TEXTURE_BUFFER=0x8C2A;GL_RGBA32F=0x8814

SIGNATURES={
 'glGetString':(C.c_char_p,[U]),
 'glGetStringi':(C.c_char_p,[U,U]),'glGetIntegerv':(None,[U,P(I)]),'glGetFloatv':(None,[U,P(F)]),
 'glGetError':(U,[]),
 'glCreateShader':(U,[U]),'glShaderSource':(None,[U,I,P(C.c_char_p),P(I)]),
 'glCompileShader':(None,[U]),'glGetShaderiv':(None,[U,U,P(I)]),
 'glGetShaderInfoLog':(None,[U,I,P(I),V]),'glDeleteShader':(None,[U]),
 'glCreateProgram':(U,[]),'glAttachShader':(None,[U,U]),
 'glLinkProgram':(None,[U]),'glGetProgramiv':(None,[U,U,P(I)]),
 'glGetProgramInfoLog':(None,[U,I,P(I),V]),'glUseProgram':(None,[U]),
 'glDeleteProgram':(None,[U]),
 'glGetUniformLocation':(I,[U,C.c_char_p]),'glUniform1i':(None,[I,I]),
 'glUniform1f':(None,[I,F]),'glUniform2f':(None,[I,F,F]),'glUniform3f':(None,[I,F,F,F]),
 'glUniform4f':(None,[I,F,F,F,F]),
 'glUniformMatrix4fv':(None,[I,I,B,P(F)]),
 'glGenBuffers':(None,[I,P(U)]),'glBindBuffer':(None,[U,U]),
 'glBufferData':(None,[U,C.c_ssize_t,V,U]),'glBufferSubData':(None,[U,C.c_ssize_t,C.c_ssize_t,V]),
 'glDeleteBuffers':(None,[I,P(U)]),
 'glGenVertexArrays':(None,[I,P(U)]),'glBindVertexArray':(None,[U]),
 'glDeleteVertexArrays':(None,[I,P(U)]),'glEnableVertexAttribArray':(None,[U]),
 'glVertexAttribPointer':(None,[U,I,U,B,I,V]),
 'glDrawArrays':(None,[U,I,I]),
 'glMultiDrawElementsBaseVertex':(None,[U,P(I),U,P(V),I,P(I)]),
 'glMultiDrawArrays':(None,[U,P(I),P(I),I]),
 'glPolygonMode':(None,[U,U]),'glLineWidth':(None,[F]),
 'glMapBufferRange':(V,[U,C.c_ssize_t,C.c_ssize_t,U]),'glUnmapBuffer':(B,[U]),
 'glFenceSync':(V,[U,U]),'glDeleteSync':(None,[V]),
 'glClientWaitSync':(U,[V,U,C.c_uint64]),'glFlush':(None,[]),
 'glGenTextures':(None,[I,P(U)]),'glBindTexture':(None,[U,U]),
 'glTexImage2D':(None,[U,I,I,I,I,I,U,U,V]),
 'glTexImage2DMultisample':(None,[U,I,U,I,I,B]),
 'glTexBuffer':(None,[U,U,U]),
 'glTexSubImage2D':(None,[U,I,I,I,I,I,U,U,V]),
 'glTexParameteri':(None,[U,U,I]),'glGenerateMipmap':(None,[U]),
 'glTexParameterf':(None,[U,U,F]),
 'glActiveTexture':(None,[U]),'glGetTexImage':(None,[U,I,U,U,V]),'glDeleteTextures':(None,[I,P(U)]),
 'glPixelStorei':(None,[U,I]),
 'glGenFramebuffers':(None,[I,P(U)]),'glBindFramebuffer':(None,[U,U]),
 'glFramebufferTexture2D':(None,[U,U,U,U,I]),'glCheckFramebufferStatus':(U,[U]),
 'glDeleteFramebuffers':(None,[I,P(U)]),'glDrawBuffers':(None,[I,P(U)]),
 'glDrawBuffer':(None,[U]),'glDepthFunc':(None,[U]),'glClearDepth':(None,[C.c_double]),'glClearBufferfv':(None,[U,I,P(F)]),
 'glClearBufferuiv':(None,[U,I,P(U)]),
 'glViewport':(None,[I,I,I,I]),'glClearColor':(None,[F,F,F,F]),
 'glClear':(None,[U]),'glEnable':(None,[U]),'glDisable':(None,[U]),
 'glBlendFunc':(None,[U,U]),'glBlendFunci':(None,[U,U,U]),
 'glEnablei':(None,[U,U]),'glDisablei':(None,[U,U]),
 'glGenQueries':(None,[I,P(U)]),'glDeleteQueries':(None,[I,P(U)]),
 'glBeginQuery':(None,[U,U]),'glEndQuery':(None,[U]),
 'glQueryCounter':(None,[U,U]),
 'glGetQueryObjectuiv':(None,[U,U,P(U)]),
 'glGetQueryObjectui64v':(None,[U,U,P(C.c_uint64)]),
 'glReadPixels':(None,[I,I,I,I,U,U,V]),'glReadBuffer':(None,[U]),'glFinish':(None,[]),
}

class GL:
    def __init__(self,context):
        conv=C.WINFUNCTYPE if sys.platform=='win32' else C.CFUNCTYPE
        self.f={}
        for name,(ret,args) in SIGNATURES.items():
            addr=context.get_proc(name)
            if not addr:
                if name in ('glBlendFunci','glEnablei','glDisablei','glGenQueries','glDeleteQueries',
                            'glBeginQuery','glEndQuery','glGetQueryObjectuiv','glGetQueryObjectui64v'):
                    continue
                raise RuntimeError('Missing OpenGL entry point: '+name)
            self.f[name]=conv(ret,*args)(addr)
        self.version=(self.glGetString(GL_VERSION) or b'?').decode(errors='replace')
        self.renderer=(self.glGetString(GL_RENDERER) or b'?').decode(errors='replace')
        if 'OpenGL ES' in self.version:raise RuntimeError('Requires desktop OpenGL 3.3 or higher')
        import re
        match=re.search(r'(\d+)\.(\d+)',self.version)
        if not match or tuple(map(int,match.groups()))<(3,3):
            raise RuntimeError('Requires OpenGL 3.3+, found '+self.version)
        self.track_draws=False;self.draw_calls=0;self.subdraws=0
        for name in ('glDrawArrays','glMultiDrawArrays','glMultiDrawElementsBaseVertex'):
            raw=self.f[name]
            def tracked(*args,_raw=raw,_name=name):
                if self.track_draws:
                    self.draw_calls+=1
                    self.subdraws+=int(args[4] if _name=='glMultiDrawElementsBaseVertex' else args[3] if _name=='glMultiDrawArrays' else 1)
                return _raw(*args)
            self.f[name]=tracked

    def reset_draw_stats(self):self.draw_calls=0;self.subdraws=0
    def __getattr__(self,name):
        if name in self.f:return self.f[name]
        raise AttributeError(name)
    def available(self,name):return name in self.f

    def program(self,vertex:str,fragment:str):
        shaders=[];program=0
        try:
            for typ,src in ((GL_VERTEX_SHADER,vertex),(GL_FRAGMENT_SHADER,fragment)):
                h=self.glCreateShader(typ);shaders.append(h)
                data=src.encode('utf-8');ptr=C.c_char_p(data);length=I(len(data))
                self.glShaderSource(h,1,C.byref(ptr),C.byref(length));self.glCompileShader(h)
                ok=I();self.glGetShaderiv(h,GL_COMPILE_STATUS,C.byref(ok))
                if not ok.value:
                    log=C.create_string_buffer(8192);self.glGetShaderInfoLog(h,8192,None,log)
                    raise RuntimeError('GLSL compilation failed: '+log.value.decode(errors='replace'))
            program=self.glCreateProgram()
            for h in shaders:self.glAttachShader(program,h)
            self.glLinkProgram(program)
            ok=I();self.glGetProgramiv(program,GL_LINK_STATUS,C.byref(ok))
            if not ok.value:
                log=C.create_string_buffer(8192);self.glGetProgramInfoLog(program,8192,None,log)
                raise RuntimeError('GLSL link failed: '+log.value.decode(errors='replace'))
            if hasattr(self,"_uniform_locations"):
                self._uniform_locations={k:v for k,v in self._uniform_locations.items() if k[0]!=int(program)}
            if hasattr(self,"_uniform_values"):
                self._uniform_values={k:v for k,v in self._uniform_values.items() if k[0]!=int(program)}
            return int(program)
        except Exception:
            if program:self.glDeleteProgram(program)
            raise
        finally:
            for h in shaders:self.glDeleteShader(h)
    def name(self,kind):
        x=U();getattr(self,'glGen'+kind)(1,C.byref(x));return x.value
    def uniform(self,program,name,value):
        if not hasattr(self,'_uniform_locations'):self._uniform_locations={}
        key=(int(program),name)
        loc=self._uniform_locations.get(key)
        if loc is None:
            loc=self.glGetUniformLocation(program,name.encode('ascii'))
            self._uniform_locations[key]=loc
        if loc<0:return
        if not hasattr(self,"_uniform_values"):self._uniform_values={}
        canonical=("int",int(value)) if isinstance(value,(int,bool)) else (("float",value) if isinstance(value,float) else ("vector",tuple(map(float,value))))
        if self._uniform_values.get(key)==canonical:return
        self._uniform_values[key]=canonical
        if isinstance(value,(int,bool)):self.glUniform1i(loc,int(value))
        elif isinstance(value,float):self.glUniform1f(loc,value)
        elif len(value)==2:self.glUniform2f(loc,*map(float,value))
        elif len(value)==3:self.glUniform3f(loc,*map(float,value))
        elif len(value)==4:self.glUniform4f(loc,*map(float,value))
        else:raise ValueError('unsupported uniform '+name)
