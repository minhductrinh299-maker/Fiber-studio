"""Linear, premultiplied, tile-isolated sampling data for blended hair.

Alpha is area coverage, not alpha-test occupancy. Float mips retain sub-byte
coverage at large minification; no threshold-dependent gain or fiber thickening.
"""
import numpy as np
from PIL import Image


def srgb_to_linear(c):
    c=np.asarray(c,dtype=np.float32)
    return np.where(c<=.04045,c/12.92,((c+.055)/1.055)**2.4)


def linear_to_srgb(c):
    c=np.maximum(0,np.asarray(c,dtype=np.float32))
    return np.where(c<=.0031308,c*12.92,1.055*c**(1/2.4)-.055)


def resize_float(data,size):
    a=np.asarray(data,dtype=np.float32)
    if a.ndim==2:
        return np.asarray(Image.fromarray(a).resize(size,Image.Resampling.BOX),dtype=np.float32)
    return np.stack([resize_float(a[...,i],size) for i in range(a.shape[2])],axis=-1)


def tile_mips(image,alpha,channel):
    """Return contiguous float32 mips. Color is linear premultiplied RGBA.

    All maps have the same top-left origin and dimensions. GPU upload alone
    flips rows. Each tile has its own GL texture, so the full mip chain is safe.
    """
    a=np.asarray(alpha.convert('L'),dtype=np.float32)/255
    if image.size!=alpha.size:
        raise ValueError('Tile image and alpha dimensions differ')
    raw=np.asarray(image.convert('RGBA' if channel=='color' else
                                 'RGB' if channel in ('normal','flow') else 'L'),dtype=np.float32)/255
    # These source-space arrays are independent of mip size. Computing them
    # for every level repeated the expensive full-resolution conversion ~10x.
    weighted=None
    if channel=='color':weighted=srgb_to_linear(raw[...,:3])*a[...,None]
    elif channel in ('normal','flow'):
        vec=raw*2-1
        if channel=='flow':vec[...,2]=0
        weighted=vec*a[...,None]
    elif channel=='roughness':weighted=raw*raw*a
    w,h=image.size
    out=[]
    while True:
        size=(w,h)
        coverage=resize_float(a,size)
        if channel=='color':
            level=np.dstack((resize_float(weighted,size),coverage))
        elif channel=='alpha':
            level=coverage
        elif channel in ('normal','flow'):
            vec=resize_float(weighted,size)
            lengths=np.linalg.norm(vec,axis=-1,keepdims=True)
            fallback=np.array([0,0,1] if channel=='normal' else [0,1,0],np.float32)
            vec=np.where(lengths>1e-8,vec/np.maximum(lengths,1e-8),fallback)
            level=vec*.5+.5
        elif channel=='roughness':
            level=np.sqrt(np.maximum(0,resize_float(weighted,size)/np.maximum(coverage,1e-8)))
            level=np.where(coverage>1e-8,level,.5)
        else:
            raise ValueError(channel)
        out.append(np.ascontiguousarray(level,dtype=np.float32))
        if w==1 and h==1:break
        w=max(1,w//2);h=max(1,h//2)
    return out


def mip_bytes(width,height,bytes_per_pixel=24):
    total=0
    while True:
        total+=width*height*bytes_per_pixel
        if width==1 and height==1:return total
        width=max(1,width//2);height=max(1,height//2)


def prepare_tile(images,alpha):
    """Worker-safe: input images are owned copies; no GL or project mutation."""
    return {channel:tile_mips(image,alpha,channel) for channel,image in images.items()}
