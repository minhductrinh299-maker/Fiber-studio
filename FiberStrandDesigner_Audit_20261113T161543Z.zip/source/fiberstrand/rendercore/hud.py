"""Reusable OpenGL 3.3 viewport overlays: top-left HUD info display & corner 3D axis gizmo."""
from __future__ import annotations

import ctypes as C
import math
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from .glapi import (
    GL_ARRAY_BUFFER,
    GL_BLEND,
    GL_CLAMP_TO_EDGE,
    GL_CULL_FACE,
    GL_DEPTH_TEST,
    GL_DYNAMIC_DRAW,
    GL_FALSE,
    GL_FLOAT,
    GL_LINEAR,
    GL_ONE_MINUS_SRC_ALPHA,
    GL_RGBA,
    GL_RGBA8,
    GL_SRC_ALPHA,
    GL_TEXTURE0,
    GL_TEXTURE_2D,
    GL_TEXTURE_MAG_FILTER,
    GL_TEXTURE_MIN_FILTER,
    GL_TEXTURE_WRAP_S,
    GL_TEXTURE_WRAP_T,
    GL_TRIANGLES,
    GL_UNSIGNED_BYTE,
    U,
    V,
)

OVERLAY_2D_VERT = """#version 330 core
layout(location=0) in vec2 aPos;
layout(location=1) in vec2 aUV;
layout(location=2) in vec4 aColor;
uniform vec2 uViewport;
out vec2 vUV;
out vec4 vColor;
void main(){
    vec2 ndc = vec2(aPos.x / max(uViewport.x, 1.0) * 2.0 - 1.0,
                    1.0 - aPos.y / max(uViewport.y, 1.0) * 2.0);
    gl_Position = vec4(ndc, 0.0, 1.0);
    vUV = aUV;
    vColor = aColor;
}
"""

OVERLAY_2D_FRAG = """#version 330 core
in vec2 vUV;
in vec4 vColor;
uniform int uUseTex;
uniform sampler2D uTex;
out vec4 outColor;
void main(){
    if(uUseTex != 0){
        vec4 tex = texture(uTex, vUV);
        outColor = tex * vColor;
    } else {
        outColor = vColor;
    }
}
"""


def _load_font(px: int, bold: bool = False):
    names = ("segoeuib.ttf", "arialbd.ttf") if bold else ("segoeui.ttf", "arial.ttf", "DejaVuSans.ttf")
    for name in names:
        try:
            return ImageFont.truetype(name, max(9, int(px)))
        except Exception:
            continue
    return ImageFont.load_default()


class ViewportOverlayRenderer:
    """Zero-flicker OpenGL 3.3 HUD panel and 3D corner axis gizmo."""

    def __init__(self, gl):
        self.gl = gl
        self.program = gl.program(OVERLAY_2D_VERT, OVERLAY_2D_FRAG)
        self.vao = gl.name("VertexArrays")
        self.vbo = gl.name("Buffers")
        self.hud_tex = gl.name("Textures")
        self.label_tex = gl.name("Textures")
        self._hud_key = None
        self._hud_size = (0, 0)
        self._label_dpr = None
        self._vbo_cap = 0

        gl.glBindVertexArray(self.vao)
        gl.glBindBuffer(GL_ARRAY_BUFFER, self.vbo)
        stride = 8 * 4  # x, y, u, v, r, g, b, a
        gl.glEnableVertexAttribArray(0)
        gl.glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, stride, None)
        gl.glEnableVertexAttribArray(1)
        gl.glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, V(8))
        gl.glEnableVertexAttribArray(2)
        gl.glVertexAttribPointer(2, 4, GL_FLOAT, GL_FALSE, stride, V(16))

        for tex in (self.hud_tex, self.label_tex):
            gl.glBindTexture(GL_TEXTURE_2D, tex)
            gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
            gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
            gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)
            gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE)

    def _upload_and_draw(self, verts: np.ndarray, width: int, height: int, tex: int = 0):
        if len(verts) == 0:
            return
        g = self.gl
        arr = np.ascontiguousarray(verts, dtype=np.float32)
        g.glBindVertexArray(self.vao)
        g.glBindBuffer(GL_ARRAY_BUFFER, self.vbo)
        if arr.nbytes > self._vbo_cap:
            self._vbo_cap = max(4096, arr.nbytes * 2)
            g.glBufferData(GL_ARRAY_BUFFER, self._vbo_cap, None, GL_DYNAMIC_DRAW)
        g.glBufferSubData(GL_ARRAY_BUFFER, 0, arr.nbytes, V(arr.ctypes.data))
        g.glUseProgram(self.program)
        g.uniform(self.program, "uViewport", (float(width), float(height)))
        g.uniform(self.program, "uUseTex", 1 if tex else 0)
        if tex:
            g.glActiveTexture(GL_TEXTURE0)
            g.glBindTexture(GL_TEXTURE_2D, tex)
            g.uniform(self.program, "uTex", 0)
        g.glDrawArrays(GL_TRIANGLES, 0, len(arr))

    def _ensure_label_atlas(self, dpr: float):
        q_dpr = round(max(1.0, float(dpr)), 2)
        if self._label_dpr == q_dpr:
            return
        self._label_dpr = q_dpr
        cell = max(24, int(round(28 * q_dpr)))
        im = Image.new("RGBA", (cell * 3, cell), (0, 0, 0, 0))
        draw = ImageDraw.Draw(im)
        font = _load_font(int(round(13 * q_dpr)), bold=True)
        for idx, letter in enumerate(("X", "Y", "Z")):
            cx = idx * cell + cell * 0.5
            cy = cell * 0.5
            bbox = draw.textbbox((0, 0), letter, font=font)
            tw = bbox[2] - bbox[0]
            th = bbox[3] - bbox[1]
            tx = cx - tw * 0.5 - bbox[0]
            ty = cy - th * 0.5 - bbox[1]
            draw.text((tx + 1, ty + 1), letter, font=font, fill=(10, 12, 16, 220))
            draw.text((tx, ty), letter, font=font, fill=(255, 255, 255, 255))
        payload = im.tobytes()
        g = self.gl
        g.glBindTexture(GL_TEXTURE_2D, self.label_tex)
        g.glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, im.width, im.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, payload)

    def _ensure_hud_texture(self, lines: tuple[str, ...], dpr: float):
        q_dpr = round(max(1.0, float(dpr)), 2)
        key = (lines, q_dpr)
        if self._hud_key == key:
            return
        self._hud_key = key
        pad_x = int(round(6 * q_dpr))
        pad_y = int(round(4 * q_dpr))
        font_title = _load_font(int(round(12 * q_dpr)), bold=True)
        font_body = _load_font(int(round(11 * q_dpr)), bold=False)

        dummy = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
        dd = ImageDraw.Draw(dummy)
        max_w = 120
        line_heights = []
        for idx, text in enumerate(lines):
            f = font_title if idx == 0 else font_body
            bb = dd.textbbox((0, 0), text, font=f)
            max_w = max(max_w, (bb[2] - bb[0]) + pad_x * 2 + 4)
            line_heights.append((bb[3] - bb[1]) + int(round(4 * q_dpr)))

        w = int(max_w)
        h = int(sum(line_heights) + pad_y * 2)
        im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(im)

        # Maya-style transparent HUD: crisp overlaid text with subtle drop-shadow, no background box
        shadow_off = max(1, int(round(1.0 * q_dpr)))
        y = pad_y
        for idx, text in enumerate(lines):
            f = font_title if idx == 0 else font_body
            color = (238, 194, 126, 245) if idx == 0 else (232, 236, 242, 235)
            draw.text((pad_x + shadow_off, y + shadow_off), text, font=f, fill=(6, 8, 12, 210))
            draw.text((pad_x, y), text, font=f, fill=color)
            y += line_heights[idx]

        self._hud_size = (w, h)
        g = self.gl
        g.glBindTexture(GL_TEXTURE_2D, self.hud_tex)
        g.glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, im.tobytes())

    def draw_hud(self, width: int, height: int, dpr: float, lines: list[str] | tuple[str, ...]):
        if not lines or width < 64 or height < 64:
            return
        self._ensure_hud_texture(tuple(lines), dpr)
        hw, hh = self._hud_size
        if hw <= 0 or hh <= 0:
            return
        x0 = 12.0 * dpr
        y0 = 12.0 * dpr
        x1 = x0 + hw
        y1 = y0 + hh
        quad = np.array(
            [
                [x0, y0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0],
                [x1, y0, 1.0, 0.0, 1.0, 1.0, 1.0, 1.0],
                [x1, y1, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0],
                [x0, y0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0],
                [x1, y1, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0],
                [x0, y1, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0],
            ],
            dtype=np.float32,
        )
        g = self.gl
        g.glDisable(GL_DEPTH_TEST)
        g.glDisable(GL_CULL_FACE)
        g.glEnable(GL_BLEND)
        g.glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        self._upload_and_draw(quad, width, height, tex=self.hud_tex)

    def draw_axis_gizmo(self, width: int, height: int, dpr: float, view_rot: np.ndarray, up_axis: str = "Y-Up"):
        if width < 80 or height < 80:
            return
        q_dpr = max(1.0, float(dpr))
        self._ensure_label_atlas(q_dpr)

        radius = 34.0 * q_dpr
        cx = 52.0 * q_dpr
        cy = float(height) - 52.0 * q_dpr

        # Solid untextured geometry: subtle circle backdrop + 3 axis shafts + tip circles
        verts = []
        bg_r = radius + 12.0 * q_dpr
        segs = 28
        for i in range(segs):
            a0 = 2.0 * math.pi * i / segs
            a1 = 2.0 * math.pi * (i + 1) / segs
            verts.append([cx, cy, 0.0, 0.0, 0.07, 0.08, 0.11, 0.55])
            verts.append([cx + bg_r * math.cos(a0), cy + bg_r * math.sin(a0), 0.0, 0.0, 0.07, 0.08, 0.11, 0.55])
            verts.append([cx + bg_r * math.cos(a1), cy + bg_r * math.sin(a1), 0.0, 0.0, 0.07, 0.08, 0.11, 0.55])

        if up_axis == "Z-Up":
            axes = [
                (0, np.array([1.0, 0.0, 0.0], dtype=np.float32), (0.95, 0.34, 0.34, 1.0)),
                (1, np.array([0.0, 0.0, -1.0], dtype=np.float32), (0.36, 0.86, 0.45, 1.0)),
                (2, np.array([0.0, 1.0, 0.0], dtype=np.float32), (0.32, 0.64, 0.98, 1.0)),
            ]
        else:
            axes = [
                (0, np.array([1.0, 0.0, 0.0], dtype=np.float32), (0.95, 0.34, 0.34, 1.0)),
                (1, np.array([0.0, 1.0, 0.0], dtype=np.float32), (0.36, 0.86, 0.45, 1.0)),
                (2, np.array([0.0, 0.0, 1.0], dtype=np.float32), (0.32, 0.64, 0.98, 1.0)),
            ]

        projected = []
        for idx, vec, col in axes:
            v = view_rot @ vec
            # Screen X = +v[0], Screen Y = -v[1] (top-down pixels)
            sx = float(v[0]) * radius
            sy = -float(v[1]) * radius
            vz = float(v[2])
            projected.append((vz, idx, sx, sy, col))
        projected.sort(key=lambda item: item[0])  # Back-to-front

        half_w = 1.4 * q_dpr
        tip_r = 8.5 * q_dpr
        tip_segs = 14
        for vz, idx, sx, sy, col in projected:
            dim = 0.68 if vz < -0.15 else 1.0
            r_c, g_c, b_c, a_c = col[0] * dim, col[1] * dim, col[2] * dim, col[3]
            tx = cx + sx
            ty = cy + sy
            length = math.hypot(sx, sy)
            if length > 1e-3:
                nx = -sy / length * half_w
                ny = sx / length * half_w
                p0 = [cx - nx, cy - ny, 0.0, 0.0, r_c, g_c, b_c, a_c]
                p1 = [cx + nx, cy + ny, 0.0, 0.0, r_c, g_c, b_c, a_c]
                p2 = [tx + nx, ty + ny, 0.0, 0.0, r_c, g_c, b_c, a_c]
                p3 = [tx - nx, ty - ny, 0.0, 0.0, r_c, g_c, b_c, a_c]
                verts.extend([p0, p1, p2, p0, p2, p3])
            for i in range(tip_segs):
                a0 = 2.0 * math.pi * i / tip_segs
                a1 = 2.0 * math.pi * (i + 1) / tip_segs
                verts.append([tx, ty, 0.0, 0.0, r_c, g_c, b_c, a_c])
                verts.append([tx + tip_r * math.cos(a0), ty + tip_r * math.sin(a0), 0.0, 0.0, r_c, g_c, b_c, a_c])
                verts.append([tx + tip_r * math.cos(a1), ty + tip_r * math.sin(a1), 0.0, 0.0, r_c, g_c, b_c, a_c])

        # Center origin dot
        c_r = 3.0 * q_dpr
        for i in range(12):
            a0 = 2.0 * math.pi * i / 12
            a1 = 2.0 * math.pi * (i + 1) / 12
            verts.append([cx, cy, 0.0, 0.0, 0.9, 0.9, 0.92, 0.9])
            verts.append([cx + c_r * math.cos(a0), cy + c_r * math.sin(a0), 0.0, 0.0, 0.9, 0.9, 0.92, 0.9])
            verts.append([cx + c_r * math.cos(a1), cy + c_r * math.sin(a1), 0.0, 0.0, 0.9, 0.9, 0.92, 0.9])

        g = self.gl
        g.glDisable(GL_DEPTH_TEST)
        g.glDisable(GL_CULL_FACE)
        g.glEnable(GL_BLEND)
        g.glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        self._upload_and_draw(np.asarray(verts, dtype=np.float32), width, height, tex=0)

        # Draw X, Y, Z label sprites over the tip circles
        badge_half = 8.5 * q_dpr
        label_verts = []
        for vz, idx, sx, sy, _ in projected:
            tx = cx + sx
            ty = cy + sy
            u0 = idx / 3.0
            u1 = (idx + 1) / 3.0
            x0, x1 = tx - badge_half, tx + badge_half
            y0, y1 = ty - badge_half, ty + badge_half
            a = 0.82 if vz < -0.15 else 1.0
            label_verts.extend([
                [x0, y0, u0, 0.0, 1.0, 1.0, 1.0, a],
                [x1, y0, u1, 0.0, 1.0, 1.0, 1.0, a],
                [x1, y1, u1, 1.0, 1.0, 1.0, 1.0, a],
                [x0, y0, u0, 0.0, 1.0, 1.0, 1.0, a],
                [x1, y1, u1, 1.0, 1.0, 1.0, 1.0, a],
                [x0, y1, u0, 1.0, 1.0, 1.0, 1.0, a],
            ])
        self._upload_and_draw(np.asarray(label_verts, dtype=np.float32), width, height, tex=self.label_tex)

    def close(self):
        g = self.gl
        for name in (self.hud_tex, self.label_tex):
            if name:
                v = U(name)
                g.glDeleteTextures(1, C.byref(v))
        if self.vbo:
            v = U(self.vbo)
            g.glDeleteBuffers(1, C.byref(v))
        if self.vao:
            v = U(self.vao)
            g.glDeleteVertexArrays(1, C.byref(v))
        if self.program:
            g.glDeleteProgram(self.program)
