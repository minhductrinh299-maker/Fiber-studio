"""Double precision reference for the normalized Chiang/PBRT hair model.

Local x is the fiber tangent. evaluate() returns the projected scattering
response (PBRT f * abs(wi.z)), integrated using d(sin(theta))*d(phi).
Adapted from PBRT v3 hair.cpp; see vendor/pbrt/LICENSE.txt.
No display transform, coverage, artistic gain or lighting is part of this model.
"""
from dataclasses import dataclass
import math
import numpy as np

PI = math.pi

@dataclass(frozen=True)
class HairOptics:
    longitudinal: float = .3
    azimuthal: float = .5
    ior: float = 1.55
    tilt_degrees: float = 2.

def absorption_from_color(color, beta_n=.5, strength=1.):
    b = float(np.clip(beta_n, .03, 1.))
    d = 5.969-.215*b+2.532*b*b-10.73*b**3+5.574*b**4+.245*b**5
    return (np.log(np.clip(color, .0001, 1.))/d)**2 * max(0., strength)

def absorption_from_card_color(color, strength=1.):
    """Painted linear RGB attenuation through a unit-radius fiber diameter.

    The PBRT measured-reflectance fit above remains available for measured data;
    painted card pixels use Beer-Lambert optical depth without that extra fit.
    """
    return -.5*np.log(np.clip(color,.0001,1.))*max(0.,strength)


def _variance(b):
    b = float(np.clip(b, .03, 1.))
    v = (.726*b+.812*b*b+3.7*b**20)**2
    return (v, v*.25, v*4., v*4.)

def _log_i0(x):
    if x > 12.:
        return x+.5*(-math.log(2*PI)-math.log(x)+1/(8*x))
    term = total = 1.
    for i in range(1, 10):
        term *= x*x/(4*i*i); total += term
    return math.log(total)

def _mp(si, ci, so, co, v):
    a = ci*co/v; b = si*so/v
    if v <= .1:
        return math.exp(min(80., _log_i0(a)-b-1/v+math.log(1/(2*v))+math.log(2)))
    return math.exp(-b+_log_i0(a))/(2*v*math.sinh(1/v))

def _fresnel(c, eta):
    st = math.sqrt(max(0., 1-c*c))/eta
    ct = math.sqrt(max(0., 1-st*st))
    rp = (eta*c-ct)/(eta*c+ct)
    rs = (c-eta*ct)/(c+eta*ct)
    return .5*(rp*rp+rs*rs)

def _np(phi, scale):
    x = (phi+PI) % (2*PI)-PI
    e = math.exp(-abs(x)/scale)
    norm = 1-2/(1+math.exp(min(700., PI/scale)))
    return e/(scale*(1+e)**2*norm)

def evaluate(wo, wi, sigma_a, optics=HairOptics(), h=0.):
    """RGB response for unit directions; h is cylinder offset in [-1,1]."""
    wo = np.asarray(wo, dtype=np.float64); wi = np.asarray(wi, dtype=np.float64)
    wo = wo/max(np.linalg.norm(wo), 1e-12); wi = wi/max(np.linalg.norm(wi), 1e-12)
    so, si = float(wo[0]), float(wi[0])
    co, ci = math.sqrt(max(1e-12, 1-so*so)), math.sqrt(max(0., 1-si*si))
    h = float(np.clip(h, -.9999, .9999)); eta = max(1.001, optics.ior)
    gt = math.asin(h*co/math.sqrt(eta*eta-so*so)); go = math.asin(h)
    ct = math.sqrt(max(1e-12, 1-(so/eta)**2))
    trans = np.exp(-np.maximum(sigma_a, 0.)*(2*math.cos(gt)/ct))
    f = _fresnel(co*math.sqrt(1-h*h), eta)
    ap = [np.full(3, f), (1-f)**2*trans]
    ap.append(ap[1]*trans*f)
    ap.append(ap[2]*trans*f/np.maximum(1-trans*f, 1e-8))
    b = float(np.clip(optics.azimuthal, .03, 1.))
    scale = math.sqrt(PI/8)*(.265*b+1.194*b*b+5.372*b**22)
    dp = math.atan2(wi[2], wi[1])-math.atan2(wo[2], wo[1])
    out = np.zeros(3)
    variance = _variance(optics.longitudinal)
    for p, angle in enumerate((-2., 1., 4., 0.)):
        a = math.radians(optics.tilt_degrees)*angle
        sp = so*math.cos(a)+co*math.sin(a)
        cp = abs(co*math.cos(a)-so*math.sin(a))
        az = _np(dp-(2*p*gt-2*go+p*PI), scale) if p < 3 else 1/(2*PI)
        out += ap[p]*_mp(si, ci, sp, cp, variance[p])*az
    return out
