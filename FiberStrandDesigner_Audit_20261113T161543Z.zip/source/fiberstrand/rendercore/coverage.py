"""Deterministic per-tile alpha preservation; safe standalone algorithms.

GPU atlas mip generation is deliberately limited while logical tiles share a page.
At lower levels the distance between adjacent tiles becomes sub-pixel and *no*
shared regular mipmap can keep their edges independent. The renderer clamps LOD
before that point; a future per-tile array/virtual texture lifts this limit.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
import numpy as np
from PIL import Image
from .sampling import srgb_to_linear,linear_to_srgb,resize_float

@dataclass(frozen=True)
class TileRect:
    page: int
    x: int
    y: int
    width: int
    height: int
    padding: int


def coverage(alpha: Image.Image | np.ndarray, threshold: float=.5) -> float:
    data=np.asarray(alpha.convert('L') if isinstance(alpha,Image.Image) else alpha,dtype=np.float32)
    if data.size == 0:return 0.
    if data.max(initial=0.)>1.0:data/=255.
    return float(np.count_nonzero(data>=threshold)/data.size)


def preserve_coverage(source: Image.Image, reduced: Image.Image, threshold: float=.5) -> tuple[Image.Image,float]:
    """Scale downsampled alpha toward the original alpha-test coverage.

    Since a finite mip pixel grid only admits quantized coverage, exact equality
    is not always possible. Uses a deterministic monotone best-fit search.
    """
    a=np.asarray(reduced.convert('L'),dtype=np.float32)/255.
    target=coverage(source,threshold)
    if target<=0 or a.max(initial=0.)<=0:return reduced.convert('L'),1.
    lo,hi=0.,16.
    best=1.;error=float('inf')
    for k in range(30):
        x=(lo+hi)*.5
        val=np.clip(a*x,0,1)
        result=float((val>=threshold).mean())
        e=abs(result-target)
        if e<error-1e-8 or (abs(e-error)<1e-8 and abs(x-1)<abs(best-1)):
            best=x;error=e
        if result<target:lo=x
        else:hi=x
    result=np.clip(np.rint(a*best*255),0,255).astype('uint8')
    return Image.fromarray(result,'L'),best


def max_safe_level(padding: int, atlas_size: int) -> int:
    """Keep >=2 px effective gutter, so separate tile regions never merge."""
    if padding<2:return 0
    return min(int(math.floor(math.log2(padding/2))),int(math.floor(math.log2(atlas_size))))


def atlas_mip_chain(image: Image.Image, alpha: Image.Image, tiles: list[TileRect],
                    channel: str, page: int, max_level: int | None=None,
                    preserve_alpha: bool=False) -> list[Image.Image]:
    """Resample each tile in isolation, with equal depth/normal/flow origin.

    Does NOT alter level 0 and never blurs one tile's content into another.
    Color channels are resampled in premultiplied alpha and then unpremultiplied.
    All non-color channels follow their own correct filtering conventions.
    """
    assert image.size==alpha.size and image.width==image.height
    subset=[t for t in tiles if t.page==page]
    levels=max_level if max_level is not None else min((max_safe_level(t.padding,image.width) for t in subset),default=0)
    mips=[image.copy()]
    for level in range(1,levels+1):
        scale=2**level
        size=max(1,image.width//scale)
        out=Image.new(image.mode,(size,size),0 if image.mode in ('L','RGB') else (0,0,0,0))
        for tile in subset:
            x,y,w,h=tile.x,tile.y,tile.width,tile.height
            # Include entire padding; truncate edges to the page.
            x0=max(0,x-tile.padding);y0=max(0,y-tile.padding)
            x1=min(image.width,x+w+tile.padding);y1=min(image.height,y+h+tile.padding)
            bx0,by0=int(math.ceil(x0/scale)),int(math.ceil(y0/scale))
            bx1,by1=int(math.floor(x1/scale)),int(math.floor(y1/scale))
            if bx1<=bx0 or by1<=by0:continue
            sz=(bx1-bx0,by1-by0)
            source_box=(bx0*scale,by0*scale,bx1*scale,by1*scale)
            patch=image.crop(source_box)
            a0=alpha.crop(source_box)
            if channel=='color':
                rgba=np.asarray(patch.convert('RGBA'),dtype=np.float32)
                weight=np.asarray(a0,dtype=np.float32)/255.
                weight=np.maximum(weight,0.)[...,None]
                weighted=resize_float(srgb_to_linear(rgba[:,:,:3]/255.)*weight,sz)
                downa=a0.resize(sz,Image.Resampling.BOX)
                if preserve_alpha:downa,_=preserve_coverage(a0,downa)
                av=np.asarray(a0.resize(sz,Image.Resampling.BOX),dtype=np.float32)/255.
                rgb=np.clip(np.rint(linear_to_srgb(weighted/np.maximum(av[...,None],1e-8))*255),0,255).astype('uint8')
                patch=Image.fromarray(np.dstack((rgb,np.asarray(downa,dtype=np.uint8))),'RGBA')
            else:
                patch=patch.resize(sz,Image.Resampling.BOX)
                if channel=='alpha' and preserve_alpha:patch,_=preserve_coverage(a0,patch)
                if channel in ('flow','normal'):
                    pix=np.asarray(patch.convert('RGB'),dtype=np.float32)/127.5-1.
                    norm=np.linalg.norm(pix,axis=2,keepdims=True)
                    pix=pix/np.maximum(norm,1e-6)
                    patch=Image.fromarray(np.clip(np.rint((pix+1)*127.5),0,255).astype('uint8'),'RGB')
            out.paste(patch,(bx0,by0))
        mips.append(out)
    return mips
