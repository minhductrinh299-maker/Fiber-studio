"""Versioned source lookdev settings shared by all workspaces."""
from dataclasses import fields,asdict
from .renderer import HairMaterial

def material_from_project(project):
    record=project.metadata.get('rendercore',{})
    data=record.get('material',{})
    accepted={f.name for f in fields(HairMaterial)}
    values={k:v for k,v in data.items() if k in accepted}
    if data and 'shading_mode' not in data:values['shading_mode']='Legacy'
    return HairMaterial(**values)

def store_material(project,material,quality='Lookdev'):
    # Replace source dictionaries; never mutate shared snapshots in place.
    value={'schema':2,'material':asdict(material),'quality':quality,
           'working_space':'linear Rec.709 D65','display_transform':'FSD Filmic'}
    if project.metadata.get('rendercore')!=value:
        project.metadata={**project.metadata,'rendercore':value}
