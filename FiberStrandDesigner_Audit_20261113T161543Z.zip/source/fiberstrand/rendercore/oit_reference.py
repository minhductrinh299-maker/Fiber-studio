"""Deterministic, scene-linear OIT comparison for GPU shader development.

The CPU oracle is *not* used to render preview frames. It provides exact
sorted compositing and a bounded K+tail approximation to validate D3D12 code.
"""
from __future__ import annotations
from dataclasses import dataclass
from collections.abc import Iterable
import numpy as np

@dataclass(frozen=True)
class Fragment:
    depth:float
    color:tuple[float,float,float]
    alpha:float


def exact_sorted(fragments:Iterable[Fragment],background=(.05,.05,.05)) -> np.ndarray:
    ordered=sorted(fragments,key=lambda f:f.depth)
    light=np.zeros(3,dtype=np.float64)
    trans=1.
    for f in ordered:
        a=np.clip(f.alpha,0.,1.)
        light+=trans*a*np.asarray(f.color,dtype=np.float64)
        trans*=1-a
    return light+trans*np.asarray(background,dtype=np.float64)


def bounded_k_tail(fragments:Iterable[Fragment], k:int=4,background=(.05,.05,.05)) -> np.ndarray:
    """Order the nearest K fragments; weighted OIT farther than the K-th.

    Deterministic irrespective of fragment submission ordering except exact
    equal-depth ties, which are resolved by an additional stable color key.
    """
    if not 1<=k<=16:raise ValueError('K must be between 1 and 16')
    ordered=sorted(fragments,key=lambda f:(f.depth,)+tuple(f.color)+(f.alpha,))
    front=ordered[:k]
    tail=ordered[k:]
    weight_sum=0.;weighted_rgb=np.zeros(3,dtype=np.float64);reveal=1.
    for f in tail:
        a=float(np.clip(f.alpha,0.,1.))
        weight=float(np.clip(3./(.2+max(f.depth,0.)**3),.05,12.))
        weighted_rgb+=a*weight*np.asarray(f.color,dtype=np.float64)
        weight_sum+=a*weight
        reveal*=1-a
    tail_col=weighted_rgb/max(weight_sum,1e-9)
    light=tail_col*(1-reveal)+reveal*np.asarray(background,dtype=np.float64)
    for f in reversed(front):
        a=float(np.clip(f.alpha,0.,1.))
        light=np.asarray(f.color,dtype=np.float64)*a+light*(1-a)
    return light


def opacity_density(alpha:float) -> float:
    """Finite optical depth per coverage layer for the four-bin shadow pass."""
    return float(-np.log(max(.02,1-np.clip(alpha,0,.98))))


def shadow_transmittance(bins:np.ndarray,depth:float,strength:float=1.0) -> float:
    """Approximate 4-bin attenuation as used by the realtime shadow shader."""
    mix=np.clip(depth*4-np.arange(4),0,1)
    optical=float(np.dot(bins,mix))
    return float((1-strength)+strength*np.exp(-min(optical,16.)))
