"""Versioned snapshot bridge to the experimental standalone D3D12 viewport.

Exports existing card geometry and cached maps; never generates or bakes fibers.
UVs in this format use the PNG/D3D top-left convention, unlike OBJ/OpenGL.
"""
from pathlib import Path
import argparse
import json
import struct
import numpy as np
from PIL import Image
from ..cards import HairCard, ribbon_mesh

MAGIC = b'FSDNAT01'
CHANNELS = ('color', 'alpha', 'normal', 'flow', 'roughness')


def write_scene(cards, placements, atlas_size, folder, pages):
    """Write one-page snapshot. Reject unsupported multi-page scenes explicitly."""
    folder = Path(folder)
    vertices = []
    for item in cards:
        card = item if isinstance(item, HairCard) else HairCard.from_dict(item)
        if not card.visible:
            continue
        p = placements.get(card.tile_id)
        if p is None:
            raise ValueError(f'Missing atlas tile: {card.tile_id}')
        if not isinstance(p, dict):
            p = {'page': p.page, 'rect_px': [p.x, p.y, p.width, p.height]}
        if p['page'] != 0:
            raise ValueError('Native viewport snapshot currently supports atlas page 0 only')
        xyz, uv, triangles, _ = ribbon_mesh(card)
        x, y, w, h = p['rect_px']
        # ribbon_mesh root v=1, tip v=0; same coordinates as PNG sampling.
        uv = (np.array([x, y]) + uv * np.array([w, h])) / atlas_size
        for tri in triangles:
            a, b, c = xyz[tri]
            normal = np.cross(b-a, c-a)
            normal /= max(float(np.linalg.norm(normal)), 1e-8)
            duv1, duv2 = uv[tri[1]]-uv[tri[0]], uv[tri[2]]-uv[tri[0]]
            det = float(duv1[0]*duv2[1] - duv1[1]*duv2[0])
            if abs(det) < 1e-12:
                raise ValueError('Degenerate native card UVs')
            # Root-to-tip tangent derived from UV gradients on both triangles.
            tangent = -(duv1[0]*(c-a) - duv2[0]*(b-a)) / det
            tangent /= max(float(np.linalg.norm(tangent)), 1e-8)
            for i in tri:
                vertices.append([*xyz[i], *normal, *tangent, *uv[i]])
    data = np.asarray(vertices, dtype='<f4').reshape(-1, 11)
    if not len(data) or not np.isfinite(data).all():
        raise ValueError('Native scene must have finite, visible triangles')
    images = {}
    for name in CHANNELS:
        im = pages(name, 0)
        if im.size != (atlas_size, atlas_size):
            raise ValueError(f'Wrong atlas dimensions for {name}')
        images[name] = im
    folder.mkdir(parents=True, exist_ok=True)
    for name, im in images.items():
        im.save(folder / f'{name}.png')
    path = folder / 'scene.fsdn'
    path.write_bytes(MAGIC + struct.pack('<II', len(data), atlas_size) + data.tobytes())
    return path


def export_cache(cards, cache, folder):
    return write_scene(cards, cache.layout.placements, cache.layout.size, folder, cache.get_page)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--atlas', type=Path, required=True)
    parser.add_argument('--project', type=Path, help='Use cards from an existing .fsd project')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads((args.atlas / 'FSD_Atlas_manifest.json').read_text(encoding='utf-8'))
    if args.project:
        from ..projectio import load_project
        cards = load_project(args.project).cards
    else:
        cards = []
        for i, tile in enumerate(manifest['tiles']):
            c = HairCard.create(tile, root=[(i-1.5)*.55, 0, 0])
            c.width = .5
            c.length = 1.5
            cards.append(c)
    def page(name, index):
        with Image.open(args.atlas / f'FSD_Atlas_{index:02d}_{name}.png') as im:
            return im.copy()
    print(write_scene(cards, manifest['tiles'], manifest['atlas_size'], args.output, page))


if __name__ == '__main__':
    main()
