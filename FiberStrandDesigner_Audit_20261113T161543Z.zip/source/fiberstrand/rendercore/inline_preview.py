"""Direct WGL Render Studio preview, owned by the enclosing workspace."""
from copy import deepcopy
import tkinter as tk
from .renderer import GPUHairRenderer,HairMaterial
from ..cards import HairCard
from ..navigation import MayaNavigation,pan_target,dolly_factor

class InlineRender(tk.Frame):
    def __init__(self,host,app,source):
        super().__init__(host,bg='#101419');self.app=app;self.source=source;self.renderer=None;self.marker=None;self.job=None
        self.place(x=0,y=0,relwidth=1,relheight=1);self.lift()
        self.note=tk.Label(self,text='Preparing Render Studio preview…',bg='#101419',fg='white');self.note.pack()
        self.stage=tk.Frame(self,bg='#101419');self.stage.pack(fill='both',expand=True)
        self.bind('<Destroy>',self.destroyed,add='+');self.after_idle(self.start)
    def start(self):
        if not self.winfo_exists():return
        try:
            self.renderer=GPUHairRenderer(max(64,self.stage.winfo_width()),max(64,self.stage.winfo_height()),hwnd=self.stage.winfo_id(),async_sampling=True)
            if getattr(self,'source_kind',None)=='cards':
                from ..object_workspace import workspace
                self.renderer.object_workspace=workspace(self.app)
            self.renderer.set_transparency('auto',2);self.renderer.show_grid=False;self.renderer.show_hud=False
            self.renderer.material=deepcopy(self.app.render_window.material) if self.app.render_window and self.app.render_window.winfo_exists() else HairMaterial()
            self.navigation=MayaNavigation(self.stage,self.orbit,self.pan,self.zoom)
            self.tick()
        except Exception as error:
            self.note.configure(text='Render preview unavailable: '+str(error))
            if self.renderer:self.renderer.close();self.renderer=None
    def orbit(self,dx,dy,snap=False):
        self.renderer.yaw-=dx*.008;self.renderer.pitch=max(-1.5,min(1.5,self.renderer.pitch+dy*.008))
    def pan(self,dx,dy):
        r=self.renderer;r.target[:]=pan_target(r.target,r.yaw,r.pitch,r.distance,self.stage.winfo_height(),dx,dy)
    def zoom(self,dx):self.renderer.distance*=dolly_factor(dx)
    def tick(self):
        if not self.winfo_exists() or not self.renderer:return
        try:
            cache,cards,stamp=self.source()
            r=self.renderer
            owner=getattr(r,'object_workspace',None)
            if owner:stamp=(stamp,owner.pose_revision)
            if cache is not None and stamp!=self.marker:
                r.load_atlas_cache(cache);r.load_cards(cards,cache.layout.placements,cache.layout.size)
                self.marker=stamp;self.note.configure(text='Render Studio · '+r.gl.renderer+' · Alt + mouse: navigate')
            if self.app.render_window and self.app.render_window.winfo_exists():r.material=deepcopy(self.app.render_window.material)
            if self.winfo_viewable():
                r.resize(max(64,self.stage.winfo_width()),max(64,self.stage.winfo_height()));r.render()
        except Exception as error:self.note.configure(text=str(error))
        self.job=self.after(33,self.tick)
    def destroy(self):
        if self.job:
            try:self.after_cancel(self.job)
            except tk.TclError:pass
            self.job=None
        if self.renderer:self.renderer.close();self.renderer=None
        super().destroy()

    def destroyed(self,e):
        if e.widget is not self:return
        if self.job:
            try:self.after_cancel(self.job)
            except tk.TclError:pass
        if self.renderer:self.renderer.close();self.renderer=None

def toggle(owner,host,app,kind):
    panel=getattr(owner,'_inline_render',None)
    if panel and panel.winfo_exists():panel.destroy();owner._inline_render=None;return
    def source():
        cache=app._atlas
        if kind=='graph':
            result=owner._preview
            if result is None:return None,[],None
            if getattr(owner,'_inline_result',None) is not result:
                from ..model import Project
                from ..atlas import AtlasCache
                tile=deepcopy(app.project.find(owner.tileid));tile.width=result.width;tile.height=result.height
                project=Project(name='Graph Preview',tiles=[tile],atlas_size=max(512,2**max(result.width,result.height).bit_length()))
                owner._inline_cache=AtlasCache(project);owner._inline_cache.update_tile(result);owner._inline_result=result
            cache=owner._inline_cache;ids=[owner.tileid]
        elif kind=='cards':
            from ..editor_scene import card_signature
            cards=owner.cards
            return cache,cards,(id(cache),tuple(card_signature(c) for c in cards))
        else:ids=[app.current_id] if app.mode.get()=='Tile' else [t.id for t in app.project.tiles]
        cards=[]
        for index,tid in enumerate(ids):
            tile=app.project.find(tid)
            if tile is None:continue
            c=HairCard.create(tid);c.id='inline:'+tid;c.root=[(index-(len(ids)-1)/2)*1.15,0,0]
            c.width=tile.width/max(tile.height,1);c.length=1;c.bend=0;c.taper=0
            cards.append(c)
        return cache,cards,(id(cache),tuple(ids))
    owner._inline_render=InlineRender(host,app,source)
    owner._inline_render.source_kind=kind
    if kind!='graph':
        for tile in app.project.tiles:
            if kind=='cards' or app.mode.get()=='Atlas' or tile.id==app.current_id:app._submit_preview(tile,show_status=False,force_atlas=True)
