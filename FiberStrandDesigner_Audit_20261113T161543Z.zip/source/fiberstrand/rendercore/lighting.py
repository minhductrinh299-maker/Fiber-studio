"""Light rig and editor gesture maths for Fiber Strand Designer.

The key light uses world-space azimuth/elevation degrees.  Shift + right-mouse
moves the studio rig, not the camera or any atlas/material baking inputs.
Pure math in this module keeps the UI interaction testable without Tk/OpenGL.
"""
from __future__ import annotations
from dataclasses import dataclass
import math

SHIFT_MASK = 0x0001   # Tk event.state ShiftMask on Windows and X11


def light_color_from_srgb(rgb):
    """Color-picker channels [0,255] -> scene-linear light RGB."""
    values=tuple(float(c)/255. for c in rgb)
    if len(values)!=3 or any(not math.isfinite(c) or c<0 or c>1 for c in values):
        raise ValueError('Light color must have three sRGB channels in [0,255]')
    return tuple(c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4 for c in values)


def light_color_hex(linear):
    """Scene-linear light RGB -> display sRGB swatch (not a material change)."""
    values=tuple(float(c) for c in linear)
    if len(values)!=3 or any(not math.isfinite(c) or c<0 for c in values):
        raise ValueError('Invalid linear light color')
    values=[min(1.,c*12.92 if c<=.0031308 else 1.055*c**(1/2.4)-.055) for c in values]
    return '#'+''.join(f'{round(c*255):02x}' for c in values)


def normalize_azimuth(degrees: float) -> float:
    """Normalize around the 0-degree forward direction, range [-180,180)."""
    if not math.isfinite(float(degrees)):
        raise ValueError('Non-finite light azimuth')
    return (float(degrees) + 180.0) % 360.0 - 180.0


def clamp_elevation(degrees: float) -> float:
    if not math.isfinite(float(degrees)):
        raise ValueError('Non-finite light elevation')
    return max(-85.0, min(85.0, float(degrees)))


def orbit_light(azimuth: float, elevation: float, delta_x: float, delta_y: float,
                degrees_per_pixel: float = 0.42) -> tuple[float, float]:
    """RMB horizontal: azimuth, RMB vertical: elevation (up raises light)."""
    if not (math.isfinite(delta_x) and math.isfinite(delta_y)
            and math.isfinite(degrees_per_pixel) and degrees_per_pixel > 0):
        raise ValueError('Invalid light-drag input')
    return (normalize_azimuth(azimuth - delta_x * degrees_per_pixel),
            clamp_elevation(elevation - delta_y * degrees_per_pixel))


@dataclass
class LightDrag:
    """Anchor-based gesture; only commits updates to light properties."""
    start_x: float
    start_y: float
    start_azimuth: float
    start_elevation: float
    sensitivity: float = .42

    def update(self, x: float, y: float) -> tuple[float, float]:
        return orbit_light(self.start_azimuth, self.start_elevation,
                           x - self.start_x, y - self.start_y, self.sensitivity)
