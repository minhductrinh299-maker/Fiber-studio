"""Cached asynchronous Render Studio shading of an unwarped map plane."""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from dataclasses import asdict
import ctypes as C
import json
import tkinter as tk
from PIL import Image
from .renderer import GPUHairRenderer,HairMaterial,orthographic
from ..cards import HairCard

_SHADE_POOL = ThreadPoolExecutor(max_workers=1,thread_name_prefix="lit-map-wgl")
_SHADE_HWND = None
_SHADE_RENDERER = None


def _get_persistent_renderer(w, h, material):
    global _SHADE_HWND, _SHADE_RENDERER
    if _SHADE_HWND is None:
        user = C.WinDLL('user32', use_last_error=True)
        user.CreateWindowExW.restype = C.c_void_p
        user.CreateWindowExW.argtypes = [
            C.c_uint32, C.c_wchar_p, C.c_wchar_p, C.c_uint32,
            C.c_int, C.c_int, C.c_int, C.c_int,
            C.c_void_p, C.c_void_p, C.c_void_p, C.c_void_p
        ]
        user.DestroyWindow.argtypes = [C.c_void_p]
        _SHADE_HWND = user.CreateWindowExW(0, 'STATIC', 'Lit Map Persistent', 0x80000000, 0, 0, 32, 32, None, None, None, None)
        if not _SHADE_HWND:
            raise RuntimeError('Cannot create offscreen WGL surface for lit map')
    if _SHADE_RENDERER is None:
        _SHADE_RENDERER = GPUHairRenderer(w, h, hwnd=_SHADE_HWND, async_sampling=False)
        _SHADE_RENDERER.set_quality('Edit',1.,'Temporal')
        _SHADE_RENDERER.show_grid = False
        _SHADE_RENDERER.show_hud = False
        _SHADE_RENDERER.show_axis_gizmo = False
        _SHADE_RENDERER.yaw = 0.
        _SHADE_RENDERER.pitch = 0.
        _SHADE_RENDERER.distance = 5.
        _SHADE_RENDERER.target[:] = [0, 0, 0]
    else:
        _SHADE_RENDERER.resize(w, h)
    _SHADE_RENDERER.material = material
    _SHADE_RENDERER.projection_matrix = lambda aspect: orthographic(-aspect, aspect, -1, 1, .1, 10)
    return _SHADE_RENDERER


class LitMap:
    def __init__(self,owner,refresh,active):
        self.owner=owner;self.refresh=refresh;self.active=active;self.pool=_SHADE_POOL
        self.future=None;self.key=None;self.cache={};self.closed=False;self.failed=None;self.job=None

    def image(self,maps,material,identity):
        key=(identity,json.dumps(asdict(material),sort_keys=True))
        if key in self.cache:return self.cache[key]
        if self.future is None and key!=self.failed:
            copied={name:image.copy() for name,image in maps.items() if name in ('color','alpha','normal','flow','roughness')}
            self.key=key
            self.future=self.pool.submit(shade,copied,deepcopy(material))
            if self.job is None and not self.closed:
                self.job=self.owner.after(50,self.poll)
        return maps['color']

    def poll(self):
        self.job=None
        if self.closed:return
        if self.future and self.future.done():
            need_refresh=False
            try:
                image=self.future.result()
                while self.cache and sum(im.width*im.height*4 for im in self.cache.values())+image.width*image.height*4>128*1024**2:self.cache.pop(next(iter(self.cache)))
                self.cache[self.key]=image
                need_refresh=True
            except Exception as error:
                self.failed=self.key
                if hasattr(self.owner,'status'):self.owner.status.set('Lit map: '+str(error))
            self.future=None
            if need_refresh and self.active():
                self.refresh()
            return
        if self.future and not self.closed:
            self.job=self.owner.after(50,self.poll)

    def close(self):
        self.closed=True
        if self.job is not None:
            try:self.owner.after_cancel(self.job)
            except tk.TclError:pass
            self.job=None
        if self.future:self.future.cancel()


def shade(maps,material):
    try:
        original=maps['color'].size
        scale=min(1.,2048/max(original))
        w=max(16,round(original[0]*scale))
        h=max(16,round(original[1]*scale))
        maps={name:image.resize((w,h),Image.Resampling.LANCZOS) for name,image in maps.items()}
        renderer=_get_persistent_renderer(w,h,material)
        padded={}
        max_dim=max(w,h)
        for name,image in maps.items():
            square=Image.new(image.mode,(max_dim,max_dim))
            square.paste(image,(0,0))
            padded[name,0]=square
        renderer.load_atlas_images(padded,max_dim)
        card=HairCard.create('map')
        card.root=[0,-1,0]
        card.width=2*w/h
        card.length=2
        card.bend=0
        card.taper=0
        renderer.load_cards([card],{'map':{'page':0,'rect_px':[0,0,w,h]}},max_dim)
        # Small map-plane preview: accumulate without changing source maps.
        renderer.info.history_limit=32;renderer.invalidate_history('lit map request')
        for _ in range(32):renderer.render()
        result=renderer.capture_transparent()
        return result.resize(original,Image.Resampling.LANCZOS) if result.size!=original else result
    except Exception:
        global _SHADE_RENDERER
        if _SHADE_RENDERER:
            try:_SHADE_RENDERER.close()
            except Exception:pass
            _SHADE_RENDERER=None
        raise


def material_for(app):
    studio=getattr(app,'render_window',None)
    from .settings import material_from_project
    material=deepcopy(studio.material) if studio and studio.winfo_exists() else material_from_project(app.project)
    if hasattr(app,'lit_angle'):material.light_azimuth=app.lit_angle.get()
    return material


def image_for(owner,app,maps,identity,refresh,active):
    service=getattr(owner,'_lit_map',None)
    if service is None or getattr(service,'closed',False):
        service=owner._lit_map=LitMap(owner,refresh,active)
    return service.image(maps,material_for(app),identity)
