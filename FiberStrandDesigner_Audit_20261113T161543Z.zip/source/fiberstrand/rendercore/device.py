"""Windows GPU discovery and honest OpenGL-context diagnostics.

Enumerating a discrete DXGI adapter does not select a WGL adapter. The startup
bootstrap requests an app-scoped high-performance policy before the render
process starts. This module independently verifies the GL renderer afterward.
"""
from __future__ import annotations
from dataclasses import dataclass
import ctypes as C
import os
import sys

@dataclass(frozen=True)
class Adapter:
    name: str
    dedicated_mb: int
    vendor_id: int
    device_id: int
    luid_high: int
    luid_low: int
    software: bool = False

    @property
    def discrete(self):
        return self.dedicated_mb >= 3072 and not self.software


class GUID(C.Structure):
    _fields_ = [('a', C.c_uint32),('b', C.c_uint16),('c', C.c_uint16),('d', C.c_ubyte*8)]

class LUID(C.Structure):
    _fields_ = [('LowPart', C.c_uint32),('HighPart', C.c_int32)]

class DXGI_ADAPTER_DESC1(C.Structure):
    _fields_ = [('Description', C.c_wchar*128), ('VendorId',C.c_uint32),
        ('DeviceId',C.c_uint32), ('SubSysId',C.c_uint32),('Revision',C.c_uint32),
        ('DedicatedVideoMemory',C.c_size_t),('DedicatedSystemMemory',C.c_size_t),
        ('SharedSystemMemory',C.c_size_t),('AdapterLuid',LUID),('Flags',C.c_uint32)]

# IID_IDXGIFactory1 = 770aae78-f26f-4dba-a829-253c83d1b387
IID_FACTORY1 = GUID(0x770aae78,0xf26f,0x4dba,(C.c_ubyte*8)(0xa8,0x29,0x25,0x3c,0x83,0xd1,0xb3,0x87))

def _com_method(obj, index, signature, *args):
    vt=C.cast(obj,C.POINTER(C.POINTER(C.c_void_p))).contents
    method=C.WINFUNCTYPE(C.c_long, C.c_void_p, *signature)(vt[index])
    return method(obj,*args)


def enumerate_dxgi_adapters() -> list[Adapter]:
    """Discover Windows adapters without installing WMI/NVML or Python packages."""
    if sys.platform != 'win32': return []
    dxgi=C.WinDLL('dxgi.dll')
    create=dxgi.CreateDXGIFactory1
    create.argtypes=[C.POINTER(GUID),C.POINTER(C.c_void_p)]
    create.restype=C.c_long
    factory=C.c_void_p()
    if create(C.byref(IID_FACTORY1),C.byref(factory))<0: return []
    adapters=[]
    try:
        for i in range(32):
            p=C.c_void_p()
            # IDXGIFactory1::EnumAdapters1 vtable index 12
            hr=_com_method(factory,12,[C.c_uint32,C.POINTER(C.c_void_p)],i,C.byref(p))
            if hr<0: break
            try:
                desc=DXGI_ADAPTER_DESC1()
                # IDXGIAdapter1::GetDesc1 vtable index 10
                hr=_com_method(p,10,[C.POINTER(DXGI_ADAPTER_DESC1)],C.byref(desc))
                if hr>=0:
                    adapters.append(Adapter(desc.Description.strip(),int(desc.DedicatedVideoMemory//(1024*1024)),
                        int(desc.VendorId),int(desc.DeviceId),int(desc.AdapterLuid.HighPart),
                        int(desc.AdapterLuid.LowPart),bool(desc.Flags & 2)))
            finally:
                _com_method(p,2,[])
    finally:
        _com_method(factory,2,[])
    return adapters


def gpu_mismatch(gl_renderer: str, adapters: list[Adapter]) -> Adapter | None:
    """Best candidate for warning, not a claim of GPU switching."""
    best=max((x for x in adapters if x.discrete),key=lambda x:x.dedicated_mb,default=None)
    if not best:return None
    displayed=(gl_renderer or '').lower()
    for adapter in adapters:
        if not adapter.discrete:continue
        gpu_name=adapter.name.lower()
        # Any real discrete renderer satisfies the request; a second discrete
        # card with less VRAM is not the CPU's integrated GPU.
        model_tokens=[x for x in gpu_name.replace('laptop gpu','').split()
                      if x.startswith(('rtx','gtx','rx','arc')) or any(ch.isdigit() for ch in x)]
        model_matches=bool(model_tokens) and all(t in displayed for t in model_tokens[:2])
        if model_matches or gpu_name in displayed:return None
    return best


def open_windows_graphics_settings():
    if sys.platform!='win32':return False
    os.startfile('ms-settings:display-advancedgraphics')
    return True


def query_video_memory(gl_renderer):
    """WDDM local process budget for an unambiguously matched WGL adapter.

    ABI follows Windows SDK dxgi1_4.h IDXGIAdapter3 (QueryVideoMemoryInfo slot14).
    A vendor match alone is insufficient on multi-GPU systems. Return None if
    WGL renderer naming cannot identify exactly one DXGI model.
    """
    if sys.platform!='win32':return None
    import re
    renderer=re.sub(r'[^a-z0-9]+',' ',gl_renderer.lower())
    candidates=[]
    for adapter in enumerate_dxgi_adapters():
        if adapter.software:continue
        tokens=[t for t in re.sub(r'[^a-z0-9]+',' ',adapter.name.lower()).split()
                if any(c.isdigit() for c in t) or t in ('rtx','gtx','rx','arc')]
        if tokens and all(t in renderer.split() for t in tokens):candidates.append(adapter)
    if len(candidates)!=1:return None
    selected=candidates[0]
    iid=GUID(0x645967A4,0x1392,0x4310,(C.c_ubyte*8)(0xA7,0x98,0x80,0x53,0xCE,0x3E,0x93,0xFD))
    class Info(C.Structure):
        _fields_=[(name,C.c_uint64) for name in ('Budget','CurrentUsage','AvailableForReservation','CurrentReservation')]
    dxgi=C.WinDLL('dxgi.dll');create=dxgi.CreateDXGIFactory1
    create.argtypes=[C.POINTER(GUID),C.POINTER(C.c_void_p)];create.restype=C.c_long
    factory=C.c_void_p()
    if create(C.byref(IID_FACTORY1),C.byref(factory))<0:return None
    try:
        for i in range(32):
            adapter=C.c_void_p()
            if _com_method(factory,12,[C.c_uint32,C.POINTER(C.c_void_p)],i,C.byref(adapter))<0:break
            try:
                desc=DXGI_ADAPTER_DESC1()
                if _com_method(adapter,10,[C.POINTER(DXGI_ADAPTER_DESC1)],C.byref(desc))<0:continue
                if (desc.AdapterLuid.HighPart,desc.AdapterLuid.LowPart)!=(selected.luid_high,selected.luid_low):continue
                newer=C.c_void_p()
                if _com_method(adapter,0,[C.POINTER(GUID),C.POINTER(C.c_void_p)],C.byref(iid),C.byref(newer))<0:return None
                try:
                    info=Info()
                    if _com_method(newer,14,[C.c_uint32,C.c_uint32,C.POINTER(Info)],0,0,C.byref(info))<0:return None
                    return {'adapter':selected.name,'budget_mib':info.Budget/1024**2,'usage_mib':info.CurrentUsage/1024**2,'source':'DXGI local process budget'}
                finally:_com_method(newer,2,[])
            finally:_com_method(adapter,2,[])
    finally:_com_method(factory,2,[])
    return None
