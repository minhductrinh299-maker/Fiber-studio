"""Legacy card drag operators shared with the Qt input adapter.
Extracted from CardEditor._apply_drag; no Tk widgets or GL ownership here.
"""
import numpy as np

def pixels(context,value):return float(value)*context.dpi_factor

def apply_card_drag(self,drag,dx,dy,x,y,targets=None):
    tool=drag['tool']
    origins=drag['orig']
    # Geometry stays in scene units (approx. 180-240 px / world unit at default zoom).
    unit=.004*self.distance/4.8
    if targets is None:targets=self._selection()
    basis=self.view.world_delta_basis() if (self.view and tool in ('Move','Root','Vertex')) else None
    use_brush=bool(self.brush.get() and self.view)
    brush_r2=max(1.0,pixels(self,self.radius))**2 if use_brush else 1.0
    centroid_x=sum(origins[c.id].root[0] for c in targets)/max(1,len(targets)) if tool=='Spread' else 0.0
    for card in targets:
        source=origins[card.id]
        falloff=1.
        if use_brush:
            p=self.view.screen_center(card.id)
            if p is not None:
                r2=(x-p[0])**2+(y-p[1])**2
                falloff=max(0.,1.-r2/brush_r2)**2
        if falloff<=0:continue
        ddx=dx*falloff;ddy=dy*falloff
        component_mode=self.selection_mode.get()
        if tool=='Vertex' or (self.mode.get()=='Mesh' and component_mode!='Card' and tool=='Move'):
            parts=drag.get('components',{}).get(card.id,set())
            if card.id not in drag.get('components',{}) and card.id==drag.get('card_id') and drag.get('part') is not None:
                parts={(component_mode,drag['part'])}
            indices=set()
            for kind,part in parts:
                if isinstance(part,tuple):indices.update(part)
                elif kind=='Vertex':indices.add(int(part))
                elif kind=='Root':indices.update(range(card.width_segments+1))
                elif kind=='Row':indices.update(range(int(part)*(card.width_segments+1),(int(part)+1)*(card.width_segments+1)))
            if basis is not None:
                eye,forward,right,up,k_scale=basis
                depth=max(.01,float(np.dot(np.asarray(source.root)-eye,forward)))
                delta=(right*ddx-up*ddy)*(depth*k_scale)
            else:
                delta=np.array([ddx*unit,-ddy*unit,0])
            for index in indices:
                if not 0<=index<(card.width_segments+1)*(card.segments+1):continue
                row,side=divmod(index,card.width_segments+1)
                if row==0 and card.locked_root and component_mode!='Root':continue
                key=f'{row}:{side}';base=source.vertex_offsets.get(key,[0.,0.,0.])
                card.vertex_offsets[key]=[base[0]+float(delta[0]),base[1]+float(delta[1]),base[2]+float(delta[2])]
        elif tool in ('Move','Root'):
            if basis is not None:
                eye,forward,right,up,k_scale=basis
                depth=max(.01,float(np.dot(np.asarray(source.root)-eye,forward)))
                delta=(right*ddx-up*ddy)*(depth*k_scale)
                card.root=[source.root[0]+float(delta[0]),source.root[1]+float(delta[1]),source.root[2]+float(delta[2])]
            else:
                card.root=[source.root[0]+ddx*unit,source.root[1]-ddy*unit,source.root[2]]
        elif tool=='Rotate':card.yaw=source.yaw+ddx*.012
        elif tool=='Scale':
            s=max(.05,1+(ddx-ddy)*.005)
            card.length=source.length*s;card.width=source.width*s
        elif tool=='Length':card.length=max(.015,source.length-ddy*unit)
        elif tool=='Width':card.width=max(.002,source.width+ddx*unit)
        elif tool=='Taper':card.taper=source.taper+ddx*.005
        elif tool=='Bend':card.bend=source.bend+ddx*.004
        elif tool=='Twist':card.twist=source.twist+ddx*.012
        elif tool=='Lift':card.lift=source.lift-ddy*.006
        elif tool=='Comb':card.tilt=source.tilt+ddx*.008
        elif tool in ('Relax','Smooth'):
            amount=min(.99,(abs(dx)+abs(dy))*.004)
            card.bend=source.bend*(1-amount)
            card.twist=source.twist*(1-amount)
            card.lift=source.lift*(1-.5*amount)
        elif tool=='Spread':
            card.root[0]=source.root[0]+(source.root[0]-centroid_x)*ddx*.008
        elif tool=='Noise':
            from .model import stable_int
            try:noise_seed=int(card.id[:4],16)
            except ValueError:noise_seed=stable_int(card.id)
            sign=1 if noise_seed%2 else -1
            card.bend=source.bend+sign*ddx*.0025
        card.sanitize()

        if getattr(self,'snap_mesh_id',None) and (tool=='Root' or
            (tool=='Move' and not (self.mode.get()=='Mesh' and component_mode!='Card'))):
            self.app.object_workspace.live_snap(self,card)
