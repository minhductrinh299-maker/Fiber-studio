"""App-scoped Windows high-performance GPU startup, before any Tk/WGL HWND.

Use a private copy of the actual CPython host, not a renamed venv redirector
(which would execute the shared system python.exe). Only that private host's
HKCU graphics preference is changed. No admin rights/global GPU policy changes.
Windows/driver selection is a request; GL_RENDERER remains the actual evidence.
"""
from pathlib import Path
import ctypes as C
import json
import os
import shutil
import subprocess
import sys
import sysconfig
import uuid

REGISTRY_PATH=r'Software\Microsoft\DirectX\UserGpuPreferences'
_status={}


def high_performance_value(existing=''):
    """Preserve unrelated app options (Auto HDR, presentation flags, etc.)."""
    tokens=[s.strip() for s in str(existing).split(';') if s.strip()]
    tokens=[s for s in tokens if s.partition('=')[0].strip().lower()!='gpupreference']
    return ';'.join([*tokens,'GpuPreference=2'])+';'


def launch_status():
    return dict(_status)


def _module_path(handle=None):
    kernel=C.WinDLL('kernel32',use_last_error=True)
    f=kernel.GetModuleFileNameW;f.argtypes=[C.c_void_p,C.c_wchar_p,C.c_uint];f.restype=C.c_uint
    buf=C.create_unicode_buffer(32768)
    n=f(C.c_void_p(handle) if handle else None,buf,len(buf))
    if not n or n>=len(buf):raise OSError('Cannot resolve the running Python image')
    return Path(buf.value).resolve()


def _copy_runtime_file(source,target):
    if source.resolve()==target.resolve():return
    source_stat=source.stat()
    if target.exists():
        target_stat=target.stat()
        if target_stat.st_size==source_stat.st_size and target_stat.st_mtime_ns==source_stat.st_mtime_ns:return
    temp=target.with_name(target.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        shutil.copy2(source,temp);os.replace(temp,target)
    finally:
        temp.unlink(missing_ok=True)


def _prepare_host(root):
    runtime=root/'.gpu_runtime';runtime.mkdir(parents=True,exist_ok=True)
    host=runtime/'fsd_python.exe'
    # With a Windows venv redirector the current process is already the base
    # interpreter; GetModuleFileName reports that actual executable image.
    source=_module_path()
    dll=_module_path(sys.dllhandle)
    if source.suffix.lower()!='.exe' or dll.suffix.lower()!='.dll':
        raise RuntimeError('This Python distribution cannot be copied as a private GPU host')
    files=[source,dll,*dll.parent.glob('vcruntime140*.dll')]
    stable=dll.parent/'python3.dll'
    if stable.is_file() and stable!=dll:files.append(stable)
    for file in files:
        _copy_runtime_file(file,host if file==source else runtime/file.name)
    config=(f'home = {sys.base_prefix}\ninclude-system-site-packages = false\n'
            f'version = {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}\n'
            f'executable = {source}\n')
    (runtime/'pyvenv.cfg').write_text(config,encoding='utf-8')
    site=runtime/'Lib'/'site-packages';site.mkdir(parents=True,exist_ok=True)
    paths=sorted({sysconfig.get_path(k) for k in ('purelib','platlib') if sysconfig.get_path(k)})
    # Reuse the launching environment's installed NumPy/Pillow, not global pip.
    (site/'fsd_environment.pth').write_text('\n'.join(paths)+'\n',encoding='utf-8')
    return host


def _set_private_preference(host):
    import winreg
    backup=host.parent/'gpu_preference_backup.json'
    with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER,REGISTRY_PATH,0,
                            winreg.KEY_QUERY_VALUE|winreg.KEY_SET_VALUE) as key:
        existed=True;kind=winreg.REG_SZ
        try:original,kind=winreg.QueryValueEx(key,str(host))
        except FileNotFoundError:existed=False;original=''
        if existed and kind!=winreg.REG_SZ:
            raise RuntimeError('Unexpected registry value type for the private app host')
        desired=high_performance_value(original)
        if not backup.exists():
            backup.write_text(json.dumps({'host':str(host),'existed':existed,'kind':kind,
                'original':original,'written':desired},ensure_ascii=False,indent=2),encoding='utf-8')
        if original!=desired:winreg.SetValueEx(key,str(host),0,winreg.REG_SZ,desired)
    return desired


def restore_private_preference(root):
    """Optional rollback; never overwrite a later, unrelated user preference."""
    if sys.platform!='win32':return False
    import winreg
    host=Path(root).resolve()/'.gpu_runtime'/'fsd_python.exe'
    backup=host.parent/'gpu_preference_backup.json'
    if not backup.exists():return False
    state=json.loads(backup.read_text(encoding='utf-8'))
    if os.path.normcase(state['host'])!=os.path.normcase(str(host)):return False
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER,REGISTRY_PATH,0,
                        winreg.KEY_QUERY_VALUE|winreg.KEY_SET_VALUE) as key:
        try:current,_=winreg.QueryValueEx(key,str(host))
        except FileNotFoundError:return False
        if current!=state['written']:return False
        if state['existed']:winreg.SetValueEx(key,str(host),0,state['kind'],state['original'])
        else:winreg.DeleteValue(key,str(host))
    return True


def maybe_launch_private_host(root,entrypoint=None):
    """Return a child exit code, or None to continue this process as the app.

    No Tk, WGL, GPU benchmarks or renderer validation are performed here.
    A one-launch marker prevents relaunch loops and supports startup fallback.
    """
    global _status
    root=Path(root).resolve()
    entrypoint=Path(entrypoint).resolve() if entrypoint is not None else root/'main.py'
    if sys.platform!='win32':
        _status={'mode':'platform native','requested':False};return None
    host=root/'.gpu_runtime'/'fsd_python.exe'
    actual=_module_path()
    if os.path.normcase(str(actual))==os.path.normcase(str(host)):
        try:_status=json.loads(os.environ.get('FSD_GPU_LAUNCH_STATUS','{}'))
        except ValueError:_status={}
        _status.update({'mode':'private high-performance host','host':str(actual)})
        ready=os.environ.get('FSD_GPU_READY_FILE','')
        if ready:
            p=Path(ready)
            if p.parent.resolve()==host.parent.resolve() and p.name.startswith('ready-'):
                p.write_text(str(os.getpid()),encoding='ascii')
        return None
    if os.environ.get('FSD_GPU_HOST_ATTEMPT'):
        _status={'mode':'fallback','requested':False,'reason':'Private host redirected to a different Python image'}
        return None
    ready=None
    try:
        # Detection is in this bootstrap process. The render context will be
        # created only in the fresh private-host process after policy is set.
        from .rendercore.device import enumerate_dxgi_adapters
        adapters=enumerate_dxgi_adapters()
        candidate=max((a for a in adapters if a.discrete),key=lambda a:a.dedicated_mb,default=None)
        host=_prepare_host(root)
        _set_private_preference(host)
        _status={'mode':'automatic high-performance request','requested':True,'host':str(host),
                 'candidate':candidate.name if candidate else None,
                 'candidate_vram_mb':candidate.dedicated_mb if candidate else None}
        ready=host.parent/('ready-'+uuid.uuid4().hex+'.txt')
        env=os.environ.copy()
        for name in ('__PYVENV_LAUNCHER__','PYTHONEXECUTABLE','PYTHONHOME'):env.pop(name,None)
        env['FSD_GPU_HOST_ATTEMPT']='1';env['FSD_GPU_READY_FILE']=str(ready)
        env['FSD_GPU_LAUNCH_STATUS']=json.dumps(_status,ensure_ascii=False)
        # Keep arguments/working directory; no shell quoting or another console.
        result=subprocess.run([str(host),str(entrypoint),*sys.argv[1:]],env=env,check=False)
        if ready.exists():return result.returncode
        _status={'mode':'fallback','requested':True,'reason':f'Private Python host could not start (exit {result.returncode})'}
    except Exception as exc:
        _status={'mode':'fallback','requested':False,'reason':str(exc)}
    finally:
        if ready is not None:
            try:ready.unlink(missing_ok=True)
            except OSError:pass
    print('FSD automatic GPU startup:',_status,file=sys.stderr)
    return None


if __name__=='__main__':
    if sys.argv[1:]==['--restore']:
        print('GPU preference restored:',restore_private_preference(Path(__file__).resolve().parents[1]))
    else:
        raise SystemExit('Use main.py / run_windows.bat; --restore rolls back only this app host preference.')
