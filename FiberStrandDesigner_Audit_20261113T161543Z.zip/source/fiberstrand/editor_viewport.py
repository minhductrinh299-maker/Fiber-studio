"""Persistent GPU Card Editor viewport. GL ownership: UI/context thread only.

No CardPreview, Pillow perspective warp, framebuffer readback presentation or
per-frame CPU vertex projection. CPU projections are limited to on-demand
component picking on one card and center/bounds queries for brush/box selection.
"""
import ctypes as C
from dataclasses import asdict,dataclass
import csv
import json
import math
from pathlib import Path
import threading
import sys
import time
import numpy as np
from .dpi import viewport_metrics,window_dpi
from .editor_scene import EditorScene
from .editor_buffers import GeometryCache,SubmissionFences,RootTransforms
from .rendercore.renderer import GPUHairRenderer,CHANNELS,SHADERS,look_at,perspective
from .rendercore.coverage import TileRect
from .rendercore.sampling import mip_bytes
from .rendercore.device import enumerate_dxgi_adapters,gpu_mismatch
from .rendercore.glapi import *


@dataclass
class EditorStats:
    gpu:str=''
    gpu_warning:str=''
    total_cards:int=0
    visible_cards:int=0
    vertices:int=0
    quads:int=0
    triangles:int=0
    draw_calls:int=0
    subdraws:int=0
    geometry_upload_bytes:int=0
    transform_upload_bytes:int=0
    overlay_upload_bytes:int=0
    atlas_upload_bytes:int=0
    gpu_buffer_reserved_mib:float=0.
    tile_payload_mib:float=0.
    cpu_ms:float=0.
    gpu_ms:float=-1.
    cpu_p95_ms:float=0.
    cpu_p99_ms:float=0.
    gpu_p95_ms:float=-1.
    gpu_p99_ms:float=-1.
    input_to_present_return_ms:float=-1.
    input_pending:bool=False
    active_fps:float=0.
    physical_width:int=0
    physical_height:int=0
    pending_geometry:bool=False
    pending_textures:bool=False
    vram_dedicated_mib:float=-1.
    vram_available_mib:float=-1.
    vram_global_used_mib:float=-1.


class EditorRenderer(GPUHairRenderer):
    def __init__(self,widget,scene):
        if sys.platform!='win32':raise RuntimeError('Direct GPU Card Editor currently requires Windows/WGL')
        self.widget=widget;self.scene=scene;self.owner=threading.get_ident()
        self.editor_stats=EditorStats();self._serial=0;self._visible=[];self._groups={}
        self._source_revision_seen=-1;self._tile_staging={};self.editing=False
        self._diagnostic_frame=0
        self._geometry_input=None
        self._atlas_cache=None;self._atlas_cursor=0;self._bindings_signature=None
        self._id_fbo=0;self._id_textures=[];self._id_size=(0,0);self._id_key=None
        self._hover_request=None;self._hover_slots=[];self._hover_result=None;self._last_hover_issue=0.
        self._hover_dirty=False
        self._latest_pointer=None
        self._points_key=None;self._points_count=0;self._point_capacity=0
        self._submitted_times=[];self._cpu_times=[];self.show_wire=False;self.selection_mode='Card'
        metrics=viewport_metrics(widget)
        super().__init__(max(32,metrics.physical_width),max(32,metrics.physical_height),
                         hwnd=widget.winfo_id(),async_sampling=True,native_owner=getattr(widget,"native_owner","tk"))
        self.set_quality('Interactive',1.,'Spatial');self.set_transparency('weighted')
        self.material.shadow_strength=0.;self.material.scatter_strength=0.
        self.show_grid=True;self.show_hud=True;self.show_axis_gizmo=True;self.fences=SubmissionFences(self.gl);self.geometry=GeometryCache(self.gl,self.fences)
        self.roots=RootTransforms(self.gl,self.fences)
        g=self.gl
        g.track_draws=True
        self.id_program=g.program((SHADERS/'hair.vert').read_text(),(SHADERS/'editor_id.frag').read_text())
        self.overlay_program=g.program((SHADERS/'editor_overlay.vert').read_text(),(SHADERS/'editor_overlay.frag').read_text())
        self._programs.extend([self.id_program,self.overlay_program])
        self.point_vao=g.name('VertexArrays');self.point_vbo=g.name('Buffers')
        g.glBindVertexArray(self.point_vao);g.glBindBuffer(GL_ARRAY_BUFFER,self.point_vbo)
        g.glEnableVertexAttribArray(0);g.glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,12,None)
        self.box_vao=g.name('VertexArrays');self.box_vbo=g.name('Buffers')
        g.glBindVertexArray(self.box_vao);g.glBindBuffer(GL_ARRAY_BUFFER,self.box_vbo)
        g.glBufferData(GL_ARRAY_BUFFER,48,None,GL_DYNAMIC_DRAW)
        g.glEnableVertexAttribArray(0);g.glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,12,None)
        line_range=(F*2)();g.glGetFloatv(GL_ALIASED_LINE_WIDTH_RANGE,line_range)
        self._line_width_max=max(1.,line_range[1])
        for _ in range(2):
            pbo=g.name('Buffers');g.glBindBuffer(GL_PIXEL_PACK_BUFFER,pbo)
            g.glBufferData(GL_PIXEL_PACK_BUFFER,4,None,GL_STREAM_READ)
            self._hover_slots.append({'pbo':pbo,'fence':None})
        g.glBindBuffer(GL_PIXEL_PACK_BUFFER,0)
        self.editor_stats.gpu=g.renderer
        try:
            mismatch=gpu_mismatch(g.renderer,enumerate_dxgi_adapters())
            if mismatch:self.editor_stats.gpu_warning='Card rời có sẵn nhưng viewport đang dùng: '+g.renderer
        except Exception:pass

    def _check_owner(self):
        if threading.get_ident()!=self.owner:raise RuntimeError('Editor GL called outside its context-owning thread')

    def projection_matrix(self,aspect):
        h=self.display_height;w=self.display_width
        fov=2*math.atan(h/(2*max(100,min(w,h)*1.45)))
        return perspective(fov,aspect,max(1e-7,self.distance*.001),max(300.,self.distance*10))

    def matrices(self):
        eye=np.asarray(self.target)+self.distance*np.array([math.sin(self.yaw)*math.cos(self.pitch),
            math.sin(self.pitch),math.cos(self.yaw)*math.cos(self.pitch)])
        return self.projection_matrix(self.width/max(1,self.height))@look_at(eye,self.target),eye

    def bind_atlas(self,cache):
        self._check_owner();self.context.activate()
        previous=self._atlas_cache
        layout_changed=previous is None or previous.layout is not cache.layout
        old_versions=getattr(self,'_tile_versions_seen',{})
        bindings={}
        for record in self.scene.records.values():
            p=cache.layout.placements.get(record.card.tile_id)
            if p:bindings[(p.page,record.card.tile_id)]=TileRect(p.page,p.x,p.y,p.width,p.height,0)
        if not layout_changed and bindings == self._tile_regions:
            all_match = True
            for key in bindings:
                tid = key[1]
                if tid in cache._tile_version:
                    version = tuple(cache._channel_versions.get((tid, ch), cache._tile_version.get(tid)) for ch in CHANNELS)
                    if old_versions.get(key) != version:
                        all_match = False
                        break
            if all_match:
                return
        if layout_changed:
            for stage in self._tile_staging.values():self._discard_stage(stage)
            self._tile_staging={}
            for future in self._sampling_jobs.values():future.cancel()
            self._sampling_jobs={};self._release_tile_textures()
            self._dirty_tiles.clear();old_versions={}
        touched=False;versions={}
        for key,rect in bindings.items():
            tid=key[1]
            # Do not turn not-yet-baked blank atlas pages into resident textures.
            ready=tid in cache._tile_version
            version=tuple(cache._channel_versions.get((tid,ch),cache._tile_version.get(tid)) for ch in CHANNELS)
            versions[key]=version
            if ready and (old_versions.get(key)!=version or self._tile_regions.get(key)!=rect or
                          not all((ch,key) in self._tile_textures for ch in CHANNELS) and
                          key not in self._sampling_jobs and key not in self._tile_staging):
                self._dirty_tiles.add(key);touched=True
                stage=self._tile_staging.pop(key,None)
                if stage:self._discard_stage(stage)
        for key in set(self._tile_regions)-set(bindings):
            stage=self._tile_staging.pop(key,None)
            if stage:self._discard_stage(stage)
            future=self._sampling_jobs.pop(key,None)
            if future:future.cancel()
            for ch in CHANNELS:
                name=self._tile_textures.pop((ch,key),0)
                if name:obj=U(name);self.gl.glDeleteTextures(1,C.byref(obj))
            self._tile_memory.pop(key,None);self._dirty_tiles.discard(key)
        self._tile_regions=bindings;self._tile_versions_seen=versions
        self._atlas_cache=cache;self._atlas_size=cache.layout.size
        pages={p for p,_ in bindings}
        self._atlas_sources={(ch,page):image for (ch,page),image in cache._pages.items() if page in pages and ch in CHANNELS}
        if layout_changed or touched:
            self._atlas_revision+=1;self.invalidate_history('editor tile sources changed');self._id_key=None

    def _upload_tile(self,key,prepared=None):
        from .fiberbake_x.sampling import SamplingPacket
        if isinstance(prepared,SamplingPacket):return self._upload_tile_gpu(key,prepared)
        if prepared is None:
            self._gpu_sampling_miss.add(key);self._dirty_tiles.add(key);return
        r=self._tile_regions[key];cost=mip_bytes(r.width,r.height)
        if sum(self._tile_memory.values())-self._tile_memory.get(key,0)+cost>768*1024**2:
            raise MemoryError('Editor tile residency exceeds 768 MiB')
        previous=self._tile_staging.pop(key,None)
        if previous:self._discard_stage(previous)
        self._tile_staging[key]={'maps':prepared,'textures':{},'channel':0,'level':0,'row':0,'cost':cost}

    def _discard_stage(self,stage):
        for name in stage['textures'].values():
            value=U(name);self.gl.glDeleteTextures(1,C.byref(value))

    def _drain_texture_uploads(self):
        # Texture work is lower priority than current geometry. Stage snapshots
        # in small row uploads and publish all five channels together.
        g=self.gl;budget=(4 if self.editing else 12)*1024**2;deadline=time.perf_counter()+.002
        for key,stage in list(self._tile_staging.items()):
            if key not in self._tile_regions:
                self._discard_stage(stage);self._tile_staging.pop(key,None);continue
            if key in self._dirty_tiles or key in self._sampling_jobs:continue
            while stage['channel']<len(CHANNELS) and budget>0 and time.perf_counter()<deadline:
                ch=CHANNELS[stage['channel']];levels=stage['maps'][ch]
                fmt=GL_RGBA if ch=='color' else GL_RGB if ch in ('normal','flow') else GL_RED
                internal=GL_RGBA16F if ch=='color' else GL_RGB16F if fmt==GL_RGB else GL_R16F
                if ch not in stage['textures']:
                    name=g.name('Textures');stage['textures'][ch]=name;g.glBindTexture(GL_TEXTURE_2D,name)
                    for p,v in ((GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR),(GL_TEXTURE_MAG_FILTER,GL_LINEAR),
                                (GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE),(GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE),
                                (GL_TEXTURE_MAX_LEVEL,len(levels)-1)):
                        g.glTexParameteri(GL_TEXTURE_2D,p,v)
                    if self._anisotropy>1:g.glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAX_ANISOTROPY_EXT,self._anisotropy)
                g.glBindTexture(GL_TEXTURE_2D,stage['textures'][ch]);array=levels[stage['level']]
                height,width=array.shape[:2]
                if stage['row']==0:
                    g.glTexImage2D(GL_TEXTURE_2D,stage['level'],internal,width,height,0,fmt,GL_FLOAT,None)
                row_bytes=width*(array.shape[2] if array.ndim==3 else 1)*4
                rows=min(height-stage['row'],max(1,budget//row_bytes))
                y=stage['row'];payload=np.ascontiguousarray(array[y:y+rows][::-1])
                g.glTexSubImage2D(GL_TEXTURE_2D,stage['level'],0,height-y-rows,width,rows,fmt,GL_FLOAT,V(payload.ctypes.data))
                budget-=payload.nbytes;self.editor_stats.atlas_upload_bytes+=payload.nbytes
                stage['row']+=rows
                if stage['row']==height:
                    stage['row']=0;stage['level']+=1
                    if stage['level']==len(levels):stage['level']=0;stage['channel']+=1
            if stage['channel']==len(CHANNELS):
                for ch,name in stage['textures'].items():
                    previous=self._tile_textures.get((ch,key))
                    self._tile_textures[ch,key]=name
                    if previous:value=U(previous);g.glDeleteTextures(1,C.byref(value))
                self._tile_memory[key]=stage['cost'];self._tile_staging.pop(key,None)
                self.info.tile_memory_mib=sum(self._tile_memory.values())/1024**2
                self._atlas_revision+=1;self._id_key=None;self.invalidate_history('editor tile snapshot published')
            if budget<=0 or time.perf_counter()>=deadline:break

    @property
    def sampling_pending(self):return super().sampling_pending or bool(self._tile_staging)

    def _sync_geometry(self):
        self.fences.poll();self.scene.pump(sync_selected=True)
        root_dirty=bool(self.scene.root_dirty)
        synced=self.roots.sync(self.scene)
        if not synced and root_dirty:
            if self.fences.wait_oldest():
                synced=self.roots.sync(self.scene)
        if synced and root_dirty:
            self._geometry_revision+=1;self._id_key=None;self.invalidate_history('editor transforms uploaded')
        if self._source_revision_seen!=self.scene.revision:
            self._source_revision_seen=self.scene.revision;self._geometry_revision+=1;self._id_key=None
            self.invalidate_history('editor model changed')
        for cid in self.scene.removed:self.geometry.remove(cid)
        self.scene.removed.clear()
        uploaded=False;budget=4*1024*1024
        records=sorted((r for r in self.scene.records.values() if r.pending_mesh is not None),
                       key=lambda r:r.card.id not in self.scene.selected)
        for record in records:
            mesh=record.pending_mesh
            size=mesh.vertices.nbytes+mesh.indices.nbytes
            if size>budget:break
            slot=self.geometry.publish(record.card.id,mesh)
            if slot is None:
                if self.fences.wait_oldest():
                    slot=self.geometry.publish(record.card.id,mesh)
                if slot is None:continue
            record.mesh=mesh;record.slot=slot;record.gpu_version=record.version
            record.gpu_signature=record.signature;record.pending_mesh=None
            budget-=size;uploaded=True
        if uploaded:
            self._geometry_revision+=1;self._id_key=None
            self.invalidate_history('editor geometry uploaded')

    def _cull(self,mvp):
        records=[r for r in self.scene.records.values() if r.mesh is not None and r.card.visible]
        if not records:self._visible=[];self._groups={};return
        planes=np.array([mvp[3]+mvp[0],mvp[3]-mvp[0],mvp[3]+mvp[1],mvp[3]-mvp[1],mvp[3]+mvp[2],mvp[3]-mvp[2]])
        planes/=np.maximum(np.linalg.norm(planes[:,:3],axis=1,keepdims=True),1e-8)
        centers=np.array([r.mesh.center+self.world_offset(r) for r in records]);radii=np.array([r.mesh.radius for r in records])
        visible=np.all(centers@planes[:,:3].T+planes[:,3]>=-radii[:,None],axis=1)
        self._visible=[r for r,yes in zip(records,visible) if yes];self._groups={}
        for record in self._visible:
            p=self._atlas_cache.layout.placements.get(record.card.tile_id) if self._atlas_cache else None
            if p:self._groups.setdefault((p.page,record.card.tile_id),[]).append(record)

    def _render_shadow(self,light_mvp):
        return super()._render_shadow(light_mvp)

    def _shadow_points(self):
        return [self.world_positions(r) for r in self.scene.records.values() if r.mesh is not None and r.card.visible]

    def _draw_shadow_geometry(self):
        g=self.gl;self.roots.bind(self.shadow_program,self._serial)
        groups={}
        for record in self.scene.records.values():
            if record.mesh is None or not record.card.visible:continue
            p=self._atlas_cache.layout.placements.get(record.card.tile_id) if self._atlas_cache else None
            if p:groups.setdefault((p.page,record.card.tile_id),[]).append(record)
        for key,records in groups.items():
            if not all((ch,key) in self._tile_textures for ch in ('color','alpha')):continue
            for unit,ch in enumerate(('color','alpha')):
                g.glActiveTexture(GL_TEXTURE0+unit);g.glBindTexture(GL_TEXTURE_2D,self._tile_textures[ch,key])
            self.geometry.draw(records,self._serial)

    @staticmethod
    def world_offset(record):return np.asarray(record.gpu_root)-record.mesh.origin

    def world_positions(self,record):return record.mesh.positions+self.world_offset(record)
    def world_rows(self,record):return record.mesh.rows+self.world_offset(record)

    def _bind_hair_uniforms(self,*args,**kwargs):
        program=super()._bind_hair_uniforms(*args,**kwargs)
        self.roots.bind(program,self._serial);return program

    def _draw_hair(self,mvp,eye,program=None,previous_depth=None,light_mvp=None,shadow_enabled=False):
        g=self.gl;p=self._bind_hair_uniforms(mvp,eye,program,previous_depth,light_mvp,shadow_enabled)
        for key,records in self._groups.items():
            if not all((ch,key) in self._tile_textures for ch in CHANNELS):continue
            rect=self._tile_regions[key]
            g.uniform(p,'uMaxMip',float(math.floor(math.log2(max(rect.width,rect.height)))))
            for unit,ch in enumerate(CHANNELS):
                g.glActiveTexture(GL_TEXTURE0+unit);g.glBindTexture(GL_TEXTURE_2D,self._tile_textures[ch,key])
            self.geometry.draw(records,self._serial)

    def _overlay_uniforms(self,mvp,color,points=False,screen=False,size=8.):
        g=self.gl;p=self.overlay_program;g.glUseProgram(p)
        matrix=np.ascontiguousarray(mvp,dtype=np.float32)
        g.glUniformMatrix4fv(g.glGetUniformLocation(p,b'uMVP'),1,GL_TRUE,matrix.ctypes.data_as(C.POINTER(F)))
        g.uniform(p,'uColor',color);g.uniform(p,'uPoints',int(points));g.uniform(p,'uScreen',int(screen))
        g.uniform(p,'uCenterPairs',0)
        g.uniform(p,'uSize',(self.display_width,self.display_height));g.uniform(p,'uPointSize',float(size))
        self.roots.bind(p,self._serial)

    def before_present(self):
        g=self.gl;mvp,_=self.matrices();ratio=window_dpi(self.widget)/96.
        g.glDisable(GL_DEPTH_TEST);g.glEnable(GL_BLEND);g.glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA)
        g.glLineWidth(min(self._line_width_max,max(1.,ratio)))
        if self.show_wire:
            self._overlay_uniforms(mvp,(.32,.38,.45));g.glPolygonMode(GL_FRONT_AND_BACK,GL_LINE)
            self.geometry.draw(self._visible,self._serial)
        selected=[r for r in self._visible if r.card.id in self.scene.selected]
        if selected:
            self._overlay_uniforms(mvp,(1.,.7,.27));g.glPolygonMode(GL_FRONT_AND_BACK,GL_LINE)
            self.geometry.draw(selected,self._serial)
        hovered=self.scene.records.get(self.scene.hover)
        if hovered and any(r is hovered for r in self._visible) and hovered.card.id not in self.scene.selected:
            self._overlay_uniforms(mvp,(.25,.85,1.));g.glPolygonMode(GL_FRONT_AND_BACK,GL_LINE)
            self.geometry.draw([hovered],self._serial)
        g.glPolygonMode(GL_FRONT_AND_BACK,GL_FILL)
        direct_points=self.selection_mode in ('Vertex','Root','Row')
        if direct_points and selected:
            self._overlay_uniforms(mvp,(1.,.8,.4),True,size=8*ratio)
            g.uniform(self.overlay_program,'uCenterPairs',int(self.selection_mode!='Vertex'))
            g.glEnable(GL_PROGRAM_POINT_SIZE)
            self.geometry.draw_points(selected,self._serial,self.selection_mode)
        key=(tuple((r.card.id,r.gpu_version,r.gpu_root) for r in selected),self.selection_mode,self.scene.selection_revision,self.scene.hover_component)
        if key!=self._points_key:
            points=[]
            for r in selected:
                positions=self.world_positions(r);rows=self.world_rows(r)
                if not direct_points:points.extend(rows[[0,len(rows)//2,-1]])
                for kind,part in self.scene.components.get(r.card.id,set()):
                    if isinstance(part,tuple):indices=part
                    elif kind=='Vertex':indices=(int(part),)
                    elif kind=='Row':indices=tuple(range(int(part)*r.mesh.columns,(int(part)+1)*r.mesh.columns))
                    else:indices=tuple(range(r.mesh.columns))
                    points.extend(positions[[i for i in indices if 0<=i<len(positions)]])
            if self.scene.hover_component:
                cid,kind,part=self.scene.hover_component;r=self.scene.records.get(cid)
                if r and r.mesh is not None:
                    if isinstance(part,tuple):points.extend(self.world_positions(r)[list(part)])
                    elif kind=='Vertex':points.append(self.world_positions(r)[int(part)])
                    else:points.append(self.world_rows(r)[int(part)])
            data=np.ascontiguousarray(points,dtype=np.float32).reshape(-1,3)
            g.glBindVertexArray(self.point_vao);g.glBindBuffer(GL_ARRAY_BUFFER,self.point_vbo)
            if data.nbytes>self._point_capacity:
                self._point_capacity=max(4096,data.nbytes*2);g.glBufferData(GL_ARRAY_BUFFER,self._point_capacity,None,GL_DYNAMIC_DRAW)
            if data.nbytes:
                g.glBufferSubData(GL_ARRAY_BUFFER,0,data.nbytes,V(data.ctypes.data))
                self.editor_stats.overlay_upload_bytes+=data.nbytes
            self._points_count=len(data);self._points_key=key
        if self._points_count:
            self._overlay_uniforms(mvp,(.3,1.,.85),True,size=10*ratio)
            g.uniform(self.overlay_program,'uUseRoots',0)
            g.glEnable(GL_PROGRAM_POINT_SIZE);g.glBindVertexArray(self.point_vao)
            g.glDrawArrays(GL_POINTS,0,self._points_count)
        if self.scene.selection_box:
            x,y,x2,y2=self.scene.selection_box
            data=np.array([[x,y,0],[x2,y,0],[x2,y2,0],[x,y2,0]],np.float32)
            g.glBindVertexArray(self.box_vao);g.glBindBuffer(GL_ARRAY_BUFFER,self.box_vbo)
            g.glBufferSubData(GL_ARRAY_BUFFER,0,data.nbytes,V(data.ctypes.data))
            self.editor_stats.overlay_upload_bytes+=data.nbytes
            self._overlay_uniforms(mvp,(.4,.8,1.),screen=True)
            g.uniform(self.overlay_program,'uUseRoots',0)
            g.glDrawArrays(GL_LINE_LOOP,0,4)
        g.glDisable(GL_BLEND)
        super().before_present()

    def render_editor(self,received=None):
        self._check_owner();self.context.activate();start=time.perf_counter()
        self.gl.reset_draw_stats()
        self.editor_stats.atlas_upload_bytes=0;self.geometry.upload_bytes=0
        self.editor_stats.overlay_upload_bytes=0
        self.roots.upload_bytes=0
        self._sync_geometry();mvp,_=self.matrices();self._cull(mvp)
        self.flush_tile_updates();self._drain_texture_uploads()
        self._serial=self.fences.begin()
        super().render();present_return=time.perf_counter();self.fences.end()
        self._hover_dirty=False;self._service_hover()
        stats=self.editor_stats;now=time.perf_counter()
        stats.draw_calls=self.gl.draw_calls;stats.subdraws=self.gl.subdraws
        stats.cpu_ms=(now-start)*1000;self._cpu_times=(self._cpu_times+[stats.cpu_ms])[-240:]
        stats.cpu_p95_ms=float(np.percentile(self._cpu_times,95));stats.cpu_p99_ms=float(np.percentile(self._cpu_times,99))
        stats.gpu_ms=self.info.gpu_ms;stats.gpu_p95_ms=self.info.gpu_p95_ms;stats.gpu_p99_ms=self.info.gpu_p99_ms
        stats.geometry_upload_bytes=self.geometry.upload_bytes
        stats.transform_upload_bytes=self.roots.upload_bytes
        stats.gpu_buffer_reserved_mib=(self.geometry.reserved_bytes+self.roots.reserved_bytes)/1024**2;stats.tile_payload_mib=self.info.tile_memory_mib
        stats.total_cards=len(self.scene.records);stats.visible_cards=len(self._visible)
        stats.vertices=sum(len(r.mesh.positions) for r in self._visible)
        stats.triangles=sum(len(r.mesh.indices)//3 for r in self._visible)
        stats.quads=stats.triangles//2
        stats.physical_width=self.display_width;stats.physical_height=self.display_height
        stats.pending_geometry=self.scene.busy;stats.pending_textures=self.sampling_pending
        if self._diagnostic_frame%30==0 and 'GL_NVX_gpu_memory_info' in self.extensions:
            dedicated=I();available=I()
            self.gl.glGetIntegerv(0x9047,C.byref(dedicated));self.gl.glGetIntegerv(0x9049,C.byref(available))
            if dedicated.value>0 and 0<=available.value<=dedicated.value:
                stats.vram_dedicated_mib=dedicated.value/1024
                stats.vram_available_mib=available.value/1024
                stats.vram_global_used_mib=(dedicated.value-available.value)/1024
        self._diagnostic_frame+=1
        if self._geometry_input:
            stamp,versions=self._geometry_input
            records=[(self.scene.records.get(cid),version,root) for cid,(version,root) in versions.items()]
            if any(r is None or r.version!=version for r,version,root in records):self._geometry_input=None
            elif all(r.gpu_version==version and r.gpu_root==root for r,version,root in records):
                stats.input_to_present_return_ms=(present_return-stamp)*1000;self._geometry_input=None
        elif received is not None:stats.input_to_present_return_ms=(present_return-received)*1000
        stats.input_pending=self._geometry_input is not None
        if self._submitted_times and now-self._submitted_times[-1]>.25:
            self._submitted_times=[];stats.active_fps=0.
        self._submitted_times=(self._submitted_times+[now])[-120:]
        if len(self._submitted_times)>1:stats.active_fps=(len(self._submitted_times)-1)/(now-self._submitted_times[0])
        return self.busy or self._hover_dirty

    def _delete_id_targets(self):
        g=self.gl
        for n in self._id_textures:
            value=U(n);g.glDeleteTextures(1,C.byref(value))
        if self._id_fbo:value=U(self._id_fbo);g.glDeleteFramebuffers(1,C.byref(value))
        self._id_textures=[];self._id_fbo=0

    def _ensure_id(self):
        self._check_owner();self.context.activate();g=self.gl
        key=(self._scene_key(),self._geometry_revision)
        if key==self._id_key:return
        if self._id_size!=(self.display_width,self.display_height):
            self._delete_id_targets();self._id_size=(self.display_width,self.display_height)
            self._id_fbo=g.name('Framebuffers');g.glBindFramebuffer(GL_FRAMEBUFFER,self._id_fbo)
            for internal,fmt,typ,attachment in ((GL_R32UI,GL_RED_INTEGER,GL_UNSIGNED_INT,GL_COLOR_ATTACHMENT0),
                                               (GL_DEPTH_COMPONENT24,GL_DEPTH_COMPONENT,GL_UNSIGNED_INT,GL_DEPTH_ATTACHMENT)):
                tex=g.name('Textures');self._id_textures.append(tex);g.glBindTexture(GL_TEXTURE_2D,tex)
                g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);g.glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST)
                g.glTexImage2D(GL_TEXTURE_2D,0,internal,*self._id_size,0,fmt,typ,None)
                g.glFramebufferTexture2D(GL_FRAMEBUFFER,attachment,GL_TEXTURE_2D,tex,0)
            g.glDrawBuffer(GL_COLOR_ATTACHMENT0)
            if g.glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE:raise RuntimeError('Editor ID framebuffer incomplete')
        mvp,eye=self.matrices();self._cull(mvp);self._serial=self.fences.begin()
        g.glBindFramebuffer(GL_FRAMEBUFFER,self._id_fbo);g.glViewport(0,0,*self._id_size)
        g.glDrawBuffer(GL_COLOR_ATTACHMENT0);g.glClearBufferuiv(GL_COLOR,0,(U*4)(0,0,0,0))
        g.glClearDepth(1.);g.glClear(GL_DEPTH_BUFFER_BIT);g.glDisable(GL_BLEND)
        g.glEnable(GL_DEPTH_TEST);g.glDepthFunc(GL_LESS)
        self._draw_hair(mvp,eye,self.id_program)
        g.glDisable(GL_DEPTH_TEST);self.fences.end();self._id_key=key

    def decode(self,value):
        cid=self.scene.numeric.get(int(value)>>9)
        return (cid,int(value)&511) if cid else (None,None)

    def read_id(self,x,y):
        self._ensure_id();g=self.gl
        x=int(max(0,min(self.display_width-1,x)));y=int(max(0,min(self.display_height-1,y)))
        value=U();g.glBindFramebuffer(GL_FRAMEBUFFER,self._id_fbo);g.glReadBuffer(GL_COLOR_ATTACHMENT0)
        g.glBindBuffer(GL_PIXEL_PACK_BUFFER,0)
        g.glReadPixels(x,self.display_height-1-y,1,1,GL_RED_INTEGER,GL_UNSIGNED_INT,C.byref(value))
        g.glBindFramebuffer(GL_FRAMEBUFFER,0)
        return self.decode(value.value)

    def request_hover(self,x,y):
        self._latest_pointer=(int(x),int(y));self._hover_request=self._latest_pointer

    def _service_hover(self):
        g=self.gl;now=time.perf_counter()
        for slot in self._hover_slots:
            if not slot['fence']:continue
            status=g.glClientWaitSync(slot['fence'],0,0)
            if status in (GL_ALREADY_SIGNALED,GL_CONDITION_SATISFIED):
                g.glBindBuffer(GL_PIXEL_PACK_BUFFER,slot['pbo'])
                ptr=g.glMapBufferRange(GL_PIXEL_PACK_BUFFER,0,4,GL_MAP_READ_BIT)
                if ptr:
                    value=C.cast(ptr,C.POINTER(U)).contents.value;g.glUnmapBuffer(GL_PIXEL_PACK_BUFFER)
                    if slot['key']==(self._scene_key(),self._geometry_revision) and slot['position']==self._latest_pointer:
                        self._hover_result=(slot['position'],self.decode(value))
                        new=self._hover_result[1][0]
                        if self.scene.hover!=new:self._hover_dirty=True
                        self.scene.hover=new
                g.glBindBuffer(GL_PIXEL_PACK_BUFFER,0);g.glDeleteSync(slot['fence']);slot['fence']=None
            elif now-slot['issued']>.25:
                g.glDeleteSync(slot['fence']);slot['fence']=None
        free=next((s for s in self._hover_slots if not s['fence']),None)
        if self._hover_request is not None and free and now-self._last_hover_issue>=.04:
            position=self._hover_request;self._hover_request=None;self._ensure_id()
            x=max(0,min(self.display_width-1,position[0]));y=max(0,min(self.display_height-1,position[1]))
            g.glBindFramebuffer(GL_FRAMEBUFFER,self._id_fbo);g.glReadBuffer(GL_COLOR_ATTACHMENT0)
            g.glBindBuffer(GL_PIXEL_PACK_BUFFER,free['pbo'])
            g.glReadPixels(x,self.display_height-1-y,1,1,GL_RED_INTEGER,GL_UNSIGNED_INT,None)
            free.update(fence=g.glFenceSync(GL_SYNC_GPU_COMMANDS_COMPLETE,0),key=(self._scene_key(),self._geometry_revision),
                        position=position,issued=now)
            g.glBindBuffer(GL_PIXEL_PACK_BUFFER,0);g.glBindFramebuffer(GL_FRAMEBUFFER,0);g.glFlush()
            self._last_hover_issue=now

    def project(self,points):
        mvp,_=self.matrices();p=np.asarray(points).reshape(-1,3)
        clip=np.column_stack((p,np.ones(len(p))))@mvp.T
        w=clip[:,3];ndc=clip[:,:3]/np.maximum(w[:,None],1e-8)
        return np.column_stack(((ndc[:,0]+1)*self.display_width*.5,(1-ndc[:,1])*self.display_height*.5)),w

    def centers_in_radius(self,x,y,radius):
        records=[r for r in self._visible if r.mesh is not None]
        if not records:return set()
        xy,z=self.project([self.world_rows(r)[len(r.mesh.rows)//2] for r in records])
        hits=(np.linalg.norm(xy-[x,y],axis=1)<=radius)&(z>0)
        return {r.card.id for r,yes in zip(records,hits) if yes}

    def select_box(self,box):
        x,y,x2,y2=box;lo=np.minimum([x,y],[x2,y2]);hi=np.maximum([x,y],[x2,y2])
        records=[r for r in self._visible if r.mesh is not None]
        if not records:return set()
        xy,z=self.project([r.mesh.center+self.world_offset(r) for r in records])
        # Conservative projected bounds / through selection, not a full-screen
        # synchronous ID readback. GPU face picking remains exact on clicks.
        f=max(100,min(self.display_width,self.display_height)*1.45)
        radius=np.array([r.mesh.radius for r in records])*f/np.maximum(z,.01)
        hits=(z>0)&np.all(xy+radius[:,None]>=lo,axis=1)&np.all(xy-radius[:,None]<=hi,axis=1)
        return {r.card.id for r,yes in zip(records,hits) if yes}

    def poll_hover(self):
        """Service async hover PBO readback without triggering a full 3D redraw unless hover changed."""
        if self._closed:return False
        self._check_owner();self.context.activate()
        self._hover_dirty=False
        self._service_hover()
        return bool(self._hover_dirty)

    @property
    def busy(self):
        return self.scene.busy or self.sampling_pending or getattr(getattr(self,'_object_renderer',None),'pending',False)

    def close(self):
        self._check_owner();self.context.activate();g=self.gl
        self.scene.close()
        for stage in self._tile_staging.values():self._discard_stage(stage)
        self._tile_staging={}
        for s in self._hover_slots:
            if s['fence']:g.glDeleteSync(s['fence'])
            value=U(s['pbo']);g.glDeleteBuffers(1,C.byref(value))
        self._delete_id_targets();self.fences.close();self.geometry.close();self.roots.close()
        for n in (self.point_vbo,self.box_vbo):v=U(n);g.glDeleteBuffers(1,C.byref(v))
        for n in (self.point_vao,self.box_vao):v=U(n);g.glDeleteVertexArrays(1,C.byref(v))
        super().close()


class GPUCardViewport:
    """Editor-facing facade; mutable edit model is separate from GPU resources."""
    def __init__(self,widget):
        self.widget=widget;self.scene=EditorScene()
        renderer=EditorRenderer.__new__(EditorRenderer)
        try:renderer.__init__(widget,self.scene);self.renderer=renderer
        except Exception:
            self.scene.close()
            worker=getattr(renderer,'_sampling_worker',None)
            if worker:worker.shutdown(wait=False,cancel_futures=True)
            context=getattr(renderer,'context',None)
            if context:
                try:context.close()
                except Exception:pass
            raise

    def _resolve(self,cards):
        owner=getattr(self.renderer,'object_workspace',None)
        if owner is None:return cards
        from .kernel.binding import resolved_card
        objects=owner.evaluated_objects()
        return [resolved_card(card,objects,owner.joint_poses) for card in cards]

    def reconcile(self,cards):self.scene.reconcile(self._resolve(cards))
    def changed(self,cards,received=None):
        cards=list(self._resolve(cards));self.scene.touch(cards)
        if received is not None:
            self.renderer._geometry_input=(received,{c.id:(self.scene.records[c.id].version,tuple(np.asarray(c.root,np.float32).tolist()))
                                                     for c in cards if c.id in self.scene.records})
    def bind_atlas(self,cache):self.renderer.bind_atlas(cache)

    def frame(self,editor,received=None):
        r=self.renderer;m=viewport_metrics(self.widget)
        r.object_workspace=editor.app.object_workspace
        from .rendercore.lit_map import material_for
        r.material=material_for(editor.app)
        if getattr(self,'_attachment_revision',None)!=r.object_workspace.pose_revision:
            self._attachment_revision=r.object_workspace.pose_revision
            self.reconcile(editor.cards)
        r.resize(max(32,m.physical_width),max(32,m.physical_height))
        r.yaw=editor.yaw;r.pitch=editor.pitch;r.distance=editor.distance;r.target[:]=editor.camera_target
        r.show_wire=editor.show_wire.get();r.selection_mode=editor.selection_mode.get()
        settings=getattr(editor.app,'app_settings',None)
        if settings is not None:
            r.up_axis=settings.up_axis
            r.show_hud=settings.show_hud
            r.show_axis_gizmo=settings.show_axis_gizmo
            r.show_grid=settings.show_grid
            desired_aa='Spatial' if settings.fast_drag_viewport else 'MSAA4'
            if r.aa_method!=desired_aa:
                r.set_quality('Interactive',1.,desired_aa)
        r.hud_dpr=m.dpr
        r.hud_lines=editor._hud_lines() if hasattr(editor,'_hud_lines') else ()
        r.editing=bool(getattr(editor,'_drag',None) or (getattr(editor,'navigation',None) and editor.navigation.active is not None))
        r.set_interaction(r.editing)
        self.scene.select(editor.selected,editor.component_selected)
        self.scene.active=getattr(editor,'_active_card',None)
        return r.render_editor(received)

    def world_delta_basis(self):
        r=self.renderer;_,eye=r.matrices();forward=np.asarray(r.target)-eye
        forward/=max(float(np.linalg.norm(forward)),1e-8)
        denom=max(100,min(r.display_width,r.display_height)*1.45)
        dpi_scale=window_dpi(self.widget)/96.
        right=np.array([math.cos(r.yaw),0.,-math.sin(r.yaw)])
        up=np.array([-math.sin(r.yaw)*math.sin(r.pitch),math.cos(r.pitch),-math.cos(r.yaw)*math.sin(r.pitch)])
        return eye,forward,right,up,dpi_scale/denom

    def screen_center(self,cid):
        record=self.scene.records.get(cid)
        if record is None or record.mesh is None:return None
        p,z=self.renderer.project(self.renderer.world_rows(record)[[len(record.mesh.rows)//2]])
        return p[0] if z[0]>0 else None

    def world_delta(self,dx,dy,anchor):
        r=self.renderer;_,eye=r.matrices();forward=np.asarray(r.target)-eye
        forward/=max(float(np.linalg.norm(forward)),1e-8)
        depth=max(.01,float(np.dot(np.asarray(anchor)-eye,forward)))
        scale=depth/max(100,min(r.display_width,r.display_height)*1.45)*window_dpi(self.widget)/96.
        right=np.array([math.cos(r.yaw),0.,-math.sin(r.yaw)])
        up=np.array([-math.sin(r.yaw)*math.sin(r.pitch),math.cos(r.pitch),-math.cos(r.yaw)*math.sin(r.pitch)])
        return (right*dx-up*dy)*scale

    def focus_bounds(self,ids=None):
        wanted=set(ids) if ids is not None else set(self.scene.records)
        lower=[];upper=[]
        for cid in wanted:
            r=self.scene.records.get(cid)
            if r is None or not r.card.visible:continue
            if r.mesh is not None and r.gpu_version==r.version:
                positions=self.renderer.world_positions(r)
                lower.append(positions.min(axis=0));upper.append(positions.max(axis=0))
            else:
                root=np.asarray(r.card.root);radius=max(r.card.width,r.card.length*(1+abs(r.card.bend)+abs(r.card.lift)))
                lower.append(root-radius);upper.append(root+radius)
        if not lower:return [0.,.7,0.],4.8
        lo=np.min(lower,axis=0);hi=np.max(upper,axis=0);center=(lo+hi)*.5
        radius=max(.1,float(np.linalg.norm(hi-lo))*.5)
        r=self.renderer;h=r.display_height;w=r.display_width
        fov=2*math.atan(h/(2*max(100,min(w,h)*1.45)))
        fit=min(fov,2*math.atan(math.tan(fov*.5)*w/max(1,h)))
        return list(map(float,center)),max(.6,radius/math.sin(fit*.5)*1.1)

    def _component(self,cid,x,y,mode,face=None):
        record=self.scene.records.get(cid)
        if record is None or record.mesh is None:return (cid,None)
        mesh=record.mesh;r=self.renderer;tolerance=13*window_dpi(self.widget)/96.
        if mode=='Face' and face is not None:
            triangle=mesh.indices.reshape(-1,3)
            return (cid,tuple(map(int,triangle[face]))) if face<len(triangle) else (cid,None)
        if mode in ('Vertex','Root','Row'):
            points=r.world_positions(record) if mode=='Vertex' else r.world_rows(record)[:1] if mode=='Root' else r.world_rows(record)
            xy,z=r.project(points);distance=np.linalg.norm(xy-[x,y],axis=1);i=int(np.argmin(distance))
            return (cid,i) if z[i]>0 and distance[i]<tolerance else (cid,None)
        if mode=='Edge':
            xy,z=r.project(r.world_positions(record));a=xy[mesh.edges[:,0]];b=xy[mesh.edges[:,1]];delta=b-a
            t=np.clip(np.sum(([x,y]-a)*delta,axis=1)/np.maximum(np.sum(delta*delta,axis=1),1e-8),0,1)
            distance=np.linalg.norm(a+t[:,None]*delta-[x,y],axis=1);i=int(np.argmin(distance))
            if distance[i]<tolerance and np.all(z[mesh.edges[i]]>0):return cid,tuple(map(int,mesh.edges[i]))
        return cid,None

    def pick(self,x,y,mode='Card'):
        r=self.renderer
        if mode in ('Root','Row','Vertex','Edge'):
            # Component handles can lie in transparent texels: examine only
            # selected cards before the alpha-aware card ID pass.
            for cid in sorted(self.scene.selected)[:512]:
                result=self._component(cid,x,y,mode)
                if result[1] is not None:return result
        cached=r._hover_result
        if cached and cached[0]==(int(x),int(y)) and r._id_key==(r._scene_key(),r._geometry_revision):cid,face=cached[1]
        else:cid,face=r.read_id(x,y)
        if cid is None or mode=='Card':return cid,None
        return self._component(cid,x,y,mode,face)

    def hover(self,x,y):
        self.scene.hover_component=None
        active=self.scene.active;mode=self.renderer.selection_mode
        if active in self.scene.selected and mode in ('Vertex','Root','Row','Edge'):
            cid,part=self._component(active,x,y,mode)
            if part is not None:
                self.scene.hover_component=(cid,mode,part);self.scene.hover=cid
                self.renderer._latest_pointer=(int(x),int(y));self.renderer._hover_request=None;return
        self.renderer.request_hover(x,y)
    def brush_hits(self,x,y,radius):return self.renderer.centers_in_radius(x,y,radius)
    def select_box(self,box):return self.renderer.select_box(box)
    def close(self):
        try:self.renderer.close()
        except Exception:
            worker=getattr(self.renderer,'_sampling_worker',None)
            if worker:worker.shutdown(wait=False,cancel_futures=True)
            try:self.renderer.context.close()
            except Exception:pass
        finally:self.scene.close()

    def export_report(self,path):
        r=self.renderer;data=asdict(r.editor_stats)
        data.update(backend=r.info.backend,aa=r.info.aa_status,
            note='Interactive telemetry, not a benchmark; latency ends at Present return, not scanout. Buffer/tile fields estimate payload. NVX VRAM is approximate GPU-global usage, not this process; -1 means unavailable.')
        path=Path(path)
        if path.suffix.lower()=='.csv':
            with path.open('w',newline='',encoding='utf-8-sig') as f:
                writer=csv.DictWriter(f,fieldnames=list(data));writer.writeheader();writer.writerow(data)
        else:path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
