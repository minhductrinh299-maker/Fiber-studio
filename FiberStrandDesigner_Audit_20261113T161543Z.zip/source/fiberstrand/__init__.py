"""Fiber Strand Designer v1.0 — procedural hair and fur atlas studio."""
from .model import Project,Tile,FiberSettings,PRESETS,VERSION
from .raster import render_tile,RenderResult
from .atlas import AtlasCache,AtlasLayout
from .projectio import save_project,load_project
__all__=["Project","Tile","FiberSettings","PRESETS","VERSION","render_tile","RenderResult","AtlasCache","AtlasLayout","save_project","load_project"]

from .cards import HairCard,ribbon_mesh,change_segments,export_obj
