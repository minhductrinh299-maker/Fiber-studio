# RenderCore HQ V1 — bản source tích hợp

Ngày 2026-11-13. Mở bằng `run_windows.bat`, vào Render Studio.
Không cần Blender. Không build/cài EXE mới.

## Cách dùng

- **Material → Physical**: R / TT / TRT / higher orders theo mô hình Chiang/PBRT,
  điều khiển longitudinal/azimuthal roughness, IOR, pigment absorption, cuticle tilt.
  Roughness map điều biến độ nhám dọc; flow định hướng frame sợi trên card.
- **Legacy** giữ cách diễn giải các gain trước đây. Trong Physical, bật Artistic
  để cộng specular / sheen / iridescence; lớp này không còn bảo toàn năng lượng.
- **View → Edit / Lookdev / Capture**. Edit dùng weighted transparency và ít mẫu.
  Lookdev yêu cầu 4 lớp trước, Capture yêu cầu 8; kéo camera chuyển đường nhanh,
  nhả chuột thì hội tụ. Các API tên Interactive/Live/Inspect cũ vẫn được nhận.
- **Lighting → HDRI** nhận Radiance HDR hoặc ảnh LDR. ICC LDR được đổi sang sRGB,
  decode linear trước khi lọc. HDR giữ giá trị lớn hơn 1. Float/high-bit TIFF chưa
  được tự suy color space; dùng HDR để tránh chuyển thành ảnh 8-bit.
- **Capture PNG / EXR**: nhập sample budget ở View, xem tiến trình, hủy bằng
  Cancel Capture hoặc Escape. PNG là straight RGBA sau hậu kỳ/display transform;
  EXR là float32 linear Rec.709 D65, premultiplied RGBA, không exposure/hậu kỳ.
  Checker, grid và overlay không ghi vào capture. EXR dùng kích thước nội bộ,
  PNG dùng kích thước viewport vật lý. File JSON bên cạnh ghi cấu hình thực tế.
- **Stats** báo timing, target estimate, DXGI process budget nếu nhận diện được
  đúng adapter, GL driver memory nếu có và fallback. Giới hạn target 1 GiB;
  giảm số lớp/scale theo budget được báo rõ. Capture dùng targets float32,
  có thể giữ được ít lớp hơn Lookdev tại cùng kích thước.
- **Ordered Layer Overflow**: vùng đỏ có optical tail phía sau K lớp; vùng xanh
  không có tail đáng kể. Chỉ có ý nghĩa khi đang chạy hybrid ordered layers.

Thiết lập vật liệu/ánh sáng lưu ở `Project.metadata.rendercore`, dùng chung cho
Card Editor và Lit Map của Tile/Atlas/Graph. HDRI được pack vào `.fsd` theo SHA256;
không ghi đè map nguồn. View ẩn giải phóng HQ layer/shadow histories của Studio.
CPU prepared HDRI cache dùng chung; GPU texture/history vẫn thuộc từng GL context.

## Những phần source đã nối

1. CPU evaluator double precision và GLSL projected hair response cùng công thức;
   phân bố dọc chuẩn hóa, logistic azimuth, dielectric Fresnel và absorption.
   Tham chiếu/license PBRT nằm tại `vendor/pbrt/LICENSE.txt`.
2. Hair IBL và opaque GGX IBL tích phân trực tiếp, balance MIS giữa HDRI importance
   và BSDF sampling. Không dùng panorama mip/GGX LUT để giả hair convolution.
   Đèn key lấy mẫu spherical cap theo góc 0–360°; intensity là tổng strength nguồn,
   giữ nguyên khi đổi góc. Nguồn góc không phải area emitter có kích thước mét.
3. Deep opacity 8 khoảng có mốc theo quantile độ sâu geometry, frustum fit scene,
   bias theo shadow resolution; hair↔hair, hair↔mesh, mesh↔mesh key visibility.
4. GL3.3 ordered depth peeling 1/2/4/8 lớp + weighted tail, không cần interlock.
5. Mỗi lớp trước có radiance, coverage, motion, depth, card identity, normal oct
   và history riêng. Đổi lớp/disocclusion reject history. Tail dùng frame hiện tại.
   Opaque mesh tích lũy riêng khi camera đứng; di chuyển camera reset history mesh.
6. Preset, source material migration, CPU environment cache, WDDM budget query,
   capture tiến trình/hủy, EXR writer không thêm dependency, UI registry semantic IDs.
7. Shader hair HQ bị driver từ chối sẽ dùng legacy và báo nguyên nhân trong Stats.
   Có thể mở chủ động bằng `run_render_legacy_windows.bat`.

## Giới hạn còn lại — không coi bản thiết kế là kết quả nghiệm thu

- Đây là source tích hợp **chưa chạy app / compile shader / test hình ảnh / benchmark**
  trong lần sửa này, theo yêu cầu để người dùng tự kiểm thử. Chỉ parse cú pháp Python.
  Các số FPS/P95, white-furnace ≤1%, CPU/GPU <2% trong thiết kế chưa có bằng chứng.
- Physical là single-fiber scattering (có higher orders bên trong sợi), **chưa có
  multiple scattering giữa nhiều sợi được hiệu chỉnh bằng reference**. Scatter/Backlight
  legacy không được đổi tên thành GI. HDRI chưa có scene visibility/indirect bounce.
- Deep opacity là histogram phi tuyến 8 khoảng, chưa có colored adaptive deep knots
  theo từng texel/voxel. Shadow softness dùng PCF của key trung tâm, chưa tích phân
  visibility theo từng area-light sample. Fill/rim không có shadow map riêng.
- Tail vẫn xấp xỉ, không tích lũy temporal; exact coplanar depth ties có thể gộp/mất
  lớp trong depth peeling. History chỉ so lớp cùng index, layer swap được reject,
  chưa tìm history xuyên index; chưa tách diffuse/specular/transmittance histories.
- Chưa có tiled capture vượt viewport/VRAM, EXR import, path tracer, ray GI hoặc
  pass graph/scheduler canonical hoàn chỉnh cho mọi loại strand/surface. CPU cache
  chung hiện phục vụ environment; geometry scheduler vẫn dùng hệ thống hiện có.
- Nguồn Radiance dùng working primaries Rec.709 giả định; chưa đọc PRIMARIES/EXPOSURE
  để tự chuyển gamut. PNG/EXR display transform là FSD Filmic, không phải ACES đầy đủ.

Vì các giới hạn trên, **chưa hoàn tất tất cả cổng M0–M6 của bản thiết kế**.
Không dùng các kết quả kiểm thử phiên bản trước làm bằng chứng cho source này.

## Tham chiếu số để người dùng chủ động chạy

`tools/render_hq_reference.py` xuất tích phân CPU theo solid angle và nhiều cylinder
offset; đây là công cụ nguồn chưa chạy, không tự gắn PASS. Tăng quadrature để xem
hội tụ; kiểm tra GPU parity và ảnh chuyển động vẫn cần thiết riêng.

Nguồn mô hình: https://pbr-book.org/4ed/Reflection_Models/Scattering_from_Hair
OpenEXR layout: https://openexr.com/en/latest/OpenEXRFileLayout.html
