# FiberBake X — tối ưu luồng thực thi, 13/11/2026

## Source đã thay đổi

1. Canonical bridge được đóng gói một lần cho cùng immutable source snapshot, chia sẻ giữa các pass production và lane preview. Cache CPU giới hạn 48 MiB; signature/bounds cache riêng 24 MiB theo geometry version và resolution. Đổi map không lặp lại concatenate và tính bounds của toàn bộ sợi.
2. Backend giữ packed strand/attribute/frame data. Khi chỉ yêu cầu channel khác của cùng source, không đóng gói và không quét byte lại các buffer bất biến. Đổi pigment không đóng gói lại geometry; đổi pigment/Material ID không dựng lại segment attributes hay frame khi các dependency đó không đổi.
3. Bộ đánh giá GPU có content-addressed result cache 48 MiB, bao gồm shader source, input bytes, shape/dtype và uniforms. Undo/Redo hoặc đánh giá lại cùng nguồn có thể bỏ qua dispatch/readback. Input buffer upload theo byte-range thay đổi; uniform locations được cache. Cache trả bản sao để consumer không sửa dữ liệu đã lưu. Cold evaluation vẫn có readback phục vụ API canonical hiện hữu.
4. Raster không xóa toàn bộ scratch buffer mỗi pass: compute ghi mọi channel được chọn trên mọi pixel trong dirty blocks, kể cả bin rỗng; chỉ các vùng đã dispatch được copy ra texture. Không giảm sample hoặc số sợi để làm nhanh.
5. GPU generator giữ điểm tạm ở output buffer, tránh tính lại toàn bộ công thức point hai lần để fit bounds. AO gộp hai lượt tìm self-proximity/depth/opacity thành một, giữ quy tắc chọn segment như trước.
6. Fence trả texture từ renderer được poll không chặn owner compute. Các lease trong nhóm Atlas vẫn trả theo thứ tự sau fence đầu nhóm; fence lỗi giữ lease cách ly. Công việc compute khác không phải đợi renderer hoàn tất chỉ để xử lý unpin.
7. Mip packet năm channel dùng một publication fence thay vì chờ từng channel; cache chỉ được commit sau fence thành công. Atlas compose không chờ fence sau từng tile đã resident, mà dựa vào thứ tự command cùng context và chờ page trước readback. Tile cần refill vẫn giữ đồng bộ an toàn trong render.
8. GPU-bin allocation bound dùng khoảng float32 mở rộng một ULP trước khi chia block, thay vì cộng hai block ở mọi trục cho mọi segment. Có kiểm tra giới hạn index. Khi thiếu budget, có thể thu hồi workspace sort/scan đã dùng xong, giữ final spatial index và canonical buffers trước khi evict tile.
9. Texture dùng làm Atlas page bị xóa version alias cũ trước khi ghi. Các kiểm tra exact source version, consumer leases và hủy job vẫn được giữ.

## Phạm vi xác nhận

Chỉ đọc/rà source và chạy script sửa văn bản. Theo yêu cầu người dùng: KHÔNG chạy app, import/compile app, shader compile, test, benchmark hoặc build EXE. Không có số đo tăng tốc mới, không xác nhận 60 FPS/50 ms hoặc hiệu năng tốt nhất trên phần cứng mục tiêu.

Đây là tối ưu triển khai của kiến trúc kết hợp CPU/GPU. CPU còn RNG/topology, điều phối DAG, canonical bridge cho Kernel/picking/cache, và fallback. Cold generator/Graph evaluation chưa trở thành một DAG GPU hoàn toàn không readback. Backend thực tế vẫn là OpenGL. Không mô tả các phần này là đã được loại bỏ.

Bản bàn giao tổng thể: `docs/FIBERBAKE_X_HANDOFF_VI.md`. Source dự phòng trước đợt này ở `work/fiberbake_x_performance/before/`; các script sửa source ở `work/fiberbake_x_performance/`. Không áp dụng kết quả parity/benchmark của checkpoint cũ cho bản hiện tại.
