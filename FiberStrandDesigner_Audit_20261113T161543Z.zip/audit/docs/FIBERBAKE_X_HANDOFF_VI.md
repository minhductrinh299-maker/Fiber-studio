# FiberBake X — bàn giao source cập nhật, 13/11/2026

## Trạng thái bàn giao

Đã bổ sung source để xử lý các giới hạn được liệt kê trong bản bàn giao trước. Theo yêu cầu của người dùng, không chạy app, test, kiểm tra compile Python/shader, benchmark hay build EXE trong đợt bổ sung này. Source mới chưa được xác nhận hoạt động hoặc đạt hiệu năng mục tiêu. Đây không phải chứng nhận hoàn thành mọi tiêu chí của đặc tả.

## Bổ sung tối ưu luồng thực thi

Đã thêm cache canonical/signature/bounds theo source version, tái sử dụng packed buffers, evaluation result cache và input delta uploads; bỏ full scratch clear trên dirty bake; giảm phép tính lặp trong generator/AO; poll consumer fences không chặn compute; gộp fence mip/Atlas; giảm bin allocation bound và thu hồi sort/scan workspace trước khi evict tile. Mip cache được publish sau fence thành công. Chi tiết và giới hạn ở `docs/FIBERBAKE_X_PERFORMANCE_VI.md`. Các thay đổi này cũng chỉ được rà source, chưa chạy/compile/đo hiệu năng.

## Phần đã bổ sung trong source

- Sinh hình học Hair/Fur/Fuzz/Stylized và Feather có đường GPU; CPU giữ RNG, topology, stable ID và metadata. Các toán tử Graph số học, scatter/along/instance có đường GPU; DAG, cache, validation, join và adapter Kernel hiện hữu vẫn được giữ.
- Spatial bins được dựng bằng compute: count/scan, emit, sort/merge, compact và tạo danh sách strand/segment. CPU chỉ tính giới hạn phân bổ bảo thủ; đường bin CPU vẫn dùng được cho reference.
- Depth profile, tangent/frame 3D được đưa vào raster GPU. Chế độ Draft lấy 1 sample, Final lấy 16 sample; bộ tích lũy float hỗ trợ 1/4/9/16 sample trước khi lượng tử hóa.
- AO Final dùng 32 depth moments của hình học nguồn, có khoảng depth động. CPU reference dùng cùng phép xấp xỉ. Các map không được dùng làm nguồn hình học cho map khác.
- Thêm Material ID và Material Mask, nâng tổng số output lên 17. Material ID dùng lọc nearest; mask hỗ trợ RGB tường minh hoặc mask mặc định từ ID. Dự án cũ nhận giá trị mặc định khi nạp.
- Mip riêng từng tile cập nhật theo dirty rectangle, có kiểm tra tính liên tục của channel/alpha version; color premultiplied tuyến tính, vector có coverage weighting và normalize, roughness RMS. Placement xoay góc bất kỳ có đường GPU.
- Production bake giữ descriptor nguồn bất biến và texture resident; AtlasCache staging lưu directory/version. Atlas page được ghép GPU khi cần; export hoặc consumer CPU mới đọc dữ liệu về. Descriptor có thể dựng lại đúng version đã công bố sau eviction.
- Texture pool độc lập với buffer hình học: có thể thu hồi geometry mà vẫn giữ texture đang được renderer sử dụng. Lookup kiểm tra pool membership và version; ghi lại texture làm mất hiệu lực version cũ trước cả khi job có thể bị hủy. Mip không lấy entry của một version khác sau Undo/Redo.
- Queue có giới hạn/latest-wins, device/context owner riêng, fence và lease bảo vệ resource đang dùng; chia nhỏ dispatch và nghỉ theo fence để nhận hủy. Thiếu budget/tính năng có đường reference, chế độ GPU nghiêm ngặt trả lỗi.
- Có boundary RasterBackend/BackendCapabilities cho backend thay thế và GPU timestamp profiling tùy chọn. Backend thực tế là OpenGL compute; không có triển khai native D3D12.

Các đường chính nằm trong `fiberstrand/fiberbake_x/`: `evaluation.py`, `feather.py`, `graph.py`, `graph_topology.py`, `binning.py`, `gpu.py`, `quality.py`, `reference.py`, `atlas.py`, `sampling.py`, `service.py`, `presenter.py`, `backend.py`, `profiling.py`. Engine V2, Construction Graph, Qt bake/export/preview và RenderCore đã được nối ở source. Không khôi phục tên tile trên Atlas; giữ xóa tile tự do, kể cả tile cuối và tile được card tham chiếu.

## Giới hạn và lựa chọn triển khai còn tồn tại

- Để tương thích Kernel, picking và cache hiện hữu, kết quả canonical geometry GPU vẫn có cầu nối readback về CPU. Không phải toàn bộ app hay toàn bộ Construction Graph cư trú GPU; CPU còn RNG/topology/orchestration và đường fallback.
- AO 32 moments là phép xấp xỉ finite-radius từ geometry, không phải ray-traced physical AO. Với depth span D và tổng trọng số proximity liên quan W, chặn sai số giải tích so với proxy liên tục là min(1, 0.45 × W × D / 32). Đây không phải sai số đo, cũng không phải chặn sai số so với một nghiệm AO vật lý.
- Budget final 768 MiB và interactive 192 MiB là budget backend; RenderCore có budget mip riêng tối đa 768 MiB. Không coi tổng này là phép đo VRAM toàn app/driver. Ca lớn có thể fallback thay vì giữ tất cả map resident trên GPU 4 GB.
- Không có chứng nhận 60 FPS, latency 50 ms hoặc RTX 3050 Ti/GTX 1650. Hiệu năng, parity và shader compatibility của source hiện tại cần người dùng tự kiểm thử.
- Shared texture chỉ dùng khi WGL sharing thành công. CPU adapter và pipeline cũ vẫn tồn tại cho tương thích và so sánh.

## Bằng chứng cũ và phạm vi

Checkpoint trước đợt bổ sung đã chạy trên Intel Iris Xe, OpenGL 4.6 / driver 31.0.101.4502: 15 channel có sai số CPU/GPU quan sát tối đa 1/255 trong các ca parity đã ghi. CPU bốn map tại 512² khoảng 464 ms/100 sợi và 2.040 ms/500 sợi. Kết quả đó KHÔNG xác nhận source 17 channel, generator/Graph GPU, GPU bins, Final supersampling, Atlas/mip và Qt integration hiện tại.

Benchmark cũ đang chạy đã bị dừng theo yêu cầu người dùng. Dữ liệu lịch sử ở `work/fiberbake_x/`; harness `tools/validate_fiberbake_x_gpu.py` và `tools/benchmark_fiberbake_x.py` đã cập nhật source nhưng chưa chạy lại. Không gọi thời gian đợi fence là GPU timestamp duration; timestamp mới chỉ bật khi `FSD_FIBERBAKE_PROFILE=1`.

## Đại ca tự mở và kiểm thử

Mở bằng `run_windows.bat` như cũ, mặc định backend `auto`. `run_fiberbake_x_cpu_windows.bat` chọn CPU reference; `FSD_FIBERBAKE_BACKEND=legacy-gpu` chọn compute cũ; `gpu` là lựa chọn nghiêm ngặt cho final bake.

Các bước nên tự kiểm tra: generator/Graph/Feather, slider và đổi channel; Tile/Atlas/3D, xoay placement; Undo/Redo và xóa mọi tile; Save/Load; Draft/Final, Bake/Cancel; export 17 map; nhiều tile/resolution lớn khi thiếu budget. Đây là hướng dẫn bàn giao, không phải danh sách kiểm thử đã chạy.

Bản bàn giao ban đầu được lưu tại `docs/FIBERBAKE_X_HANDOFF_INITIAL_VI.md` để phân biệt giới hạn cũ với source mới.
