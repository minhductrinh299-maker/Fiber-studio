"""Read-only source audit. Never imports the app or executes benchmark code."""
import argparse, ast, csv, hashlib, importlib.metadata, io, json, platform
import re, struct, sys, zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-root', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--selection', type=Path, default=HERE/'source_selection.json')
parser.add_argument('--gpu-inventory', type=Path)
args = parser.parse_args()
root = args.source_root.resolve()
args.out.mkdir(parents=True, exist_ok=True)
stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
archive = args.out / ('FiberStrandDesigner_Audit_' + stamp + '.zip')
selection = json.loads(args.selection.read_text(encoding='utf-8-sig'))
payload = {}
manifest = []
missing = []
for relative in selection:
    path = (root/relative).resolve()
    if not path.is_relative_to(root):
        raise ValueError('Source selection escapes root')
    if not path.is_file():
        missing.append(relative)
        continue
    data = path.read_bytes()
    payload['source/'+relative] = data
    manifest.append(dict(path=relative, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
snapshot = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()

def write_json(name, value):
    payload[name] = json.dumps(value, ensure_ascii=False, indent=2).encode('utf-8')

def write_csv(name, rows, columns):
    stream = io.StringIO(newline='')
    writer = csv.DictWriter(stream, fieldnames=columns, extrasaction='ignore')
    writer.writeheader()
    writer.writerows(rows)
    payload[name] = stream.getvalue().encode('utf-8-sig')

def module_name(relative):
    parts = list(Path(relative).with_suffix('').parts)
    if parts[-1] == '__init__':
        parts.pop()
    return '.'.join(parts)

trees, paths, parse_errors = {}, {}, []
for item in manifest:
    relative = item['path']
    if not relative.endswith('.py'):
        continue
    module = module_name(relative)
    try:
        trees[module] = ast.parse(payload['source/'+relative].decode('utf-8-sig'), filename=relative)
        paths[module] = relative
    except (SyntaxError, UnicodeError) as error:
        parse_errors.append(dict(path=relative, error=str(error)))

def imports(node, module):
    if isinstance(node, ast.Import):
        return [(alias.asname or alias.name.split('.')[0], alias.name if alias.asname else alias.name.split('.')[0], alias.name) for alias in node.names]
    if not isinstance(node, ast.ImportFrom):
        return []
    package = module if paths[module].endswith('__init__.py') else module.rpartition('.')[0]
    parts = package.split('.') if package else []
    if node.level:
        parts = parts[:max(0, len(parts)-node.level+1)]
        base = '.'.join(parts + ([node.module] if node.module else []))
    else:
        base = node.module or ''
    return [(alias.asname or alias.name, '.'.join(filter(None, (base, alias.name))), base) for alias in node.names]

def owning_module(symbol):
    while symbol:
        if symbol in trees:
            return symbol
        symbol = symbol.rpartition('.')[0]
    return None

module_edges, externals, stars = [], Counter(), []
for module, tree in trees.items():
    for node in ast.walk(tree):
        for alias, target, imported in imports(node, module):
            owner = owning_module(target) or owning_module(imported)
            if owner:
                module_edges.append(dict(source=module, target=owner, line=node.lineno, imported=target))
            else:
                externals[imported.split('.')[0]] += 1
            if alias == '*':
                stars.append(dict(module=module, line=node.lineno, imported=imported))

definitions = []
class Define(ast.NodeVisitor):
    def __init__(self, module):
        self.module, self.scope = module, []
    def record(self, node, kind):
        name = '.'.join(self.scope+[node.name])
        definitions.append(dict(id=self.module+'::'+name, symbol=self.module+'.'+name, module=self.module,
                                name=name, kind=kind, path=paths[self.module], line=node.lineno))
        self.scope.append(node.name)
        self.generic_visit(node)
        self.scope.pop()
    def visit_ClassDef(self, node): self.record(node, 'class')
    def visit_FunctionDef(self, node): self.record(node, 'function')
    def visit_AsyncFunctionDef(self, node): self.record(node, 'async_function')
for module, tree in trees.items(): Define(module).visit(tree)
symbols = {item['symbol']: item for item in definitions}
calls = []

def dotted(node):
    if isinstance(node, ast.Name): return node.id
    if isinstance(node, ast.Attribute):
        base = dotted(node.value)
        return base+'.'+node.attr if base else None
    return None

class Calls(ast.NodeVisitor):
    def __init__(self, module):
        self.module, self.scope, self.classes = module, [], []
        self.aliases = [{}]
    def visit_Import(self, node):
        for alias, target, _ in imports(node, self.module): self.aliases[-1][alias] = target
    visit_ImportFrom = visit_Import
    def enter(self, node, cls=False):
        for decorator in node.decorator_list: self.visit(decorator)
        if cls:
            for base in node.bases: self.visit(base)
        else:
            for default in node.args.defaults+node.args.kw_defaults:
                if default: self.visit(default)
        self.scope.append(node.name)
        self.aliases.append({})
        if cls: self.classes.append('.'.join(self.scope))
        for child in node.body: self.visit(child)
        if cls: self.classes.pop()
        self.aliases.pop(); self.scope.pop()
    def visit_ClassDef(self, node): self.enter(node, True)
    def visit_FunctionDef(self, node): self.enter(node)
    def visit_AsyncFunctionDef(self, node): self.enter(node)
    def visit_Call(self, node):
        expr = dotted(node.func)
        target, method = None, 'unresolved_dynamic'
        if expr:
            pieces = expr.split('.')
            aliases = {}
            for layer in self.aliases: aliases.update(layer)
            candidates = []
            if pieces[0] in aliases:
                candidates.append((aliases[pieces[0]]+'.'+'.'.join(pieces[1:])).rstrip('.'))
                method = 'import_alias_candidate'
            elif pieces[0] in ('self', 'cls') and self.classes:
                candidates.append(self.module+'.'+self.classes[-1]+'.'+'.'.join(pieces[1:]))
                method = 'same_class_candidate'
            else:
                for depth in range(len(self.scope), -1, -1):
                    candidates.append('.'.join([self.module]+self.scope[:depth]+[expr]))
                method = 'lexical_candidate'
            target = next((symbols[c]['id'] for c in candidates if c in symbols), None)
        calls.append(dict(caller=self.module+'::'+('.'.join(self.scope) or '<module>'),
                          callee=target or '', expression=expr or ast.unparse(node.func)[:200],
                          path=paths[self.module], line=node.lineno,
                          resolution=method if target else 'unresolved_or_external'))
        self.generic_visit(node)
for module, tree in trees.items(): Calls(module).visit(tree)

def dot_graph(nodes, edges, label):
    lines = ['digraph audit {', 'rankdir=LR;', 'graph [label='+json.dumps(label)+',labelloc=t];', 'node [shape=box];']
    for name in sorted(nodes): lines.append(json.dumps(name)+';')
    for (source, target), count in sorted(Counter(edges).items()):
        lines.append(json.dumps(source)+' -> '+json.dumps(target)+' [label='+json.dumps(str(count))+'];')
    return ('\n'.join(lines+['}'])+'\n').encode()

write_json('audit/source_manifest.json', dict(snapshot_sha256=snapshot, files=manifest, missing=missing))
write_json('audit/graphs/module_graph.json', dict(nodes=[dict(module=m,path=paths[m]) for m in sorted(trees)], edges=module_edges, wildcard_imports=stars, parse_errors=parse_errors))
write_json('audit/graphs/call_graph.json', dict(definitions=definitions, calls=calls, scope='Python AST candidates, not runtime traces; instance types, shadowing, inheritance, decorators, Qt signals and dynamic dispatch may change targets.'))
write_csv('audit/graphs/module_edges.csv', module_edges, ['source','target','line','imported'])
write_csv('audit/graphs/calls.csv', calls, ['caller','callee','expression','path','line','resolution'])
payload['audit/graphs/module_graph.dot'] = dot_graph(trees, [(e['source'],e['target']) for e in module_edges], 'Python internal imports')
resolved = [c for c in calls if c['callee']]
payload['audit/graphs/call_graph.dot'] = dot_graph([d['id'] for d in definitions], [(c['caller'],c['callee']) for c in resolved], 'Static call candidates - not runtime proof')
def subsystem(module):
    parts = module.split('.')
    return '.'.join(parts[:2]) if len(parts)>1 else module
weights = Counter((subsystem(e['source']),subsystem(e['target'])) for e in module_edges if subsystem(e['source'])!=subsystem(e['target']))
groups = sorted({subsystem(m) for m in trees}); ids = {g:'n'+str(i) for i,g in enumerate(groups)}
mermaid = ['flowchart LR']+[f'  {ids[g]}["{g}"]' for g in groups]
mermaid += [f'  {ids[a]} -->|"{n} imports"| {ids[b]}' for (a,b),n in sorted(weights.items())]
payload['audit/graphs/subsystem_graph.mmd'] = ('\n'.join(mermaid)+'\n').encode()
native = []
for item in manifest:
    if Path(item['path']).suffix.lower() in ('.c','.cpp','.h','.hpp','.hlsl','.glsl'):
        text = payload['source/'+item['path']].decode('utf-8-sig',errors='replace')
        for match in re.finditer(r'^\s*#\s*include\s*[<"]([^>"]+)', text, re.M):
            native.append(dict(source=item['path'], include=match.group(1)))
write_json('audit/graphs/native_includes.json', native)

installed = sorted([dict(name=d.metadata.get('Name','unknown'),version=d.version,requires=d.requires or []) for d in importlib.metadata.distributions()],key=lambda d:d['name'].lower())
write_json('audit/dependencies/installed_distributions.json',dict(scope='Interpreter running audit; not a lockfile or clean-install verification', python=platform.python_version(), packages=installed))
payload['audit/dependencies/requirements.txt'] = payload.get('source/requirements.txt',b'')
payload['audit/dependencies/installed_versions.txt'] = ('\n'.join(d['name']+'=='+d['version'] for d in installed)+'\n').encode()
write_json('audit/dependencies/import_inventory.json',dict(external_top_level_imports=sorted(externals.items()),stdlib_names=sorted(sys.stdlib_module_names), note='Import names are not distribution names; conditional/platform imports remain included. Native build needs MSVC x64, Windows SDK and CMake for D3D12 probes; ufbx source is bundled.'))

gpu_inventory = []
if args.gpu_inventory and args.gpu_inventory.is_file():
    gpu_inventory = json.loads(args.gpu_inventory.read_text(encoding='utf-8-sig'))
historical, benchmark_rows, historical_renderers = [], [], set()
for filename in ('baseline_cpu.json','parity.json','benchmark_gpu.json','benchmark_gpu_segment_bins.json'):
    path = root/'work/fiberbake_x'/filename
    if not path.is_file():
        path = HERE.parent/'benchmarks/historical'/filename
    if not path.is_file(): continue
    data = path.read_bytes(); payload['audit/benchmarks/historical/'+filename] = data
    record = dict(file=filename, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), status='historical_checkpoint_not_current_source')
    try:
        document = json.loads(data)
        rows = document.get('rows',[]) if isinstance(document,dict) else []
        record['rows'] = len(rows)
        for row in rows:
            if not isinstance(row,dict): continue
            if row.get('renderer'): historical_renderers.add(row['renderer'])
            benchmark_rows.append(dict(artifact=filename, **{k:v for k,v in row.items() if isinstance(v,(str,int,float,bool)) or v is None}))
    except (ValueError,TypeError) as error: record['parse_error'] = str(error)
    historical.append(record)
write_json('audit/benchmarks/status.json', dict(current_snapshot=snapshot, current_benchmark_run=False, reason='User previously requested source-only handoff and self-testing. No app/shader probe or benchmark launched by this audit.', artifacts=historical))
columns=['artifact','count','size','edit','wall_ms','truth_ms','bins_ms','total_ms','prepare_ms','fence_wait_ms','uploaded_bytes','gpu_bytes','renderer','version','backend']
write_csv('audit/benchmarks/historical_summary.csv', benchmark_rows, columns)
for name in ('benchmark_fiberbake_x.py','validate_fiberbake_x_gpu.py','benchmark_fiber_v2.py'):
    path=root/'tools'/name
    if path.is_file(): payload['tools/'+name]=path.read_bytes()
for name in ('FIBERBAKE_X_HANDOFF_VI.md','FIBERBAKE_X_PERFORMANCE_VI.md'):
    path=root/'docs'/name
    if path.is_file(): payload['audit/docs/'+name]=path.read_bytes()
write_json('audit/gpu/backend_inventory.json', dict(current_runtime_probe=False, installed_display_drivers=gpu_inventory,
    inventory_source='Windows display driver registry; CIM unavailable; does not establish the active renderer',
    historical_gl_renderers=sorted(historical_renderers), actual_runtime_backend='unknown_for_current_snapshot',
    implemented_backend=dict(api='OpenGL compute/WGL', declared_minimum='OpenGL 4.3', implementation='fiberstrand/fiberbake_x/gpu.py',
       owner_service='fiberstrand/fiberbake_x/service.py', budgets_MiB=dict(final=768,interactive=192), channels=17,
       quality=dict(preview_samples=1,final_samples=16,final_ao='32 depth moments; finite-radius approximation'),
       switches=['auto','cpu','gpu','legacy-gpu'], profiling_env='FSD_FIBERBAKE_PROFILE=1',
       canonical_cpu_bridge=True, native_d3d12='Experimental native source exists separately; FiberBake X has no native D3D12 raster backend'),
    policy_source='Static source inspection, not device capability measurement'))

write_json('audit/automation/source_selection.json', selection)
payload['audit/automation/generate_audit.py'] = Path(__file__).read_bytes()
if gpu_inventory: write_json('audit/gpu/installed_display_drivers.json',gpu_inventory)
summary=dict(created_utc=stamp,source_snapshot_sha256=snapshot,source_files=len(manifest),python_modules=len(trees),
    static_definitions=len(definitions),call_sites=len(calls),resolved_candidate_calls=len(resolved),
    unresolved_or_external_calls=len(calls)-len(resolved),module_import_edges=len(module_edges),
    ast_parse_errors=parse_errors,historical_benchmark_files=len(historical),new_benchmarks_run=False,
    app_imported_or_launched=False,source_repo_modified=False)
write_json('audit/summary.json',summary)
readme=f'''# Fiber Strand Designer — audit bundle

Snapshot: `{snapshot}`. Created UTC: {stamp}.

## Nội dung

- `source/`: {len(manifest)} file source Python/C++/shader, runtime UI assets, dependency declaration và license. Không có venv/build/dist/cache/backup/project cá nhân.
- `audit/dependencies/`: requirements và dependency/version của interpreter đang tạo audit, cùng inventory import. Danh sách installed không phải lockfile.
- `audit/graphs/`: module graph JSON/CSV/DOT; subsystem Mermaid; call graph JSON/CSV/DOT; C/C++/shader include inventory.
- `audit/gpu/`: cấu hình backend đọc từ source, driver đã cài và renderer lịch sử. Driver cài đặt KHÔNG chứng minh GPU được app chọn.
- `audit/benchmarks/`: raw benchmark/parity lịch sử, summary CSV và provenance. KHÔNG có benchmark mới cho snapshot hiện tại.
- `tools/`: harness benchmark/parity hiện tại, chưa chạy trong đợt này.
- `audit/automation/`: script tái tạo audit và source selection.
- `audit/source_manifest.json`: SHA-256 từng file source; `audit/package_manifest.json`: SHA-256 các file còn lại.

## Giới hạn phân tích

AST chỉ đọc source, không import/chạy/compile app. Có {len(parse_errors)} lỗi parse được ghi nhận. Call graph có {len(calls)} call sites, {len(resolved)} target ứng viên và {len(calls)-len(resolved)} lời gọi external/chưa xác định. Các cạnh là ứng viên theo cú pháp, không phải runtime trace; không xác định đầy đủ Qt signals/slots, callback, variable shadowing, inheritance, decorators hay dispatch động. Module graph gồm import có điều kiện. Native include graph không phải native call graph. Không suy luận code không dùng chỉ từ graph.

Benchmark lịch sử thuộc checkpoint cũ, có thể là lượt đo bị ngắt; không có hash source gốc để khẳng định tương ứng snapshot. Renderer GL lịch sử: {', '.join(sorted(historical_renderers)) or 'unknown'}. Không dùng số liệu cũ làm chứng nhận parity, latency hay FPS của source mới. Audit này không chạy app, GPU probe hoặc benchmark theo yêu cầu tự kiểm thử trước đó.

## Tái tạo tự động (chỉ đọc source)

Sau giải nén, dùng Python của môi trường app:

    python audit/automation/generate_audit.py --source-root source --out ../audit-output --gpu-inventory audit/gpu/installed_display_drivers.json

Đặt output ngoài source repo. Script không cài dependency, không import app, không chạy benchmark. Nếu không có inventory GPU thì bỏ tham số đó. Nó ghi phiên bản dependency của interpreter thực thi và dùng danh sách source đã chọn; source mới ngoài selection cần bổ sung vào selection.

## Benchmark mới — chỉ khi chủ app tự chọn chạy

Harness không được tự chạy khi tạo audit. Từ thư mục giải nén, sau khi tự chuẩn bị môi trường app:

    python tools/benchmark_fiberbake_x.py --counts 100 500 --out ../audit-output/current_benchmark.json

Harness đi kèm dùng sibling `source/` trong bundle. Lượt đo tạo native WGL context và có thể tốn thời gian. Chế độ profiler GPU bật bằng `FSD_FIBERBAKE_PROFILE=1`. Giữ kết quả mới riêng dữ liệu historical. Harness này đo bốn map; không phải chứng nhận mọi channel, Qt/Atlas/3D hay tất cả thông số Final.

File build/test launcher trong source có thể tham chiếu tests/samples/tooling bị loại khỏi gói source nhẹ; đây là gói audit, không phải binary release hay full dev checkout.
'''
payload['README_AUDIT_VI.md'] = readme.encode('utf-8')
# Make the shipped harness locate the curated source without changing the repo.
for name in list(payload):
    if name.startswith('tools/') and name.endswith('.py'):
        content=payload[name].decode('utf-8-sig')
        content=content.replace("sys.path.insert(0,str(Path(__file__).resolve().parents[1]))", "sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))")
        content=content.replace("sys.path.insert(0, str(Path(__file__).resolve().parents[1]))", "sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'source'))")
        content=content.replace("ROOT = Path(__file__).resolve().parents[1]\n", "ROOT = Path(__file__).resolve().parents[1]/'source'\n")
        payload[name]=content.encode('utf-8')
write_json('audit/package_manifest.json',[dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in sorted(payload.items())])
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(payload.items()): z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    bad=z.testzip()
    if bad: raise RuntimeError('ZIP CRC failed: '+bad)
    for record in json.loads(z.read('audit/package_manifest.json')):
        if hashlib.sha256(z.read(record['path'])).hexdigest()!=record['sha256']:
            raise RuntimeError('Manifest mismatch: '+record['path'])
print(json.dumps(dict(archive=str(archive),zip_bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),**summary),ensure_ascii=False))
