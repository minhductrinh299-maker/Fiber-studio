# Fiber Strand Designer — audit bundle

Snapshot: `8b1d9665a2080ba143c16eb51b989f81ade82ad129f06946a46e56e67a39ef05`. Created UTC: 20261113T161543Z.

## Nội dung

- `source/`: 259 file source Python/C++/shader, runtime UI assets, dependency declaration và license. Không có venv/build/dist/cache/backup/project cá nhân.
- `audit/dependencies/`: requirements và dependency/version của interpreter đang tạo audit, cùng inventory import. Danh sách installed không phải lockfile.
- `audit/graphs/`: module graph JSON/CSV/DOT; subsystem Mermaid; call graph JSON/CSV/DOT; C/C++/shader include inventory.
- `audit/gpu/`: cấu hình backend đọc từ source, driver đã cài và renderer lịch sử. Driver cài đặt KHÔNG chứng minh GPU được app chọn.
- `audit/benchmarks/`: raw benchmark/parity lịch sử, summary CSV và provenance. KHÔNG có benchmark mới cho snapshot hiện tại.
- `tools/`: harness benchmark/parity hiện tại, chưa chạy trong đợt này.
- `audit/automation/`: script tái tạo audit và source selection.
- `audit/source_manifest.json`: SHA-256 từng file source; `audit/package_manifest.json`: SHA-256 các file còn lại.

## Giới hạn phân tích

AST chỉ đọc source, không import/chạy/compile app. Có 0 lỗi parse được ghi nhận. Call graph có 25727 call sites, 3564 target ứng viên và 22163 lời gọi external/chưa xác định. Các cạnh là ứng viên theo cú pháp, không phải runtime trace; không xác định đầy đủ Qt signals/slots, callback, variable shadowing, inheritance, decorators hay dispatch động. Module graph gồm import có điều kiện. Native include graph không phải native call graph. Không suy luận code không dùng chỉ từ graph.

Benchmark lịch sử thuộc checkpoint cũ, có thể là lượt đo bị ngắt; không có hash source gốc để khẳng định tương ứng snapshot. Renderer GL lịch sử: Intel(R) Iris(R) Xe Graphics. Không dùng số liệu cũ làm chứng nhận parity, latency hay FPS của source mới. Audit này không chạy app, GPU probe hoặc benchmark theo yêu cầu tự kiểm thử trước đó.

## Tái tạo tự động (chỉ đọc source)

Sau giải nén, dùng Python của môi trường app:

    python audit/automation/generate_audit.py --source-root source --out ../audit-output --gpu-inventory audit/gpu/installed_display_drivers.json

Đặt output ngoài source repo. Script không cài dependency, không import app, không chạy benchmark. Nếu không có inventory GPU thì bỏ tham số đó. Nó ghi phiên bản dependency của interpreter thực thi và dùng danh sách source đã chọn; source mới ngoài selection cần bổ sung vào selection.

## Benchmark mới — chỉ khi chủ app tự chọn chạy

Harness không được tự chạy khi tạo audit. Từ thư mục giải nén, sau khi tự chuẩn bị môi trường app:

    python tools/benchmark_fiberbake_x.py --counts 100 500 --out ../audit-output/current_benchmark.json

Harness đi kèm dùng sibling `source/` trong bundle. Lượt đo tạo native WGL context và có thể tốn thời gian. Chế độ profiler GPU bật bằng `FSD_FIBERBAKE_PROFILE=1`. Giữ kết quả mới riêng dữ liệu historical. Harness này đo bốn map; không phải chứng nhận mọi channel, Qt/Atlas/3D hay tất cả thông số Final.

File build/test launcher trong source có thể tham chiếu tests/samples/tooling bị loại khỏi gói source nhẹ; đây là gói audit, không phải binary release hay full dev checkout.
